#!/usr/bin/env python3
"""Point d'entrée ASGI : `python main.py` ou `uvicorn main:app`."""

from __future__ import annotations

import os

from wm.main import app  # noqa: F401  (ré-exporté pour uvicorn/gunicorn)

HOST = os.environ.get("WM_HOST", "0.0.0.0")
PORT = int(os.environ.get("WM_PORT", "5001"))
RELOAD = os.environ.get("WM_RELOAD", "").lower() in {"1", "true", "yes"}


def main() -> None:
    import uvicorn

    if RELOAD:
        uvicorn.run("main:app", host=HOST, port=PORT, reload=True)
    else:
        uvicorn.run(app, host=HOST, port=PORT)


if __name__ == "__main__":
    main()
