"""Modèles Pydantic v2 (corps de requête / réponses stables)."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# ------------------------------------------------------------------ auth
class LoginRequest(BaseModel):
    username: str = ""
    password: str = ""


class UserOut(BaseModel):
    username: str
    role: str


class LoginResponse(BaseModel):
    username: str
    role: str


# ------------------------------------------------------------------ générique
class ClientUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    risk_profile: Optional[str] = None
    country: Optional[str] = None
    birth_year: Optional[Any] = None
    advisor: Optional[str] = None
    notes: Optional[str] = None


class AccountUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    client_id: Optional[str] = None
    account_name: Optional[str] = None
    account_type: Optional[str] = None
    currency: Optional[str] = None
    cash: Optional[Any] = None
    opening_date: Optional[str] = None
    advisor: Optional[str] = None
    notes: Optional[str] = None


class HoldingUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    account_id: Optional[str] = None
    ticker: Optional[str] = None
    name: Optional[str] = None
    isin: Optional[str] = None
    asset_class: Optional[str] = None
    sector: Optional[str] = None
    currency: Optional[str] = None
    quantity: Optional[Any] = None
    unit_cost: Optional[Any] = None
    unit_price: Optional[Any] = None
    buy_date: Optional[str] = None
    last_price_date: Optional[str] = None
    perf_ytd: Optional[Any] = None
    perf_1y: Optional[Any] = None
    perf_3y: Optional[Any] = None
    perf_5y: Optional[Any] = None


# ------------------------------------------------------------------ clients
class ClientCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: Optional[str] = None
    name: str = ""
    email: str = ""
    phone: str = ""
    risk_profile: str = "equilibre"
    country: str = ""
    birth_year: Optional[Any] = ""
    advisor: str = ""
    notes: str = ""


# ------------------------------------------------------------------ accounts
class AccountCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: Optional[str] = None
    client_id: str = ""
    account_name: str = ""
    account_type: str = "ct"
    currency: str = "EUR"
    cash: Optional[Any] = 0
    opening_date: str = ""
    advisor: str = ""
    notes: str = ""


# ------------------------------------------------------------------ holdings
class HoldingCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: Optional[str] = None
    account_id: str = ""
    ticker: str = ""
    name: str = ""
    isin: str = ""
    asset_class: str = "Action"
    sector: str = ""
    currency: str = "EUR"
    quantity: Optional[Any] = 0
    unit_cost: Optional[Any] = 0
    unit_price: Optional[Any] = 0
    buy_date: str = ""
    last_price_date: str = ""
    perf_ytd: Optional[Any] = 0
    perf_1y: Optional[Any] = 0
    perf_3y: Optional[Any] = 0
    perf_5y: Optional[Any] = 0


# ------------------------------------------------------------------ data source
class DatasourceConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    action: Literal["save", "reset"] = "save"
    clients_path: Optional[str] = None
    accounts_path: Optional[str] = None
    holdings_path: Optional[str] = None
    valuation_path: Optional[str] = None
    reference_path: Optional[str] = None
    # Absent = ne pas toucher au modèle ; vide = rétablir le modèle par défaut.
    model_path: Optional[str] = None


class TableInfo(BaseModel):
    label: str
    configured: str
    resolved: str
    exists: bool
    rows: int
    cols: List[str]


class ModelInfo(BaseModel):
    label: str
    configured: str
    resolved: str
    exists: bool
    size_mb: float


class DatasourceOut(BaseModel):
    config: Dict[str, str]
    tables: Dict[str, TableInfo]
    model: ModelInfo
    base_dir: str


class OkResponse(BaseModel):
    ok: bool = True
    message: Optional[str] = None


class ErrorResponse(BaseModel):
    """Format d'erreur commun de l'API."""

    error: str
    login_required: Optional[bool] = None
