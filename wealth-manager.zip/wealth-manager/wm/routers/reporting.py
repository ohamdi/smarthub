"""Reporting : rapport, exports CSV, factsheets Excel/PDF."""

from __future__ import annotations

import csv
import io
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse, Response

from .. import security, storage
from ..serialization import df_to_json
from ..services.reporting import build_factsheet_report, build_report

router = APIRouter(tags=["reporting"])


@router.get("/report")
async def api_report(
    client_id: str = Query("", description="Restreint le rapport à un client"),
    period: str = Query("all", description="all | 1m | 3m | 6m | 1y | ytd"),
    start: str = Query("", description="Date de début (YYYY-MM-DD)"),
    end: str = Query("", description="Date de fin (YYYY-MM-DD)"),
    user: str = Depends(security.require_user),
) -> Dict[str, Any]:
    return build_report(client_id=client_id, period=period, start=start, end=end)


def _csv_response(kind: str, content: str) -> Response:
    return Response(
        content=content,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename=wealth_{kind}.csv"},
    )


@router.get("/export")
async def api_export(
    kind: str = Query("holdings", description="holdings | clients | accounts | client_detail"),
    client_id: str = Query("", description="Restreint l'export à un client"),
    period: str = Query("all"),
    start: str = Query(""),
    end: str = Query(""),
    user: str = Depends(security.require_user),
) -> Response:
    si = io.StringIO()
    w = csv.writer(si)

    if kind == "holdings":
        rows = storage.enrich_holdings(storage.load_holdings()).to_dict("records")
        acct = {a["id"]: a for a in df_to_json(storage.load_accounts())}
        cli = {c["id"]: c for c in df_to_json(storage.load_clients())}
        w.writerow(["Client", "Compte", "Ticker", "Nom", "ISIN", "Classe", "Secteur", "Qté",
                    "PRU", "Cours", "Valorisation", "Coût", "P&L", "P&L %", "Poids %",
                    "Date achat"])
        for r in sorted(rows, key=lambda x: -x["market_value"]):
            a = acct.get(r["account_id"], {})
            w.writerow([
                cli.get(a.get("client_id"), {}).get("name", ""), a.get("account_name", ""),
                r["ticker"], r["name"], r["isin"], r["asset_class"], r["sector"],
                r["quantity"], r["unit_cost"], r["unit_price"],
                round(r["market_value"], 2), round(r["cost_value"], 2),
                round(r["total_pnl"], 2), round(r["pnl_pct"], 2),
                round(r["weight_pct"], 2), r["buy_date"],
            ])

    elif kind == "clients":
        rep: Dict[str, Any] = build_report(client_id=client_id, period=period,
                                            start=start, end=end)["clients"]
        w.writerow(["Client", "Profil de risque", "Conseiller", "Comptes", "Positions",
                    "Valorisation", "Cash", "AuM", "P&L", "P&L %"])
        for c in rep:
            w.writerow([c["name"], c["risk_label"], c.get("advisor", ""), c["accounts"],
                        c["positions"], c["market_value"], c["cash"], c["aum"],
                        c["pnl"], c["pnl_pct"]])

    elif kind == "accounts":
        rep = build_report(client_id=client_id, period=period,
                           start=start, end=end)["accounts"]
        w.writerow(["Client", "Compte", "Valorisation", "Cash", "Total", "P&L", "P&L %",
                    "Positions"])
        for a in rep.values():
            w.writerow([a["client_name"], a["account_name"], a["mv"], a["cash"],
                        a["total_value"], a["pnl"], a["pnl_pct"], len(a["positions"])])

    elif kind == "client_detail":
        rep = build_factsheet_report(client_id=client_id, period=period,
                                     start=start, end=end)
        matrix = rep.get("period_matrix", {})
        w.writerow(["Client", "Compte", "Type", "Devise", "Valorisation",
                    "Apports/Retraits YTD", "Var. fortune YTD", "Perf. 1M", "Perf. YTD"])
        for a in rep.get("accounts", {}).values():
            m = matrix.get(a.get("account_id"), {})
            w.writerow([a["client_name"], a["account_name"],
                        (a.get("account_type") or "").upper(), a.get("currency", ""),
                        a.get("total_value", 0), a.get("cash_flow_ytd", 0),
                        a.get("ytd_var", 0), m.get("1m"), m.get("ytd")])

    return _csv_response(kind, si.getvalue())


@router.get("/report/excel")
async def api_report_excel(
    client_id: str = Query(""),
    period: str = Query("all"),
    start: str = Query(""),
    end: str = Query(""),
    user: str = Depends(security.require_user),
) -> Response:
    from factsheet import build_excel

    report = build_factsheet_report(client_id=client_id, period=period,
                                    start=start, end=end)
    try:
        data = build_excel(report)
    except Exception:
        import traceback

        traceback.print_exc()
        return JSONResponse(
            status_code=500, content={"error": "Erreur génération Excel"})
    ctx = report.get("context_client") or {}
    fname = (ctx.get("id") or "all_clients") + "_factsheet.xlsx"
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={fname}"},
    )


@router.get("/report/pdf")
async def api_report_pdf(
    client_id: str = Query(""),
    period: str = Query("all"),
    start: str = Query(""),
    end: str = Query(""),
    user: str = Depends(security.require_user),
) -> Response:
    from factsheet import build_pdf

    report = build_factsheet_report(client_id=client_id, period=period,
                                    start=start, end=end)
    try:
        data = build_pdf(report)
    except Exception:
        import traceback

        traceback.print_exc()
        return JSONResponse(
            status_code=500, content={"error": "Erreur génération PDF"})
    ctx = report.get("context_client") or {}
    fname = (ctx.get("id") or "all_clients") + "_factsheet.pdf"
    return Response(
        content=data,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={fname}"},
    )
