"""Historique de valorisation."""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, Query

from .. import security, storage
from ..serialization import df_to_json

router = APIRouter(tags=["valuation"])


@router.get("/valuation", response_model=List[dict])
async def api_valuation(
    account_id: str = Query("", description="Filtre par compte"),
    client_id: str = Query("", description="Filtre par client"),
    user: str = Depends(security.require_user),
) -> List[dict]:
    df = storage.load_valuation()
    if account_id:
        df = df[df["account_id"] == account_id]
    if client_id:
        accounts = storage.load_accounts()
        ids = set(accounts[accounts["client_id"] == client_id]["id"])
        df = df[df["account_id"].isin(ids)]
    if "date" in df.columns:
        df = df.sort_values("date")
    return df_to_json(df)
