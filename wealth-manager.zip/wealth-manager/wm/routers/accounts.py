"""CRUD comptes."""

from __future__ import annotations

import secrets
from datetime import datetime
from typing import Any, Dict, List

import pandas as pd
from fastapi import APIRouter, Depends, Query, status

from .. import config, security, storage
from ..schemas import AccountCreate, AccountUpdate
from ..serialization import df_to_json

router = APIRouter(tags=["accounts"])


@router.get("/accounts", response_model=List[dict])
async def api_accounts(
    client_id: str = Query("", description="Filtre par client"),
    user: str = Depends(security.require_user),
) -> List[dict]:
    df = storage.load_accounts()
    if client_id:
        df = df[df["client_id"] == client_id]
    return df_to_json(df)


@router.post("/accounts", status_code=status.HTTP_201_CREATED)
async def api_create_account(
    payload: AccountCreate, user: str = Depends(security.require_user)
) -> Dict[str, Any]:
    account = {
        "id": payload.id or "acc_" + secrets.token_hex(4),
        "client_id": payload.client_id,
        "account_name": payload.account_name,
        "account_type": payload.account_type,
        "currency": payload.currency,
        "cash": payload.cash,
        "opening_date": payload.opening_date,
        "advisor": payload.advisor,
        "notes": payload.notes,
        "created_at": datetime.now().isoformat(),
    }
    df = storage.load_accounts()
    df = pd.concat([df, pd.DataFrame([account])], ignore_index=True)
    storage.save_table(config.ACCOUNTS_PATH, df)
    storage.regenerate_account_perf()
    return account


@router.put("/accounts/{aid}")
async def api_update_account(
    aid: str, payload: AccountUpdate, user: str = Depends(security.require_user)
) -> Dict[str, bool]:
    data = payload.model_dump(exclude_unset=True, exclude_none=False)
    df = storage.load_accounts()
    cols = [k for k in data if k in df.columns]
    if cols:
        df.loc[df["id"] == aid, cols] = [data[k] for k in cols]
        storage.save_table(config.ACCOUNTS_PATH, df)
        storage.regenerate_account_perf()
    return {"ok": True}


@router.delete("/accounts/{aid}")
async def api_delete_account(
    aid: str, user: str = Depends(security.require_user)
) -> Dict[str, bool]:
    df = storage.load_accounts()
    df = df[df["id"] != aid]
    storage.save_table(config.ACCOUNTS_PATH, df)
    h = storage.load_holdings()
    storage.save_table(config.HOLDINGS_PATH, h[h["account_id"] != aid])
    v = storage.load_valuation()
    storage.save_table(config.VALUATION_PATH, v[v["account_id"] != aid])
    storage.regenerate_account_perf()
    return {"ok": True}
