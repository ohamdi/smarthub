"""CRUD clients."""

from __future__ import annotations

import secrets
from datetime import datetime
from typing import Any, Dict, List

import pandas as pd
from fastapi import APIRouter, Depends, status

from .. import config, security, storage
from ..schemas import ClientCreate, ClientUpdate
from ..serialization import df_to_json

router = APIRouter(tags=["clients"])


@router.get("/clients", response_model=List[dict])
async def api_clients(user: str = Depends(security.require_user)) -> List[dict]:
    return df_to_json(storage.load_clients())


@router.post("/clients", status_code=status.HTTP_201_CREATED)
async def api_create_client(
    payload: ClientCreate, user: str = Depends(security.require_user)
) -> Dict[str, Any]:
    client = {
        "id": payload.id or "cl_" + secrets.token_hex(4),
        "name": payload.name,
        "email": payload.email,
        "phone": payload.phone,
        "risk_profile": payload.risk_profile,
        "country": payload.country,
        "birth_year": payload.birth_year,
        "advisor": payload.advisor,
        "notes": payload.notes,
        "created_at": datetime.now().isoformat(),
    }
    df = storage.load_clients()
    df = pd.concat([df, pd.DataFrame([client])], ignore_index=True)
    storage.save_table(config.CLIENTS_PATH, df)
    return client


@router.put("/clients/{cid}")
async def api_update_client(
    cid: str, payload: ClientUpdate, user: str = Depends(security.require_user)
) -> Dict[str, bool]:
    data = payload.model_dump(exclude_unset=True, exclude_none=False)
    df = storage.load_clients()
    cols = [k for k in data if k in df.columns]
    if cols:
        df.loc[df["id"] == cid, cols] = [data[k] for k in cols]
        storage.save_table(config.CLIENTS_PATH, df)
    return {"ok": True}


@router.delete("/clients/{cid}")
async def api_delete_client(
    cid: str, user: str = Depends(security.require_user)
) -> Dict[str, bool]:
    df = storage.load_clients()
    df = df[df["id"] != cid]
    storage.save_table(config.CLIENTS_PATH, df)
    return {"ok": True}
