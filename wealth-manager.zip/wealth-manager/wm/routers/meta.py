"""Données de référence (`/api/meta`)."""

from __future__ import annotations

from typing import Any, Dict, List

from fastapi import APIRouter, Depends

from .. import security, storage

router = APIRouter(tags=["meta"])


@router.get("/meta")
async def api_meta(user: str = Depends(security.require_user)) -> Dict[str, Any]:
    securities: List[Dict[str, Any]] = [
        {"ticker": s["ticker"], "name": s["name"], "isin": s["isin"],
         "class": s["class"], "sector": s["sector"], "px": s["px"]}
        for s in storage.SECURITIES
    ]
    return {
        "account_types": storage.ACCOUNT_TYPES,
        "securities": securities,
        "risk_labels": storage.RISK_LABELS,
        "asset_classes": storage.ASSET_CLASSES,
    }
