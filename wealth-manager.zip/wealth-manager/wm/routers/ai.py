"""Routes de l'analyse IA : statut, chat, synthèse, configuration, PPTX.

Toutes les routes sont déclarées en `def` (synchrone) : la génération est
bloquante (inférence CPU) et FastAPI l'exécute alors dans son threadpool,
sans jamais figer la boucle d'événements ni le reste de l'application.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, File, Form, Query, UploadFile
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, ConfigDict, Field

from .. import security
from ..ai import assistant, brand, engine
from ..ai.config import load_ai_config, list_models, save_ai_config
from ..ai.context import DEFAULT_DETAIL, DETAIL_LEVELS
from ..ai.pptx_report import build_pptx

log = logging.getLogger("wm.ai")

router = APIRouter(prefix="/ai", tags=["ai"])

PPTX_MEDIA = ("application/vnd.openxmlformats-officedocument"
              ".presentationml.presentation")


# ------------------------------------------------------------------ schémas
class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    message: str = Field(..., min_length=1, max_length=2000,
                         description="Question en langage naturel")
    client_id: str = ""
    detail: str = DEFAULT_DETAIL
    history: List[Dict[str, str]] = Field(default_factory=list)


class EstimateRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    message: str = ""
    client_id: str = ""
    detail: str = DEFAULT_DETAIL


class CommentaryRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    client_id: str = ""
    detail: str = DEFAULT_DETAIL


class PptxRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    client_id: str = ""
    commentary: str = Field("", description="Texte déjà généré, évite un appel LLM")
    detail: str = DEFAULT_DETAIL
    model: str = ""


class WarmupRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    client_id: str = ""
    detail: str = DEFAULT_DETAIL


class BrandRequest(BaseModel):
    """Charte PPTX. Tous les champs sont optionnels : seuls ceux fournis
    sont enregistrés, les autres conservent leur valeur."""
    model_config = ConfigDict(extra="ignore")
    company: Optional[str] = Field(None, max_length=80)
    tagline: Optional[str] = Field(None, max_length=120)
    primary: Optional[str] = Field(None, description="Couleur principale, ex. 0D6E4F")
    accent: Optional[str] = Field(None, description="Couleur d'accentuation")
    ink: Optional[str] = None
    muted: Optional[str] = None
    surface: Optional[str] = None
    negative: Optional[str] = None
    font: Optional[str] = Field(None, max_length=40)
    footer: Optional[str] = Field(None, max_length=200)
    show_footer: Optional[bool] = None
    charts_from_template: Optional[bool] = Field(
        None, description="Colorer les graphiques avec le thème du modèle")


class AiConfigRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    model_path: Optional[str] = None
    n_ctx: Optional[int] = None
    n_threads: Optional[int] = None
    n_batch: Optional[int] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    system_prompt: Optional[str] = None


# ------------------------------------------------------------------ erreurs
def _unavailable(exc: Exception) -> JSONResponse:
    """503 avec un message lisible (modèle absent, contexte impossible…)."""
    return JSONResponse(status_code=503, content={"error": str(exc)})


def _guard(fn, *args, **kwargs):
    """Traduit les exceptions du moteur en réponses HTTP explicites."""
    try:
        return fn(*args, **kwargs)
    except engine.ModelNotAvailable as exc:
        return _unavailable(exc)
    except ValueError as exc:
        return JSONResponse(status_code=422, content={"error": str(exc)})
    except Exception as exc:  # noqa: BLE001
        log.exception("Echec du module IA")
        return _unavailable(f"Erreur du moteur IA : {exc}")


# ------------------------------------------------------------------ routes
@router.get("/status")
def ai_status(user: str = Depends(security.require_user)) -> Dict[str, Any]:
    """État du moteur, modèles détectés et niveaux de détail disponibles."""
    return {
        **engine.status(),
        "models": list_models(),
        "detail_levels": [
            {"id": k, "chars": v["max_chars"], "positions": v["positions"]}
            for k, v in DETAIL_LEVELS.items()
        ],
        "default_detail": DEFAULT_DETAIL,
    }


@router.get("/context")
def ai_context(
    client_id: str = Query(""),
    detail: str = Query(DEFAULT_DETAIL),
    user: str = Depends(security.require_user),
) -> Any:
    """Aperçu du bloc de données réellement envoyé au modèle (transparence)."""
    from ..ai.context import build_context

    try:
        ctx = build_context(client_id=client_id, detail=detail)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse(status_code=422, content={"error": str(exc)})
    return {
        "scope": ctx["scope"],
        "detail": ctx["detail"],
        "chars": len(ctx["text"]),
        "context": ctx["text"],
    }


@router.post("/estimate")
def ai_estimate(payload: EstimateRequest,
                user: str = Depends(security.require_user)) -> Any:
    """Estime la durée d'une question sans lancer le modèle."""
    return _guard(assistant.estimate, payload.message or "Question ?",
                  payload.client_id, payload.detail)


@router.post("/warmup")
def ai_warmup(payload: WarmupRequest,
              user: str = Depends(security.require_user)) -> Any:
    """Charge le modèle et pré-remplit le cache de contexte (1re question rapide)."""
    return _guard(assistant.warmup, payload.client_id, payload.detail)


@router.post("/chat")
def ai_chat(payload: ChatRequest, user: str = Depends(security.require_user)) -> Any:
    """Question en langage naturel sur le périmètre demandé."""
    return _guard(
        assistant.ask,
        payload.message,
        payload.client_id,
        payload.history,
        payload.detail,
    )


@router.post("/commentary")
def ai_commentary(payload: CommentaryRequest,
                  user: str = Depends(security.require_user)) -> Any:
    """Synthèse narrative destinée à la présentation."""
    return _guard(assistant.commentary, payload.client_id, payload.detail)


@router.post("/pptx")
def ai_pptx(payload: PptxRequest, user: str = Depends(security.require_user)) -> Any:
    """Présentation de synthèse (PPTX), avec ou sans commentaire IA."""
    try:
        data, filename = build_pptx(
            client_id=payload.client_id,
            commentary=payload.commentary or None,
            detail=payload.detail,
            model=payload.model or engine.model_path().name,
        )
    except ValueError as exc:
        # périmètre inexistant ou portefeuille vide : erreur de requête (422),
        # pas une panne du serveur.
        return JSONResponse(status_code=422, content={"error": f"PPTX : {exc}"})
    except Exception as exc:  # noqa: BLE001
        log.exception("Echec de la generation PPTX")
        return JSONResponse(status_code=500, content={"error": f"PPTX : {exc}"})

    return Response(
        content=data,
        media_type=PPTX_MEDIA,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/brand")
def ai_get_brand(user: str = Depends(security.require_user)) -> Dict[str, Any]:
    """Charte PPTX effective + palette de graphiques qui sera appliquée."""
    return brand.public_brand()


@router.get("/brand/logo")
def ai_brand_logo(user: str = Depends(security.require_user)) -> Any:
    """Logo déposé, pour l'aperçu dans l'interface."""
    path = brand.logo_path()
    if not path:
        return JSONResponse(status_code=404, content={"error": "Aucun logo."})
    media = {
        ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".bmp": "image/bmp", ".gif": "image/gif",
    }.get(path.suffix.lower(), "application/octet-stream")
    return Response(content=path.read_bytes(), media_type=media,
                    headers={"Cache-Control": "no-cache"})


@router.post("/brand")
def ai_set_brand(payload: BrandRequest,
                 user: str = Depends(security.require_user)) -> Any:
    """Enregistre la charte (société, couleurs, police, pied de page)."""
    try:
        saved = brand.save_brand(payload.model_dump(exclude_none=True))
    except brand.BrandError as exc:
        return JSONResponse(status_code=422, content={"error": str(exc)})
    return {"ok": True, "brand": brand.public_brand(saved)}


@router.post("/brand/logo")
def ai_set_logo(file: UploadFile = File(None, description="Image PNG, JPEG, BMP ou GIF"),
                remove: bool = Form(False),
                user: str = Depends(security.require_user)) -> Any:
    """Dépose (ou retire) le logo utilisé sur la couverture et les diapositives.

    `remove=true` suffit : le champ `file` n'est attendu que pour un dépôt.
    """
    try:
        if remove:
            current = brand.logo_path()
            if current and current.parent == brand.ASSETS_DIR:
                current.unlink(missing_ok=True)
            saved = brand.save_brand({"logo": ""})
        elif file is None:
            return JSONResponse(status_code=422,
                                content={"error": "Aucun fichier reçu pour le logo."})
        else:
            saved = brand.store_logo(file.file.read(), file.filename or "logo.png")
    except brand.BrandError as exc:
        return JSONResponse(status_code=422, content={"error": str(exc)})
    except OSError as exc:
        return JSONResponse(status_code=500, content={"error": f"Logo : {exc}"})
    return {"ok": True, "brand": brand.public_brand(saved)}


@router.post("/brand/template")
def ai_set_template(file: UploadFile = File(None, description="Modèle .pptx ou .potx"),
                    remove: bool = Form(False),
                    user: str = Depends(security.require_user)) -> Any:
    """Dépose (ou retire) le modèle corporate servant de base à la présentation.

    Le modèle apporte ses mises en page et son thème ; ses couleurs
    d'accentuation sont relues pour les graphiques. La taille est normalisée
    en 16:9.
    """
    try:
        if remove:
            current = brand.template_path()
            if current and current.parent == brand.TEMPLATES_DIR:
                current.unlink(missing_ok=True)
            saved = brand.save_brand({"template": ""})
        elif file is None:
            return JSONResponse(status_code=422,
                                content={"error": "Aucun fichier reçu pour le modèle."})
        else:
            saved = brand.store_template(file.file.read(), file.filename or "corporate.pptx")
    except brand.BrandError as exc:
        return JSONResponse(status_code=422, content={"error": str(exc)})
    except OSError as exc:
        return JSONResponse(status_code=500, content={"error": f"Modèle : {exc}"})
    return {"ok": True, "brand": brand.public_brand(saved)}


@router.post("/brand/reset")
def ai_reset_brand(user: str = Depends(security.require_user)) -> Any:
    """Rétablit la charte neutre et efface le logo et le modèle déposés."""
    return {"ok": True, "brand": brand.public_brand(brand.reset_brand())}


@router.get("/config")
def ai_get_config(user: str = Depends(security.require_user)) -> Dict[str, Any]:
    return load_ai_config()


@router.post("/config")
def ai_set_config(payload: AiConfigRequest,
                  user: str = Depends(security.require_user)) -> Dict[str, Any]:
    """Enregistre la configuration ; libère le modèle si le chemin change."""
    before = load_ai_config().get("model_path")
    saved = save_ai_config(payload.model_dump(exclude_none=True))
    reloaded = saved.get("model_path") != before
    if reloaded:
        engine.unload()
    return {"ok": True, "config": saved, "model_unloaded": reloaded}
