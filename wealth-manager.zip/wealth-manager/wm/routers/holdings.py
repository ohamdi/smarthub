"""CRUD positions (holdings)."""

from __future__ import annotations

import secrets
from typing import Any, Dict, List

import pandas as pd
from fastapi import APIRouter, Depends, Query, status

from .. import config, security, storage
from ..schemas import HoldingCreate, HoldingUpdate
from ..serialization import df_to_json

router = APIRouter(tags=["holdings"])


@router.get("/holdings", response_model=List[dict])
async def api_holdings(
    account_id: str = Query("", description="Filtre par compte"),
    client_id: str = Query("", description="Filtre par client"),
    user: str = Depends(security.require_user),
) -> List[dict]:
    df = storage.enrich_holdings(storage.load_holdings())
    if account_id:
        df = df[df["account_id"] == account_id]
    if client_id:
        accounts = storage.load_accounts()
        ids = set(accounts[accounts["client_id"] == client_id]["id"])
        df = df[df["account_id"].isin(ids)]
    df = df.sort_values("market_value", ascending=False)
    return df_to_json(df)


@router.post("/holdings", status_code=status.HTTP_201_CREATED)
async def api_create_holding(
    payload: HoldingCreate, user: str = Depends(security.require_user)
) -> Dict[str, Any]:
    holding = {
        "id": payload.id or "h_" + secrets.token_hex(4),
        "account_id": payload.account_id,
        "ticker": payload.ticker,
        "name": payload.name,
        "isin": payload.isin,
        "asset_class": payload.asset_class,
        "sector": payload.sector,
        "currency": payload.currency,
        "quantity": payload.quantity,
        "unit_cost": payload.unit_cost,
        "unit_price": payload.unit_price,
        "buy_date": payload.buy_date,
        "last_price_date": payload.last_price_date,
        "perf_ytd": payload.perf_ytd,
        "perf_1y": payload.perf_1y,
        "perf_3y": payload.perf_3y,
        "perf_5y": payload.perf_5y,
    }
    df = storage.load_holdings()
    df = pd.concat([df, pd.DataFrame([holding])], ignore_index=True)
    storage.save_table(config.HOLDINGS_PATH, df)
    return holding


@router.put("/holdings/{hid}")
async def api_update_holding(
    hid: str, payload: HoldingUpdate, user: str = Depends(security.require_user)
) -> Dict[str, bool]:
    data = payload.model_dump(exclude_unset=True, exclude_none=False)
    df = storage.load_holdings()
    cols = [k for k in data if k in df.columns]
    if cols:
        df.loc[df["id"] == hid, cols] = [data[k] for k in cols]
        storage.save_table(config.HOLDINGS_PATH, df)
    return {"ok": True}


@router.delete("/holdings/{hid}")
async def api_delete_holding(
    hid: str, user: str = Depends(security.require_user)
) -> Dict[str, bool]:
    df = storage.load_holdings()
    df = df[df["id"] != hid]
    storage.save_table(config.HOLDINGS_PATH, df)
    return {"ok": True}
