"""Routes du tableau de bord."""

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Depends, Query

from .. import security
from ..services.dashboard import build_dashboard

router = APIRouter(tags=["dashboard"])


@router.get("/dashboard")
async def api_dashboard(
    client_id: str = Query("", description="Restreint le dashboard à un client"),
    user: str = Depends(security.require_user),
) -> Dict[str, Any]:
    return build_dashboard(client_id)
