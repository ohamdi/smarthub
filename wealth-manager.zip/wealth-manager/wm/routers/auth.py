"""Authentification : login / logout / me."""

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Depends, Request, status
from fastapi.responses import JSONResponse

from .. import security
from ..schemas import LoginRequest, UserOut

router = APIRouter(tags=["auth"])


@router.post("/login", responses={401: {"description": "Identifiants invalides"}})
async def api_login(payload: LoginRequest, request: Request) -> Any:
    user = security.authenticate(payload.username, payload.password)
    if not user:
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={"error": "Identifiants invalides"},
        )
    username = payload.username.strip().lower()
    security.login(request, username, user["role"], user["client_id"])
    return {"username": username, "role": user["role"]}


@router.post("/logout")
async def api_logout(request: Request) -> Dict[str, bool]:
    security.logout(request)
    return {"ok": True}


@router.get("/me", response_model=UserOut)
async def api_me(request: Request, user: str = Depends(security.require_user)) -> UserOut:
    return UserOut(username=user, role=request.session.get("role", ""))
