"""Configuration du DataSource (redirection des fichiers Parquet et du modèle IA)."""

from __future__ import annotations

import os
from typing import Any, Dict

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from .. import config, security, storage
from ..schemas import DatasourceConfig

router = APIRouter(tags=["datasource"])


def _resolved_tables() -> Dict[str, Dict[str, Any]]:
    cfg = config.load_config()
    resolved: Dict[str, Dict[str, Any]] = {}
    for key, default, label in config.DS_FIELDS:
        path = config.get_parquet_path(key, default)
        resolved[key] = {
            "label": label,
            "configured": cfg.get(key, ""),
            "resolved": str(path),
            **storage.table_info(path),
        }
    return resolved


def _resolved_model() -> Dict[str, Any]:
    """Chemin du modèle GGUF, avec le même état que les tables.

    La valeur reste celle de `ai_config.json` : l'onglet DataSource et l'onglet
    Analyse IA lisent et écrivent le même réglage, il n'y a pas de doublon.
    """
    from ..ai.config import DEFAULT_MODEL, expand, load_ai_config

    configured = str(load_ai_config().get("model_path") or "").strip()
    path = expand(configured or DEFAULT_MODEL)
    exists = path.is_file()
    size_mb = 0.0
    if exists:
        try:
            size_mb = round(path.stat().st_size / (1024 * 1024), 1)
        except OSError:
            exists = False
    return {
        "label": "Modèle IA",
        "configured": configured,
        "resolved": str(path),
        "exists": exists,
        "size_mb": size_mb,
    }


@router.get("/config/datasource")
async def api_datasource_config(
    user: str = Depends(security.require_user),
) -> Dict[str, Any]:
    return {
        "config": config.load_config(),
        "tables": _resolved_tables(),
        "model": _resolved_model(),
        "base_dir": str(config.PROJECT_DIR),
    }


@router.post("/config/datasource")
async def api_save_datasource_config(
    payload: DatasourceConfig, user: str = Depends(security.require_user)
) -> Any:
    if payload.action == "reset":
        try:
            os.remove(config.CONFIG_PATH)
        except OSError:
            pass
        for _, default, _ in config.DS_FIELDS:
            path = config.default_path(default)
            try:
                if path.exists():
                    path.unlink()
            except OSError:
                pass
        from seed import main as seed_main

        seed_main()
        return {"ok": True, "message": "Données de démo régénérées"}

    cfg: Dict[str, str] = {}
    for key, _, _ in config.DS_FIELDS:
        v = str(getattr(payload, key, "") or "").strip()
        if v:
            cfg[key] = v
    config.save_config(cfg)

    # Le modèle n'est pas une table : il est relu à chaque appel, donc il
    # s'applique sans redémarrage. Un champ absent laisse la valeur en place,
    # un champ vide rétablit le modèle par défaut.
    parts = []
    if cfg:
        parts.append("les chemins Parquet sont appliqués au redémarrage du serveur")
    if "model_path" in payload.model_dump(exclude_unset=True):
        from ..ai import engine
        from ..ai.config import DEFAULT_MODEL, load_ai_config, save_ai_config

        target = str(payload.model_path or "").strip() or DEFAULT_MODEL
        if load_ai_config().get("model_path") != target:
            save_ai_config({"model_path": target})
            # le modèle déjà chargé garderait l'ancien fichier en mémoire
            engine.unload()
            parts.append("le nouveau modèle est à charger via « Préparer »")
    if not parts:
        parts.append("aucun changement")

    return JSONResponse(
        content={
            "ok": True,
            "message": "Config enregistrée — " + " ; ".join(parts),
        }
    )
