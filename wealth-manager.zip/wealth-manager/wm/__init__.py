"""Smart Wealth Manager — application FastAPI.

Le paquet expose un point d'entrée ASGI via :func:`wm.main.create_app`.
"""

import sys
from pathlib import Path

# `seed.py` et `factsheet.py` vivent à la racine du projet et sont importés
# tels quels par la couche service.
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

__all__ = ["BASE_DIR"]
