"""Assemblage de l'application FastAPI (factory + middleware + statique)."""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Dict

from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import HTTPException, RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.responses import FileResponse
from starlette.types import Scope

from . import config, storage
from .routers import (
    accounts,
    ai,
    auth,
    clients,
    dashboard,
    datasource,
    holdings,
    meta,
    reporting,
    valuation,
)

SESSION_PARAMS = {
    "session_cookie": config.SESSION_COOKIE,
    "max_age": config.SESSION_MAX_AGE,
    "path": "/",
    "same_site": "lax",
    "https_only": config.SESSION_HTTPS_ONLY,
}


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    storage.ensure_demo_data()
    yield


def _include_api_routes(app: FastAPI) -> None:
    for module in (auth, dashboard, clients, accounts, holdings,
                   valuation, reporting, meta, datasource, ai):
        app.include_router(module.router, prefix=config.API_PREFIX)


def _mount_static(app: FastAPI) -> None:
    static_dir = config.STATIC_DIR
    index = static_dir / "index.html"

    if not static_dir.is_dir():
        @app.get("/", include_in_schema=False)
        async def _missing_static() -> FileResponse:
            return FileResponse(index, status_code=500)  # pragma: no cover
        return

    class SPAStaticFiles(StaticFiles):
        """Sert `static/` et retombe sur `index.html` (équivalent du catch-all Flask)."""

        async def get_response(self, path: str, scope: Scope):
            try:
                response = await super().get_response(path, scope)
            except Exception:
                if path == "index.html" or path.startswith("api"):
                    raise
                return await super().get_response("index.html", scope)
            if getattr(response, "status_code", 200) == 404 and not path.startswith("api"):
                return await super().get_response("index.html", scope)
            return response

    app.mount("/", SPAStaticFiles(directory=str(static_dir), html=True),
              name="static")


def _install_error_handlers(app: FastAPI) -> None:
    """Aligne le format d'erreur sur l'ancien contrat Flask (`{"error": ...}`)."""

    @app.exception_handler(HTTPException)
    async def _http_error(request: Request, exc: HTTPException) -> JSONResponse:
        body: Dict[str, Any] = {"error": str(exc.detail)}
        if exc.status_code == 401:
            body["login_required"] = True
        return JSONResponse(body, status_code=exc.status_code, headers=exc.headers)

    @app.exception_handler(RequestValidationError)
    async def _validation_error(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        # `exc.errors()` peut contenir le corps brut de la requête (octets sur
        # un envoi multipart tronqué, `UploadFile` sur un dépôt) : ces valeurs
        # ne sont pas sérialisables en JSON et faisaient échouer la réponse
        # elle-même, transformant un 422 attendu en 500.
        return JSONResponse(
            {"error": "Requête invalide", "detail": jsonable_encoder(exc.errors())},
            status_code=422,
        )


def create_app() -> FastAPI:
    app = FastAPI(
        title=config.APP_TITLE,
        version=config.APP_VERSION,
        description=(
            "API de gestion de patrimoine : clients, comptes, positions, "
            "valorisation, reporting et factsheets. Données servies depuis des "
            "fichiers Parquet (cf. DATA.md)."
        ),
        lifespan=lifespan,
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        openapi_url="/api/openapi.json",
    )
    app.add_middleware(SessionMiddleware, secret_key=config.secret_key(), **SESSION_PARAMS)
    _install_error_handlers(app)
    _include_api_routes(app)
    _mount_static(app)
    return app


app = create_app()
