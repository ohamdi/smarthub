"""Configuration applicative : chemins, data source, session, utilisateurs."""

from __future__ import annotations

import json
import os
import secrets
from pathlib import Path
from typing import Any, Dict, List, Tuple

from . import BASE_DIR

#: Racine du projet (contient les fichiers Parquet et `static/`).
PROJECT_DIR: Path = BASE_DIR
STATIC_DIR: Path = BASE_DIR / "static"
CONFIG_PATH: Path = BASE_DIR / "datasource_config.json"
SECRET_KEY_PATH: Path = BASE_DIR / ".session_key"

ACCOUNT_PERF_FILE = "account_perf.parquet"

#: Tables redirigeables via `datasource_config.json` : (clé, défaut, libellé).
DS_FIELDS: List[Tuple[str, str, str]] = [
    ("clients_path", "clients.parquet", "Clients"),
    ("accounts_path", "accounts.parquet", "Comptes"),
    ("holdings_path", "holdings.parquet", "Positions"),
    ("valuation_path", "valuation.parquet", "Valorisations"),
    ("reference_path", "reference.parquet", "Référence"),
]

#: Comptes utilisateurs (hors données métier, cf. DATA.md).
USERS: Dict[str, Dict[str, Any]] = {
    "admin": {"password": "admin123", "role": "admin", "client_id": None},
    "gestionnaire": {"password": "wealth123", "role": "user", "client_id": None},
}

SESSION_COOKIE = "session"
SESSION_MAX_AGE = 8 * 60 * 60  # 8 heures, comme `permanent_session_lifetime`
SESSION_HTTPS_ONLY = os.environ.get("WM_HTTPS_ONLY", "").lower() in {"1", "true", "yes"}

API_PREFIX = "/api"
APP_TITLE = "Smart Wealth Manager"
APP_VERSION = "2.0.0"


def default_path(name: str) -> Path:
    """Chemin par défaut d'un fichier de données dans la racine du projet."""
    return PROJECT_DIR / name


def load_config() -> Dict[str, str]:
    """Lit `datasource_config.json` (vide si absent/illisible)."""
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg: Dict[str, str]) -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


def get_parquet_path(key: str, default: str) -> Path:
    """Résout le chemin d'une table : config > défaut projet."""
    p = load_config().get(key)
    if p:
        candidate = Path(p)
        if not candidate.is_absolute():
            candidate = PROJECT_DIR / candidate
        if candidate.exists():
            return candidate
    return default_path(default)


def secret_key() -> str:
    """Clé de signature des cookies de session.

    `WM_SECRET_KEY` si défini, sinon une clé persistée dans `.session_key`
    (les sessions survivent ainsi aux redémarrages du serveur).
    """
    env = os.environ.get("WM_SECRET_KEY")
    if env:
        return env
    try:
        if SECRET_KEY_PATH.exists():
            value = SECRET_KEY_PATH.read_text(encoding="utf-8").strip()
            if value:
                return value
    except OSError:
        pass
    value = secrets.token_hex(32)
    try:
        SECRET_KEY_PATH.write_text(value, encoding="utf-8")
        os.chmod(SECRET_KEY_PATH, 0o600)
    except OSError:
        pass
    return value


# Chemins des tables métier, résolus au démarrage.
CLIENTS_PATH: Path = get_parquet_path("clients_path", "clients.parquet")
ACCOUNTS_PATH: Path = get_parquet_path("accounts_path", "accounts.parquet")
HOLDINGS_PATH: Path = get_parquet_path("holdings_path", "holdings.parquet")
VALUATION_PATH: Path = get_parquet_path("valuation_path", "valuation.parquet")
REFERENCE_PATH: Path = get_parquet_path("reference_path", "reference.parquet")
ACCOUNT_PERF_PATH: Path = default_path(ACCOUNT_PERF_FILE)
