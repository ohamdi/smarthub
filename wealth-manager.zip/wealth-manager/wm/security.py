"""Authentification par cookie de session (équivalent du `session` Flask)."""

from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import HTTPException, Request, status

from .config import USERS


def authenticate(username: str, password: str) -> Optional[Dict[str, Any]]:
    """Vérifie un couple identifiant/mot de passe (utilisateurs de `config.USERS`)."""
    user = USERS.get((username or "").strip().lower())
    if not user or user["password"] != password:
        return None
    return user


def login(request: Request, username: str, role: str, client_id: Optional[str] = None) -> None:
    request.session["user"] = username
    request.session["role"] = role
    request.session["client_id"] = client_id


def logout(request: Request) -> None:
    request.session.clear()


def current_username(request: Request) -> Optional[str]:
    return request.session.get("user")


def require_user(request: Request) -> str:
    """Dépendance FastAPI : exige une session valide, sinon 401."""
    user = current_username(request)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized",
        )
    return user


def require_admin(request: Request) -> str:
    """Dépendance FastAPI : réserve la route au rôle `admin`."""
    user = require_user(request)
    if request.session.get("role") != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")
    return user
