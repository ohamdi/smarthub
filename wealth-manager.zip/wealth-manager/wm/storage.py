"""Accès aux données : lecture/écriture des tables Parquet + données de référence."""

from __future__ import annotations

import math
from typing import Any, Dict, List

import pandas as pd

from . import config

CLIENT_COLUMNS = ["id", "name", "email", "phone", "risk_profile",
                  "country", "birth_year", "advisor", "notes", "created_at"]

ACCOUNT_COLUMNS = ["id", "client_id", "account_name", "account_type",
                   "currency", "cash", "opening_date", "advisor",
                   "notes", "created_at"]

HOLDING_COLUMNS = ["id", "account_id", "ticker", "name", "isin",
                   "asset_class", "sector", "currency", "quantity",
                   "unit_cost", "unit_price", "buy_date",
                   "last_price_date", "perf_ytd", "perf_1y",
                   "perf_3y", "perf_5y", "market_value", "cost_value",
                   "total_pnl", "pnl_pct", "weight_pct"]

VALUATION_COLUMNS = ["id", "account_id", "date", "market_value", "cash", "total_value"]

ACCOUNT_PERF_COLUMNS = ["account_id", "perf_ytd", "perf_1m", "ytd_var", "cash_flow_ytd"]


# ------------------------------------------------------------------ bas niveau
def load_table(path, cols: List[str]) -> pd.DataFrame:
    """Lit un Parquet et garantit la présence de toutes les colonnes attendues."""
    try:
        df = pd.read_parquet(path)
    except Exception:
        return pd.DataFrame(columns=cols)
    for c in cols:
        if c not in df.columns:
            df[c] = None
    return df[cols]


def save_table(path, df: pd.DataFrame) -> None:
    """Écrit un DataFrame en Parquet en normalisant les colonnes textuelles."""
    df = df.copy()
    for col in df.columns:
        dtype = str(df[col].dtype)
        if df[col].dtype == object or dtype == "string" or dtype.startswith("String"):
            has_nan = df[col].isna().any()
            raw = df[col].where(df[col].notna(), None)
            if not has_nan:
                num = pd.to_numeric(raw.replace("", None), errors="coerce")
                non_null = raw.replace("", None).notna()
                if non_null.any() and num[non_null].notna().all():
                    df[col] = num
                    continue
            df[col] = raw
    df.to_parquet(path, index=False)


# ------------------------------------------------------------------ référence
def _reference_fallback() -> Dict[str, Any]:
    from seed import ACCOUNT_TYPES, ASSET_CLASSES, RISK_LABELS, SECURITIES

    return {
        "account_types": ACCOUNT_TYPES,
        "risk_labels": RISK_LABELS,
        "asset_classes": ASSET_CLASSES,
        "securities": SECURITIES,
    }


def load_reference() -> Dict[str, Any]:
    """Charge `reference.parquet` (domain/key/value) avec repli sur `seed.py`."""
    try:
        df = pd.read_parquet(config.REFERENCE_PATH)
    except Exception:
        return _reference_fallback()
    if df.empty or "domain" not in df.columns or "key" not in df.columns:
        return _reference_fallback()

    def kv(domain: str) -> Dict[str, Any]:
        return {r["key"]: r["value"] for r in df[df["domain"] == domain].to_dict("records")}

    account_types = kv("account_type")
    risk_labels = kv("risk_label")
    asset_classes = df[df["domain"] == "asset_class"]["key"].astype(str).tolist()
    securities = []
    for r in df[df["domain"] == "security"].to_dict("records"):
        px = r.get("px")
        if px is None or (isinstance(px, float) and math.isnan(px)):
            px = 0.0
        securities.append({
            "ticker": r["key"],
            "name": r["value"],
            "isin": r.get("isin") or "",
            "class": r.get("class") or "",
            "sector": r.get("sector") or "",
            "px": float(px),
        })
    if not (account_types and risk_labels and asset_classes and securities):
        return _reference_fallback()
    return {
        "account_types": account_types,
        "risk_labels": risk_labels,
        "asset_classes": asset_classes,
        "securities": securities,
    }


REFERENCE: Dict[str, Any] = load_reference()
RISK_LABELS: Dict[str, str] = REFERENCE["risk_labels"]
ACCOUNT_TYPES: Dict[str, str] = REFERENCE["account_types"]
ASSET_CLASSES: List[str] = REFERENCE["asset_classes"]
SECURITIES: List[Dict[str, Any]] = REFERENCE["securities"]


# ------------------------------------------------------------------ tables métier
def load_clients() -> pd.DataFrame:
    return load_table(config.CLIENTS_PATH, CLIENT_COLUMNS)


def load_accounts() -> pd.DataFrame:
    return load_table(config.ACCOUNTS_PATH, ACCOUNT_COLUMNS)


def load_holdings() -> pd.DataFrame:
    return load_table(config.HOLDINGS_PATH, HOLDING_COLUMNS)


def load_valuation() -> pd.DataFrame:
    return load_table(config.VALUATION_PATH, VALUATION_COLUMNS)


def load_account_perf() -> pd.DataFrame:
    return load_table(config.ACCOUNT_PERF_PATH, ACCOUNT_PERF_COLUMNS)


def enrich_holdings(df: pd.DataFrame) -> pd.DataFrame:
    """Force les colonnes monétaires en `float` (0.0 au lieu de NaN)."""
    df = df.copy()
    for col in ["quantity", "unit_cost", "unit_price", "market_value", "cost_value",
                "total_pnl", "pnl_pct", "weight_pct"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def regenerate_account_perf() -> None:
    """Recalcule `account_perf.parquet` depuis `valuation.parquet`."""
    from seed import build_account_perf

    valuation = load_valuation()
    records = valuation.to_dict("records") if not valuation.empty else []
    rows = build_account_perf(records)
    df = pd.DataFrame(rows) if rows else pd.DataFrame(columns=ACCOUNT_PERF_COLUMNS)
    save_table(config.ACCOUNT_PERF_PATH, df)


def ensure_demo_data() -> None:
    """Génère le jeu de démo si `clients.parquet` est absent."""
    if not config.CLIENTS_PATH.exists():
        from seed import main as seed_main

        print("Données de démo absentes -> génération...")
        seed_main()


def table_info(path) -> Dict[str, Any]:
    """Métadonnées d'un fichier Parquet pour l'écran DataSource."""
    info: Dict[str, Any] = {"configured": str(path), "exists": False, "rows": 0, "cols": []}
    try:
        import os

        if os.path.exists(path):
            df = pd.read_parquet(path)
            info["exists"] = True
            info["rows"] = int(len(df))
            info["cols"] = list(df.columns)
    except Exception:
        info["exists"] = False
    return info
