"""Charte graphique du reporting PPTX et modèle corporate importable.

Deux mécanismes se combinent :

1. **Charte intégrée** — un JSON (`pptx_brand.json`) qui décrit la marque :
   société, logo, couleurs, police, pied de page. C'est le défaut.
2. **Modèle corporate** — un fichier `.pptx` / `.potx` déposé par l'utilisateur.
   L'application part alors de ce fichier : on conserve ses mises en page, son
   thème et sa taille, et les couleurs d'accentuation du thème sont relues pour
   colorer les graphiques.

Quand un modèle est importé, la charte intégrée ne fournit plus que ce que le
modèle ne dit pas (logo, pied de page, société).
"""

from __future__ import annotations

import io
import json
import re
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from pptx.dml.color import RGBColor

from .. import config

BRAND_PATH: Path = config.PROJECT_DIR / "pptx_brand.json"
ASSETS_DIR: Path = config.PROJECT_DIR / "assets"
TEMPLATES_DIR: Path = config.PROJECT_DIR / "templates"

#: Formats de logo acceptés par python-pptx (SVG non supporté nativement).
LOGO_EXTENSIONS = (".png", ".jpg", ".jpeg", ".bmp", ".gif")
TEMPLATE_EXTENSIONS = (".pptx", ".potx")

MAX_LOGO_BYTES = 4 * 1024 * 1024
MAX_TEMPLATE_BYTES = 40 * 1024 * 1024

#: Les champs textuels sont **vides** par défaut : une installation non
#: configurée produit exactement la présentation d'origine (deck vert, sans
#: raison sociale, avec les mentions de confidentialité historiques). Les
#: valeurs de repli vivent côté présentation (`wm/ai/pptx.py`, `FOOTER`).
DEFAULT_BRAND: Dict[str, Any] = {
    "company": "",
    "tagline": "",
    "logo": "",            # nom de fichier dans assets/, ou chemin absolu
    "primary": "0D6E4F",   # couverture et en-têtes de tableau
    "accent": "0A7D57",    # filets, surtitres, titres de rubrique
    "ink": "1F2937",       # texte courant
    "muted": "6B7280",     # texte secondaire
    "surface": "F3F7F5",   # fond des cartes et des lignes alternées
    "negative": "C02C2C",  # valeurs négatives
    "font": "Calibri",
    "footer": "",
    "show_footer": True,
    "template": "",        # nom de fichier dans templates/, ou chemin absolu
    #: Un modèle corporate fournit la palette des graphiques *ou* la charte.
    #: L'option évite une présentation à deux teintes si la charte a été
    #: choisie indépendamment du modèle déposé.
    "charts_from_template": True,
}

#: Champs de la charte qui portent une couleur hexadécimale.
COLOR_KEYS = ("primary", "accent", "ink", "muted", "surface", "negative")

_HEX_RE = re.compile(r"^[0-9a-fA-F]{6}$")
_SHORT_HEX_RE = re.compile(r"^[0-9a-fA-F]{3}$")


def _is_short_hex(text: str) -> bool:
    return bool(_SHORT_HEX_RE.match(text))


class BrandError(ValueError):
    """Charte incohérente (couleur invalide, modèle illisible…)."""


# ------------------------------------------------------------------ couleurs
def clean_hex(value: Any, fallback: str) -> str:
    """Normalise `#0d6e4f`, `0D6E4F`, `#0d6e` en `0D6E4F`."""
    text = str(value or "").strip().lstrip("#")
    if _is_short_hex(text):
        text = "".join(c * 2 for c in text)
    return text.upper() if _HEX_RE.match(text) else fallback


def rgb(value: str) -> RGBColor:
    return RGBColor.from_string(clean_hex(value, "000000"))


def contrast_ok(background: str, foreground: str) -> bool:
    """La couleur de premier plan reste-t-elle lisible sur ce fond ?

    Le contrôle vise le seul cas réellement en jeu dans le deck : du texte
    **blanc** sur un aplat de marque. Il rejette donc les teintes trop claires
    (luminance > 0,65) qui rendraient ce texte illisible, sans juger des
    combinaisons que l'application n'utilise pas.
    """
    def lum(value: str) -> float:
        v = clean_hex(value, "000000")
        r, g, b = (int(v[i:i + 2], 16) / 255 for i in (0, 2, 4))
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    return abs(lum(background) - lum(foreground)) >= 0.35


def _mix(color: str, target: str = "FFFFFF", ratio: float = 0.88) -> str:
    """Éclaircit (`ratio` vers `target`) une couleur — pour les aplats de fond."""
    a, b = clean_hex(color, "000000"), clean_hex(target, "FFFFFF")
    out = []
    for i in (0, 2, 4):
        ca, cb = int(a[i:i + 2], 16), int(b[i:i + 2], 16)
        out.append(f"{round(ca + (cb - ca) * ratio):02X}")
    return "".join(out)


# ------------------------------------------------------------------ chargement
def load_brand() -> Dict[str, Any]:
    """Charte effective = défauts + `pptx_brand.json` (tolérant aux erreurs)."""
    brand = dict(DEFAULT_BRAND)
    try:
        with open(BRAND_PATH, encoding="utf-8") as f:
            stored = json.load(f) or {}
        if isinstance(stored, dict):
            brand.update({k: v for k, v in stored.items() if k in DEFAULT_BRAND})
    except Exception:
        pass
    for key in COLOR_KEYS:
        brand[key] = clean_hex(brand.get(key), DEFAULT_BRAND[key])
    brand["font"] = (str(brand.get("font") or "").strip() or DEFAULT_BRAND["font"])[:40]
    brand["company"] = str(brand.get("company") or "").strip()[:80]
    brand["tagline"] = str(brand.get("tagline") or "").strip()[:120]
    brand["footer"] = str(brand.get("footer") or "").strip()[:200]
    brand["show_footer"] = bool(brand.get("show_footer", True))
    brand["charts_from_template"] = bool(brand.get("charts_from_template", True))
    return brand


def save_brand(updates: Dict[str, Any]) -> Dict[str, Any]:
    """Enregistre les champs connus ; les autres sont ignorés."""
    clean: Dict[str, Any] = {}
    for key, value in (updates or {}).items():
        if key not in DEFAULT_BRAND or value is None:
            continue
        if key in COLOR_KEYS:
            text = str(value).strip().lstrip("#")
            # Une couleur saisie est refusée si elle est illisible : la
            # remplacer en silence par la valeur par défaut donnerait un
            # graphique d'une autre couleur que celle demandée.
            if not _HEX_RE.match(text) and not _is_short_hex(text):
                raise BrandError(f"Couleur « {value} » illisible pour « {key} ». "
                                 "Format attendu : 6 chiffres hexadécimaux "
                                 "(ou 3 en format court), par exemple #0D6E4F.")
            clean[key] = clean_hex(text, DEFAULT_BRAND[key])
        elif key in ("show_footer", "charts_from_template"):
            clean[key] = bool(value)
        else:
            clean[key] = str(value).strip()

    if "primary" in clean and not contrast_ok(clean["primary"], "FFFFFF"):
        raise BrandError("La couleur principale est trop claire : le texte blanc "
                         "y serait illisible.")
    if "accent" in clean and not contrast_ok(clean["accent"], "FFFFFF"):
        raise BrandError("La couleur d'accentuation est trop claire : le texte "
                         "blanc y serait illisible.")

    brand = load_brand()
    brand.update(clean)
    try:
        BRAND_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(BRAND_PATH, "w", encoding="utf-8") as f:
            json.dump(brand, f, indent=2, ensure_ascii=False)
    except OSError as exc:
        raise BrandError(f"Charte non enregistrable : {exc}") from exc
    return brand


def reset_brand() -> Dict[str, Any]:
    """Supprime la charte personnalisée et les fichiers déposés.

    Les répertoires `assets/` et `templates/` appartiennent au seul module de
    charte : ils sont vidés. Un chemin de logo absolu placé hors de ces
    répertoires (fichier fourni par l'utilisateur) n'est jamais touché.
    """
    for key, directory in (("logo", ASSETS_DIR), ("template", TEMPLATES_DIR)):
        external = resolve_asset(load_brand().get(key, ""), key)
        if external and external.parent not in (ASSETS_DIR, TEMPLATES_DIR):
            continue
        if directory.is_dir():
            for path in directory.iterdir():
                if path.is_file():
                    try:
                        path.unlink()
                    except OSError:
                        pass
    try:
        BRAND_PATH.unlink()
    except OSError:
        pass
    return load_brand()


# ------------------------------------------------------------------ fichiers
def resolve_asset(value: str, kind: str = "logo") -> Optional[Path]:
    """Résout un chemin de marque : absolu, ou nom de fichier déposé."""
    text = str(value or "").strip()
    if not text:
        return None
    base = ASSETS_DIR if kind == "logo" else TEMPLATES_DIR
    path = Path(text)
    if not path.is_absolute():
        path = base / path
    return path


def logo_path(brand: Optional[Dict[str, Any]] = None) -> Optional[Path]:
    brand = brand or load_brand()
    path = resolve_asset(brand.get("logo", ""), "logo")
    if path and path.exists() and path.suffix.lower() in LOGO_EXTENSIONS:
        return path
    return None


def template_path(brand: Optional[Dict[str, Any]] = None) -> Optional[Path]:
    brand = brand or load_brand()
    path = resolve_asset(brand.get("template", ""), "template")
    if path and path.exists() and path.suffix.lower() in TEMPLATE_EXTENSIONS:
        return path
    return None


def _safe_name(filename: str, fallback: str) -> str:
    """Ne conserve que le nom de fichier, sans traversée de répertoire."""
    name = Path(str(filename or "")).name.strip().replace(" ", "_")
    name = re.sub(r"[^A-Za-z0-9._-]", "", name) or fallback
    return name[:80]


def _replace_file(directory: Path, name: str, data: bytes, previous: str) -> str:
    """Écrit `name` dans `directory` et efface le fichier de marque précédent.

    Un seul logo et un seul modèle sont conservés : un dépôt ne laisse pas
    d'orphelin sur le disque.
    """
    directory.mkdir(parents=True, exist_ok=True)
    (directory / name).write_bytes(data)
    old = resolve_asset(previous, "logo" if directory is ASSETS_DIR else "template")
    if old and old.exists() and old.parent == directory and old.name != name:
        try:
            old.unlink()
        except OSError:
            pass
    return name


def store_logo(data: bytes, filename: str) -> Dict[str, Any]:
    """Enregistre un logo déposé et renvoie la charte mise à jour."""
    if not data:
        raise BrandError("Fichier logo vide.")
    if len(data) > MAX_LOGO_BYTES:
        raise BrandError(f"Logo trop lourd ({len(data) // 1024} Ko, "
                         f"maximum {MAX_LOGO_BYTES // 1024} Ko).")
    suffix = Path(filename or "").suffix.lower()
    if suffix not in LOGO_EXTENSIONS:
        raise BrandError(f"Format de logo non supporté : {suffix or 'inconnu'}. "
                         f"Formats acceptés : {', '.join(LOGO_EXTENSIONS)}.")
    # Un fichier corrompu ne doit pas casser la génération du PPTX plus tard.
    try:
        from PIL import Image

        with Image.open(io.BytesIO(data)) as img:
            img.verify()
    except BrandError:
        raise
    except Exception as exc:
        raise BrandError(f"Image illisible : {exc}") from exc

    previous = load_brand().get("logo", "")
    name = _replace_file(ASSETS_DIR, _safe_name(filename, f"logo{suffix}"), data, previous)
    return save_brand({"logo": name})


def store_template(data: bytes, filename: str) -> Dict[str, Any]:
    """Enregistre un modèle corporate et renvoie la charte mise à jour."""
    if not data:
        raise BrandError("Fichier modèle vide.")
    if len(data) > MAX_TEMPLATE_BYTES:
        raise BrandError(f"Modèle trop lourd ({len(data) // (1024 * 1024)} Mo, "
                         f"maximum {MAX_TEMPLATE_BYTES // (1024 * 1024)} Mo).")
    suffix = Path(filename or "").suffix.lower()
    if suffix not in TEMPLATE_EXTENSIONS:
        raise BrandError(f"Format de modèle non supporté : {suffix or 'inconnu'}. "
                         f"Formats acceptés : {', '.join(TEMPLATE_EXTENSIONS)}.")
    if not zipfile.is_zipfile(io.BytesIO(data)):
        raise BrandError("Ce fichier n'est pas une présentation PowerPoint valide.")
    try:
        from pptx import Presentation

        prs = Presentation(io.BytesIO(data))
        if not prs.slide_layouts:
            raise BrandError("Le modèle ne contient aucune mise en page.")
    except BrandError:
        raise
    except Exception as exc:
        raise BrandError(f"Modèle illisible : {exc}") from exc

    previous = load_brand().get("template", "")
    name = _replace_file(TEMPLATES_DIR, f"corporate{suffix}", data, previous)
    return save_brand({"template": name})


# ------------------------------------------------------------------ thème
def theme_palette(path: Optional[Path]) -> List[str]:
    """Couleurs d'accentuation du thème d'un modèle, sinon palette verte.

    PowerPoint lit `ppt/theme/theme1.xml` ; on extrait `accent1` à `accent6`
    pour que les graphiques restent dans les couleurs de la société.
    """
    if not path:
        return []
    try:
        from xml.etree import ElementTree

        with zipfile.ZipFile(path) as zf:
            xml = zf.read("ppt/theme/theme1.xml")
        ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
        root = ElementTree.fromstring(xml)
        scheme = root.find(".//a:clrScheme", ns)
        if scheme is None:
            return []
        colors = []
        for i in range(1, 7):
            node = scheme.find(f"a:accent{i}", ns)
            if node is None:
                continue
            srgb = node.find("a:srgbClr", ns)
            if srgb is not None and srgb.get("val"):
                colors.append(clean_hex(srgb.get("val"), "0D6E4F"))
            else:
                sys_node = node.find("a:sysClr", ns)
                if sys_node is not None and sys_node.get("lastClr"):
                    colors.append(clean_hex(sys_node.get("lastClr"), "0D6E4F"))
        return colors
    except Exception:
        return []


def default_palette(brand: Dict[str, Any]) -> List[str]:
    """Palette de graphiques dérivée de la charte (sans modèle importé)."""
    primary = brand["primary"]
    return [
        primary, _mix(primary, "FFFFFF", 0.45), _mix(primary, "FFFFFF", 0.68),
        _mix(primary, "FFFFFF", 0.83), "0F4C81", "3B82B6", "7CA9D4",
        "8B5E34", "C88A4B", "E0B266", "6B4E8F", "9B7EC4",
    ]


def public_brand(brand: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Charte augmentée des informations exploitables par l'interface."""
    brand = brand or load_brand()
    logo = logo_path(brand)
    template = template_path(brand)
    theme = theme_palette(template) if brand.get("charts_from_template") else []
    palette = theme or default_palette(brand)
    return {
        **brand,
        "logo_url": f"/api/ai/brand/logo?v={int(logo.stat().st_mtime)}" if logo else "",
        "logo_present": bool(logo),
        "template_present": bool(template),
        "template_name": template.name if template else "",
        "template_size_kb": round(template.stat().st_size / 1024) if template else 0,
        "palette": palette,
        "template_colors": bool(theme),
        "template_palette_available": bool(theme_palette(template)),
        "charts_source": "Modèle corporate" if theme else "Charte intégrée",
        "defaults": DEFAULT_BRAND,
        "logo_extensions": list(LOGO_EXTENSIONS),
        "template_extensions": list(TEMPLATE_EXTENSIONS),
        "max_logo_kb": MAX_LOGO_BYTES // 1024,
        "max_template_mb": MAX_TEMPLATE_BYTES // (1024 * 1024),
    }
