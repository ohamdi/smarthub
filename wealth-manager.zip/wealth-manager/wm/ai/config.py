"""Configuration du module IA (modèle GGUF, paramètres de génération)."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List

from .. import config

AI_CONFIG_PATH: Path = config.PROJECT_DIR / "ai_config.json"

DEFAULT_MODEL = "~/Models/Ministral-3-3B-Instruct-2512-Q4_K_M.gguf"

DEFAULT_SYSTEM_PROMPT = (
    "Tu es un analyste financier expert en gestion de patrimoine privé, "
    "intégré au logiciel Smart Wealth Manager.\n"
    "Règles strictes :\n"
    "1. Réponds UNIQUEMENT à partir des données chiffrées fournies dans le bloc "
    "<DONNEES>. N'invente jamais un montant, un titre, un client ou une date.\n"
    "2. Si l'information demandée n'est pas dans les données, réponds exactement : "
    "\"Cette information n'est pas disponible dans les données chargées.\"\n"
    "3. Écris les montants en euros avec la convention française (espace comme "
    "séparateur de milliers, virgule décimale) et les pourcentages avec un %.\n"
    "4. Sois concret et chiffré : cite les clients, les comptes, les types de "
    "compte (PEA, assurance vie, compte titres, espèces, immobilier), classes "
    "d'actifs et positions concernés par la question.\n"
    "5. Structure : un à trois paragraphes courts, ou des puces si la question "
    "appelle une liste. Maximum 200 mots.\n"
    "6. Quand c'est pertinent, termine par une remarque d'analyse (concentration, "
    "risque, performance) sans jamais donner de conseil en investissement "
    "personnalisé ni de recommandation de placement.\n"
    "7. Rédige en français, registre professionnel."
)

DEFAULTS: Dict[str, Any] = {
    "model_path": DEFAULT_MODEL,
    "n_ctx": 8192,
    # 0 = tous les cœurs détectés. Mesuré sur cette machine : le prefill passe
    # de 34 à 58 tok/s en passant de la détection par défaut à 16 threads.
    "n_threads": 0,
    "n_batch": 2048,
    "temperature": 0.2,
    "max_tokens": 500,
    "top_p": 0.9,
    "repeat_penalty": 1.1,
    "max_holdings": 12,          # (obsolète, conservé pour la config existante)
    "max_context_chars": 12000,  # plafond dur du bloc <DONNEES>
    "system_prompt": DEFAULT_SYSTEM_PROMPT,
}

#: Coût mesuré sur CPU (16 cœurs, AVX2, sans GPU) pour un modèle 3B Q4_K_M,
#: utilisé pour afficher une estimation avant de lancer une génération.
PREFILL_TOKENS_PER_S = 58
DECODE_TOKENS_PER_S = 11

#: Dossiers scannés pour proposer des modèles dans l'interface.
MODEL_DIRS = [
    Path.home() / "Models",
    Path.home() / "Documents",
    Path.home() / "Downloads",
]


def expand(path: str) -> Path:
    """Résout un chemin éventuellement relatif ou commencement par `~`."""
    p = Path(os.path.expandvars(os.path.expanduser(str(path or ""))))
    return p if p.is_absolute() else config.PROJECT_DIR / p


def load_ai_config() -> Dict[str, Any]:
    """Configuration effective = défauts + `ai_config.json`."""
    cfg = dict(DEFAULTS)
    try:
        with open(AI_CONFIG_PATH, encoding="utf-8") as f:
            cfg.update(json.load(f) or {})
    except Exception:
        pass
    return cfg


def save_ai_config(values: Dict[str, Any]) -> Dict[str, Any]:
    """Écrit les valeurs fournies (clés autorisées uniquement) et renvoie la config."""
    current = load_ai_config()
    for key in DEFAULTS:
        if key in values and values[key] is not None:
            current[key] = values[key]
    with open(AI_CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(current, f, indent=2, ensure_ascii=False)
    return current


def ai_config() -> Dict[str, Any]:
    return load_ai_config()


def list_models() -> List[Dict[str, Any]]:
    """Liste les fichiers `.gguf` disponibles sur la machine."""
    seen: Dict[str, Dict[str, Any]] = {}
    dirs = list(MODEL_DIRS)
    current = expand(load_ai_config().get("model_path", ""))
    if current.parent.is_dir():
        dirs.insert(0, current.parent)

    for d in dirs:
        if not d.is_dir():
            continue
        for f in sorted(d.glob("*.gguf")):
            if f in seen or not f.is_file():
                continue
            try:
                size = f.stat().st_size
            except OSError:
                size = 0
            seen[f] = {
                "name": f.name,
                "path": str(f),
                "size_mb": round(size / (1024 * 1024), 1),
                "dir": str(f.parent),
            }
    return sorted(seen.values(), key=lambda m: m["name"].lower())
