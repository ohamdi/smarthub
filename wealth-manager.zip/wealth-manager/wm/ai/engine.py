"""Moteur LLM : chargement paresseux d'un modèle GGUF via `llama-cpp-python`.

Le modèle est chargé à la première requête et conservé en mémoire. Un verrou
unique protège l'instance (`Llama` n'est pas thread-safe) ; les endpoints
concernés sont déclarés en `def` (synchrone) afin que FastAPI les exécute dans
son threadpool et ne bloque jamais la boucle d'événements.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import (
    DECODE_TOKENS_PER_S,
    PREFILL_TOKENS_PER_S,
    expand,
    load_ai_config,
)

log = logging.getLogger("wm.ai")

#: Verrou global : protège le chargement ET la génération.
_LOCK = threading.RLock()

_LLM = None            # instance llama_cpp.Llama
_LOADED_KEY = None     # (chemin, n_ctx) correspondant à l'instance en cours
_LOADED_AT = None      # timestamp de chargement
_LOAD_ERROR: Optional[str] = None


class ModelNotAvailable(RuntimeError):
    """Levé quand aucun modèle ne peut être chargé."""


def _llama_class():
    try:
        from llama_cpp import Llama
    except ImportError as exc:  # pragma: no cover
        raise ModelNotAvailable(
            "llama-cpp-python n'est pas installé (pip install llama-cpp-python)"
        ) from exc
    return Llama


def model_path(cfg: Optional[Dict[str, Any]] = None) -> Path:
    cfg = cfg or load_ai_config()
    return expand(cfg.get("model_path", ""))


def unload() -> None:
    """Libère le modèle de la mémoire."""
    global _LLM, _LOADED_KEY, _LOADED_AT, _LOAD_ERROR
    with _LOCK:
        _LLM = None
        _LOADED_KEY = None
        _LOADED_AT = None
        _LOAD_ERROR = None


def get_llm(cfg: Optional[Dict[str, Any]] = None):
    """Retourne l'instance chargée, en la (re)chargeant si la config a changé."""
    global _LLM, _LOADED_KEY, _LOADED_AT, _LOAD_ERROR
    cfg = cfg or load_ai_config()
    path = model_path(cfg)
    n_ctx = int(cfg.get("n_ctx", 4096))
    key = (str(path), n_ctx)

    with _LOCK:
        if _LLM is not None and _LOADED_KEY == key:
            return _LLM

        if not path.exists():
            _LOAD_ERROR = f"Modèle introuvable : {path}"
            raise ModelNotAvailable(_LOAD_ERROR)

        started = time.time()
        log.info("Chargement du modèle %s (n_ctx=%s)…", path.name, n_ctx)
        kwargs: Dict[str, Any] = {
            "model_path": str(path),
            "n_ctx": n_ctx,
            "verbose": False,
        }
        n_threads = int(cfg.get("n_threads") or 0) or (os.cpu_count() or 4)
        kwargs["n_threads"] = n_threads
        n_batch = int(cfg.get("n_batch") or 0)
        if n_batch > 0:
            kwargs["n_batch"] = n_batch
        log.debug("threads=%s batch=%s", n_threads, n_batch)
        try:
            _LLM = _llama_class()(**kwargs)
        except Exception as exc:
            _LLM = None
            _LOADED_KEY = None
            _LOAD_ERROR = f"Échec du chargement ({exc})"
            raise ModelNotAvailable(_LOAD_ERROR) from exc

        _LOADED_KEY = key
        _LOADED_AT = time.time()
        _LOAD_ERROR = None
        log.info("Modèle chargé en %.1fs", _LOADED_AT - started)
        return _LLM


def warmup() -> bool:
    """Charge le modèle sans échouer (utilisé au démarrage)."""
    try:
        get_llm()
        return True
    except ModelNotAvailable as exc:
        log.info("Modèle non chargé au démarrage : %s", exc)
        return False


def status() -> Dict[str, Any]:
    """État du moteur, exposable tel quel par `/api/ai/status`."""
    global _LOADED_AT, _LOAD_ERROR
    cfg = load_ai_config()
    path = model_path(cfg)
    with _LOCK:
        loaded = _LLM is not None
        loaded_at = _LOADED_AT
        error = _LOAD_ERROR
    return {
        "available": path.exists(),
        "loaded": loaded,
        "model_path": str(path),
        "model_name": path.name,
        "error": error,
        "loaded_at": loaded_at,
        "uptime_s": round(time.time() - loaded_at, 1) if loaded_at else None,
        "config": {
            "model_path": cfg["model_path"],
            "n_ctx": cfg["n_ctx"],
            "n_threads": cfg["n_threads"],
            "n_batch": cfg.get("n_batch"),
            "temperature": cfg["temperature"],
            "max_tokens": cfg["max_tokens"],
            "top_p": cfg["top_p"],
            "repeat_penalty": cfg["repeat_penalty"],
            "max_holdings": cfg["max_holdings"],
        },
    }


# ------------------------------------------------------------------ budget
def count_tokens(llm, text: str) -> int:
    """Nombre de tokens d'un texte, mesuré avec le vrai tokenizer du modèle."""
    if not text:
        return 0
    try:
        return len(llm.tokenize(text.encode("utf-8"), add_bos=False,
                                special=False))
    except Exception:  # noqa: BLE001 - repli grossier si le tokenizer échoue
        return int(len(text) / 3.2)


def estimate(prompt_tokens: int, max_tokens: int, cached: bool = False
             ) -> Dict[str, Any]:
    """Estimation de durée, à partir des vitesses mesurées sur cette machine."""
    prefill = 0.0 if cached else prompt_tokens / PREFILL_TOKENS_PER_S
    decode = max_tokens / DECODE_TOKENS_PER_S
    return {
        "prompt_tokens": prompt_tokens,
        "max_tokens": max_tokens,
        "estimated_s": round(prefill + decode, 1),
        "prefill_s": round(prefill, 1),
        "decode_s": round(decode, 1),
        "cache_hit": cached,
    }


def warm_prefix(prefix: str, cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Pré-calcule le cache KV à partir d'une liste de messages.

    Point important : il faut passer par `create_chat_completion` et non
    `create_completion`, sinon le template de conversation (jetons
    `<|im_start|>`…) produit une séquence de tokens différente et le cache
    n'est jamais réutilisé. Mesuré : 86 s par question sans priming correct,
    ~45 s avec.
    """
    cfg = cfg or load_ai_config()
    llm = get_llm(cfg)
    started = time.time()
    with _LOCK:
        n_ctx = int(cfg.get("n_ctx", 8192))
        n = sum(count_tokens(llm, str(m.get("content", ""))) for m in prefix)
        if n >= n_ctx - 16:
            raise ValueError("Préfixe trop long pour la fenêtre de contexte")
        llm.create_chat_completion(messages=prefix, max_tokens=1, temperature=0.0)
    return {
        "prefix_tokens": n,
        "elapsed_s": round(time.time() - started, 2),
    }


def chat(
    messages: List[Dict[str, str]],
    cfg: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Exécute un chat completion et renvoie texte + métadonnées de timing."""
    cfg = cfg or load_ai_config()
    llm = get_llm(cfg)

    prepared = [
        {"role": m.get("role", "user"), "content": str(m.get("content", ""))}
        for m in messages
        if m.get("content")
    ]
    if not prepared:
        raise ValueError("Aucun message à envoyer")

    started = time.time()
    with _LOCK:
        result = llm.create_chat_completion(
            messages=prepared,
            max_tokens=int(cfg.get("max_tokens", 600)),
            temperature=float(cfg.get("temperature", 0.2)),
            top_p=float(cfg.get("top_p", 0.9)),
            repeat_penalty=float(cfg.get("repeat_penalty", 1.1)),
        )
    elapsed = round(time.time() - started, 2)

    choice = (result.get("choices") or [{}])[0]
    usage = result.get("usage") or {}
    return {
        "text": (choice.get("message", {}) or {}).get("content", "") or "",
        "elapsed_s": elapsed,
        "model": model_path(cfg).name,
        "usage": {
            "prompt_tokens": usage.get("prompt_tokens"),
            "completion_tokens": usage.get("completion_tokens"),
            "total_tokens": usage.get("total_tokens"),
        },
        "finish_reason": choice.get("finish_reason"),
    }
