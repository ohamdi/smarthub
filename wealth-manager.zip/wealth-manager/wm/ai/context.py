"""Construction du contexte métier transmis au modèle.

Le modèle ne reçoit QUE des faits calculés à partir des fichiers Parquet :
c'est le garde-fou principal contre les hallucinations. Le texte produit est
compact et assemblé **par priorité** (les sections les plus importantes sont
construites en premier et les suivantes ne sont ajoutées que si le budget de
caractères le permet), afin de tenir dans la fenêtre de contexte sans jamais
tronquer une section en plein milieu.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from ..serialization import safe_num
from ..services.reporting import build_factsheet_report

_PERIOD_LABELS = [("1m", "1 mois"), ("3m", "3 mois"), ("6m", "6 mois"),
                  ("ytd", "YTD"), ("1y", "1 an")]

#: Niveaux de détail : (budget de caractères, nb de comptes, nb de positions, nb de clients).
DETAIL_LEVELS: Dict[str, Dict[str, int]] = {
    "rapide":   {"max_chars": 2900, "accounts": 5,  "positions": 6,  "clients": 5,  "sectors": 5},
    "standard": {"max_chars": 6400, "accounts": 8,  "positions": 10, "clients": 99, "sectors": 8},
    "complet":  {"max_chars": 14000, "accounts": 20, "positions": 25, "clients": 99, "sectors": 12},
}
DEFAULT_DETAIL = "standard"


# ------------------------------------------------------------------ format FR
def num(v: Any, decimals: int = 0) -> str:
    """Nombre à la française : séparateur de milliers = espace, décimale = virgule."""
    try:
        x = float(v)
    except (TypeError, ValueError):
        return "—"
    return f"{x:,.{decimals}f}".replace(",", " ").replace(".", ",")


def eur(v: Any, decimals: int = 2) -> str:
    return f"{num(v, decimals)} €"


def pct(v: Any, decimals: int = 2) -> str:
    if v is None:
        return "n/d"
    try:
        return f"{num(v, decimals)} %"
    except (TypeError, ValueError):
        return "n/d"


def _pct_str(v: Any) -> str:
    return "n/d" if v is None else pct(v)


# ------------------------------------------------------------------ agrégats
def _aggregate(holdings: List[Dict[str, Any]], key: str,
               top: Optional[int] = None) -> List[Dict[str, Any]]:
    buckets: Dict[str, float] = {}
    for h in holdings:
        label = (h.get(key) or "").strip() or "Non classé"
        buckets[label] = buckets.get(label, 0.0) + safe_num(h.get("market_value"))
    rows = sorted(buckets.items(), key=lambda kv: -kv[1])
    if top:
        rows = rows[:top]
    return [{"label": k, "value": v} for k, v in rows]


def _account_type_label(key: str) -> str:
    """`av` -> `Assurance vie` (libellés de la table de référence)."""
    from ..storage import ACCOUNT_TYPES

    return ACCOUNT_TYPES.get(key) or key.upper()


def _by_account_type(accounts: Dict[str, Any], holdings: List[Dict[str, Any]],
                     matrix: Dict[str, Any], aum: float) -> List[Dict[str, Any]]:
    """Ventilation par type de compte : volumes, titres, liquidités, P&L, perf."""
    buckets: Dict[str, Dict[str, Any]] = {}
    for aid, a in accounts.items():
        key = (a.get("account_type") or "").strip() or "inconnu"
        b = buckets.setdefault(key, {
            "key": key, "label": _account_type_label(key), "accounts": 0, "positions": 0,
            "market_value": 0.0, "cash": 0.0, "total_value": 0.0,
            "pnl": 0.0, "cost": 0.0, "classes": {},
        })
        b["accounts"] += 1
        b["cash"] += safe_num(a.get("cash"))
        b["total_value"] += safe_num(a.get("total_value"))
        b["pnl"] += safe_num(a.get("pnl"))

    for h in holdings:
        acc = accounts.get(h.get("account_id")) or {}
        b = buckets.get((acc.get("account_type") or "").strip() or "inconnu")
        if b is None:
            continue
        b["positions"] += 1
        b["market_value"] += safe_num(h.get("market_value"))
        b["cost"] += safe_num(h.get("cost_value"))
        cls = (h.get("asset_class") or "").strip() or "Non classé"
        b["classes"][cls] = b["classes"].get(cls, 0.0) + safe_num(h.get("market_value"))

    rows: List[Dict[str, Any]] = []
    for b in buckets.values():
        perf = (matrix or {}).get(b["key"]) or {}
        total = b["total_value"]
        rows.append({
            "key": b["key"],
            "label": b["label"],
            "accounts": b["accounts"],
            "positions": b["positions"],
            "market_value": round(b["market_value"], 2),
            "cash": round(b["cash"], 2),
            "total_value": round(total, 2),
            "weight": round(total / aum * 100, 2) if aum else 0.0,
            "cash_weight": round(b["cash"] / total * 100, 2) if total else 0.0,
            "pnl": round(b["pnl"], 2),
            "pnl_pct": round(b["pnl"] / b["cost"] * 100, 2) if b["cost"] else None,
            "classes": b["classes"],
            "perf": perf,
            "ytd": perf.get("ytd"),
            "1y": perf.get("1y"),
        })
    return sorted(rows, key=lambda r: -r["total_value"])


def _top_by_account_type(holdings: List[Dict[str, Any]], accounts: Dict[str, Any],
                         types: List[Dict[str, Any]], per_type: int = 2,
                         max_types: int = 5) -> List[Dict[str, Any]]:
    """Principaux titres de chaque type de compte (les X plus gros de chaque)."""
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for h in holdings:
        acc = accounts.get(h.get("account_id")) or {}
        groups.setdefault((acc.get("account_type") or "").strip() or "inconnu", []).append(h)

    rows: List[Dict[str, Any]] = []
    for t in types[:max_types]:
        for h in sorted(groups.get(t["key"], []),
                        key=lambda x: -safe_num(x.get("market_value")))[:per_type]:
            rows.append({
                "account_type": t["label"],
                "ticker": h.get("ticker", ""),
                "name": h.get("name", ""),
                "account_name": h.get("account_name", ""),
                "client_name": h.get("client_name", ""),
                "asset_class": h.get("asset_class", ""),
                "market_value": round(safe_num(h.get("market_value")), 2),
                "weight": round(safe_num(h.get("market_value")) / t["market_value"] * 100, 2)
                          if t["market_value"] else 0.0,
                "pnl_pct": h.get("pnl_pct"),
            })
    return rows


def _performance(matrix: Dict[str, Any], key: str) -> str:
    row = (matrix or {}).get(key) or {}
    return " | ".join(f"{label} {pct(row.get(k))}" for k, label in _PERIOD_LABELS)


# ------------------------------------------------------------------ contexte
def build_context(client_id: str = "", detail: str = DEFAULT_DETAIL) -> Dict[str, Any]:
    """Assemble les faits et le texte de contexte pour un périmètre donné."""
    limits = DETAIL_LEVELS.get(detail) or DETAIL_LEVELS[DEFAULT_DETAIL]
    detail = detail if detail in DETAIL_LEVELS else DEFAULT_DETAIL
    budget = int(limits["max_chars"])

    report = build_factsheet_report(client_id=client_id)
    matrix = report.get("period_matrix") or {}
    group_matrix = report.get("period_matrix_group") or {}
    accounts: Dict[str, Any] = report.get("accounts") or {}
    holdings: List[Dict[str, Any]] = report.get("holdings") or []
    clients: List[Dict[str, Any]] = report.get("clients") or []
    ctx_client = report.get("context_client")
    today = datetime.now().date().isoformat()

    # Un client inconnu ne doit pas produire un contexte vide (le modèle
    # répondrait alors en inventant) : on remonte une erreur explicite.
    if client_id and not ctx_client:
        raise ValueError(f"Client inconnu : {client_id}")
    if not holdings and not accounts:
        raise ValueError("Aucune donnée de portefeuille à analyser")

    # ---- indicateurs globaux ----
    mv_total = sum(safe_num(h.get("market_value")) for h in holdings)
    cash_total = sum(safe_num(a.get("cash")) for a in accounts.values())
    aum = mv_total + cash_total
    pnl = sum(safe_num(h.get("total_pnl")) for h in holdings)
    cost = sum(safe_num(h.get("cost_value")) for h in holdings)
    pnl_pct = (pnl / cost * 100) if cost else None

    by_class = _aggregate(holdings, "asset_class")
    by_sector = _aggregate(holdings, "sector", top=limits["sectors"])
    by_currency = _aggregate(holdings, "currency")
    by_account_type = _by_account_type(
        accounts, holdings, report.get("period_matrix_account_type") or {}, aum)

    # ---- positions ----
    ranked = sorted(holdings, key=lambda h: -safe_num(h.get("market_value")))
    total_positions = len(ranked)
    top_positions = ranked[: max(1, int(limits["positions"]))]
    top_sum = sum(safe_num(h.get("market_value")) for h in top_positions)
    top_weight = (top_sum / mv_total * 100) if mv_total else 0.0
    top_by_account_type = _top_by_account_type(holdings, accounts, by_account_type)

    # ---- concentrations ----
    client_aums = sorted((safe_num(c.get("aum")) for c in clients), reverse=True)
    top3_client_w = (sum(client_aums[:3]) / aum * 100) if aum and client_aums else 0.0
    risk_counts: Dict[str, int] = {}
    for c in clients:
        key = c.get("risk_profile") or "non renseigné"
        risk_counts[key] = risk_counts.get(key, 0) + 1

    # ---- sections, par ordre de priorité d'inclusion ----
    scope_label = ctx_client["name"] if ctx_client else f"tous les clients ({len(clients)})"
    header = [f"PORTEFEUILLE au {today} — PERIMETRE : {scope_label}"]

    kpis = [
        f"- Actifs sous gestion (AuM) : {eur(aum)} dont {eur(cash_total)} de liquidites",
        f"- Valorisation des titres : {eur(mv_total)}",
        f"- Plus/moins-value latent : {eur(pnl)} ({_pct_str(pnl_pct)} du cout d'acquisition)",
        f"- Volumetrie : {len(clients)} clients, {len(accounts)} comptes, "
        f"{total_positions} positions",
    ]
    perf_pf = _performance(matrix, "portfolio")
    if perf_pf:
        kpis.append(f"- Performance du portefeuille : {perf_pf}")
    sections: List[Tuple[int, str]] = [(0, "INDICATEURS\n" + "\n".join(kpis))]

    if by_account_type:
        lines = [
            f"- {t['label']} : {t['accounts']} compte(s), {t['positions']} positions, "
            f"AuM {eur(t['total_value'])} ({pct(t['weight'], 1)} de l'AuM) | "
            f"titres {eur(t['market_value'])} + liquidites {eur(t['cash'])} "
            f"({pct(t['cash_weight'], 0)} du solde en especes) | "
            f"P&L {eur(t['pnl'])} ({_pct_str(t['pnl_pct'])}) | "
            f"{_performance(report.get('period_matrix_account_type') or {}, t['key']) or 'performance n/d'}"
            for t in by_account_type
        ]
        sections.append((1, "PAR TYPE DE COMPTE (PEA, assurance vie, compte titres…)\n"
                            + "\n".join(lines)))

    if by_class:
        lines = [f"- {r['label']} : {eur(r['value'])} "
                 f"({pct(r['value'] / mv_total * 100 if mv_total else 0, 1)})"
                 for r in by_class]
        sections.append((1, "ALLOCATION PAR CLASSE D'ACTIFS (hors liquidites)\n" + "\n".join(lines)))

    if by_sector:
        lines = [f"- {r['label']} : {eur(r['value'])} "
                 f"({pct(r['value'] / mv_total * 100 if mv_total else 0, 1)})"
                 for r in by_sector]
        sections.append((2, "ALLOCATION PAR SECTEUR\n" + "\n".join(lines)))

    if accounts:
        lines = []
        for aid, a in sorted(accounts.items(),
                             key=lambda kv: -safe_num(kv[1].get("total_value")))[: limits["accounts"]]:
            owner = a.get("client_name") or "client non renseigne"
            lines.append(
                f"- {owner} / {a.get('account_name', aid)} [ref {aid}] "
                f"({(a.get('account_type') or '').upper()}, {a.get('currency', '')}) : "
                f"{eur(a.get('total_value'))} | P&L {eur(a.get('pnl'))} "
                f"({_pct_str(a.get('pnl_pct'))}) | {_performance(matrix, aid)}")
        sections.append((3, "COMPTES (les plus representatifs)\n" + "\n".join(lines)))

    if top_positions:
        shown = "toutes les positions" if total_positions <= len(top_positions) \
            else f"{len(top_positions)} premieres sur {total_positions}"
        lines = [
            f"- {h.get('ticker', '')} — {h.get('name', '')} [{h.get('asset_class', '')}"
            f"{' / ' + h['sector'] if h.get('sector') else ''}] : "
            f"{eur(h.get('market_value'))} "
            f"({pct(safe_num(h.get('market_value')) / mv_total * 100 if mv_total else 0, 2)} "
            f"du portefeuille) | P&L {eur(h.get('total_pnl'))} ({_pct_str(h.get('pnl_pct'))})"
            for h in top_positions
        ]
        sections.append((4, f"POSITIONS PRINCIPALES ({shown})\n" + "\n".join(lines)))

    if clients:
        lines = []
        for c in sorted(clients, key=lambda c: -safe_num(c.get("aum")))[: limits["clients"]]:
            gid = c.get("id")
            perf_c = _performance(group_matrix, gid) if group_matrix else _performance(matrix, gid)
            lines.append(
                f"- {c.get('name', '')} ({c.get('risk_profile', '')}) : "
                f"{c.get('accounts', 0)} comptes, {c.get('positions', 0)} positions | "
                f"AuM {eur(c.get('aum'))} | P&L {eur(c.get('pnl'))} "
                f"({_pct_str(c.get('pnl_pct'))}) | {perf_c or 'performance n/d'}")
        sections.append((5, "SYNTHESE PAR CLIENT\n" + "\n".join(lines)))

    conc = [f"- Les {len(top_positions)} premieres positions representent "
            f"{pct(top_weight, 1)} de la valorisation des titres"]
    if client_aums and aum:
        conc.append(f"- Les {min(3, len(client_aums))} premiers clients representent "
                    f"{pct(top3_client_w, 1)} de l'AuM")
    if risk_counts:
        conc.append("- Profils de risque : " + ", ".join(
            f"{k} ({v} client{'s' if v > 1 else ''})"
            for k, v in sorted(risk_counts.items(), key=lambda kv: -kv[1])))
    if by_currency:
        conc.append("- Devises : " + ", ".join(
            f"{r['label']} ({pct(r['value'] / mv_total * 100 if mv_total else 0, 1)})"
            for r in by_currency))
    ranked_pnl = [h for h in holdings if h.get("pnl_pct") is not None]
    if ranked_pnl:
        worst = sorted(ranked_pnl, key=lambda h: safe_num(h.get("pnl_pct")))[:3]
        best = sorted(ranked_pnl, key=lambda h: -safe_num(h.get("pnl_pct")))[:3]
        conc.append("- Plus fortes baisses : " + ", ".join(
            f"{h.get('ticker', '')} ({_pct_str(h.get('pnl_pct'))})" for h in worst))
        conc.append("- Plus fortes hausses : " + ", ".join(
            f"{h.get('ticker', '')} ({'+' if safe_num(h.get('pnl_pct')) >= 0 else ''}"
            f"{_pct_str(h.get('pnl_pct'))})" for h in best))
    sections.append((6, "CONCENTRATION\n" + "\n".join(conc)))

    # ---- assemblage par priorité ----
    text = "\n".join(header)
    included: List[str] = []
    for _, block in sorted(sections, key=lambda s: s[0]):
        candidate = text + "\n\n" + block
        if len(candidate) <= budget or not included:
            text = candidate
            included.append(block.split("\n", 1)[0])
    truncated = len(included) < len(sections)
    if truncated:
        missing = len(sections) - len(included)
        text += f"\n\n[{missing} section(s) de détail omise(s) : niveau de detail « {detail} »]"

    return {
        "text": text,
        "detail": detail,
        "scope": ctx_client["name"] if ctx_client else "Tous les clients",
        "context_client": ctx_client,
        "report": report,
        "facts": {
            "aum": round(aum, 2),
            "market_value": round(mv_total, 2),
            "cash": round(cash_total, 2),
            "pnl": round(pnl, 2),
            "pnl_pct": round(pnl_pct, 2) if pnl_pct is not None else None,
            "clients": len(clients),
            "accounts": len(accounts),
            "positions": total_positions,
            "by_class": by_class,
            "by_sector": by_sector,
            "by_currency": by_currency,
            "by_account_type": by_account_type,
            "top_by_account_type": top_by_account_type,
            "top_positions": top_positions,
            "accounts_detail": accounts,
            "clients_detail": clients,
            "performance": matrix,
            "performance_by_client": group_matrix or matrix,
            "performance_by_account_type": report.get("period_matrix_account_type") or {},
            "series": report.get("series_global") or [],
            "series_detail": report.get("series_detail") or [],
            "generated_at": today,
        },
    }
