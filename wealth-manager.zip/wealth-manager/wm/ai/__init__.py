"""Module d'analyse IA : moteur GGUF local, contexte métier et génération PPTX."""

from .config import (
    AI_CONFIG_PATH,
    ai_config,
    list_models,
    load_ai_config,
    save_ai_config,
)
from .context import build_context

__all__ = [
    "AI_CONFIG_PATH",
    "ai_config",
    "build_context",
    "list_models",
    "load_ai_config",
    "save_ai_config",
]
