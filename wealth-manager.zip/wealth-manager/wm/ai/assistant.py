"""Assistant : assemble le prompt, manage le budget de contexte et interroge le modèle.

Deux points de fiabilité importants :

1. si le prompt complet dépasse la fenêtre du modèle, le bloc `<DONNEES>` est
   progressivement raccourci plutôt que de renvoyer une erreur 500 ;
2. la réponse est systématiquement passed au contrôleur de chiffres
   (`verify.check`) avant d'être renvoyée à l'interface.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from . import engine, verify
from .config import load_ai_config
from .context import DEFAULT_DETAIL, build_context

MAX_HISTORY = 8          # nombre de tours conservés
_TRIM_FACTOR = 0.75     # part du contexte retirée à chaque nouvelle tentative


def prefix_text(system_prompt: str, context_text: str) -> str:
    """Préfixe commun à tous les tours : invite système + bloc de données.

    Il est placé en premier pour que le cache KV de `llama_cpp` soit réutilisé
    d'une question à l'autre (gain mesuré : pré-remplissage ~30 s une fois,
    puis ~45 s par question au lieu de ~85 s à chaque fois).
    """
    return f"{system_prompt}\n\n<DONNEES>\n{context_text}\n</DONNEES>\n\n"


def _messages(system_prompt: str, context_text: str,
              history: List[Dict[str, str]], question: str) -> List[Dict[str, str]]:
    msgs: List[Dict[str, str]] = [{"role": "system", "content": system_prompt}]
    for h in history[-MAX_HISTORY:]:
        role = h.get("role")
        if role in ("user", "assistant") and h.get("content"):
            msgs.append({"role": role, "content": str(h["content"])})
    user = f"<DONNEES>\n{context_text}\n</DONNEES>\n\n{question}" if context_text else question
    msgs.append({"role": "user", "content": user})
    return msgs


def _shrink(context_text: str, keep_ratio: float) -> str:
    """Réduit le bloc de contexte en gardant sa tête et sa queue."""
    if not context_text:
        return context_text
    limit = int(len(context_text) * keep_ratio)
    if limit < 400:
        return context_text[:limit]
    marker = "\n[... donnees tronquees ...]\n"
    head = int(limit * 0.6)
    tail = limit - head - len(marker)
    if tail <= 0:
        return context_text[:head]
    return context_text[:head] + marker + context_text[-tail:]


def _tickers(report: Dict[str, Any]) -> List[str]:
    return [str(h.get("ticker") or "").upper()
            for h in (report.get("holdings") or []) if h.get("ticker")]


def _finalize(result: Dict[str, Any], context: Dict[str, Any],
              question: str) -> Dict[str, Any]:
    """Enrichit la réponse brute : vérification des chiffres, coût, périmètre."""
    facts = context["facts"]
    check = verify.check(
        result["text"],
        context["text"],
        facts,
        tickers=_tickers(context["report"]),
    )
    result["verification"] = check
    result["warning"] = verify.warning(check)
    result["scope"] = context["scope"]
    result["detail"] = context["detail"]
    result["context_chars"] = len(context["text"])
    result["facts"] = {
        k: facts.get(k)
        for k in ("aum", "market_value", "cash", "pnl", "pnl_pct",
                  "clients", "accounts", "positions")
    }
    result["suggestions"] = suggest(context)
    return result


def ask(question: str, client_id: str = "", history: Optional[List[Dict[str, str]]] = None,
        detail: str = DEFAULT_DETAIL) -> Dict[str, Any]:
    """Pose une question au modèle sur le périmètre `client_id`."""
    question = (question or "").strip()
    if not question:
        raise ValueError("La question est vide")

    cfg = load_ai_config()
    context = build_context(client_id, detail=detail)
    history = history or []

    context_text = context["text"]
    attempt = 0
    last_error: Optional[Exception] = None

    while attempt < 4:
        msgs = _messages(cfg["system_prompt"], context_text, history, question)
        try:
            result = engine.chat(msgs, cfg)
        except ValueError as exc:
            # Fenêtre de contexte dépassée : on raccourcit et on réessaie.
            last_error = exc
            if "context window" not in str(exc).lower():
                raise
            context_text = _shrink(context_text, _TRIM_FACTOR ** (attempt + 1))
            attempt += 1
            continue
        result["context_trimmed"] = attempt > 0
        return _finalize(result, context, question)

    raise RuntimeError(
        "Impossible de tenir le contexte dans la fenêtre du modèle : "
        f"{last_error}"
    )


def estimate(question: str, client_id: str = "", detail: str = DEFAULT_DETAIL
             ) -> Dict[str, Any]:
    """Estime le coût d'une question sans exécuter le modèle."""
    cfg = load_ai_config()
    context = build_context(client_id, detail=detail)
    prompt = prefix_text(cfg["system_prompt"], context["text"]) + question
    llm = engine.get_llm(cfg)
    tokens = engine.count_tokens(llm, prompt)
    return engine.estimate(tokens, int(cfg.get("max_tokens", 500)))


def warmup(client_id: str = "", detail: str = DEFAULT_DETAIL) -> Dict[str, Any]:
    """Charge le modèle et pré-remplit le cache KV du préfixe de conversation.

    On fait tourner une complétion d'un seul token sur la liste de messages
    *exactement* telle qu'elle sera envoyée au premier tour (avec une question
    vide) : le cache KV se remplit alors exactement du préfixe réutilisable.
    """
    cfg = load_ai_config()
    context = build_context(client_id, detail=detail)
    messages = _messages(cfg["system_prompt"], context["text"], [], "")
    info = engine.warm_prefix(messages, cfg)
    return {
        **info,
        "scope": context["scope"],
        "detail": context["detail"],
        "model": engine.model_path(cfg).name,
    }


# ------------------------------------------------------------------ prompts
COMMENTARY_PROMPT = (
    "Rédige la synthèse de comité pour la présentation de gestion de patrimoine.\n"
    "Structure obligatoire, 5 rubriques. Une ligne de titre en capitales, "
    "puis une ou deux phrases, en français :\n"
    "SYNTHESE — taille du portefeuille et tendance sur 1 mois, YTD et 1 an.\n"
    "ALLOCATION — répartition par classe d'actifs et par secteur, points saillants.\n"
    "PERFORMANCE — clients et comptes qui contribuent le plus, et le moins.\n"
    "RISQUES — concentration, liquidité, exposition sectorielle, profils de risque.\n"
    "POINTS DE VIGILANCE — deux constats factuels à suivre.\n"
    "Reprends les montants exactement tels qu'ils sont écrits dans les données. "
    "N'invente aucun chiffre. Maximum 220 mots."
)

COMMENTARY_RUBRICS = ["SYNTHESE", "ALLOCATION", "PERFORMANCE", "RISQUES", "VIGILANCE"]

CLIENT_COMMENTARY_PROMPT = (
    "Rédige le commentaire de gestion pour la fiche client.\n"
    "Quatre rubriques en capitales, puis une phrase chacune, en français :\n"
    "SITUATION — AuM, nombre de comptes et de positions, profil de risque.\n"
    "PERFORMANCE — évolution sur 1 mois, YTD et 1 an, P&L latent.\n"
    "ALLOCATION — classes d'actifs et secteurs dominants, concentrations.\n"
    "POINTS DE VIGILANCE — deux constats factuels.\n"
    "Reprends les montants exactement. Maximum 110 mots."
)

CLIENT_COMMENTARY_RUBRICS = ["SITUATION", "PERFORMANCE", "ALLOCATION", "VIGILANCE"]


def commentary(client_id: str = "", detail: str = DEFAULT_DETAIL) -> Dict[str, Any]:
    """Synthèse narrative destinée à la présentation PPTX."""
    result = ask(COMMENTARY_PROMPT, client_id=client_id, detail=detail)
    result["blocks"] = verify.commentary_blocks(result["text"], COMMENTARY_RUBRICS)
    return result


def client_commentary(client_id: str, detail: str = DEFAULT_DETAIL) -> Dict[str, Any]:
    """Commentaire court pour la fiche d'un client précis."""
    result = ask(CLIENT_COMMENTARY_PROMPT, client_id=client_id, detail=detail)
    result["blocks"] = verify.commentary_blocks(result["text"],
                                                CLIENT_COMMENTARY_RUBRICS)
    return result


# ------------------------------------------------------------------ suggestions
def suggest(context: Dict[str, Any]) -> List[str]:
    """Questions proposées, adaptées au périmètre courant."""
    facts = context["facts"]
    name = (context.get("context_client") or {}).get("name")
    if name:
        return [
            f"Quelle est la performance de {name} sur 1 an ?",
            f"Comment {name} est-il réparti par classe d'actifs ?",
            f"Quelles sont les plus grandes positions de {name} ?",
            f"Quels sont les principaux risques du portefeuille de {name} ?",
        ]
    top = facts.get("top_positions") or []
    first = top[0].get("ticker") if top else None
    return [
        "Quelle est la répartition du portefeuille par classe d'actifs ?",
        "Quels clients concentrent le plus d'actifs ?",
        f"Quel est le P&L latent du portefeuille et ses meilleurs contributeurs ?",
        f"Quels sont les principaux risques de concentration ?"
        + (f" Que penser de la position {first} ?" if first else ""),
        "Quelle est la performance des comptes assurance vie ?",
    ]
