"""Contrôle des chiffres cités par le modèle.

Un modèle 3B peut recopier un montant en perdant un chiffre (7 666 784 ->
766 784). Plutôt que de faire confiance la sortie brute, on extrait tous les
nombres de la réponse et on vérifie qu'ils figurent effectivement dans le
contexte fourni ; ceux qui n'existent pas sont remontés à l'interface comme
« à vérifier ». C'est une garde-barre, pas une preuve : le but est d'alerter
l'utilisateur, pas de certifier la réponse.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Set

#: 1 234 567,89 / 1,234,567.89 / 1 234 567
_NUMBER_RE = re.compile(r"\d[\d\s  .,]{0,18}\d|\d")
#: Motif de tickerboursier : MAJEUSCULES + point d'échange (AIR.PA, VWCE.DE)
_TICKER_RE = re.compile(r"\b[A-Z]{2,6}\.[A-Z]{2}\b")
#: Ticker « nu », sans suffixe d'échange (NVDA, AAPL, CW8)
_BARE_TICKER_RE = re.compile(r"\b[A-Z][A-Z0-9-]{1,7}\b")
#: Marqueurs Markdown et de mise en forme, retirés avant toute extraction.
_MD_RE = re.compile(r"[*_`#>\[\]•·—–]")

#: Sigles financiers, unités et unités de temps qui ne sont pas des tickers.
ACRONYMS = {
    "EUR", "USD", "GBP", "CHF", "JPY", "CAD", "AUD",
    "YTD", "MTD", "T", "TD", "DA", "DMA", "SEM", "AN", "ANS",
    "ETF", "ETP", "ETC", "SICAV", "FCP", "FIA", "ISIN", "UCITS", "AMF",
    "AUM", "NAV", "PER", "PEA", "CT", "AV", "PE", "SCPI", "SIC", "SAC",
    "PRIME", "TVA", "CMF", "MOA", "IMO", "ESG", "RGPD", "CNIL", "IA",
    "P", "L", "DL", "EM", "TMO",
}

#: Titres de section en capitales, fréquents dans les réponses structurées.
SECTION_WORDS = {
    "SYNTHESE", "ALLOCATION", "PERFORMANCE", "RISQUE", "RISQUES", "VIGILANCE",
    "SITUATION", "POINTS", "GLOBAL", "GLOBALE", "INDICATEURS", "CONCENTRATION",
    "PATRIMOINE", "PREVOYANCE", "REPARTITION", "EVOLUTION", "CONCLUSION",
    "RECOMMANDATIONS", "CONCLUSION", "SYNTHESES", "AVERTISSEMENT", "REPONSE",
    "ANALYSE", "FONDS", "ACTIFS", "PASSIF", "PRODUITS", "CLIENT", "CLIENTS",
    "CASH", "RISQUES", "AUR", "AUM", "TRS", "ESG", "PEA",
}

#: En dessous de ce seuil, un nombre est un pourcentage, un jour ou un
#: petit compte : trop bruyant pour être vérifié (et les arrondis sont
#: legitimes). Au-dessus, il s'agit d'un montant.
SIGNIFICANT_FROM = 1000.0
REL_TOLERANCE = 0.005  # 0,5 %


def _to_float(raw: str) -> Optional[float]:
    """Normalise un nombre écrit à la française ou à l'anglaise."""
    s = raw.strip().replace(" ", " ").replace(" ", " ")
    s = re.sub(r"[ ]", "", s)
    if not re.search(r"\d", s):
        return None
    # On retire les séparateurs de milliers, puis on normalise la décimale.
    if "," in s and "." in s:
        s = s.replace(",", "") if s.rindex(".") > s.rindex(",") else s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    s = s.replace(".", "", 1) if s.count(".") > 1 else s
    try:
        return float(s)
    except ValueError:
        return None


def _numbers(text: str) -> List[float]:
    out: List[float] = []
    for match in _NUMBER_RE.finditer(text or ""):
        value = _to_float(match.group(0))
        if value is not None:
            out.append(abs(value))
    return out


def _format(raw: str) -> str:
    return re.sub(r"\s+", " ", raw).strip(" .,%")


def known_values(context_text: str, facts: Optional[Dict[str, Any]] = None
                 ) -> Set[float]:
    """Ensemble des valeurs autorisées : tout ce qui figure dans le contexte."""
    values: Set[float] = set()

    def add(v: Any) -> None:
        try:
            values.add(abs(float(v)))
        except (TypeError, ValueError):
            pass

    for n in _numbers(context_text):
        # On enregistre aussi les arrondis à l'unité et à 0,1 % près, le modèle
        #	nalignant legers arrondis.
        values.add(n)
        values.add(round(n))
        values.add(round(n, 1))
        values.add(round(n, 2))
        if n >= 1000:
            values.add(round(n / 1000.0, 1))
            values.add(round(n / 1000.0))
            values.add(round(n / 1000.0, 2))
            values.add(round(n / 1000000.0, 2))

    for key in ("aum", "market_value", "cash", "pnl"):
        add((facts or {}).get(key))
    for row in ((facts or {}).get("by_class") or []):
        add(row.get("value"))
    for row in ((facts or {}).get("by_sector") or []):
        add(row.get("value"))
    for row in ((facts or {}).get("by_account_type") or []):
        add(row.get("total_value"))
        add(row.get("market_value"))
        add(row.get("cash"))
        add(row.get("pnl"))
    for h in ((facts or {}).get("top_positions") or []):
        add(h.get("market_value"))
        add(h.get("total_pnl"))
    return values


def _is_known(value: float, pool: Iterable[float]) -> bool:
    if value in pool:
        return True
    for candidate in pool:
        if candidate <= 0:
            continue
        if abs(candidate - value) / max(abs(candidate), 1.0) <= REL_TOLERANCE:
            return True
    return False


def _unknown_tickers(answer: str, known: Set[str], context: str = "") -> Set[str]:
    """Sigles en capitales qui ne correspondent à aucun titre du portefeuille.

    Couvre les deux formes rencontrées dans les données : le ticker avec
    suffixe d'échange (`AIR.PA`) et le ticker nu (`NVDA`). Le Markdown est
    neutralisé au préalable pour ne pas confondre `**SYNTHESE**` avec un
    ticker.

    Un sigle qui figure tel quel dans le contexte est accepté même s'il n'est
    pas un ticker : les fonds sont nommés « ETF MSCI World » et le modèle peut
    légitimement citer ce mot.
    """
    if not known:
        return set()
    text = _MD_RE.sub(" ", answer or "")
    dotted = {t.upper() for t in _TICKER_RE.findall(text)}
    # On neutralize les tickers à suffixe avant de chercher les tickers nus,
    # sinon « AIR.PA » serait aussi lu comme deux sigles « AIR » et « PA ».
    bare_text = _TICKER_RE.sub(" ", text)
    bare = {t.upper() for t in _BARE_TICKER_RE.findall(bare_text)}
    # Les radicaux des tickers connus (ASML.AS -> ASML) sont acceptés.
    roots = {t.split(".")[0] for t in known}
    return {
        t for t in dotted | bare
        if t not in known and t.split(".")[0] not in roots
        and t not in ACRONYMS and t not in SECTION_WORDS
        and not _mentioned_in(t, context)
    }


def _mentioned_in(token: str, context: str) -> bool:
    """Le sigle figure-t-il tel quel dans le contexte fourni au modèle ?"""
    if not context or not token:
        return False
    return re.search(rf"(?<![A-Za-z0-9]){re.escape(token)}(?![A-Za-z0-9])",
                     context, re.IGNORECASE) is not None


def check(answer: str, context_text: str, facts: Optional[Dict[str, Any]] = None,
          tickers: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    """Vérifie la réponse : montants et tickers contre le contexte connu."""
    pool = known_values(context_text, facts)
    known_tickers = {t.upper() for t in (tickers or [])}

    unverified: List[Dict[str, Any]] = []
    checked = 0
    seen: Set[str] = set()
    for match in _NUMBER_RE.finditer(answer or ""):
        raw = match.group(0)
        value = _to_float(raw)
        if value is None:
            continue
        value = abs(value)
        if value < SIGNIFICANT_FROM:
            continue
        label = _format(raw)
        if label in seen:
            continue
        seen.add(label)
        checked += 1
        if not _is_known(value, pool):
            unverified.append({"value": label, "number": value})

    unknown_tickers = sorted(_unknown_tickers(answer, known_tickers, context_text))

    return {
        "ok": not unverified and not unknown_tickers,
        "numbers_checked": checked,
        "unverified_numbers": unverified[:8],
        "unknown_tickers": unknown_tickers[:8],
    }


def warning(result: Dict[str, Any]) -> str:
    """Message court affiché dans l'interface si la vérification échoue."""
    if result.get("ok"):
        return ""
    parts: List[str] = []
    nums = result.get("unverified_numbers") or []
    if nums:
        parts.append("montant(s) absent(s) des données : "
                     + ", ".join(n["value"] for n in nums))
    tickers = result.get("unknown_tickers") or []
    if tickers:
        parts.append("ticker(s) inconnu(s) : " + ", ".join(tickers))
    return "À vérifier — " + " ; ".join(parts)


def commentary_blocks(text: str, rubrics: Optional[List[str]] = None
                     ) -> List[Dict[str, str]]:
    """Découpe un commentaire libre en blocs `{title, text}` pour le PPTX.

    Si le modèle respecte les rubriques demandées (lignes en capitales
    suivies de « — » ou « : »), on les retrouve ; sinon on retombe sur des
    blocs de paragraphes.
    """
    raw = (text or "").strip()
    if not raw:
        return []

    cleaned = re.sub(r"^#{1,6}\s*", "", raw, flags=re.MULTILINE)
    cleaned = re.sub(r"\*\*(.+?)\*\*", r"\1", cleaned)
    cleaned = re.sub(r"(?<!\w)\*(.+?)\*(?!\w)", r"\1", cleaned)
    cleaned = re.sub(r"^\s*[-•]\s+", "• ", cleaned, flags=re.MULTILINE)

    wanted = [r.upper() for r in (rubrics or [])]
    blocks: List[Dict[str, str]] = []
    current: Optional[Dict[str, Any]] = None
    for line in cleaned.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        head = re.match(r"^([A-ZÀ-Þ][A-ZÀ-Þ /'’-]{2,30})\s*(?:[—–:-]\s*)?(.*)$", stripped)
        title = head.group(1).strip() if head else None
        if title and (not wanted or any(w in title for w in wanted)):
            current = {"title": title, "lines": []}
            if head.group(2).strip():
                current["lines"].append(head.group(2).strip())
            blocks.append(current)
            continue
        if current is None:
            current = {"title": "", "lines": []}
            blocks.append(current)
        current["lines"].append(stripped)

    if not blocks:
        return []

    out: List[Dict[str, str]] = []
    for b in blocks:
        body = " ".join(l for l in b["lines"] if not l.startswith("•"))
        bullets = [l.lstrip("• ").strip() for l in b["lines"] if l.startswith("•")]
        pieces: List[str] = []
        if body:
            pieces.append(body)
        if bullets:
            pieces.append("\n".join(bullets))
        text_block = "\n".join(pieces)
        if b["title"] or text_block:
            out.append({"title": b["title"], "text": text_block})
    return out
