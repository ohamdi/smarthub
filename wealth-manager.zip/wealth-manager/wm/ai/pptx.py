"""Génération du reporting PPTX de synthèse des actifs (python-pptx).

La charte (couleurs, police, logo, pied de page) et le modèle corporate
éventuellement importé sont pilotés par `wm.ai.brand` : `Deck` lit la charte au
moment de sa construction et n'utilise plus les constantes de module que comme
valeurs par défaut.
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

from . import brand as brand_mod

# ------------------------------------------------------------------ charte
GREEN = RGBColor(0x0D, 0x6E, 0x4F)
ACCENT = RGBColor(0x0A, 0x7D, 0x57)
DARK = RGBColor(0x1F, 0x29, 0x37)
MUTED = RGBColor(0x6B, 0x72, 0x80)
LIGHT = RGBColor(0xF3, 0xF7, 0xF5)
BORDER = RGBColor(0xE2, 0xE8, 0xE4)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
RED = RGBColor(0xC0, 0x2C, 0x2C)

PALETTE = [
    RGBColor(0x0D, 0x6E, 0x4F), RGBColor(0x2E, 0x9E, 0x74), RGBColor(0x5A, 0xC1, 0x9A),
    RGBColor(0x8A, 0xD9, 0xBC), RGBColor(0x0F, 0x4C, 0x81), RGBColor(0x3B, 0x82, 0xB6),
    RGBColor(0x7C, 0xA9, 0xD4), RGBColor(0x8B, 0x5E, 0x34), RGBColor(0xC8, 0x8A, 0x4B),
    RGBColor(0xE0, 0xB2, 0x66), RGBColor(0x6B, 0x4E, 0x8F), RGBColor(0x9B, 0x7E, 0xC4),
]

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)
MARGIN = Inches(0.6)
CONTENT_W = SLIDE_W - 2 * MARGIN
FOOTER = "Smart Wealth Manager — document confidentiel, ne constitue pas un conseil en investissement"

#: Ratio du format de référence. Un modèle corporate d'un autre format est
#: normalisé : toutes les coordonnées de mise en page en dépendent.
ASPECT = round(SLIDE_W / SLIDE_H, 4)


class Colors:
    """Palette d'une présentation, dérivée de la charte."""

    def __init__(self, brand: Dict[str, Any]):
        self.primary = brand_mod.rgb(brand["primary"])
        self.accent = brand_mod.rgb(brand["accent"])
        self.ink = brand_mod.rgb(brand["ink"])
        self.muted = brand_mod.rgb(brand["muted"])
        self.surface = brand_mod.rgb(brand["surface"])
        self.negative = brand_mod.rgb(brand["negative"])
        self.border = brand_mod.rgb(brand_mod._mix(brand["surface"], "000000", 0.10))
        self.white = RGBColor(0xFF, 0xFF, 0xFF)


def open_presentation(template: Optional[str] = None):
    """Ouvre un modèle corporate ou une présentation vierge, 16:9.

    Les diapositives présentes dans le modèle sont retirées : on ne garde que
    ses mises en page, son thème et ses masters.
    """
    prs = Presentation(template) if template else Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H
    if template:
        # python-pptx ne expose pas la suppression de diapositives : on
        # supprime leurs relations, ce qui les retire du document.
        slide_ids = prs.slides._sldIdLst  # noqa: SLF001
        for sld_id in list(slide_ids):
            prs.part.drop_rel(sld_id.rId)  # noqa: SLF001
            slide_ids.remove(sld_id)
    return prs


def blank_layout(prs) -> Any:
    """Mise en page vierge : la moins susceptible d'ajouter des habillages."""
    layouts = list(prs.slide_layouts)
    if not layouts:
        raise brand_mod.BrandError("Le modèle ne contient aucune mise en page.")
    for keywords in (("blank", "vide", "aucun", "none"), ("title only",)):
        for layout in layouts:
            if any(k in layout.name.lower() for k in keywords):
                return layout
    return layouts[-1]


# ------------------------------------------------------------------ helpers
def _set_text(shape, text: str, size: int = 14, bold: bool = False,
              color: RGBColor = DARK, align: PP_ALIGN = PP_ALIGN.LEFT,
              italic: bool = False, font: str = "Calibri") -> None:
    tf = shape.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    f = run.font
    f.size = Pt(size)
    f.bold = bold
    f.italic = italic
    f.color.rgb = color
    f.name = font or "Calibri"


def _textbox(slide, left, top, width, height, text, **kw):
    box = slide.shapes.add_textbox(left, top, width, height)
    _set_text(box, text, **kw)
    return box


def _rect(slide, left, top, width, height, fill: RGBColor, line: Optional[RGBColor] = None):
    from pptx.enum.shapes import MSO_SHAPE

    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    if line is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = line
        shape.line.width = Pt(0.75)
    shape.shadow.inherit = False
    shape.text_frame.text = ""
    return shape


# ------------------------------------------------------------------ deck
class Deck:
    """Assemble une présentation 16:9."""

    def __init__(self, title: str, subtitle: str = "",
                 brand: Optional[Dict[str, Any]] = None,
                 template: Optional[str] = None):
        self.brand = dict(brand or brand_mod.load_brand())
        self.c = Colors(self.brand)
        self.font = self.brand["font"] or "Calibri"
        # Un modèle corporate fournit la palette des graphiques, sauf si la
        # charte a été réglée pour garder ses propres couleurs.
        theme = (brand_mod.theme_palette(Path(template)) if template else []) \
            if self.brand.get("charts_from_template", True) else []
        self.palette = [RGBColor.from_string(h) for h in
                        (theme or brand_mod.default_palette(self.brand))]
        self.template = template
        self.prs = open_presentation(template)
        self.blank = blank_layout(self.prs)
        self.title = title
        self.subtitle = subtitle
        self.page = 0
        self.logo = brand_mod.logo_path(self.brand)
        # Mention de repli : la charte vide redonne le pied de page d'origine.
        self.footer_text = ((self.brand["footer"] or FOOTER)
                            if self.brand.get("show_footer") else "")

    # -- squelette ------------------------------------------------------
    def add_slide(self, kicker: str = "", heading: str = "", numbered: bool = True):
        slide = self.prs.slides.add_slide(self.blank)
        if numbered:
            self.page += 1
        c, font = self.c, self.font
        top = Inches(0.42)
        if kicker:
            _textbox(slide, MARGIN, top, self.title_w(), Inches(0.24), kicker.upper(),
                     size=10, bold=True, color=c.accent, font=font)
            top = Inches(0.68)
        if heading:
            _textbox(slide, MARGIN, top, self.title_w(), Inches(0.45), heading,
                     size=24, bold=True, color=c.ink, font=font)
        _rect(slide, MARGIN, top + Inches(0.52), Inches(1.1), Pt(3), c.accent)
        if self.logo:
            self.add_logo(slide, top=Inches(0.45), width=Inches(1.6), box_h=Inches(0.62))
        # pied de page
        if self.footer_text:
            _textbox(slide, MARGIN, SLIDE_H - Inches(0.42), Inches(9), Inches(0.25),
                     self.footer_text, size=8, color=c.muted, font=font)
        if numbered:
            _textbox(slide, SLIDE_W - MARGIN - Inches(1), SLIDE_H - Inches(0.42),
                     Inches(1), Inches(0.25), str(self.page), size=9,
                     color=c.muted, align=PP_ALIGN.RIGHT, font=font)
        return slide

    def title_w(self):
        """Largeur réservée au titre : le logo occupe le coin droit."""
        return CONTENT_W - Inches(1.8) if self.logo else CONTENT_W

    def add_logo(self, slide, top=None, width=None, left=None, box_h=None):
        """Pose le logo (coin droit par défaut), proportions conservées.

        `width` et `box_h` bornent ensemble le logo : un visuel vertical ou
        très large reste dans son cadre au lieu de déborder de la diapositive.
        """
        if not self.logo:
            return None
        width = width or Inches(1.5)
        box_h = box_h or Inches(0.75)
        try:
            from PIL import Image

            with Image.open(str(self.logo)) as img:
                ratio = float(img.height) / float(img.width or 1)
        except Exception:
            ratio = 0.5
        height = int(width * ratio)
        if height > box_h:
            height = int(box_h)
            width = int(height / ratio) if ratio else width
        left = SLIDE_W - MARGIN - width if left is None else left
        try:
            return slide.shapes.add_picture(str(self.logo), left,
                                            top or Inches(0.4), width=width, height=height)
        except Exception:
            # Un logo illisible ne doit pas faire échouer la génération.
            self.logo = None
            return None

    def content_top(self) -> int:
        return Inches(1.55)

    def sync_page(self) -> None:
        """Aligne le compteur sur la position réelle des diapositives.

        La couverture est posée directement (elle ne porte pas de numéro) : sans
        cet appel, la page suivante s'afficherait « 1 » alors qu'elle est la
        deuxième, et la table des matieres afficherait des numeros faux.
        """
        self.page = len(self.prs.slides)

    # -- blocs ----------------------------------------------------------
    def kpi_row(self, slide, items: Sequence[Dict[str, str]], top=None, height=None):
        """Bandeau d'indicateurs clés."""
        top = top or self.content_top()
        n = len(items) or 1
        gap = Inches(0.18)
        width = int((CONTENT_W - gap * (n - 1)) / n)
        c, font = self.c, self.font
        for i, it in enumerate(items):
            left = MARGIN + i * (width + gap)
            card = _rect(slide, left, top, width, height or Inches(1.25),
                         c.surface, c.border)
            tf = card.text_frame
            tf.word_wrap = True
            tf.margin_left = Inches(0.14)
            tf.margin_right = Inches(0.1)
            tf.margin_top = Inches(0.1)
            p = tf.paragraphs[0]
            r = p.add_run()
            r.text = it["label"].upper()
            r.font.size = Pt(9)
            r.font.bold = True
            r.font.color.rgb = c.muted
            r.font.name = font
            p2 = tf.add_paragraph()
            r2 = p2.add_run()
            r2.text = it["value"]
            r2.font.size = Pt(it.get("size", 20))
            r2.font.bold = True
            r2.font.color.rgb = it.get("color", c.primary)
            r2.font.name = font
            if it.get("sub"):
                p3 = tf.add_paragraph()
                r3 = p3.add_run()
                r3.text = it["sub"]
                r3.font.size = Pt(9)
                r3.font.color.rgb = c.muted
                r3.font.name = font
        return top + (height or Inches(1.25))

    def table(self, slide, headers: Sequence[str], rows: Sequence[Sequence[str]],
              top=None, left=None, width=None, height=None,
              col_widths: Optional[Sequence[float]] = None,
              numeric_cols: Sequence[int] = (), font_size: int = 10,
              row_kinds: Optional[Sequence[str]] = ()):
        """Tableau stylé : en-tête vert, lignes alternées, colonnes alignées à droite.

        `row_kinds` étiquette les lignes pour un rendu d'inventaire :
        `group` (intitulé de classe d'actif), `subtotal`, `total` (bandeau de
        synthèse, inversé aux couleurs de la marque).
        """
        top = top or self.content_top()
        left = left or MARGIN
        width = width or CONTENT_W
        n_rows = len(rows) + 1
        n_cols = len(headers)
        height = height or Inches(0.32 * n_rows)
        shape = slide.shapes.add_table(n_rows, n_cols, left, top, width, height)
        table = shape.table
        colors, font = self.c, self.font

        if col_widths:
            total = sum(col_widths)
            for i, ratio in enumerate(col_widths):
                table.columns[i].width = Emu(int(width * ratio / total))

        # en-tête
        for c, h in enumerate(headers):
            cell = table.cell(0, c)
            cell.text = ""
            cell.fill.solid()
            cell.fill.fore_color.rgb = colors.primary
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.margin_left = cell.margin_right = Inches(0.06)
            p = cell.text_frame.paragraphs[0]
            p.alignment = PP_ALIGN.RIGHT if c in numeric_cols else PP_ALIGN.LEFT
            run = p.add_run()
            run.text = str(h)
            run.font.size = Pt(font_size)
            run.font.bold = True
            run.font.color.rgb = colors.white
            run.font.name = font

        # lignes
        for r, row in enumerate(rows, start=1):
            kind = row_kinds[r - 1] if r - 1 < len(row_kinds or ()) else ""
            if kind == "total":
                fill, ink, force_bold = colors.primary, colors.white, True
            elif kind == "group":
                fill, ink, force_bold = colors.surface, colors.primary, True
            elif kind == "subtotal":
                fill, ink, force_bold = colors.white, colors.ink, True
            else:
                fill = colors.white if r % 2 else colors.surface
                ink, force_bold = colors.ink, False
            for c, value in enumerate(row):
                cell = table.cell(r, c)
                cell.text = ""
                cell.fill.solid()
                cell.fill.fore_color.rgb = fill
                cell.vertical_anchor = MSO_ANCHOR.MIDDLE
                cell.margin_left = cell.margin_right = Inches(0.06)
                p = cell.text_frame.paragraphs[0]
                p.alignment = PP_ALIGN.RIGHT if c in numeric_cols else PP_ALIGN.LEFT
                run = p.add_run()
                run.text = "" if value is None else str(value)
                run.font.size = Pt(font_size)
                run.font.color.rgb = ink
                run.font.name = font
                run.font.bold = force_bold
                if c in numeric_cols and _is_negative(value) and kind != "total":
                    run.font.color.rgb = colors.negative
                    run.font.bold = True
        return table

    def bullets(self, slide, blocks: Sequence[Dict[str, str]], top=None,
                left=None, width=None, font_size: int = 13, gap: int = 5,
                height=None):
        """Liste de blocs `{title, text}` avec sous-titre en gras."""
        top = top or self.content_top()
        left = left or MARGIN
        width = width or CONTENT_W
        box = slide.shapes.add_textbox(left, top, width, height or Inches(4.5))
        tf = box.text_frame
        tf.word_wrap = True
        first = True
        for b in blocks:
            title = (b.get("title") or "").strip()
            text = (b.get("text") or "").strip()
            if not title and not text:
                continue
            p = tf.paragraphs[0] if first else tf.add_paragraph()
            first = False
            p.space_after = Pt(2)
            if title:
                r = p.add_run()
                r.text = f"{title} "
                r.font.size = Pt(font_size)
                r.font.bold = True
                r.font.color.rgb = self.c.accent
                r.font.name = self.font
            if text:
                r2 = p.add_run()
                r2.text = text
                r2.font.size = Pt(font_size)
                r2.font.color.rgb = self.c.ink
                r2.font.name = self.font
            for line in text.split("\n"):
                if line.strip():
                    sub = tf.add_paragraph()
                    sub.level = 1
                    sub.space_after = Pt(1)
                    rr = sub.add_run()
                    rr.text = f"• {line.strip()}"
                    rr.font.size = Pt(font_size - 1)
                    rr.font.color.rgb = self.c.ink
                    rr.font.name = self.font
            p2 = tf.add_paragraph()
            p2.space_after = Pt(gap)
            r3 = p2.add_run()
            r3.text = " "
            r3.font.size = Pt(4)
        return box

    def chart(self, slide, kind, categories: Sequence[str], series_name: str = "",
              values: Optional[Sequence[float]] = None, top=None, left=None,
              width=None, height=None, legend: bool = True, data_labels: bool = True,
              gap_width=None, series: Optional[Sequence] = None,
              point_colors: Optional[Sequence[RGBColor]] = None,
              number_format: str = '0.0', axis_title: str = ""):
        """Graphique catégoriel.

        `series` : liste de `(nom, valeurs)` pour un graphique multi-séries
        (sinon la série unique `series_name` / `values` est utilisée).
        `point_colors` : couleur par point d'une série unique (vert/rouge).
        """
        top = top or self.content_top()
        left = left or MARGIN
        width = width or CONTENT_W
        height = height or Inches(4.4)
        colors, font = self.c, self.font
        items = list(series) if series else [(series_name, list(values or []))]
        data = CategoryChartData()
        data.categories = list(categories)
        for name, vals in items:
            data.add_series(name, [float(v or 0) for v in vals])
        frame = slide.shapes.add_chart(kind, left, top, width, height, data)
        chart = frame.chart
        chart.has_title = False
        chart.font.size = Pt(10)
        chart.font.color.rgb = colors.ink
        chart.font.name = font

        chart.has_legend = legend
        if legend:
            chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            chart.legend.include_in_layout = False
            chart.legend.font.size = Pt(9)

        plot = chart.plots[0]
        is_line = "LINE" in str(kind)
        if kind in (XL_CHART_TYPE.PIE, XL_CHART_TYPE.DOUGHNUT):
            for i, point in enumerate(plot.series[0].points):
                point.format.fill.solid()
                point.format.fill.fore_color.rgb = self.palette[i % len(self.palette)]
            plot.has_data_labels = data_labels
            if data_labels:
                dl = plot.data_labels
                dl.show_percentage = True
                dl.show_value = False
                dl.show_category_name = False
                dl.position = XL_LABEL_POSITION.OUTSIDE_END
                # `show_percentage` fournit une fraction (0,47) : le format doit
                # comporter le % natif, sinon l'étiquette affiche « 0,5 % ».
                dl.number_format = '0.0%'
                dl.number_format_is_linked = False
                dl.font.size = Pt(9)
                dl.font.color.rgb = colors.ink
        else:
            single = len(chart.series) == 1
            for i, serie in enumerate(chart.series):
                color = colors.primary if single else self.palette[i % len(self.palette)]
                if is_line:
                    serie.format.line.color.rgb = color
                    serie.format.line.width = Pt(2.25)
                    try:
                        serie.smooth = False
                    except (AttributeError, NotImplementedError):
                        pass
                else:
                    serie.format.fill.solid()
                    serie.format.fill.fore_color.rgb = color
            if point_colors:
                for i, point in enumerate(plot.series[0].points):
                    color = point_colors[i] if i < len(point_colors) else colors.primary
                    point.format.fill.solid()
                    point.format.fill.fore_color.rgb = color
            chart.value_axis.has_major_gridlines = True
            chart.value_axis.tick_labels.font.size = Pt(9)
            chart.category_axis.tick_labels.font.size = Pt(9)
            if axis_title:
                chart.value_axis.has_title = True
                chart.value_axis.axis_title.text_frame.text = axis_title
                chart.value_axis.axis_title.text_frame.paragraphs[0].runs[0].font.size = Pt(9)
            if gap_width is not None:
                plot.gap_width = gap_width
            if "STACKED" in str(kind):
                plot.overlap = 100  # indispensable pour un empilement lisible
            if is_line:
                plot.has_data_labels = False  # illisible sur une courbe
            else:
                plot.has_data_labels = data_labels
                if data_labels:
                    plot.data_labels.font.size = Pt(9)
                    plot.data_labels.font.color.rgb = colors.ink
                    plot.data_labels.number_format = number_format
                    plot.data_labels.number_format_is_linked = False
        return chart

    def save(self) -> bytes:
        buf = io.BytesIO()
        self.prs.save(buf)
        return buf.getvalue()


def _is_negative(value: Any) -> bool:
    if value is None:
        return False
    s = str(value)
    if not s:
        return False
    if s.startswith("-"):
        return True
    return "(" in s and ")" in s
