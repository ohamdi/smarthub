"""Assemblage du reporting PPTX (slides) à partir des faits calculés."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional, Sequence

from pptx.enum.chart import XL_CHART_TYPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt

from ..serialization import safe_num
from . import brand as brand_mod
from . import verify
from .context import build_context, eur, num, pct
from .pptx import CONTENT_W, Deck, MARGIN, SLIDE_H, SLIDE_W, _rect, _textbox

_PERIODS = [("1m", "1 mois"), ("3m", "3 mois"), ("6m", "6 mois"),
            ("ytd", "YTD"), ("1y", "1 an")]


# ------------------------------------------------------------------ utilitaires
def _f(v: Any, decimals: int = 2) -> str:
    try:
        return f"{float(v):,.{decimals}f}".replace(",", " ").replace(".", ",")
    except (TypeError, ValueError):
        return "—"


def _signed_pct(v: Any) -> str:
    if v is None:
        return "—"
    try:
        x = float(v)
    except (TypeError, ValueError):
        return "—"
    return ("+" if x >= 0 else "") + f"{x:,.2f}".replace(",", " ").replace(".", ",") + " %"


def _pct_or_dash(v: Any) -> str:
    return "—" if v is None else f"{float(v):,.2f}".replace(",", " ").replace(".", ",") + " %"


def _signed_eur(v: Any) -> str:
    if v is None:
        return "—"
    try:
        x = float(v)
    except (TypeError, ValueError):
        return "—"
    return ("+" if x >= 0 else "-") + eur(abs(x), 0)


def _class_pnl_pct(ctx: Dict[str, Any], label: str) -> Optional[float]:
    """P&L en % du coût d'acquisition d'une classe d'actifs (toutes positions)."""
    cost = pnl = 0.0
    for h in ctx["report"].get("holdings") or []:
        if (h.get("asset_class") or "") == label:
            cost += safe_num(h.get("cost_value"))
            pnl += safe_num(h.get("total_pnl"))
    return round(pnl / cost * 100, 2) if cost else None


def _monthly(series: Sequence[Dict[str, Any]], key: str = "total_value") -> list:
    """Agrège une série quotidienne en fin de mois (libellés uniques et triés)."""
    if not series:
        return []
    buckets: Dict[str, Dict[str, Any]] = {}
    for point in series:
        value = point.get(key)
        if point.get("date") and value is not None:
            buckets[str(point["date"])[:7]] = {"month": str(point["date"])[:7],
                                               "value": float(value)}
    return [buckets[k] for k in sorted(buckets)]


def _series_points(series: Sequence[Dict[str, Any]], max_points: int = 14) -> tuple:
    """Sous-échantillonne une série temporelle pour un graphique lisible."""
    points = _monthly([{"date": s.get("date"), "value": s.get("value")} for s in series])
    if not points:
        return [], []
    step = max(1, len(points) // max_points)
    sampled = points[::step]
    if sampled and sampled[-1] is not points[-1]:
        sampled.append(points[-1])
    return [s["month"] for s in sampled], [s["value"] / 1_000_000 for s in sampled]


def _series_months(series_detail: Sequence[Dict[str, Any]],
                   max_points: int = 14) -> tuple:
    """Trois courbes (titres / liquidités / AuM) sur des mois uniques."""
    if not series_detail:
        return [], []
    months = sorted({str(s["date"])[:7] for s in series_detail if s.get("date")})
    if len(months) > max_points:
        step = max(1, len(months) // max_points)
        months = months[::step]
    wanted = set(months)
    picked: Dict[str, Dict[str, float]] = {}
    for s in sorted(series_detail, key=lambda x: str(x.get("date"))):
        month = str(s.get("date"))[:7]
        if month in wanted:
            picked[month] = {k: float(s.get(k) or 0) for k in
                             ("market_value", "cash", "total_value")}
    labels = [m for m in months if m in picked]
    return labels, picked


# ------------------------------------------------------------------ slides
def _slide_cover(deck: Deck, ctx: Dict[str, Any], model: str = "") -> None:
    """Page de titre épurée : logo, titre, date. Les chiffres sont en page 2."""
    facts = ctx["facts"]
    slide = deck.prs.slides.add_slide(deck.blank)
    c = deck.c
    # Fond blanc : seul un filet de marque rappelle la couleur de la société.
    _rect(slide, 0, 0, SLIDE_W, Pt(6), c.primary)
    if deck.logo:
        pic = deck.add_logo(slide, top=Inches(1.5), width=Inches(2.6), box_h=Inches(1.1))
        if pic is not None:
            # Centré horizontalement sur la diapositive.
            pic.left = int((SLIDE_W - pic.width) / 2)
    title_top = Inches(3.35) if deck.logo else Inches(2.7)
    _textbox(slide, MARGIN, title_top, SLIDE_W - 2 * MARGIN, Inches(0.8),
             "Synthese des actifs", size=40, bold=True, color=c.primary,
             align=PP_ALIGN.CENTER, font=deck.font)
    _rect(slide, int(SLIDE_W / 2) - Inches(0.7), title_top + Inches(0.95),
          Inches(1.4), Pt(3), c.accent)
    _textbox(slide, MARGIN, title_top + Inches(1.25), SLIDE_W - 2 * MARGIN, Inches(0.4),
             datetime.now().strftime("%d/%m/%Y"), size=16, color=c.ink,
             align=PP_ALIGN.CENTER, font=deck.font)
    if deck.brand.get("company"):
        _textbox(slide, MARGIN, title_top + Inches(1.75), SLIDE_W - 2 * MARGIN, Inches(0.3),
                 deck.brand["company"]
                 + (f" — {deck.brand['tagline']}" if deck.brand.get("tagline") else ""),
                 size=11, bold=True, color=c.muted, align=PP_ALIGN.CENTER, font=deck.font)
    if deck.brand.get("show_footer"):
        _textbox(slide, MARGIN, SLIDE_H - Inches(0.6), SLIDE_W - 2 * MARGIN, Inches(0.3),
                 deck.brand.get("footer")
                 or "Document confidentiel. Ne constitue pas un conseil en investissement.",
                 size=8, color=c.muted, align=PP_ALIGN.CENTER, font=deck.font)
    if model:
        _textbox(slide, MARGIN, SLIDE_H - Inches(0.95), SLIDE_W - 2 * MARGIN, Inches(0.25),
                 f"Commentaire genere par {model} (modele local)", size=8,
                 color=c.muted, align=PP_ALIGN.CENTER, font=deck.font)


def _slide_scope(deck: Deck, ctx: Dict[str, Any]) -> None:
    """Page 2 : ce que couvre la présentation, en chiffres."""
    facts = ctx["facts"]
    perf = (facts.get("performance") or {}).get("portfolio", {})
    slide = deck.add_slide(kicker="Perimetre", heading=ctx["scope"])
    deck.bullets(slide, [
        {"title": "Actif sous gestion.",
         "text": f"{eur(facts['aum'])} repartis sur {facts['accounts']} comptes "
                 f"et {facts['positions']} positions, pour {facts['clients']} clients."},
        {"title": "Titres et liquidites.",
         "text": f"{eur(facts['market_value'])} de titres "
                 f"({_pct_or_dash(safe_num(facts['market_value']) / facts['aum'] * 100 if facts['aum'] else 0)} "
                 f"de l'AuM) et {eur(facts['cash'])} en comptes especes."},
        {"title": "Performance.",
         "text": f"P&L latent {eur(facts['pnl'])} ({_signed_pct(facts.get('pnl_pct'))}), "
                 f"YTD {_signed_pct(perf.get('ytd'))}, 1 an {_signed_pct(perf.get('1y'))}."},
        {"title": "Contenu.",
         "text": "Repartition par type de compte, inventaire compte par compte, historique "
                 "mensuel de l'annee en cours, puis analyse."},
    ], top=deck.content_top(), font_size=12, height=Inches(3.5))

    ytd = safe_num(perf.get("ytd"))
    deck.kpi_row(slide, [
        {"label": "ACTIF SOUS GESTION", "value": eur(facts["aum"], 0), "size": 22,
         "color": deck.c.primary},
        {"label": "TITRES", "value": eur(facts["market_value"], 0), "size": 16},
        {"label": "LIQUIDITES", "value": eur(facts["cash"], 0), "size": 16},
        {"label": "PERFORMANCE YTD",
         "value": _signed_pct(perf.get("ytd")), "size": 16,
         "color": deck.c.primary if ytd >= 0 else deck.c.negative},
    ], top=Inches(5.35), height=Inches(1.0))


def _slide_toc(deck: Deck, ctx: Dict[str, Any], plan: Sequence[Dict[str, Any]]) -> None:
    """Sommaire : chaque rubrique avec sa ou ses pages.

    Le plan est calculé lors d'une première passe de rendu, de sorte que les
    numéros affichés correspondent exactement à la position des diapositives.
    """
    slide = deck.add_slide(kicker="Sommaire", heading="Table des matieres")
    rows = []
    for entry in plan or []:
        page = str(entry["page"])
        if entry.get("pages", 1) > 1:
            page = f"{page}–{entry['page'] + entry['pages'] - 1}"
        rows.append([entry["title"], page])
    if not rows:
        rows = [["—", "—"]]
    top = Inches(1.75)
    budget = Inches(4.55)
    height = min(Inches(0.34), int(budget / (len(rows) + 1)))
    deck.table(slide, ["Rubrique", "Page(s)"], rows, top=top,
               height=height * (len(rows) + 1),
               col_widths=[11.2, 1.3], numeric_cols=(1,), font_size=11)
    total = plan[-1]["page"] + plan[-1]["pages"] - 1 if plan else 2
    _textbox(slide, MARGIN, top + height * (len(rows) + 1) + Inches(0.25),
             CONTENT_W, Inches(0.3),
             f"{len(rows)} rubriques — {total} diapositives au total.",
             size=9, italic=True, color=deck.c.muted, font=deck.font)


# --------------------------------------------------------------- inventaire
_MONTHS_FR = ["janv.", "fevr.", "mars", "avr.", "mai", "juin", "juil.",
              "aout", "sept.", "oct.", "nov.", "dec."]

# Colonnes de l'inventaire : intitulé, ticker, quantité, PRU, cours, valorisation,
# poids, P&L en euros, P&L en %, performance depuis le début de l'année.
_INV_COLS = [2.55, 1.05, 1.00, 0.95, 0.95, 1.50, 0.80, 1.30, 0.95, 0.95]
_INV_NUM = (2, 3, 4, 5, 6, 7, 8, 9)


def _month_label(month: str) -> str:
    """`2026-03` -> `mars 2026`."""
    try:
        year, m = month.split("-")
        return f"{_MONTHS_FR[int(m) - 1]} {year}"
    except (ValueError, IndexError):
        return month


def _securities_accounts(facts: Dict[str, Any]) -> list:
    """Compts détenant des titres, du plus valorisé au moins valorisé."""
    accounts = [a for a in (facts.get("accounts_detail") or {}).values()
                if a.get("positions")]
    accounts.sort(key=lambda a: -safe_num(a.get("mv")))
    return accounts


def _class_groups(positions: Sequence[Dict[str, Any]]) -> list:
    """Regroupe les positions par classe d'actif, de la plus lourde à la plus légère."""
    buckets: Dict[str, list] = {}
    for p in positions:
        buckets.setdefault((p.get("asset_class") or "Non classe"), []).append(p)
    groups = []
    for klass, items in buckets.items():
        mv = sum(safe_num(p.get("market_value")) for p in items)
        cost = sum(safe_num(p.get("cost_value")) for p in items)
        groups.append((klass, items, mv, sum(safe_num(p.get("total_pnl")) for p in items), cost))
    groups.sort(key=lambda g: -g[2])
    return groups


def _inv_line(label: str, position: Dict[str, Any], weight: float) -> list:
    return [
        label,
        str(position.get("ticker") or "—"),
        _f(position.get("quantity")),
        _f(position.get("unit_cost")),
        _f(position.get("unit_price")),
        _f(position.get("market_value"), 0),
        _pct_or_dash(weight),
        _f(position.get("total_pnl"), 0),
        _signed_pct(position.get("pnl_pct")),
        _signed_pct(position.get("perf_ytd")),
    ]


def _inv_totals(mv: float, pnl: float, cost: float, weight: float) -> list:
    pct_pnl = round(pnl / cost * 100, 2) if cost else None
    return ["", "", "", "", "", _f(mv, 0), _pct_or_dash(weight),
            _f(pnl, 0), _signed_pct(pct_pnl), ""]


def _inventory_pages(account: Dict[str, Any], max_rows: int = 17) -> list:
    """Découpe l'inventaire d'un compte en pages de lignes de tableau.

    Chaque page porte des groupes intacts (intitulé de classe, positions,
    sous-total) ; le bandeau `total` n'est posé que sur la dernière page.
    """
    positions = account.get("positions") or []
    if not positions:
        return []
    total_mv = sum(safe_num(p.get("market_value")) for p in positions)
    total_cost = sum(safe_num(p.get("cost_value")) for p in positions)
    total_pnl = sum(safe_num(p.get("total_pnl")) for p in positions)
    cap = max(4, max_rows - 2)
    pages: list = []
    rows: list = []
    kinds: list = []

    def flush() -> None:
        nonlocal rows, kinds
        if rows:
            pages.append((rows, kinds))
        rows, kinds = [], []

    for klass, items, mv, pnl, cost in _class_groups(positions):
        for start in range(0, len(items), cap):
            chunk = items[start:start + cap]
            # Une page n'est close que si le bloc à venir ne tient plus.
            if rows and len(rows) + len(chunk) + 2 > max_rows:
                flush()
            last_chunk = start + cap >= len(items)
            if last_chunk and len(items) > cap:
                suffix = f" — {len(items)} lignes"
            elif last_chunk:
                suffix = ""
            else:
                suffix = f" (part {start // cap + 1})"
            rows.append([f"{klass.upper()}{suffix}"] + [""] * 9)
            kinds.append("group")
            for p in chunk:
                rows.append(_inv_line(str(p.get("name") or p.get("ticker") or "—"), p,
                                      safe_num(p.get("market_value")) / total_mv * 100
                                      if total_mv else 0.0))
                kinds.append("")
            label = "Sous-total " + klass
            if not last_chunk:
                label += " (partielle)"
            rows.append([label] + _inv_totals(mv, pnl, cost, 100.0 * mv / total_mv if total_mv else 0.0)[1:])
            kinds.append("subtotal")
    flush()
    if pages:
        # Les deux lignes de synthèse réservent leur place : si la dernière page
        # déborde, elles passent seules sur une page de clôture.
        rows, kinds = pages.pop()
        if len(rows) + 2 > max_rows:
            pages.append((rows, kinds))
            rows, kinds = [], []
        pages.append((rows + [
            ["Sous-total titres"] + _inv_totals(total_mv, total_pnl, total_cost, 100.0)[1:],
            ["TOTAL DU COMPTE", "", "", "", "", _f(total_mv + safe_num(account.get("cash")), 0),
             _pct_or_dash(100.0), _f(total_pnl, 0),
             _signed_pct(round(total_pnl / total_cost * 100, 2) if total_cost else None), ""],
        ], kinds + ["subtotal", "total"]))
    return pages


def _slide_inventory(deck: Deck, ctx: Dict[str, Any], account: Dict[str, Any],
                     page: Sequence, part: int, parts: int) -> None:
    """Une page d'inventaire pour un compte : le détail, puis le sous-total de
    chaque classe d'actif, puis le total du compte."""
    rows, kinds = page
    positions = account.get("positions") or []
    # Hors perimetre client, le nom du client distingue deux comptes homonymes.
    label = str(account.get("account_name") or "")
    if not ctx.get("context_client"):
        label = f"{account.get('client_name')} · {label}"
    kicker = "Inventaire" if parts == 1 else f"Inventaire — {part}/{parts}"
    slide = deck.add_slide(kicker=kicker, heading=label)
    total_mv = sum(safe_num(p.get("market_value")) for p in positions)
    pnl = safe_num(account.get("pnl"))
    pnl_pct = safe_num(account.get("pnl_pct"))
    deck.kpi_row(slide, [
        {"label": "VALORISATION DES TITRES", "value": eur(total_mv), "size": 19},
        {"label": "LIQUIDITES", "value": eur(account.get("cash")), "size": 19},
        {"label": "TOTAL DU COMPTE", "value": eur(account.get("total_value")), "size": 19,
         "color": deck.c.primary},
        {"label": "P&L LATENT", "value": eur(pnl), "size": 19,
         "color": deck.c.primary if pnl >= 0 else deck.c.negative,
         "sub": _signed_pct(pnl_pct)},
        {"label": "LIGNES", "value": str(len(positions)), "size": 19,
         "sub": f"{len(_class_groups(positions))} "
                f"{'classe' if len(_class_groups(positions)) < 2 else 'classes'} d'actifs"},
    ], top=Inches(1.5), height=Inches(1.02))
    deck.table(slide,
               ["Instrument", "Ticker", "Quantite", "PRU", "Cours", "Valorisation",
                "Poids", "P&L", "P&L %", "Perf. YTD"],
               rows, top=Inches(2.66), height=Inches(0.24) * (len(rows) + 1),
               col_widths=_INV_COLS, numeric_cols=_INV_NUM, font_size=9,
               row_kinds=kinds)


def _year_history(facts: Dict[str, Any], year: int) -> list:
    """Fin de mois de l'année demandée, avec la variation contre le mois
    précédent et le cumul depuis le début de l'année."""
    points = _monthly(facts.get("series_detail") or [], "total_value")
    prefix = f"{year:04d}"
    before = [p for p in points if p["month"] < prefix]
    inside = [p for p in points if p["month"].startswith(prefix)]
    if not inside:
        return []
    base = before[-1]["value"] if before else inside[0]["value"]
    prev = before[-1]["value"] if before else None
    rows = []
    for p in inside:
        value = p["value"]
        change = value - prev if prev else None
        rows.append({
            "month": p["month"],
            "label": _month_label(p["month"]),
            "value": value,
            "change": change,
            "change_pct": (change / prev * 100.0) if (change is not None and prev) else None,
            "ytd": value - base,
            "ytd_pct": ((value - base) / base * 100.0) if base else None,
        })
        prev = value
    return rows


def _slide_monthly(deck: Deck, ctx: Dict[str, Any], year: int) -> None:
    """Historique des performances mensuelles de l'année en cours."""
    facts = ctx["facts"]
    history = _year_history(facts, year)
    slide = deck.add_slide(kicker="Historique",
                           heading=f"Performances mensuelles — {year}")
    if not history:
        _textbox(slide, MARGIN, Inches(2.2), CONTENT_W, Inches(0.5),
                 f"Aucune valuation disponible en {year}.", size=12,
                 color=deck.c.muted, font=deck.font)
        return
    first, last = history[0], history[-1]
    ytd, ytd_pct = last["ytd"], last["ytd_pct"]
    deck.kpi_row(slide, [
        {"label": f"AUM — {first['label'].upper()}", "value": eur(first["value"], 0), "size": 18},
        {"label": f"AUM — {last['label'].upper()}", "value": eur(last["value"], 0), "size": 18},
        {"label": f"VARIATION {year}", "value": _signed_eur(ytd), "size": 18,
         "color": deck.c.primary if ytd >= 0 else deck.c.negative,
         "sub": _signed_pct(ytd_pct)},
        {"label": "MOIS COUVERTS", "value": str(len(history)), "size": 18,
         "sub": "moyenne mensuelle "
                + _signed_pct(sum(h["change_pct"] for h in history
                                  if h["change_pct"] is not None)
                              / max(1, len([h for h in history
                                            if h["change_pct"] is not None])))},
    ], top=Inches(1.5), height=Inches(1.05))
    deck.chart(
        slide, XL_CHART_TYPE.COLUMN_CLUSTERED, [h["label"] for h in history],
        f"Variation mensuelle (%)", [h["change_pct"] or 0.0 for h in history],
        top=Inches(2.8), left=MARGIN, width=Inches(5.95), height=Inches(3.0),
        legend=False, data_labels=True, gap_width=60, number_format='+0.0"%";-0.0"%"',
        point_colors=[deck.c.primary if (h["change_pct"] or 0) >= 0 else deck.c.negative
                      for h in history],
    )
    rows = [[h["label"], _f(h["value"], 0), _signed_eur(h["change"]),
             _signed_pct(h["change_pct"]), _signed_eur(h["ytd"]),
             _signed_pct(h["ytd_pct"])] for h in history]
    deck.table(slide, ["Mois", "Fin de mois", "Variation", "Variation %",
                       f"Cumul {year}", f"Cumul {year} %"],
               rows, top=Inches(2.8), left=Inches(6.75), width=Inches(5.98),
               height=Inches(0.31) * (len(rows) + 1),
               col_widths=[1.25, 1.35, 1.25, 1.05, 1.25, 1.05],
               numeric_cols=(1, 2, 3, 4, 5), font_size=9)


def _slide_kpis(deck: Deck, ctx: Dict[str, Any]) -> None:
    facts = ctx["facts"]
    matrix = facts.get("performance") or {}
    pf = matrix.get("portfolio") or {}
    pnl = facts.get("pnl")
    pnl_pct = facts.get("pnl_pct")

    slide = deck.add_slide(kicker="Vue d'ensemble", heading="Indicateurs cles")
    deck.kpi_row(slide, [
        {"label": "Actifs sous gestion", "value": eur(facts["aum"], 0),
         "sub": f"dont {eur(facts['cash'], 0)} de liquidites"},
        {"label": "Valeur des titres", "value": eur(facts["market_value"], 0),
         "sub": f"{facts['positions']} positions"},
        {"label": "P&L latent", "value": eur(pnl, 0),
         "sub": _signed_pct(pnl_pct), "color": deck.c.primary if safe_num(pnl) >= 0 else deck.c.negative},
        {"label": "Reseau", "value": f"{facts['clients']} / {facts['accounts']}",
         "sub": "clients / comptes", "size": 20},
    ])


def _slide_performance(deck: Deck, ctx: Dict[str, Any]) -> None:
    """Rendues par periode, et repartition des titres par classe d'actifs."""
    facts = ctx["facts"]
    matrix = facts.get("performance") or {}
    pf = matrix.get("portfolio") or {}
    slide = deck.add_slide(kicker="Performance", heading="Evolution du portefeuille")
    deck.kpi_row(slide, [
        {"label": label, "value": _signed_pct(pf.get(key)), "size": 17}
        for key, label in _PERIODS
    ], top=deck.content_top(), height=Inches(1.05))
    deck.chart(
        slide, XL_CHART_TYPE.COLUMN_CLUSTERED,
        [label for _, label in _PERIODS], "Performance (%)",
        [safe_num(pf.get(k)) for k, _ in _PERIODS],
        top=Inches(4.25), left=MARGIN, width=Inches(5.9), height=Inches(2.45),
        legend=False, data_labels=True, gap_width=60,
        number_format='+0.0;-0.0', axis_title="%",
        point_colors=[deck.c.primary if safe_num(pf.get(k)) >= 0 else deck.c.negative for k, _ in _PERIODS],
    )
    deck.table(
        slide,
        ["Classe d'actifs", "Valorisation", "Poids"],
        [
            [r["label"], eur(r["value"], 0),
             _pct_or_dash(r["value"] / facts["market_value"] * 100
                          if facts["market_value"] else 0)]
            for r in (facts.get("by_class") or [])
        ],
        top=Inches(4.25), left=Inches(6.8), width=Inches(5.93), height=Inches(1.8),
        col_widths=[3, 1.6, 1.1], numeric_cols=(1, 2), font_size=9,
    )
    _textbox(slide, Inches(6.8), Inches(6.2), Inches(5.93), Inches(0.5),
             "Repartition des titres par classe, hors liquidites "
             f"({eur(facts['cash'], 0)} en comptes especes).", size=8, italic=True,
             color=deck.c.muted, font=deck.font)


def _slide_allocation(deck: Deck, ctx: Dict[str, Any]) -> None:
    facts = ctx["facts"]
    by_class = facts.get("by_class") or []
    by_sector = facts.get("by_sector") or []
    if not by_class and not by_sector:
        return
    slide = deck.add_slide(kicker="Allocation", heading="Repartition des actifs")

    if by_class:
        # camembert sur l'AuM complet : les liquidités sont une tranche à part,
        # sans elles le total affiché ne correspond pas à l'Actif sous gestion
        slices = [{"label": r["label"], "value": safe_num(r["value"])} for r in by_class]
        if safe_num(facts.get("cash")) > 0:
            slices.append({"label": "Liquidites", "value": safe_num(facts["cash"])})
        total = sum(r["value"] for r in slices) or 1.0
        deck.chart(slide, XL_CHART_TYPE.PIE, [r["label"] for r in slices],
                   "Valorisation", [r["value"] for r in slices],
                   top=Inches(1.5), left=MARGIN, width=Inches(5.9),
                   height=Inches(3.3), legend=True, data_labels=True)
        deck.table(
            slide,
            ["Classe", "Montant", "Poids", "P&L %"],
            [[r["label"], eur(r["value"], 0), _pct_or_dash(r["value"] / total * 100),
              _signed_pct(_class_pnl_pct(ctx, r["label"]))]
             for r in slices]
            + [["TOTAL AuM", eur(total, 0), "100,00 %", _signed_pct(facts.get("pnl_pct"))]],
            top=Inches(1.5), left=Inches(6.8), width=Inches(5.93),
            height=Inches(0.3) * (len(slices) + 2),
            col_widths=[2.4, 1.6, 1.1, 1.1], numeric_cols=(1, 2, 3), font_size=9,
        )
    if by_sector:
        deck.chart(slide, XL_CHART_TYPE.BAR_CLUSTERED,
                   [r["label"] for r in by_sector][:8],
                   "Valorisation (k€)",
                   [safe_num(r["value"]) / 1000 for r in by_sector][:8],
                   top=Inches(5.15), left=MARGIN, width=Inches(12.13),
                   height=Inches(1.8), legend=False, data_labels=True, gap_width=45,
                   number_format='#,##0')
        _textbox(slide, MARGIN, Inches(4.88), Inches(9), Inches(0.25),
                 "Valorisation des titres par secteur economique", size=9, bold=True,
                 color=deck.c.accent, font=deck.font)


def _slide_account_types(deck: Deck, ctx: Dict[str, Any]) -> None:
    """Les types de compte : volumes, P&L, structure titres / liquidités."""
    facts = ctx["facts"]
    types = facts.get("by_account_type") or []
    if not types:
        return
    slide = deck.add_slide(kicker="Comptes", heading="Repartition par type de compte")

    deck.chart(
        slide, XL_CHART_TYPE.COLUMN_CLUSTERED, [t["label"] for t in types],
        "Valeur totale (k€)", [safe_num(t["total_value"]) / 1000 for t in types],
        top=Inches(1.5), left=MARGIN, width=Inches(5.9), height=Inches(3.0),
        legend=False, data_labels=True, gap_width=55, number_format='#,##0',
        axis_title="k€",
    )
    deck.chart(
        slide, XL_CHART_TYPE.BAR_CLUSTERED, [t["label"] for t in types],
        "P&L latent (k€)", [safe_num(t["pnl"]) / 1000 for t in types],
        top=Inches(1.5), left=Inches(6.8), width=Inches(5.93), height=Inches(3.0),
        legend=False, data_labels=True, gap_width=55, number_format='#,##0',
        point_colors=[deck.c.primary if safe_num(t["pnl"]) >= 0 else deck.c.negative
                      for t in types],
    )

    rows = []
    for t in types:
        rows.append([
            t["label"], str(t["accounts"]), str(t["positions"]),
            eur(t["market_value"], 0), eur(t["cash"], 0), eur(t["total_value"], 0),
            _pct_or_dash(t["weight"]), _pct_or_dash(t["cash_weight"]),
            eur(t["pnl"], 0), _signed_pct(t["pnl_pct"]),
            _signed_pct(t.get("ytd")), _signed_pct(t.get("1y")),
        ])
    rows.append([
        "TOTAL", str(facts["accounts"]), str(facts["positions"]),
        eur(facts["market_value"], 0), eur(facts["cash"], 0), eur(facts["aum"], 0),
        "100,00 %",
        _pct_or_dash(safe_num(facts["cash"]) / facts["aum"] * 100
                     if facts["aum"] else 0),
        eur(facts["pnl"], 0), _signed_pct(facts.get("pnl_pct")),
        _signed_pct((facts.get("performance") or {}).get("portfolio", {}).get("ytd")),
        _signed_pct((facts.get("performance") or {}).get("portfolio", {}).get("1y")),
    ])
    deck.table(
        slide,
        ["Type de compte", "Cptes", "Pos.", "Titres", "Liquidites", "Total", "Poids",
         "% cash", "P&L", "P&L %", "YTD", "1 an"],
        rows, top=Inches(4.75), height=Inches(0.28) * (len(rows) + 1),
        col_widths=[1.9, 0.7, 0.7, 1.3, 1.2, 1.3, 0.8, 0.8, 1.2, 0.9, 0.9, 0.9],
        numeric_cols=tuple(range(1, 12)), font_size=8,
    )


def _slide_account_type_allocation(deck: Deck, ctx: Dict[str, Any]) -> None:
    """Contenu de chaque type de compte : allocation par classe et principaux titres."""
    facts = ctx["facts"]
    types = facts.get("by_account_type") or []
    tops = facts.get("top_by_account_type") or []
    if not types:
        return
    classes = [r["label"] for r in (facts.get("by_class") or [])][:6]
    slide = deck.add_slide(kicker="Comptes", heading="Contenu par type de compte")
    # un compte « espèces » n'a aucune valeur à empiler : il ferait une barre vide
    held = [t for t in types if t["positions"] > 0] or types
    if classes:
        series = [(label, [safe_num(t["classes"].get(label)) / 1000 for t in held])
                  for label in classes]
        series = [s for s in series if any(s[1])]
        if series:
            deck.chart(slide, XL_CHART_TYPE.BAR_STACKED, [t["label"] for t in held],
                       "Valorisation (k€)", top=Inches(1.5), left=MARGIN,
                       width=Inches(6.5), height=Inches(4.7), legend=True,
                       data_labels=False, series=series, gap_width=50, axis_title="k€")
    if tops:
        _textbox(slide, Inches(7.4), Inches(1.5), Inches(5.33), Inches(0.3),
                 "Principaux titres par type de compte", size=9, bold=True,
                 color=deck.c.accent, font=deck.font)
        deck.table(
            slide,
            ["Type de compte", "Ticker", "Libelle", "Client", "Valorisation", "Poids"],
            [[r["account_type"], r["ticker"], (r["name"] or "")[:24],
              (r.get("client_name") or "")[:20],
              eur(r["market_value"], 0), _pct_or_dash(r["weight"])]
             for r in tops],
            top=Inches(1.85), left=Inches(7.4), width=Inches(5.33),
            height=Inches(0.28) * (len(tops) + 1),
            col_widths=[1.5, 1.1, 2.1, 1.5, 1.3, 0.8], numeric_cols=(4, 5),
            font_size=8,
        )
        _textbox(slide, Inches(7.4), Inches(1.85) + Inches(0.28) * (len(tops) + 1)
                 + Inches(0.15), Inches(5.33), Inches(1.6),
                 "Poids calcule au sein du type de compte : il indique la part du "
                 "premier titre dans les titres detenus par ce type de compte. "
                 "Le tableau se lit par type de compte, de la plus_large a la plus "
                 "reductrice.", size=8, italic=True, color=deck.c.muted, font=deck.font)


def _slide_evolution(deck: Deck, ctx: Dict[str, Any]) -> None:
    facts = ctx["facts"]
    detail = facts.get("series_detail") or []
    slide = deck.add_slide(kicker="Dynamique", heading="Evolution de l'Actif sous gestion")
    chart_slide = None
    if detail:
        labels, picked = _series_months(detail)
        if len(labels) >= 2:
            chart_slide = deck.chart(
                slide, XL_CHART_TYPE.LINE, labels, top=Inches(1.55), left=MARGIN,
                width=Inches(8.4), height=Inches(4.6), legend=True, series=[
                    ("Titres (M€)", [picked[m]["market_value"] / 1e6 for m in labels]),
                    ("Liquidites (M€)", [picked[m]["cash"] / 1e6 for m in labels]),
                    ("AuM total (M€)", [picked[m]["total_value"] / 1e6 for m in labels]),
                ])
    if chart_slide is None:
        labels, values = _series_points(facts.get("series") or [])
        if len(labels) < 2:
            return
        deck.chart(slide, XL_CHART_TYPE.LINE_MARKERS, labels, "AuM (M€)", values,
                   top=Inches(1.55), left=MARGIN, width=Inches(8.4),
                   height=Inches(4.6), legend=False, data_labels=False)

    if chart_slide is not None:
        labels, picked = _series_months(detail)
        values = [picked[m]["total_value"] / 1e6 for m in labels]
    else:
        _, values = _series_points(facts.get("series") or [])
    first, last = values[0], values[-1]
    variation = ((last - first) / first * 100) if first else 0.0
    deck.table(
        slide,
        ["Indicateur", "Valeur"],
        [[" Debut de periode", f"{_f(first)} M€"],
         [" Fin de periode", f"{_f(last)} M€"],
         [" Variation", _signed_pct(variation)],
         [" Liquidites", eur(facts["cash"], 0)],
         [" Valeur des titres", eur(facts["market_value"], 0)]],
        top=Inches(1.55), left=Inches(9.3), width=Inches(3.4),
        col_widths=[1.9, 1.5], numeric_cols=(1,), font_size=9,
    )


def _slide_concentration(deck: Deck, ctx: Dict[str, Any], limit: int = 10) -> None:
    """Les plus grosses positions et leur performance, en graphique."""
    facts = ctx["facts"]
    holdings = ctx["report"].get("holdings") or []
    ranked = sorted(holdings, key=lambda h: -safe_num(h.get("market_value")))[:limit]
    if len(ranked) < 2:
        return
    slide = deck.add_slide(kicker="Concentration",
                           heading=f"Principales positions (sur {facts['positions']})")
    mv_total = facts.get("market_value") or 0
    deck.chart(
        slide, XL_CHART_TYPE.BAR_CLUSTERED,
        [str(h.get("ticker", ""))[:16] for h in ranked],
        "Valorisation (k€)", [safe_num(h.get("market_value")) / 1000 for h in ranked],
        top=Inches(1.5), left=MARGIN, width=Inches(6.5), height=Inches(4.7),
        legend=False, data_labels=True, gap_width=45, number_format='#,##0',
        axis_title="k€",
    )
    with_pnl = [h for h in ranked if h.get("pnl_pct") is not None]
    if with_pnl:
        deck.chart(
            slide, XL_CHART_TYPE.BAR_CLUSTERED,
            [str(h.get("ticker", ""))[:16] for h in with_pnl],
            "P&L %", [safe_num(h.get("pnl_pct")) for h in with_pnl],
            top=Inches(1.5), left=Inches(7.4), width=Inches(5.33), height=Inches(4.7),
            legend=False, data_labels=True, gap_width=45, number_format='+0.0;-0.0',
            axis_title="%",
            point_colors=[deck.c.primary if safe_num(h.get("pnl_pct")) >= 0 else deck.c.negative
                          for h in with_pnl],
        )
    top_sum = sum(safe_num(h.get("market_value")) for h in ranked)
    _textbox(slide, MARGIN, Inches(6.4), Inches(12.13), Inches(0.35),
             f"Les {len(ranked)} premieres positions representent "
             f"{_pct_or_dash(top_sum / mv_total * 100 if mv_total else 0)} de la "
             f"valorisation des titres ({eur(top_sum, 0)}). A droite : performance "
             "realisee de chaque position.", size=9, italic=True, color=deck.c.muted, font=deck.font)


def _slide_positions(deck: Deck, ctx: Dict[str, Any], limit: int = 12) -> None:
    facts = ctx["facts"]
    ranked = sorted((facts.get("top_positions") or []),
                    key=lambda h: -safe_num(h.get("market_value")))
    rows = ranked[:limit]
    if not rows:
        return
    slide = deck.add_slide(kicker="Positions", heading=f"Principales positions "
                                                    f"(sur {len(ranked)})")
    mv_total = facts.get("market_value") or 0
    deck.table(
        slide,
        ["Ticker", "Valeur", "Classe", "Secteur", "Valorisation", "Poids", "P&L", "P&L %"],
        [[h.get("ticker", ""), h.get("name", "")[:34],
          h.get("asset_class", ""), (h.get("sector") or "")[:18],
          eur(h.get("market_value"), 0),
          _pct_or_dash(safe_num(h.get("market_value")) / mv_total * 100
                       if mv_total else 0),
          eur(h.get("total_pnl"), 0), _signed_pct(h.get("pnl_pct"))]
         for h in rows],
        top=deck.content_top(), height=Inches(0.3) * (len(rows) + 1),
        col_widths=[1.0, 3.0, 1.2, 1.4, 1.4, 0.8, 1.2, 0.9],
        numeric_cols=(4, 5, 6, 7), font_size=8,
    )


def _slide_accounts(deck: Deck, ctx: Dict[str, Any], limit: int = 14) -> None:
    facts = ctx["facts"]
    accounts = facts.get("accounts_detail") or {}
    matrix = facts.get("performance") or {}
    if not accounts:
        return
    rows = []
    for aid, a in sorted(accounts.items(),
                         key=lambda kv: -safe_num(kv[1].get("total_value")))[:limit]:
        perf = matrix.get(aid) or {}
        rows.append([
            a.get("client_name", ""), a.get("account_name", ""),
            (a.get("account_type") or "").upper(), a.get("currency", ""),
            eur(a.get("total_value"), 0), eur(a.get("pnl"), 0),
            _signed_pct(a.get("pnl_pct")),
            _signed_pct(perf.get("1m")), _signed_pct(perf.get("ytd")),
            _signed_pct(perf.get("1y")),
        ])
    slide = deck.add_slide(kicker="Comptes", heading="Performance par compte")
    deck.table(
        slide,
        ["Client", "Compte", "Type", "Dev.", "Valeur totale", "P&L", "P&L %",
         "1 mois", "YTD", "1 an"],
        rows, top=deck.content_top(), height=Inches(0.29) * (len(rows) + 1),
        col_widths=[2.1, 2.1, 0.7, 0.6, 1.4, 1.2, 0.9, 0.9, 0.9, 0.9],
        numeric_cols=(4, 5, 6, 7, 8, 9), font_size=8,
    )


def _slide_account_charts(deck: Deck, ctx: Dict[str, Any], limit: int = 10) -> None:
    """Concentration des comptes : taille et performance des plus gros comptes."""
    facts = ctx["facts"]
    accounts = facts.get("accounts_detail") or {}
    if len(accounts) < 2:
        return
    matrix = facts.get("performance") or {}
    ranked = sorted(accounts.items(),
                    key=lambda kv: -safe_num(kv[1].get("total_value")))[:limit]
    slide = deck.add_slide(kicker="Comptes", heading="Les plus gros comptes du portefeuille")
    labels = [f"{a.get('account_name', aid)}"[:20] for aid, a in ranked]
    deck.chart(slide, XL_CHART_TYPE.BAR_CLUSTERED, labels,
               "Valeur totale (k€)",
               [safe_num(a.get("total_value")) / 1000 for _, a in ranked],
               top=Inches(1.5), left=MARGIN, width=Inches(6.5), height=Inches(4.7),
               legend=False, data_labels=True, gap_width=45, number_format='#,##0',
               axis_title="k€")
    deck.chart(slide, XL_CHART_TYPE.BAR_CLUSTERED, labels, "P&L %",
               [safe_num(a.get("pnl_pct")) for _, a in ranked],
               top=Inches(1.5), left=Inches(7.4), width=Inches(5.33), height=Inches(4.7),
               legend=False, data_labels=True, gap_width=45, number_format='+0.0;-0.0',
               axis_title="%",
               point_colors=[deck.c.primary if safe_num(a.get("pnl_pct")) >= 0 else deck.c.negative
                             for _, a in ranked])
    top_sum = sum(safe_num(a.get("total_value")) for _, a in ranked)
    best = max(ranked, key=lambda kv: safe_num((matrix.get(kv[0]) or {}).get("1y")))
    _textbox(slide, MARGIN, Inches(6.4), Inches(12.13), Inches(0.35),
             f"Les {len(ranked)} plus gros comptes representent "
             f"{_pct_or_dash(top_sum / facts['aum'] * 100 if facts['aum'] else 0)} "
             f"de l'AuM. Meilleure performance annuelle : {best[1].get('account_name', '')} "
             f"({_signed_pct((matrix.get(best[0]) or {}).get('1y'))} sur 1 an).",
             size=9, italic=True, color=deck.c.muted, font=deck.font)


def _slide_clients(deck: Deck, ctx: Dict[str, Any]) -> None:
    facts = ctx["facts"]
    clients = facts.get("clients_detail") or []
    if not clients or len(clients) < 2:
        return
    matrix = facts.get("performance_by_client") or facts.get("performance") or {}
    rows = []
    for c in sorted(clients, key=lambda c: -safe_num(c.get("aum"))):
        perf = matrix.get(c.get("id")) or {}
        rows.append([
            c.get("name", ""), c.get("risk_profile", ""),
            f"{c.get('accounts', 0)} / {c.get('positions', 0)}",
            eur(c.get("aum"), 0), _pct_or_dash(
                safe_num(c.get("aum")) / facts["aum"] * 100 if facts["aum"] else 0),
            eur(c.get("pnl"), 0), _signed_pct(c.get("pnl_pct")),
            _signed_pct(perf.get("ytd")), _signed_pct(perf.get("1y")),
        ])
    slide = deck.add_slide(kicker="Synthese", heading="Repartition par client")
    ordered = sorted(clients, key=lambda c: -safe_num(c.get("aum")))
    deck.table(
        slide,
        ["Client", "Profil", "Comptes / pos.", "AuM", "Poids", "P&L", "P&L %",
         "YTD", "1 an"],
        rows, top=deck.content_top(), height=Inches(0.28) * (len(rows) + 1),
        col_widths=[2.6, 1.2, 1.4, 1.5, 0.8, 1.3, 0.9, 0.9, 0.9],
        numeric_cols=(3, 4, 5, 6, 7, 8), font_size=9,
    )
    top = deck.content_top() + Inches(0.28) * (len(rows) + 1) + Inches(0.2)
    deck.chart(slide, XL_CHART_TYPE.BAR_CLUSTERED,
               [str(c.get("name", ""))[:22] for c in ordered[:8]],
               "AuM par client (k€)",
               [safe_num(c.get("aum")) / 1000 for c in ordered[:8]],
               top=top, left=MARGIN, width=Inches(12.13),
               height=Inches(6.7) - top, legend=False, data_labels=True,
               gap_width=40, number_format='#,##0', axis_title="k€")


def _slide_commentary(deck: Deck, ctx: Dict[str, Any], text: str,
                      model: str = "", warning: str = "") -> None:
    blocks = verify.commentary_blocks(text)
    if not blocks and text:
        blocks = [{"title": "", "text": text}]
    if not blocks:
        return
    slide = deck.add_slide(kicker="Analyse", heading="Commentaire de l'analyseur",
                           numbered=False)
    deck.bullets(slide, blocks, top=deck.content_top(), font_size=12, gap=6)
    note = ("Redige par un modele local ("
            + (model or "GGUF") + "), a partir des seules donnees du portefeuille.")
    if warning:
        note += " Attention : " + warning
    _textbox(slide, MARGIN, SLIDE_H - Inches(0.75), SLIDE_W - 2 * MARGIN,
             Inches(0.3), note, size=8, italic=True, color=deck.c.muted,
             font=deck.font)


# ------------------------------------------------------------------ point d'entrée
def _compose(deck: Deck, ctx: Dict[str, Any], model: str, commentary: Optional[str],
             year: int, toc: Optional[Sequence[Dict[str, Any]]] = None) -> list:
    """Rend les diapositives dans l'ordre et renvoie le plan des rubriques.

    Une diapositive peut décider de ne pas se rendre (donnée absente) : le plan
    est donc mesuré sur le rendu réel, pas sur une liste théorique. La première
    passe collecte le plan, la seconde l'affiche dans la table des matieres.
    """
    facts = ctx["facts"]
    found: list = list(toc) if toc is not None else []

    def render(title: str, fn, *args) -> int:
        before = len(deck.prs.slides)
        fn(*args)
        added = len(deck.prs.slides) - before
        if added and title and toc is None:
            found.append({"title": title, "page": before + 1, "pages": added})
        return added

    _slide_cover(deck, ctx, model)
    deck.sync_page()
    render("Perimetre et chiffres cles", _slide_scope, deck, ctx)
    _slide_toc(deck, ctx, found)

    render("Repartition par type de compte", _slide_account_types, deck, ctx)

    # Inventaire : une page par compte, un sous-total par classe d'actif.
    accounts = _securities_accounts(facts)
    pages_by_account = [(a, _inventory_pages(a)) for a in accounts]
    pages_by_account = [(a, p) for a, p in pages_by_account if p]
    if pages_by_account:
        title = ("Inventaire — %d comptes" % len(pages_by_account)
                 if len(pages_by_account) > 1
                 else f"Inventaire — {pages_by_account[0][0].get('account_name')}")
        render(title, lambda: [
            _slide_inventory(deck, ctx, account, page, part, len(pages))
            for account, pages in pages_by_account
            for part, page in enumerate(pages, start=1)])

    render(f"Performances mensuelles {year}", _slide_monthly, deck, ctx, year)

    render("Contenu par type de compte", _slide_account_type_allocation, deck, ctx)
    render("Vue d'ensemble", _slide_kpis, deck, ctx)
    render("Evolution du portefeuille", _slide_performance, deck, ctx)
    render("Repartition des actifs", _slide_allocation, deck, ctx)
    render("Evolution de l'Actif sous gestion", _slide_evolution, deck, ctx)
    render("Concentration", _slide_concentration, deck, ctx)
    render("Principales positions", _slide_positions, deck, ctx)
    render("Les plus gros comptes", _slide_accounts, deck, ctx)
    render("Performance par compte", _slide_account_charts, deck, ctx)
    render("Repartition par client", _slide_clients, deck, ctx)
    render("Commentaire de l'analyseur", _slide_commentary, deck, ctx, commentary, model)
    return found


def build_pptx(client_id: str = "", commentary: Optional[str] = None,
               detail: str = "standard", model: str = "",
               brand: Optional[Dict[str, Any]] = None,
               template: Optional[str] = None,
               year: Optional[int] = None) -> tuple:
    """Construit la présentation et renvoie `(octets, nom_de_fichier)`.

    `brand` et `template` sont résolus par défaut depuis `wm.ai.brand` : la
    charte intégrée s'applique, et le modèle corporate importé remplace le
    document vierge. `year` fixe l'année de l'historique mensuel (par défaut
    l'année en cours).
    """
    ctx = build_context(client_id, detail=detail)
    scope = ctx["scope"]
    year = int(year) if year else datetime.now().year

    effective = brand or brand_mod.load_brand()
    template_path = template or brand_mod.template_path(effective)

    def new_deck() -> Deck:
        return Deck("Synthese des actifs", scope, brand=effective,
                    template=str(template_path) if template_path else None)

    # Passe 1 : on mesure le plan réel pourque le sommaire affiche les bons
    # numéros de page. Passe 2 : rendu définitif.
    plan = _compose(new_deck(), ctx, model, commentary, year)
    deck = new_deck()
    _compose(deck, ctx, model, commentary, year, toc=plan)

    stamp = datetime.now().strftime("%Y%m%d-%H%M")
    label = "global" if not client_id else f"client-{client_id}"
    return deck.save(), f"synthese-{label}-{stamp}.pptx"
