"""Fonctions métier partagées par les endpoints."""

from .reporting import build_factsheet_report, build_report
from .dashboard import build_dashboard

__all__ = ["build_dashboard", "build_report", "build_factsheet_report"]
