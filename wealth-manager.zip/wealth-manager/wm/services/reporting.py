"""Rapport de performance, matrices de périodes et factsheets."""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional

import pandas as pd

from .. import storage
from ..serialization import df_to_json, safe_num
from .dashboard import scope_client

_PERIOD_DAYS = {
    "1m": 30,
    "3m": 91,
    "6m": 183,
    "1y": 365,
}


def resolve_period(period: str = "all", start: str = "", end: str = "") -> tuple[Optional[date], date]:
    """Traduit `period`/`start`/`end` en fenêtre de dates (start=None = tout)."""
    today = datetime.now().date()
    try:
        end_d = datetime.strptime(end, "%Y-%m-%d").date() if end else today
    except ValueError:
        end_d = today
    if start:
        try:
            start_d: Optional[date] = datetime.strptime(start, "%Y-%m-%d").date()
        except ValueError:
            start_d = None
    else:
        if period == "ytd":
            start_d = date(end_d.year, 1, 1)
        else:
            days = _PERIOD_DAYS.get(period)
            start_d = end_d - timedelta(days=days) if days else None
    return start_d, end_d


def build_report(
    client_id: str = "",
    period: str = "all",
    start: str = "",
    end: str = "",
) -> Dict[str, Any]:
    """Charge utile de `GET /api/report`."""
    clients = df_to_json(storage.load_clients())
    accounts = df_to_json(storage.load_accounts())
    holdings = storage.enrich_holdings(storage.load_holdings())
    valuation = storage.load_valuation()

    start_d, end_d = resolve_period(period, start, end)

    context_client, clients, accounts, holdings, valuation = scope_client(
        client_id, clients, accounts, holdings, valuation)

    acct_map = {a["id"]: a for a in accounts}
    cash_map = {a["id"]: safe_num(a.get("cash")) for a in accounts}
    client_map = {c["id"]: c for c in clients}

    holdings_rows: List[Dict[str, Any]] = []
    for r in holdings.to_dict("records"):
        a = acct_map.get(r["account_id"], {})
        holdings_rows.append({
            **r,
            "account_name": a.get("account_name", ""),
            "client_id": a.get("client_id", ""),
            "client_name": client_map.get(a.get("client_id"), {}).get("name", ""),
            "market_value": round(r["market_value"], 2),
            "cost_value": round(r["cost_value"], 2),
            "total_pnl": round(r["total_pnl"], 2),
            "pnl_pct": round(r["pnl_pct"], 2),
            "weight_pct": round(r["weight_pct"], 2),
        })

    # regroup by account
    account_report: Dict[str, Dict[str, Any]] = {
        a["id"]: {
            "account_id": a["id"],
            "client_id": a.get("client_id", ""),
            "client_name": client_map.get(a.get("client_id", ""), {}).get("name", ""),
            "account_name": a.get("account_name", a["id"]),
            "account_type": a.get("account_type", ""),
            "currency": a.get("currency", ""),
            "positions": [],
            "mv": 0.0, "cost": 0.0, "pnl": 0.0,
        } for a in accounts
    }
    for r in holdings_rows:
        aid = r["account_id"]
        row = account_report.setdefault(aid, {
            "account_id": aid,
            "client_id": r["client_id"],
            "client_name": r["client_name"],
            "account_name": r["account_name"],
            "account_type": "",
            "positions": [],
            "mv": 0.0, "cost": 0.0, "pnl": 0.0,
        })
        row["positions"].append(r)
        row["mv"] += r["market_value"]
        row["cost"] += r["cost_value"]
        row["pnl"] += r["total_pnl"]

    for aid, row in account_report.items():
        row["cash"] = cash_map.get(aid, 0.0)
        row["total_value"] = round(row["mv"] + row["cash"], 2)
        row["mv"] = round(row["mv"], 2)
        row["cost"] = round(row["cost"], 2)
        row["pnl"] = round(row["pnl"], 2)
        row["pnl_pct"] = round(row["pnl"] / row["cost"] * 100, 2) if row["cost"] else 0.0
        row["positions"].sort(key=lambda p: -p["market_value"])
        row["positions"] = row["positions"][:15]

    # clients report
    client_report = []
    for c in clients:
        ca = [acct_map[a] for a in acct_map if acct_map[a]["client_id"] == c["id"]]
        ch = [r for r in holdings_rows if r["client_id"] == c["id"]]
        mv = sum(r["market_value"] for r in ch)
        cost = sum(r["cost_value"] for r in ch)
        pnl = sum(r["total_pnl"] for r in ch)
        cash = sum(cash_map.get(a["id"], 0.0) for a in ca)
        client_report.append({
            **c,
            "risk_label": storage.RISK_LABELS.get(c.get("risk_profile", ""), ""),
            "accounts": len(ca),
            "positions": len(ch),
            "aum": round(mv + cash, 2),
            "market_value": round(mv, 2),
            "cash": round(cash, 2),
            "pnl": round(pnl, 2),
            "pnl_pct": round(pnl / cost * 100, 2) if cost else 0.0,
            "accounts_detail": account_report,
        })

    # performance per account from valuation series (within selected period)
    perf: Dict[str, Dict[str, Any]] = {}
    if not valuation.empty:
        v = valuation.copy()
        v["total_value"] = pd.to_numeric(v["total_value"], errors="coerce")
        v["date"] = v["date"].astype(str)
        dmin = start_d.isoformat() if start_d else None
        dmax = end_d.isoformat()
        for aid, g in v.groupby("account_id"):
            g = g.sort_values("date")
            if dmin:
                g = g[(g["date"] >= dmin) & (g["date"] <= dmax)]
            else:
                g = g[g["date"] <= dmax]
            if len(g) >= 2:
                first = float(g.iloc[0]["total_value"])
                last = float(g.iloc[-1]["total_value"])
                perf[aid] = {
                    "start": g.iloc[0]["date"],
                    "end": g.iloc[-1]["date"],
                    "start_value": round(first, 2),
                    "end_value": round(last, 2),
                    "growth": round(last - first, 2),
                    "growth_pct": round((last / first - 1) * 100, 2) if first else 0.0,
                }

    return {
        "generated_at": datetime.now().isoformat(),
        "period": {
            "key": period,
            "start": start_d.isoformat() if start_d else None,
            "end": end_d.isoformat(),
        },
        "total_aum": round(sum(r["mv"] for r in account_report.values())
                           + sum(cash_map.values()), 2),
        "total_pnl": round(sum(r["pnl"] for r in account_report.values()), 2),
        "context_client": context_client,
        "clients": client_report,
        "accounts": account_report,
        "holdings": holdings_rows,
        "performance": perf,
    }


# ------------------------------------------------------------------ factsheet
def period_matrix(
    valuation: pd.DataFrame,
    accounts: Dict[str, Any],
    today: date,
    group_map: Optional[Dict[str, str]] = None,
) -> Dict[str, Dict[str, Optional[float]]]:
    """Variation % sur 1m/3m/6m/YTD/1an, par compte (ou par groupe via `group_map`)."""
    periods = {"1m": 30, "3m": 91, "6m": 183, "ytd": None, "1y": 365}
    rows: Dict[str, Dict[str, Optional[float]]] = {}
    if valuation.empty:
        return rows
    v = valuation.copy()
    v["total_value"] = pd.to_numeric(v["total_value"], errors="coerce")
    v["date"] = v["date"].astype(str)
    if accounts:
        v = v[v["account_id"].isin(set(accounts.keys()))]
    if group_map:
        v["_g"] = v["account_id"].map(group_map).fillna("?")
        groups = list(v.groupby("_g"))
    else:
        groups = list(v.groupby("account_id"))
    daily = v.groupby("date")["total_value"].sum().reset_index().sort_values("date")
    if not daily.empty:
        groups.append(("portfolio", daily))
    for aid, g in groups:
        g = g.groupby("date", as_index=False)["total_value"].sum().sort_values("date")
        row: Dict[str, Optional[float]] = {}
        for key, days in periods.items():
            d0 = (today - timedelta(days=days)).isoformat() if days else f"{today.year}-01-01"
            d1 = today.isoformat()
            seg = g[(g["date"] >= d0) & (g["date"] <= d1)]
            if len(seg) >= 2:
                f = float(seg.iloc[0]["total_value"])
                last = float(seg.iloc[-1]["total_value"])
                row[key] = round((last / f - 1) * 100, 2) if f else None
            else:
                row[key] = None
        rows[aid] = row
    return rows


def global_series(valuation: pd.DataFrame, accounts: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Série de valorisation agrégée (tous comptes) pour le graphique de synthèse."""
    if valuation.empty:
        return []
    v = valuation.copy()
    v["total_value"] = pd.to_numeric(v["total_value"], errors="coerce")
    v["date"] = v["date"].astype(str)
    if accounts:
        v = v[v["account_id"].isin(set(accounts.keys()))]
    s = v.groupby("date")["total_value"].sum().sort_index()
    return [{"date": d, "value": round(float(x), 2)} for d, x in s.items()]


def global_series_detail(valuation: pd.DataFrame,
                         accounts: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Série agrégée éclatée en titres / liquidités (graphique multi-séries)."""
    if valuation.empty:
        return []
    v = valuation.copy()
    for col in ("market_value", "cash", "total_value"):
        v[col] = pd.to_numeric(v[col], errors="coerce")
    v["date"] = v["date"].astype(str)
    if accounts:
        v = v[v["account_id"].isin(set(accounts.keys()))]
    g = v.groupby("date")[["market_value", "cash", "total_value"]].sum()
    rows: List[Dict[str, Any]] = []
    for date, r in g.sort_index().iterrows():
        rows.append({
            "date": date,
            "market_value": round(float(r["market_value"]), 2),
            "cash": round(float(r["cash"]), 2),
            "total_value": round(float(r["total_value"]), 2),
        })
    return rows


def build_factsheet_report(
    client_id: str = "",
    period: str = "all",
    start: str = "",
    end: str = "",
) -> Dict[str, Any]:
    """Rapport enrichi des données nécessaires au factsheet (Excel/PDF)."""
    report = build_report(client_id=client_id, period=period, start=start, end=end)
    try:
        valuation = storage.load_valuation()
        accounts = report.get("accounts") or {}
        today = datetime.now().date()
        report["period_matrix"] = period_matrix(valuation, accounts, today)
        report["series_global"] = global_series(valuation, accounts)
        report["series_detail"] = global_series_detail(valuation, accounts)
        if report.get("context_client"):
            report["period_matrix_group"] = None
        else:
            group_map = {a.get("account_id"): a.get("client_id") for a in accounts.values()}
            report["period_matrix_group"] = period_matrix(valuation, accounts, today, group_map)
        # même regroupement par type de compte (PEA, AV, CT, espèces…) :
        # utile y compris en périmètre client, où plusieurs types coexistent
        type_map = {a.get("account_id"): (a.get("account_type") or "inconnu")
                    for a in accounts.values()}
        report["period_matrix_account_type"] = period_matrix(valuation, accounts, today, type_map)
        # add ytd_var and cash_flow_ytd per account from parquet
        perf_df = storage.load_account_perf()
        if not perf_df.empty:
            perf_map = {r["account_id"]: r for r in perf_df.to_dict("records")}
            for aid in accounts:
                p = perf_map.get(aid, {})
                accounts[aid]["ytd_var"] = p.get("ytd_var") or 0.0
                accounts[aid]["cash_flow_ytd"] = p.get("cash_flow_ytd") or 0.0
    except Exception:
        report.setdefault("period_matrix", {})
        report.setdefault("period_matrix_group", {})
        report.setdefault("period_matrix_account_type", {})
        report.setdefault("series_global", [])
        report.setdefault("series_detail", [])
    return report
