"""Agrégations du tableau de bord."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from .. import storage
from ..serialization import df_to_json, safe_num


def scope_client(
    client_id: str,
    clients: List[dict],
    accounts: List[dict],
    holdings: pd.DataFrame,
    valuation: pd.DataFrame,
) -> Tuple[Optional[dict], List[dict], List[dict], pd.DataFrame, pd.DataFrame]:
    """Restreint clients/accounts/holdings/valuation à un client donné."""
    context_client = None
    if client_id:
        for c in clients:
            if c["id"] == client_id:
                context_client = c
                break
        clients = [c for c in clients if c["id"] == client_id]
        account_ids = {a["id"] for a in accounts if a["client_id"] == client_id}
        accounts = [a for a in accounts if a["id"] in account_ids]
        if not holdings.empty:
            holdings = holdings[holdings["account_id"].isin(account_ids)]
        if not valuation.empty:
            valuation = valuation[valuation["account_id"].isin(account_ids)]
    return context_client, clients, accounts, holdings, valuation


def build_dashboard(client_id: str = "") -> Dict[str, Any]:
    """Construit la charge utile de `GET /api/dashboard`."""
    clients = df_to_json(storage.load_clients())
    accounts = df_to_json(storage.load_accounts())
    holdings = storage.enrich_holdings(storage.load_holdings())
    valuation = storage.load_valuation()

    context_client, clients, accounts, holdings, valuation = scope_client(
        client_id, clients, accounts, holdings, valuation)

    cash_map = {a["id"]: safe_num(a.get("cash")) for a in accounts}

    total_aum = float(holdings["market_value"].sum()) + sum(cash_map.values())
    total_pnl = float(holdings["total_pnl"].sum())
    cost_total = float(holdings["cost_value"].sum())

    acct_map = {a["id"]: a for a in accounts}
    client_map = {c["id"]: c for c in clients}

    # --- per-account performance from parquet ---
    account_perf: Dict[str, Dict[str, Any]] = {}
    perf_df = storage.load_account_perf()
    if not perf_df.empty:
        for r in perf_df.to_dict("records"):
            account_perf[r["account_id"]] = {
                "perf_ytd": r.get("perf_ytd"),
                "perf_1m": r.get("perf_1m"),
                "ytd_var": r.get("ytd_var"),
                "cash_flow_ytd": r.get("cash_flow_ytd"),
            }

    # per account aggregates
    per_account: Dict[str, Dict[str, Any]] = {}
    for r in holdings.to_dict("records"):
        acc = per_account.setdefault(
            r["account_id"], {"mv": 0.0, "pnl": 0.0, "cost": 0.0, "count": 0})
        acc["mv"] += r["market_value"]
        acc["pnl"] += r["total_pnl"]
        acc["cost"] += r["cost_value"]
        acc["count"] += 1

    account_rows = []
    for aid, acc in per_account.items():
        a = acct_map.get(aid, {})
        cash = cash_map.get(aid, 0.0)
        p = account_perf.get(aid, {})
        account_rows.append({
            "account_id": aid,
            "account_name": a.get("account_name", aid),
            "account_type": a.get("account_type", ""),
            "currency": a.get("currency", ""),
            "client_id": a.get("client_id", ""),
            "client_name": client_map.get(a.get("client_id"), {}).get("name", "—"),
            "market_value": round(acc["mv"], 2),
            "cash": round(cash, 2),
            "total_value": round(acc["mv"] + cash, 2),
            "pnl": round(acc["pnl"], 2),
            "pnl_pct": round(acc["pnl"] / acc["cost"] * 100, 2) if acc["cost"] else 0.0,
            "position_count": acc["count"],
            "perf_ytd": p.get("perf_ytd"),
            "perf_1m": p.get("perf_1m"),
            "ytd_var": p.get("ytd_var"),
            "cash_flow_ytd": p.get("cash_flow_ytd"),
        })

    # per client aggregates
    client_rows = []
    for c in clients:
        client_accounts = [a for a in account_rows if a["client_id"] == c["id"]]
        mv = sum(a["market_value"] for a in client_accounts)
        cash = sum(cash_map[a["id"]] for a in accounts if a["client_id"] == c["id"])
        pnl = sum(a["pnl"] for a in client_accounts)
        cost = sum(per_account[a["account_id"]]["cost"]
                   for a in client_accounts if a["account_id"] in per_account)
        client_rows.append({
            "client_id": c["id"],
            "name": c.get("name", ""),
            "risk_profile": c.get("risk_profile", ""),
            "risk_label": storage.RISK_LABELS.get(
                c.get("risk_profile", ""), c.get("risk_profile", "")),
            "advisor": c.get("advisor", ""),
            "accounts": len(client_accounts),
            "positions": sum(a["position_count"] for a in client_accounts),
            "aum": round(mv + cash, 2),
            "market_value": round(mv, 2),
            "cash": round(cash, 2),
            "pnl": round(pnl, 2),
            "pnl_pct": round(pnl / cost * 100, 2) if cost else 0.0,
        })

    # allocation by asset class & sector
    asset_class: Dict[str, float] = {}
    sector: Dict[str, float] = {}
    for r in holdings.to_dict("records"):
        ac = r["asset_class"] or "—"
        asset_class[ac] = asset_class.get(ac, 0.0) + r["market_value"]
        sec = r["sector"] or "—"
        sector[sec] = sector.get(sec, 0.0) + r["market_value"]

    allocation_by_class = [{"label": k, "value": round(v, 2)}
                           for k, v in sorted(asset_class.items(), key=lambda x: -x[1])]
    allocation_by_sector = [{"label": k, "value": round(v, 2)}
                            for k, v in sorted(sector.items(), key=lambda x: -x[1])]

    # valuation series
    valuation_series: List[Dict[str, Any]] = []
    if not valuation.empty:
        val_df = valuation.copy()
        val_df["date"] = val_df["date"].astype(str)
        val_df["total_value"] = pd.to_numeric(val_df["total_value"], errors="coerce")
        for r in val_df.to_dict("records"):
            valuation_series.append({
                "date": r["date"],
                "account_id": r["account_id"],
                "account_name": acct_map.get(
                    r["account_id"], {}).get("account_name", r["account_id"]),
                "client_id": acct_map.get(r["account_id"], {}).get("client_id", ""),
                "total_value": round(r["total_value"] or 0, 2),
                "cash": round(r["cash"] or 0, 2),
            })

    return {
        "clients_count": len(clients),
        "accounts_count": len(accounts),
        "positions_count": int(len(holdings)),
        "total_aum": round(total_aum, 2),
        "total_pnl": round(total_pnl, 2),
        "total_pnl_pct": round(total_pnl / cost_total * 100, 2) if cost_total else 0.0,
        "context_client": context_client,
        "clients": client_rows,
        "accounts": account_rows,
        "allocation_by_class": allocation_by_class,
        "allocation_by_sector": allocation_by_sector,
        "valuation": valuation_series,
        "risk_labels": storage.RISK_LABELS,
    }
