"""Conversion DataFrame / types pandas -> JSON (compatible avec l'ancien `df_to_json`)."""

from __future__ import annotations

import math
from datetime import date, datetime
from typing import Any

import numpy as np
import pandas as pd


def jsonable(value: Any) -> Any:
    """Convertit une valeur pandas/numpy en type JSON natif.

    Les `NaN` / `NaT` / `pd.NA` deviennent `None` afin de produire du JSON
    strict (contrairement à Flask qui sérialisait `NaN`).
    """
    if value is None:
        return None
    if isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        return None if math.isnan(value) or math.isinf(value) else value
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        f = float(value)
        return None if math.isnan(f) or math.isinf(f) else f
    if value is pd.NaT or value is pd.NA:
        return None
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, np.ndarray, pd.Index)):
        return [jsonable(v) for v in value]
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (bytes, bytearray)):
        return value.decode("utf-8", "replace")
    if pd.isna(value):  # pragma: no cover - types exotiques
        return None
    return value


def df_to_json(df: pd.DataFrame) -> list[dict]:
    """DataFrame -> liste de dictionnaires JSON-safe."""
    if df is None or df.empty:
        return []
    return [jsonable(r) for r in df.to_dict("records")]


def safe_num(v: Any) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0
