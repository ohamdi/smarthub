# Smart Wealth Manager

Application de gestion de patrimoine : agrégation de clients, comptes, positions et
valorisations stockées en **Parquet**, avec dashboard, reporting et factsheets
Excel/PDF, et un onglet **Analyse IA** adossé à un modèle **GGUF local**.

L'API est **FastAPI** (ASGI, Uvicorn). L'interface reste une page unique servie
depuis `static/index.html`.

## Démarrage

```bash
pip install -r requirements.txt
python main.py                    # http://localhost:5001
```

Ou avec Uvicorn directement :

```bash
uvicorn main:app --host 0.0.0.0 --port 5001 --reload
```

Identifiants par défaut : `admin` / `admin123`, `gestionnaire` / `wealth123`.

### Variables d'environnement

| Variable | Défaut | Rôle |
|---|---|---|
| `WM_HOST` | `0.0.0.0` | Interface d'écoute |
| `WM_PORT` | `5001` | Port |
| `WM_RELOAD` | `0` | `1` active le rechargement à chaud |
| `WM_SECRET_KEY` | `.session_key` | Clé de signature des sessions |
| `WM_HTTPS_ONLY` | `0` | `1` restreint le cookie de session à HTTPS |

## Documentation de l'API

- Swagger UI : <http://localhost:5001/api/docs>
- ReDoc : <http://localhost:5001/api/redoc>
- Schéma OpenAPI : <http://localhost:5001/api/openapi.json>

## Analyse IA (modèle GGUF local)

L'onglet **Analyse IA** interroge un modèle **local au format GGUF** via
`llama-cpp-python`. Aucune donnée ne sort de la machine : le modèle tourne en
processus dans le serveur, il n'y a aucun appel réseau.

Le modèle ne reçoit **que des faits calculés** à partir des fichiers Parquet
(indicateurs, **ventilation par type de compte**, allocation, positions,
performances, synthèse par client), assemblés par priorité selon le niveau
de détail choisi :

| Niveau | Contexte | Usage |
|---|---|---|
| `rapide` | ~2 700 caractères | Question simple, première réponse |
| `standard` | ~5 400 caractères | Défaut |
| `complet` | ~11 100 caractères | Analyse approfondie |

Fonctions :

- **Questions en langage naturel** sur le périmètre courant (tous les clients
  ou un client), avec historique de conversation ;
- **Présentation PPTX** de synthèse des actifs : couverture, sommaire,
  **inventaire compte par compte** (un sous-total par classe d'actifs),
  **historique des performances mensuelles de l'année en cours**, puis
  l'analyse par type de compte (PEA, assurance vie, compte titres,
  compte espèces, immobilier) ;
- **Contrôle des chiffres** : chaque montant et chaque sigle cité par le
  modèle est confronté aux données. Ce qui n'existe pas est signalé par un
  bandeau « À vérifier » — un modèle 3B peut tronquer un montant
  (`7 666 784` → `766 784`) et il faut le savoir ;
- **Aperçu du contexte** : le bouton « Voir les données envoyées au modèle »
  affiche exactement le bloc transmis.

### Contenu de la présentation

Le deck suit l'ordre de lecture d'un inventaire : on cadre, on liste, on
regarde l'historique, puis on analyse.

| # | Diapositive | Graphiques | Contenu |
|---|---|---|---|
| 1 | Couverture | — | logo, « Synthèse des actifs », date du jour |
| 2 | Périmètre | — | ce que couvre le deck : AuM, titres, liquidités, performance |
| 3 | Table des matières | — | chaque rubrique avec sa ou ses pages |
| 4 | **Répartition par type de compte** | 2 | valeur et P&L latent par type de compte + tableau détaillé (comptes, positions, titres, liquidités, poids, % cash, P&L, YTD, 1 an) |
| 5… | **Inventaire, un compte par page** | — | positions groupées par classe d'actifs, **sous-total par classe**, sous-total titres et total du compte (titres + liquidités) |
| … | **Performances mensuelles** | 1 | variation mensuelle en % de l'année en cours + tableau fin de mois, variation, variation %, cumul, cumul % |
| … | Contenu par type de compte | 1 | allocation empilée par classe et par type de compte + principaux titres de chaque type |
| … | Vue d'ensemble | — | AuM, titres, P&L latent, réseau |
| … | Performance | 1 | 1 mois / 3 mois / 6 mois / YTD / 1 an en colonnes + allocation par classe |
| … | Répartition des actifs | 2 | camembert des classes **sur l'AuM complet** (liquidités incluses) + barres par secteur |
| … | Évolution de l'AuM | 1 | 3 courbes : titres, liquidités, AuM total (agrégées par mois) |
| … | Concentration | 2 | valorisation et P&L % des 10 plus grosses positions |
| … | Principales positions | — | tableau des 12 plus grosses lignes |
| … | Les plus gros comptes | 2 | valeur et P&L % par compte individuel |
| … | Performance par compte | — | 14 comptes : valeur, P&L, 1 mois, YTD, 1 an |
| … | Répartition par client | 1 | tableau des clients + barres d'AuM (périmètre global seulement) |
| … | Commentaire de l'analyseur | — | synthèse rédigée par le modèle local, vérifiée |

L'inventaire ne porte que sur les comptes qui détiennent des titres : **28
pages en périmètre global** (10 comptes titres, 10 assurances vie, 5 PEA, 3
immobilier), 3 pour un client, soit **43 diapositives** sans commentaire. Un
compte dont le détail dépasse une page est coupé : la première page porte
l'intitulé de la classe, les suivantes « (partie 2) », et le bandeau de total
reste sur la dernière.

Le sommaire annonce les pages réelles : le deck est rendu une première fois
pour mesurer la plan, une seconde fois pour y inscrire les bons numéros.

Le deck parle de comptes à **deux niveaux**, à ne pas confondre :

- le **type de compte** regroupe les comptes qui partagent la même nature —
  PEA, assurance vie, compte titres, compte espèces, immobilier. C'est la
  lecture par catégorie, celle qui répond à « où est l'argent » ;
- le **compte** est l'unité individuelle (`acc_001`, « Compte titres de
  Jean Dupont »), celle de l'inventaire et des diapositives de performance.

Tous les chiffres sont calculés par l'application. Seule la dernière
diapositive est rédigée par le modèle, et son texte est confronté aux
données avant insertion (bandeau d'avertissement en pied de diapositive si un
montant ne correspond à rien).

### Périmètre client

Deux sélecteurs, dans l'onglet **IA** :

- en haut de l'onglet, pour le **chat** et l'estimation de durée ;
- dans la carte « Présentation de synthèse », pour le **PPTX** — « Tous les
  clients » produit la vue de référence (43 diapositives, inventaire des 28
  comptes qui détiennent des titres), un client nommé produit la présentation
  individuelle (17 diapositives : ni la synthèse multi-clients, ni les comptes
  des autres clients).

Ils sont **indépendants du filtre général** de l'application : on peut
préparer une présentation pour un client tout en consultant la vue globale.
Au premier ouverture de l'onglet, ils reprennent le filtre général ; ensuite
ils ne suivent plus que l'utilisateur. Un commentaire IA rédigé pour un
client n'est pas réutilisé pour un autre : le texte serait invérifiable.

### Charte corporate et modèle PowerPoint

Le panneau « Charte corporate et modèle PowerPoint », dans la carte PPTX,
règle l'identité visuelle des présentations. Deux mécanismes se combinent.

**1. Charte intégrée** — enregistrée dans `pptx_brand.json` :

| Champ | Rôle |
|---|---|
| `company`, `tagline` | Société et signature, en haut de la couverture |
| `primary` | Couverture, en-têtes de tableau, indicateurs |
| `accent` | Filets, surtitres, titres de rubrique |
| `surface` | Fond des cartes et des lignes alternées |
| `font` | Police de tous les textes |
| `logo` | PNG / JPEG / BMP / GIF (4 Mo max), couverture + chaque diapositive |
| `footer` | Mention de pied de page ; vide = mention d'origine conservée |
| `show_footer` | Afficher ou non cette mention |
| `charts_from_template` | Colorer les graphiques avec le thème du modèle |

Une couleur est refusée si elle est illisible sous du texte blanc, ou trop
claire pour lui — le deck ne devient pas illisible par un choix de teinte.

**Aucune configuration n'est nécessaire** : les champs société, signature et
mention sont vides par défaut, et le deck produit est alors exactement celui
d'origine (vert `0D6E4F`, mentions historiques, aucune raison sociale). La
charte ne sert qu'à personnaliser ce qui est déjà là. Le bouton
« Réinitialiser » du panneau revient à cet état et supprime le logo et le
modèle déposés.

**2. Modèle corporate** — un fichier `.pptx` / `.potx` déposé par le
gestionnaire (40 Mo max). La présentation est alors construite **à partir de
ce fichier** : ses mises en page, son thème et son logo sont conservés, ses
diapositives éventuelles retirées. Le format est normalisé en 16:9
(13,333 × 7,5 po) : un modèle 4:3 produit une présentation 16:9 aux mises en
page de la société.

Les couleurs d'accentuation du thème du modèle (`accent1` à `accent6` dans
`ppt/theme/theme1.xml`) sont relues pour les graphiques — le graphique est
alors dans la charte de la société, sans qu'il faille la recopier. L'option
**« Colorer les graphiques avec les couleurs du modèle »** (case qui
n'apparaît que si un modèle est déposé) permet de faire l'inverse :
décochée, les graphiques gardent les couleurs de la charte intégrée. Sans
modèle, cette option n'a aucun effet et la palette dérive de `primary`.

Sans modèle, la charte intégrée suffit : les mises en page sont celles
construites par l'application. Le logo, la société et le pied de page restent
applicables dans les deux cas.

Fichiers produits : `pptx_brand.json` (la charte), `assets/` (le logo),
`templates/` (le modèle). Ces deux répertoires appartiennent à la charte et
sont vidés quand on la réinitialise.

### Configuration

Le fichier `ai_config.json` (créé au premier enregistrement) surcharge les
défauts de `wm/ai/config.py` :

```json
{
  "model_path": "~/Models/Ministral-3-3B-Instruct-2512-Q4_K_M.gguf",
  "n_ctx": 8192,
  "n_threads": 0,
  "n_batch": 2048,
  "temperature": 0.2,
  "max_tokens": 500,
  "max_holdings": 12,
  "system_prompt": "…"
}
```

Le modèle se choisit depuis l'interface (tous les `.gguf` de `~/Models`,
`~/Documents` et `~/Downloads` sont détectés), ainsi que le prompt système.

Le chemin du modèle est aussi modifiable depuis l'onglet **DataSource**, à
côté des chemins Parquet. Les deux écrans lisent et écrivent la même valeur
dans `ai_config.json` : il n'y a pas de second réglage qui pourrait diverger.
Contrairement aux chemins Parquet, il s'applique immédiatement — le modèle
déjà chargé est déchargé, il reste à le recharger via « Préparer ». Un champ
vide rétablit le modèle par défaut.

### Performance : à quoi s'attendre

Le modèle par défaut (Ministral 3B Q4_K_M) tourne **sur CPU** (aucun GPU
détecté). Mesures réelles sur 16 cœurs AVX2, Ryzen 7 7735U :

| Étape | Durée |
|---|---|
| Chargement du modèle (2,1 Go) | ~3 s |
| Pré-remplissage du cache de contexte (`rapide`) | ~31 s |
| Pré-remplissage du cache de contexte (`standard`) | ~58 s |
| **Question** (contexte en cache, 380 tokens générés) | ~45 s |
| Présentation PPTX sans IA (43 diapositives, 12 graphiques) | ~3 s |

Deux points expliquent ces durées :

- **Le décodage est le vrai goulot** (~11 tokens/s). Le prefill du contexte
  n'est payé qu'une fois : le cache KV de `llama.cpp` n'est réutilisé que si
  le préfixe est rigoureusement identique, d'où le bouton **Préparer** qui
  l'amorce en amont. Sans lui, ajoutez ~30 à 55 s par question.
- **La génération est sérialisée** par construction (un `Llama` n'est pas
  thread-safe) : deux questions simultanées se font simplement attendre. Les
  routes sont déclarées en `def` synchrone pour ne pas figer la boucle
  d'événements de FastAPI — le reste de l'application reste réactif.

### Fiabilité : le contrôle des chiffres

Sur trois générations testées, **deux contenaient un montant absent des
données** : un modèle de cette taille transforme parfois un montant en un
autre (`1 931 020,32` → `1 847 802,06`). Le contrôle automatique les a
signalés dans les deux cas.

C'est la raison pour laquelle le module IA n'est pas seulement un chat : toute
réponse est confrontée au contexte, et l'interface affiche un bandeau
« À vérifier » listant précisément ce qui n'a pas été retrouvé. Un modèle
local de cette taille reste un outil d'aide à la décision, pas une source de
vérité — les chiffres du PPTX, eux, sont toujours calculés par
l'application, jamais par le modèle.

## Structure

```
main.py                  Point d'entrée ASGI (`app` = wm.main:app)
wm/
  config.py              Chemins, DataSource, session, utilisateurs
  storage.py             Lecture/écriture Parquet, données de référence
  serialization.py       DataFrame/pandas -> JSON
  security.py            Authentification par cookie de session
  schemas.py             Modèles Pydantic (corps de requête)
  main.py                Factory FastAPI, middlewares, statique
  services/
    dashboard.py         Agrégations du tableau de bord
    reporting.py         Rapport, matrices de périodes, factsheets
  ai/
    config.py            Configuration du modèle (ai_config.json, détection GGUF)
    engine.py            Chargement paresseux, cache KV, génération
    context.py           Faits métier -> bloc de contexte, assemblé par priorité
    assistant.py         Prompt, gestion du budget, décrochage par rubriques
    verify.py            Contrôle des montants et sigles cités
    brand.py             Charte PPTX (pptx_brand.json), logo, modèle corporate,
                         couleurs du thème d'un .pptx importé
    pptx.py              Primitives de mise en page PPTX (graphiques mono- et
                         multi-séries, couleurs au point), application de la
                         charte, ouverture d'un modèle corporate
    pptx_report.py       Assemblage des slides
  routers/
    auth.py              /api/login, /api/logout, /api/me
    dashboard.py         /api/dashboard
    clients.py           CRUD /api/clients
    accounts.py          CRUD /api/accounts
    holdings.py          CRUD /api/holdings
    valuation.py         /api/valuation
    reporting.py         /api/report, /api/export, factsheets
    meta.py              /api/meta
    datasource.py        /api/config/datasource
    ai.py                /api/ai/status, /chat, /commentary, /pptx, /context,
                         /brand (charte), /brand/logo, /brand/template,
                         /brand/reset
seed.py                  Génération du jeu de démonstration
factsheet.py             Rendu Excel / PDF des factsheets
static/                  Interface web
tests/
  parity_check.py        Compare les réponses FastAPI à celles de l'ancien Flask
  test_write.py          Tests des endpoints d'écriture (données restaurées)
  test_ai.py             Contexte, ventilation par type de compte, contrôle
                         des chiffres, rubriques, génération PPTX, routes HTTP
  test_pptx_layout.py    Contrôle géométrique du PPTX : aucune forme hors de la
                         zone utile, aucun chevauchement, graphiques alimentés
  test_brand.py          Charte PPTX : couleurs, contraste, persistance, dépôt
                         et retrait du logo et du modèle corporate, application
                         au PPTX, routes HTTP
  http_brand.py          Test HTTP de bout en bout de la charte (serveur lancé)
```

## Tests

```bash
python tests/test_ai.py           # 127 assertions — contexte, types de compte,
                                 # chiffres cités, PPTX, DataSource, routes HTTP
                                 # (sans modèle)
python tests/test_brand.py        # 130 assertions — charte, logo, modèle
                                 # corporate, application au PPTX
python tests/test_pptx_layout.py  # 1301 assertions — géométrie et contenu des
                                 # graphiques du PPTX, avec et sans logo
python tests/test_write.py        # 43 assertions sur POST/PUT/DELETE + auth
python tests/parity_check.py      # nécessite l'ancien app.py Flask
python tests/http_brand.py        # de bout en bout (serveur sur :5001)
```

Aucun test ne charge le modèle : ils tournent en quelques secondes.
`tests/test_brand.py` redirige la charte vers un répertoire temporaire et ne
touche jamais vos fichiers de marque. `tests/test_write.py` sauvegarde et
restaure les fichiers Parquet, il peut être exécuté sans risque sur vos
données.

## Données

Voir [DATA.md](DATA.md) pour le détail des tables Parquet et du mécanisme
DataSource (redirection des chemins via `datasource_config.json`).
