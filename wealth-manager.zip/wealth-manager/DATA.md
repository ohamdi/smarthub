# Smart Wealth Manager — Documentation des données

## Principe

Toutes les données métier et de référence proviennent de fichiers **Parquet** situés à
la racine du projet. L'application les charge via `pd.read_parquet` (fonctions
`load_table` / `load_*` dans `wm/storage.py`) à chaque requête API.

Seuls les **comptes utilisateurs** (`admin`, `gestionnaire`) restent codés en dur
dans `wm/config.py` (`USERS`) — les utilisateurs ne font pas partie des fichiers
Parquet.

### Fichiers de données

| Fichier | Contenu |
|---------|---------|
| `clients.parquet` | Liste des clients |
| `accounts.parquet` | Comptes de chaque client |
| `holdings.parquet` | Positions (titres détenus) |
| `valuation.parquet` | Historique de valorisation par compte |
| `reference.parquet` | Données de référence (types de comptes, profils, classes d'actifs, titres) |

### Chemins et redirigeable (DataSource)

Les chemins vers les fichiers Parquet sont résolus par `get_parquet_path()`
dans `wm/config.py` selon la priorité suivante :

1. **`datasource_config.json`** (optionnel, à la racine du projet) — permet de
   rediriger chaque table vers un fichier externe (chemin absolu ou relatif au projet).
2. **Valeur par défaut** — `{racine_projet}/{fichier}.parquet` (ex. `clients.parquet`).

La configuration est modifiable via l'onglet **DataSource** de l'interface web
(`GET /api/config/datasource`, `POST /api/config/datasource`), puis appliquée au
redémarrage du serveur.

Le même écran gère aussi le **chemin du modèle IA** (`model_path`), qui est
relu à chaque appel et s'applique donc sans redémarrage. Il est stocké dans
`ai_config.json` — et non dans `datasource_config.json` — pour rester la source
unique de la valeur, que l'onglet DataSource et l'onglet Analyse IA lisent et
écrivent tous les deux. Un champ absent dans la requête laisse le modèle en
place, un champ vide rétablit `DEFAULT_MODEL`.

### Fallback (données de secours)

Si `reference.parquet` est absent ou vide, l'application utilise des constantes
de secours importées de `seed.py` (`_reference_fallback()` dans `wm/storage.py`).

### Régénération des données de démo

L'onglet DataSource propose un bouton **« Réinitialiser les données de démo »**
qui supprime les fichiers Parquet et la config, puis régénère un jeu complet via
`seed.py` (`reset → seed_main()`). Au démarrage du serveur, si aucun fichier
`clients.parquet` n'existe, `ensure_demo_data()` (lifespan de `wm/main.py`)
génère automatiquement le jeu de démo.

---

## Structure des tables

Une ligne = un enregistrement. Les identifiants sont des chaînes uniques (`id`).
Les dates sont des chaînes au format ISO `YYYY-MM-DD` (ou timestamp
`YYYY-MM-DDTHH:MM:SS` pour `created_at`).

### `clients.parquet` — Clients

| Champ | Type | Description | Exemple |
|---|---|---|---|
| `id` | string | Identifiant unique du client | `cl_dupont` |
| `name` | string | Nom complet | `Jean Dupont` |
| `email` | string | Adresse e-mail | `jean.dupont@example.com` |
| `phone` | string | Numéro de téléphone | `+33 6 11 22 33 44` |
| `risk_profile` | string | Profil de risque — valeurs : `conservateur`, `equilibre`, `dynamique` | `equilibre` |
| `country` | string | Code pays ISO 3166-1 alpha-2 | `FR`, `CH` |
| `birth_year` | int | Année de naissance | `1968` |
| `advisor` | string | Conseiller en gestion affecté | `M. Martin` |
| `notes` | string | Notes libres | `Client historique depuis 2015.` |
| `created_at` | string | Date de création (ISO timestamp) | `2024-01-15T10:00:00` |

### `accounts.parquet` — Comptes

| Champ | Type | Description | Exemple |
|---|---|---|---|
| `id` | string | Identifiant unique du compte | `acc_001` |
| `client_id` | string | Référence au client (`clients.id`) | `cl_dupont` |
| `account_name` | string | Libellé du compte | `Compte titres` |
| `account_type` | string | Type de compte — valeurs : `ct` (Compte titres), `pea` (PEA), `av` (Assurance vie), `cash` (Cash), `immobilier` (Immobilier) | `ct` |
| `currency` | string | Devise du compte (ISO 4217) | `EUR` |
| `cash` | float | Liquidités du compte | `60433.00` |
| `opening_date` | string | Date d'ouverture (ISO) | `2025-03-30` |
| `advisor` | string | Conseiller affecté | `M. Martin` |
| `notes` | string | Notes libres | `—` |
| `created_at` | string | Date de création (ISO timestamp) | `2026-08-14T14:29:35` |

### `holdings.parquet` — Positions (titres détenus)

| Champ | Type | Description | Exemple |
|---|---|---|---|
| `id` | string | Identifiant unique de la ligne de position | `h_0001` |
| `account_id` | string | Référence au compte (`accounts.id`) | `acc_001` |
| `ticker` | string | Code de cotation | `AIR.PA` |
| `name` | string | Nom du titre | `Airbus SE` |
| `isin` | string | Code ISIN (12 caractères) | `FR0000120073` |
| `asset_class` | string | Classe d'actifs — `Action`, `ETF`, `Obligation`, `Fonds`… | `Action` |
| `sector` | string | Secteur économique | `Aéronautique` |
| `currency` | string | Devise du titre (ISO 4217) | `EUR` |
| `quantity` | float | Quantité détenue | `1270.5957` |
| `unit_cost` | float | Prix de revient unitaire (PRU) | `182.87` |
| `unit_price` | float | Cours actuel unitaire (dernier cours) | `168.50` |
| `buy_date` | string | Date d'achat (ISO) | `2025-09-03` |
| `last_price_date` | string | Date du dernier cours (ISO) | `2026-08-19` |
| `perf_ytd` | float | Performance depuis le 1er janvier (%) | `15.45` |
| `perf_1y` | float | Performance sur 1 an (%) | `33.53` |
| `perf_3y` | float | Performance sur 3 ans (%) | `-2.18` |
| `perf_5y` | float | Performance sur 5 ans (%) | `47.74` |
| `market_value` | float | Valorisation = `quantity × unit_price` | `214095.38` |
| `cost_value` | float | Montant prix de revient = `quantity × unit_cost` | `232353.84` |
| `total_pnl` | float | P&L = `market_value − cost_value` | `-18258.46` |
| `pnl_pct` | float | P&L % = `total_pnl / cost_value × 100` | `-7.86` |
| `weight_pct` | float | Poids dans le portefeuille (%) | `1.53` |

Toutes les valeurs (y compris `market_value`, `cost_value`, `total_pnl`, `pnl_pct`,
`weight_pct`) sont **stockées dans le fichier Parquet** et lues directement par
l'application — aucun calcul à l'exécution.

### `valuation.parquet` — Historique de valorisation

| Champ | Type | Description | Exemple |
|---|---|---|---|
| `id` | string | Identifiant unique du point de valorisation | `v_000001` |
| `account_id` | string | Référence au compte (`accounts.id`) | `acc_001` |
| `date` | string | Date de la valorisation (ISO) | `2025-09-03` |
| `market_value` | float | Valorisation des titres hors liquidités | `229730.36` |
| `cash` | float | Liquidités à cette date | `60433.00` |
| `total_value` | float | Valeur totale = `market_value + cash` | `290163.36` |

### `reference.parquet` — Données de référence

Table **normalisée** (`domaine / clé / valeur` + colonnes titres) alimentant les
listes de référence de l'application (`/api/meta`) : types de comptes, libellés
de profils de risque, classes d'actifs et univers de titres.

| Champ | Type | Description | Exemple |
|---|---|---|---|
| `domain` | string | Domaine — valeurs : `account_type`, `risk_label`, `asset_class`, `security` | `account_type` |
| `key` | string | Clé du domaine | `ct`, `equilibre`, `Action`, `AIR.PA` |
| `value` | string | Libellé / nom du titre | `Compte titres`, `Airbus SE` |
| `isin` | string | Code ISIN (titres uniquement, sinon `null`) | `FR0000120073` |
| `class` | string | Classe d'actifs du titre (titres uniquement) | `Action` |
| `sector` | string | Secteur du titre (titres uniquement) | `Aéronautique` |
| `px` | float | Cours de référence du titre (titres uniquement) | `168.5` |

#### Contenu par domaine

| `domain` | Rôle | Exemple de ligne |
|---|---|---|
| `account_type` | Types de comptes (`ACCOUNT_TYPES`) | `ct` → `Compte titres` |
| `risk_label` | Libellés de profils de risque (`RISK_LABELS`) | `conservateur` → `Conservateur` |
| `asset_class` | Liste des classes d'actifs (`ASSET_CLASSES`) | `Action`, `ETF`, `Cash`… |
| `security` | Univers de titres (`SECURITIES`, avec ISIN/classe/secteur/cours) | `AIR.PA` → `Airbus SE` |

---

## Relations entre tables

```
clients (1) ──< accounts (1) ──< holdings
                     └──< valuation
```

- `accounts.client_id` → `clients.id`
- `holdings.account_id` → `accounts.id`
- `valuation.account_id` → `accounts.id`

---

## Endpoints API (données → Parquet)

Chaque requête API recharge les données depuis les fichiers Parquet via les
fonctions `load_*()`. Les opérations d'écriture (POST / PUT / DELETE) relisent
le fichier, modifient le DataFrame, puis écrivent via `save_table()`.

| Endpoint | Méthode | Fichiers Parquet lus | Opération |
|----------|---------|----------------------|-----------|
| `/api/login` | POST | — | Authentification (session) |
| `/api/logout` | POST | — | Fin de session |
| `/api/me` | GET | — | Utilisateur connecté |
| `/api/dashboard` | GET | clients, accounts, holdings, valuation | Agrégation (AuM, P&L, allocation) |
| `/api/clients` | GET | clients | Liste |
| `/api/clients` | POST | clients | Ajout |
| `/api/clients/<cid>` | PUT | clients | Mise à jour |
| `/api/clients/<cid>` | DELETE | clients | Suppression |
| `/api/accounts` | GET | accounts | Liste |
| `/api/accounts` | POST | accounts | Ajout |
| `/api/accounts/<aid>` | PUT | accounts | Mise à jour |
| `/api/accounts/<aid>` | DELETE | accounts, holdings, valuation | Suppression (+ cascades) |
| `/api/holdings` | GET | holdings, accounts | Liste (enrichie) |
| `/api/holdings` | POST | holdings | Ajout |
| `/api/holdings/<hid>` | PUT | holdings | Mise à jour |
| `/api/holdings/<hid>` | DELETE | holdings | Suppression |
| `/api/valuation` | GET | valuation, accounts | Historique |
| `/api/report` | GET | clients, accounts, holdings, valuation | Rapport complet |
| `/api/meta` | GET | reference | Données de référence |
| `/api/export` | GET | holdings, accounts, clients | Export CSV |
| `/api/config/datasource` | GET/POST | — | Configuration des chemins Parquet **et** du modèle IA |
| `/api/ai/status` | GET | — | État du moteur, modèles `.gguf` détectés |
| `/api/ai/context` | GET | clients, accounts, holdings, valuation | Bloc de données envoyé au modèle |
| `/api/ai/estimate` | POST | idem | Durée estimée d'une question |
| `/api/ai/warmup` | POST | idem | Chargement du modèle + cache de contexte |
| `/api/ai/chat` | POST | idem | Question en langage naturel |
| `/api/ai/commentary` | POST | idem | Synthèse narrative pour la présentation |
| `/api/ai/pptx` | POST | idem | Présentation PPTX (binaire) |
| `/api/ai/config` | GET/POST | — | Configuration du modèle |

Les routes `/api/ai/*` sont **en lecture seule** sur les Parquet : aucune ne
modifie les données. Elles sont déclarées en `def` synchrone pour que
l'inférence CPU s'exécute dans le threadpool de FastAPI et ne bloque pas
l'application.

### Agrégats par type de compte

Le reporting IA ventile l'AuM par **type de compte** (`accounts.account_type` :
PEA, assurance vie, compte titres, compte espèces, immobilier). Ces agrégats
sont calculés dans `wm/ai/context.py` (`_by_account_type`,
`_top_by_account_type`) à partir de `accounts` et `holdings`, et servent à la
fois au contexte envoyé au modèle, à la diapositive « Répartition par type de
compte » et à la diapositive « Contenu par type de compte » de la présentation.

Le type de compte est le niveau **agrégé** ; le compte individuel
(`accounts_detail`, clé `acc_001`) est le niveau **unitaire**, celui de
l'inventaire. Les deux coexistent : la première donne la lecture par
catégorie, la seconde le détail ligne à ligne.

### Inventaire et historique mensuel

Deux diapositives du PPTX lisent directement les tables sources, via
`facts["accounts_detail"]` et `facts["series_detail"]` :

- l'**inventaire** reprend, pour chaque compte qui détient des titres, les
  positions de `holdings` groupées par `asset_class`, avec un sous-total par
  classe. Le poids de chaque ligne est recalculé sur la valorisation des
  titres du compte — et non repris de `holdings.weight_pct`, exprimé sur un
  autre périmètre ;
- l'**historique mensuel** agrège `valuation` par mois (`total_value` en fin
  de mois) sur l'année civile en cours et compare chaque mois au précédent ;
  le premier mois de l'année est ramené au dernier point de l'année
  précédente lorsqu'il existe.

`build_factsheet_report()` expose en plus deux agrégats réutilisables par le
PPTX :

| Clé | Contenu |
|---|---|
| `period_matrix_account_type` | Variation 1m/3m/6m/YTD/1an par type de compte (équivalent de `period_matrix_group`, qui regroupe par client) |
| `series_detail` | Série temporelle agrégée éclatée en `market_value` / `cash` / `total_value`, pour le graphique multi-courbes de l'AuM |

Les types de compte totalisent exactement l'AuM du périmètre (le contrôle est
asserté dans `tests/test_ai.py`).

### Charte PPTX

Hors des données métier, `wm/ai/brand.py` lit trois éléments de configuration,
qu'il ne faut pas confondre avec les tables Parquet :

| Élément | Emplacement | Contenu |
|---|---|---|
| Charte | `pptx_brand.json` | Société, logo, couleurs, police, pied de page |
| Logo | `assets/` | Image déposée par le gestionnaire (PNG, JPEG, BMP, GIF — 4 Mo max) |
| Modèle corporate | `templates/` | `.pptx` / `.potx` déposé (40 Mo max) |

Ces fichiers ne sont pas versionnés avec les données et ne sont pas décrits
par `datasource_config.json` : la charte décrit l'identité visuelle du
reporting, pas la source métier. Un logo ou un modèle peut aussi être désigné
par un chemin absolu, auquel cas l'application ne le supprime jamais.

---

## Interface (front-end `static/index.html`)

Application FastAPI (**Smart Wealth Manager**) accessible sur `http://localhost:5001`
(login `admin` / `admin123`, ou `gestionnaire` / `wealth123`). Une seule page avec
onglets :

| Onglet | Contenu |
|---|---|
| **Tableau de bord** | KPIs (AuM, P&L, comptes, positions), graphiques (allocation par classe/secteur, P&L par compte, AuM par client, courbe de valorisation) |
| **Clients** | Tableau des clients : AuM, performance, profil de risque, conseiller + bouton « Dossier » |
| **Comptes** | Tableau des comptes : valorisation, cash, total, P&L, nombre de positions |
| **Positions** | Filtres (client, compte, classe, secteur, recherche), vue **tableau** ou **arborescente**, 3 camemberts (classe, secteur, devise) — colonnes : ISIN, Titre, Classe, Devise, Qté, Cours, Date cours, Valorisation, Prix de revient, Poids, P&L, Perf YTD, Perf 1Y, Perf 3Y, Perf 5Y |
| **Valorisation** | Courbe de valorisation par compte + historique tableau |
| **Reporting** | Générateur de factsheet PDF/Excel, reporting par compte, tableau de performance |
| **Analyse IA** | Questions en langage naturel sur un modèle GGUF local, génération d'une présentation PPTX de synthèse (par client ou vue de référence), réglage de la charte corporate et import d'un modèle PowerPoint |
| **DataSource** | Configuration des chemins fichiers Parquet et du modèle IA, réinitialisation des données de démo |

### Sélecteur Périmètre

Le sélecteur **Périmètre** de l'en-tête restreint toute l'application à un client
(« Tous les clients » par défaut) : en mode dossier, les onglets Clients, Comptes
et Positions sont filtrés sur ce client et le dashboard affiche les KPIs du dossier.

L'onglet **Analyse IA** possède ses propres sélecteurs, **indépendants** de ce
filtre : l'un pour le chat, l'autre pour la présentation. Au premier
chargement, ils reprennent le périmètre général ; ensuite seul l'utilisateur
les modifie. Changer de périmètre réinitialise la conversation, et un
commentaire IA n'est jamais réutilisé pour un client qu'il ne décrit pas.

---

## Onglet Analyse IA

Les données envoyées au modèle ne sont pas une copie brute des tables : ce sont
des **faits agrégés** calculés par `wm/ai/context.py` à partir de
`build_factsheet_report()`. Le modèle n'a donc aucun accès aux identifiants
comptables ni aux lignes de valorisation détaillées.

Sections produites, par ordre de priorité d'inclusion (les suivantes ne sont
ajoutées que si le budget de caractères le permet) :

| Priorité | Section | Contenu |
|---|---|---|
| 0 | Indicateurs | AuM, titres, liquidités, P&L latent, volumétrie, performance du portefeuille |
| 1 | Allocation par classe d'actifs | Valorisation et poids |
| 2 | Allocation par secteur | 5 à 12 secteurs selon le niveau de détail |
| 3 | Comptes | Les plus representatifs : client, référence, type, devise, valeur, P&L, 1M/3M/6M/YTD/1A |
| 4 | Positions principales | Ticker, nom, classe, secteur, valorisation, poids, P&L |
| 5 | Synthèse par client | Profil de risque, volumétrie, AuM, P&L, performances |
| 6 | Concentration | Poids des top positions, des top clients, profils de risque, devises, meilleures et pires positions |

Un client inconnu ou un portefeuille vide provoquent une erreur explicite
(`422`) plutôt qu'un contexte vide que le modèle comblerait par invention.

Les montants et sigles cités dans une réponse sont confrontés au contexte
envoyé (`wm/ai/verify.py`) ; ce qui n'y figure pas est signalé à l'utilisateur.

---

## Notes

- La couche d'accès aux données est centralisée dans `wm/storage.py` ; la logique
  d'agrégation vit dans `wm/services/`, les routes dans `wm/routers/`.
- Toutes les dates sont des chaînes ISO (pas de type `date` natif) ; l'affichage
  front est mis en forme `jj/mm/aaaa` côté client.
- Les montants (`cash`, `unit_cost`, `unit_price`, `quantity`, valorisations)
  sont des `float` ; les agrégats arrondis à 2 décimales côté API.
- Les fichiers sont régénérés par `seed.py` (jeu de démo).
- La seed utilise `random.seed(42)` et `np.random.seed(42)` pour la reproductibilité.
