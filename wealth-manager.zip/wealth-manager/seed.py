import os
import random
from datetime import datetime, timedelta

import pandas as pd
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

random.seed(42)
np.random.seed(42)

CLIENTS = [
    {
        "id": "cl_dupont",
        "name": "Jean Dupont",
        "email": "jean.dupont@example.com",
        "phone": "+33 6 11 22 33 44",
        "risk_profile": "equilibre",
        "country": "FR",
        "birth_year": 1968,
        "advisor": "M. Martin",
        "notes": "Client historique depuis 2015.",
        "created_at": "2024-01-15T10:00:00",
    },
    {
        "id": "cl_bernard",
        "name": "Sophie Bernard",
        "email": "sophie.bernard@example.com",
        "phone": "+33 6 55 44 33 22",
        "risk_profile": "dynamique",
        "country": "CH",
        "birth_year": 1982,
        "advisor": "Mme Laurent",
        "notes": "Préférence pour la tech et les actions internationales.",
        "created_at": "2024-03-02T14:30:00",
    },
    {
        "id": "cl_roche",
        "name": "Pierre Roche",
        "email": "pierre.roche@example.com",
        "phone": "+41 79 123 45 67",
        "risk_profile": "conservateur",
        "country": "FR",
        "birth_year": 1955,
        "advisor": "M. Martin",
        "notes": "Retraité, sensibilité forte au capital.",
        "created_at": "2024-05-20T09:15:00",
    },
    {
        "id": "cl_moreau",
        "name": "Claire Moreau",
        "email": "claire.moreau@example.com",
        "phone": "+33 7 99 88 77 66",
        "risk_profile": "equilibre",
        "country": "DE",
        "birth_year": 1975,
        "advisor": "Mme Laurent",
        "notes": "Projet immobilier à horizon 3 ans.",
        "created_at": "2024-08-11T16:45:00",
    },
    {
        "id": "cl_lambert",
        "name": "Marc Lambert",
        "email": "marc.lambert@example.com",
        "phone": "+41 76 555 12 34",
        "risk_profile": "dynamique",
        "country": "CH",
        "birth_year": 1979,
        "advisor": "Mme Laurent",
        "notes": "Cadre dirigeant, appétence pour les valeurs technologiques.",
        "created_at": "2024-10-05T11:20:00",
    },
    {
        "id": "cl_nguyen",
        "name": "Hélène Nguyen",
        "email": "helene.nguyen@example.com",
        "phone": "+33 6 44 55 66 77",
        "risk_profile": "equilibre",
        "country": "FR",
        "birth_year": 1985,
        "advisor": "M. Martin",
        "notes": "Patrimoine en constitution.",
        "created_at": "2025-01-22T09:00:00",
    },
    {
        "id": "cl_rossi",
        "name": "Antonio Rossi",
        "email": "antonio.rossi@example.com",
        "phone": "+39 347 555 88 99",
        "risk_profile": "conservateur",
        "country": "IT",
        "birth_year": 1950,
        "advisor": "M. Martin",
        "notes": "Retraité, recherche de revenus réguliers.",
        "created_at": "2025-02-14T15:30:00",
    },
    {
        "id": "cl_vandenberg",
        "name": "Lucas Van den Berg",
        "email": "lucas.vdb@example.com",
        "phone": "+31 6 1234 5678",
        "risk_profile": "dynamique",
        "country": "NL",
        "birth_year": 1988,
        "advisor": "Mme Laurent",
        "notes": "Entrepreneur, forte exposition actions.",
        "created_at": "2025-03-30T13:45:00",
    },
    {
        "id": "cl_gharbi",
        "name": "Inès Gharbi",
        "email": "ines.gharbi@example.com",
        "phone": "+33 6 22 33 44 55",
        "risk_profile": "equilibre",
        "country": "FR",
        "birth_year": 1972,
        "advisor": "Mme Laurent",
        "notes": "Diversification entre titres vifs et immobilier.",
        "created_at": "2025-06-18T10:15:00",
    },
    {
        "id": "cl_keller",
        "name": "Franz Keller",
        "email": "franz.keller@example.com",
        "phone": "+49 151 2345 6789",
        "risk_profile": "conservateur",
        "country": "DE",
        "birth_year": 1948,
        "advisor": "M. Martin",
        "notes": "Priorité à la préservation du capital.",
        "created_at": "2025-07-02T14:00:00",
    },
]

ACCOUNT_TYPES = {
    "ct": "Compte titres",
    "pea": "PEA",
    "av": "Assurance vie",
    "cash": "Compte espèces",
    "immobilier": "Immobilier",
}

RISK_LABELS = {
    "conservateur": "Conservateur",
    "equilibre": "Équilibré",
    "dynamique": "Dynamique",
}

ASSET_CLASSES = ["Action", "Obligation", "ETF", "Immobilier", "Cash", "Fonds"]

SECURITIES = [
    {"ticker": "AIR.PA", "name": "Airbus SE", "isin": "FR0000120073", "class": "Action", "sector": "Aéronautique", "px": 168.5},
    {"ticker": "MC.PA", "name": "LVMH Moët Hennessy", "isin": "FR0000121014", "class": "Action", "sector": "Luxe", "px": 645.2},
    {"ticker": "OR.PA", "name": "L'Oréal", "isin": "FR0000120321", "class": "Action", "sector": "Consommation", "px": 410.7},
    {"ticker": "SAN.PA", "name": "Sanofi", "isin": "FR0000120578", "class": "Action", "sector": "Santé", "px": 98.4},
    {"ticker": "TTE.PA", "name": "TotalEnergies", "isin": "FR0000120271", "class": "Action", "sector": "Énergie", "px": 59.8},
    {"ticker": "BNP.PA", "name": "BNP Paribas", "isin": "FR0000131104", "class": "Action", "sector": "Finance", "px": 72.6},
    {"ticker": "SU.PA", "name": "Schneider Electric", "isin": "FR0000121972", "class": "Action", "sector": "Industrie", "px": 238.9},
    {"ticker": "ASML.AS", "name": "ASML Holding", "isin": "NL0010273215", "class": "Action", "sector": "Semi-conducteurs", "px": 902.3},
    {"ticker": "NESN.SW", "name": "Nestlé", "isin": "CH0038863350", "class": "Action", "sector": "Consommation", "px": 92.1},
    {"ticker": "AAPL", "name": "Apple Inc.", "isin": "US0378331005", "class": "Action", "sector": "Technologie", "px": 232.4},
    {"ticker": "MSFT", "name": "Microsoft Corp.", "isin": "US5949181045", "class": "Action", "sector": "Technologie", "px": 428.9},
    {"ticker": "NVDA", "name": "NVIDIA Corp.", "isin": "US67066G1040", "class": "Action", "sector": "Semi-conducteurs", "px": 138.2},
    {"ticker": "VWCE.DE", "name": "ETF MSCI World", "isin": "IE00BK5BQT80", "class": "ETF", "sector": "Fonds", "px": 156.4},
    {"ticker": "CW8.DE", "name": "ETF MSCI World Amundi", "isin": "FR0010315770", "class": "ETF", "sector": "Fonds", "px": 682.5},
    {"ticker": "PAEEM", "name": "ETF Amundi EM", "isin": "FR0010692042", "class": "ETF", "sector": "Fonds", "px": 28.9},
    {"ticker": "IAGG.DE", "name": "ETF Aggregates Bond EUR", "isin": "IE00BDBRDM35", "class": "ETF", "sector": "Obligataire", "px": 96.2},
    {"ticker": "OAT-FR2035", "name": "OAT 2,0% 2035", "isin": "FR0013516927", "class": "Obligation", "sector": "Obligataire", "px": 98.7},
    {"ticker": "BTP-FR2028", "name": "BTP 3,5% 2028", "isin": "FR0014007PV8", "class": "Obligation", "sector": "Obligataire", "px": 101.2},
    {"ticker": "SCPI-CM", "name": "SCPI Comète", "isin": "FR0007008291", "class": "Immobilier", "sector": "Immobilier", "px": 1315.0},
    {"ticker": "CASH-EUR", "name": "Liquidités EUR", "isin": "", "class": "Cash", "sector": "Cash", "px": 1.0},
]

ALLOCATION = {
    "cl_dupont": {
        "ct": ["AIR.PA", "MC.PA", "OR.PA", "SAN.PA", "TTE.PA", "BNP.PA", "VWCE.DE"],
        "pea": ["AAPL", "MSFT", "NVDA", "ASML.AS"],
        "av": ["VWCE.DE", "IAGG.DE", "OAT-FR2035", "BTP-FR2028"],
        "cash": ["CASH-EUR"],
    },
    "cl_bernard": {
        "ct": ["NVDA", "AAPL", "MSFT", "ASML.AS", "AIR.PA"],
        "pea": ["NVDA", "ASML.AS", "MSFT"],
        "av": ["VWCE.DE", "CW8.DE", "PAEEM"],
        "cash": ["CASH-EUR"],
    },
    "cl_roche": {
        "ct": ["OAT-FR2035", "BTP-FR2028", "IAGG.DE", "TTE.PA"],
        "av": ["IAGG.DE", "OAT-FR2035", "BTP-FR2028"],
        "immobilier": ["SCPI-CM"],
        "cash": ["CASH-EUR"],
    },
    "cl_moreau": {
        "ct": ["SU.PA", "MC.PA", "BNP.PA", "VWCE.DE"],
        "pea": ["SU.PA", "MC.PA"],
        "av": ["VWCE.DE", "IAGG.DE", "PAEEM"],
        "cash": ["CASH-EUR"],
    },
    "cl_lambert": {
        "ct": ["NVDA", "MSFT", "ASML.AS", "AIR.PA", "SU.PA"],
        "pea": ["NVDA", "ASML.AS", "MSFT"],
        "av": ["VWCE.DE", "PAEEM", "IAGG.DE"],
        "cash": ["CASH-EUR"],
    },
    "cl_nguyen": {
        "ct": ["MC.PA", "OR.PA", "SU.PA", "BNP.PA"],
        "av": ["CW8.DE", "IAGG.DE", "OAT-FR2035"],
        "cash": ["CASH-EUR"],
    },
    "cl_rossi": {
        "ct": ["OAT-FR2035", "BTP-FR2028", "TTE.PA", "IAGG.DE"],
        "av": ["OAT-FR2035", "IAGG.DE"],
        "immobilier": ["SCPI-CM"],
        "cash": ["CASH-EUR"],
    },
    "cl_vandenberg": {
        "ct": ["NVDA", "AAPL", "MSFT", "SAN.PA"],
        "pea": ["NVDA", "AAPL"],
        "av": ["VWCE.DE", "PAEEM"],
        "cash": ["CASH-EUR"],
    },
    "cl_gharbi": {
        "ct": ["MC.PA", "OR.PA", "TTE.PA", "AIR.PA"],
        "av": ["VWCE.DE", "IAGG.DE"],
        "immobilier": ["SCPI-CM"],
        "cash": ["CASH-EUR"],
    },
    "cl_keller": {
        "ct": ["OAT-FR2035", "BTP-FR2028", "NESN.SW"],
        "av": ["OAT-FR2035", "IAGG.DE"],
        "cash": ["CASH-EUR"],
    },
}

ACCOUNT_NAMES = {
    "ct": "Compte titres",
    "pea": "PEA",
    "av": "Assurance vie",
    "cash": "Compte espèces",
    "immobilier": "Immobilier",
}


def iso(d):
    return d.strftime("%Y-%m-%d")


def build_data():
    clients = []
    accounts = []
    holdings = []
    valuation = []

    account_seq = 1
    for client in CLIENTS:
        cid = client["id"]
        clients.append(client)
        allocation = ALLOCATION[cid]

        for atype, tickers in allocation.items():
            acc_id = f"acc_{account_seq:03d}"
            account_seq += 1

            cash = round(random.uniform(8_000, 90_000), 2)
            accounts.append({
                "id": acc_id,
                "client_id": cid,
                "account_name": ACCOUNT_NAMES[atype],
                "account_type": atype,
                "currency": "EUR",
                "cash": cash,
                "opening_date": iso(datetime.now() - timedelta(days=random.randint(400, 2600))),
                "advisor": client["advisor"],
                "notes": "",
                "created_at": datetime.now().isoformat(),
            })

            for t in tickers:
                sec = next(s for s in SECURITIES if s["ticker"] == t)
                if sec["class"] == "Cash":
                    continue
                # allocation of invested capital between positions
                invest_cap = random.uniform(25_000, 280_000)
                qty = round(invest_cap / sec["px"], 4)
                # cost price = current price with a drift
                drift = random.uniform(-0.25, 0.45)
                unit_cost = round(sec["px"] / (1 + drift), 2)
                buy_date = iso(datetime.now() - timedelta(days=random.randint(60, 1800)))
                holdings.append({
                    "id": f"h_{len(holdings)+1:04d}",
                    "account_id": acc_id,
                    "ticker": sec["ticker"],
                    "name": sec["name"],
                    "isin": sec["isin"],
                    "asset_class": sec["class"],
                    "sector": sec["sector"],
                    "currency": "EUR",
                    "quantity": qty,
                    "unit_cost": unit_cost,
                    "unit_price": sec["px"],
                    "buy_date": buy_date,
                })

            # valuation history (12 months, 2 points/month)
            base_mv = sum(
                (next(s for s in SECURITIES if s["ticker"] == t)["px"] * random.uniform(80, 300))
                for t in tickers if next(s for s in SECURITIES if s["ticker"] == t)["class"] != "Cash"
            )
            base_total = base_mv + cash
            n_points = 24
            for i in range(n_points):
                d = datetime.now() - timedelta(days=(n_points - 1 - i) * 15)
                t = i / (n_points - 1)
                drift = 0.004 * (i - n_points * 0.5)
                noise = np.random.normal(0, 0.012)
                total = base_total * (1 + drift + noise)
                mv = max(total - cash, 0)
                valuation.append({
                    "id": f"v_{len(valuation)+1:06d}",
                    "account_id": acc_id,
                    "date": iso(d),
                    "market_value": round(mv, 2),
                    "cash": round(cash, 2),
                    "total_value": round(total, 2),
                })

    return clients, accounts, holdings, valuation


def build_reference():
    rows = []
    for k, v in ACCOUNT_TYPES.items():
        rows.append({"domain": "account_type", "key": k, "value": v,
                     "isin": None, "class": None, "sector": None, "px": None})
    for k, v in RISK_LABELS.items():
        rows.append({"domain": "risk_label", "key": k, "value": v,
                     "isin": None, "class": None, "sector": None, "px": None})
    for a in ASSET_CLASSES:
        rows.append({"domain": "asset_class", "key": a, "value": a,
                     "isin": None, "class": None, "sector": None, "px": None})
    for s in SECURITIES:
        rows.append({"domain": "security", "key": s["ticker"], "value": s["name"],
                     "isin": s["isin"], "class": s["class"], "sector": s["sector"], "px": s["px"]})
    return pd.DataFrame(rows)


def main():
    clients, accounts, holdings, valuation = build_data()
    pd.DataFrame(clients).to_parquet(os.path.join(BASE_DIR, "clients.parquet"), index=False)
    pd.DataFrame(accounts).to_parquet(os.path.join(BASE_DIR, "accounts.parquet"), index=False)
    pd.DataFrame(holdings).to_parquet(os.path.join(BASE_DIR, "holdings.parquet"), index=False)
    pd.DataFrame(valuation).to_parquet(os.path.join(BASE_DIR, "valuation.parquet"), index=False)
    build_reference().to_parquet(os.path.join(BASE_DIR, "reference.parquet"), index=False)
    print(f"OK: {len(clients)} clients, {len(accounts)} comptes, "
          f"{len(holdings)} positions, {len(valuation)} points de valorisation, "
          f"référence (types, risques, classes, titres)")


if __name__ == "__main__":
    main()
