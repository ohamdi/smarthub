#!/usr/bin/env python3
"""Test HTTP de la charte PPTX et du modèle corporate (client réel)."""

import io
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

from pptx import Presentation

BASE = "http://localhost:5001"
ok = fail = 0


def check(label, cond, detail=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"  OK   {label}" + (f" ({detail})" if detail else ""))
    else:
        fail += 1
        print(f"  ECHEC {label} {detail}")


def jbody(obj):
    return json.dumps(obj).encode()


# ------------------------------------------------------------------ session
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor())
req = urllib.request.Request(BASE + "/api/login", data=jbody({"username": "admin",
                                                              "password": "admin123"}),
                             method="POST", headers={"Content-Type": "application/json"})
resp = opener.open(req)
print(f"  OK   session etablie ({resp.status})")


def api(method, path, data=None, headers=None, raw=False):
    req = urllib.request.Request(BASE + path, data=data, method=method)
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with opener.open(req) as r:
            body = r.read()
            return r.status, (body if raw else json.loads(body or b"{}"))
    except urllib.error.HTTPError as e:
        body = e.read()
        try:
            return e.code, json.loads(body or b"{}")
        except Exception:
            return e.code, {"raw": body[:160].decode("utf-8", "replace")}


BOUNDARY = "----wmtest1234"

def multipart(fields, filename, content, ctype):
    parts = []
    for k, v in fields.items():
        parts.append(f"--{BOUNDARY}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n")
    head = (f"--{BOUNDARY}\r\nContent-Disposition: form-data; name=\"file\"; "
            f"filename=\"{filename}\"\r\nContent-Type: {ctype}\r\n\r\n").encode()
    parts.append(head)
    parts.append(content)
    parts.append(f"\r\n--{BOUNDARY}--\r\n".encode())
    return (b"".join(p.encode() if isinstance(p, str) else p for p in parts),
            {"Content-Type": f"multipart/form-data; boundary={BOUNDARY}"})


# ------------------------------------------------------------------ charte
print("\n== Charte : lecture")
st, b = api("GET", "/api/ai/brand")
check("GET /brand 200", st == 200, f"{st}")
check("champs presents", all(k in b for k in
      ("company", "primary", "accent", "font", "footer", "palette", "defaults")), str(len(b)))
check("pas de logo au depart", b["logo_present"] is False)
check("pas de modele au depart", b["template_present"] is False)
check("palette non vide", len(b["palette"]) >= 6, str(len(b.get("palette", []))))
check("controle d'acces", api("GET", "/api/ai/brand/logo")[0] == 404)

print("\n== Charte : enregistrement")
st, b = api("POST", "/api/ai/brand", jbody({"company": "Cabinet Meridian",
                                            "tagline": "Conseillers en gestion de patrimoine",
                                            "primary": "1B3A5C", "accent": "C8A34B",
                                            "font": "Georgia",
                                            "footer": "Cabinet Meridian — confidentiel"}),
            {"Content-Type": "application/json"})
check("POST /brand 200", st == 200, f"{st} {b.get('error','')}")
check("champs enregistres", b["brand"]["company"] == "Cabinet Meridian", b["brand"]["company"])
check("couleurs normalisees", b["brand"]["primary"] == "1B3A5C", b["brand"]["primary"])
check("palette derivee du bleu", b["brand"]["palette"][0] == "1B3A5C", b["brand"]["palette"][0])

st, b = api("POST", "/api/ai/brand", jbody({"primary": "fffff"}),
            {"Content-Type": "application/json"})
check("couleur trop claire refusee (422)", st == 422, f"{st} {b.get('error','')}")
st, b = api("POST", "/api/ai/brand", jbody({"primary": "f9f9f9"}),
            {"Content-Type": "application/json"})
check("contraste insuffisant refuse (422)", st == 422, f"{st} {b.get('error','')[:50]}")

print("\n== Logo")
from PIL import Image
buf = io.BytesIO()
Image.new("RGB", (900, 300), (27, 58, 92)).save(buf, "PNG")
data, hdr = multipart({}, "mon-logo.png", buf.getvalue(), "image/png")
st, b = api("POST", "/api/ai/brand/logo", data, hdr)
check("POST logo 200", st == 200, f"{st} {b.get('error','')}")
check("logo_signale present", b["brand"]["logo_present"] is True)
check("url du logo", b["brand"]["logo_url"].startswith("/api/ai/brand/logo"),
      b["brand"]["logo_url"])
st, raw = api("GET", "/api/ai/brand/logo", raw=True)
check("GET logo 200 + PNG", st == 200 and raw[:4] == b"\x89PNG", f"{st} {raw[:4]!r}")
st, b = api("POST", "/api/ai/brand/logo", *multipart({}, "x.svg", b"<svg/>", "image/svg+xml"))
check("SVG refuse (422)", st == 422, f"{st} {b.get('error','')[:60]}")
st, b = api("POST", "/api/ai/brand/logo", *multipart({}, "x.png", b"pas une image", "image/png"))
check("image corrompue refusee (422)", st == 422, f"{st} {b.get('error','')[:60]}")

print("\n== Modele corporate")
src = "/home/ohamdi/Bureau/synthese-global-20260930-1013.pptx"
with open(src, "rb") as f:
    raw_tpl = f.read()
st, b = api("POST", "/api/ai/brand/template", *multipart({}, "corporate.pptx", raw_tpl,
                                                          "application/vnd.openxmlformats-officedocument.presentationml.presentation"))
check("POST template 200", st == 200, f"{st} {b.get('error','')}")
check("modele signale present", b["brand"]["template_present"] is True, b["brand"].get("template_name"))
check("taille du modele", b["brand"]["template_size_kb"] > 0, str(b["brand"]["template_size_kb"]))
check("couleurs du theme lues", b["brand"]["template_colors"] is True, str(b["brand"]["palette"][:3]))
st, b = api("POST", "/api/ai/brand/template", *multipart({}, "x.txt", b"bonjour", "text/plain"))
check("format non modele refuse (422)", st == 422, f"{st} {b.get('error','')[:60]}")

# ------------------------------------------------------------------ PPTX
print("\n== PPTX avec charte + modele, global et par client")
# Le deck client a moins de diapositives : ni la synthèse multi-clients, ni
# l'inventaire des comptes des autres clients.
for cid, label, nb_slides, min_charts in (("", "global", 43, 12),
                                          ("cl_dupont", "client Jean Dupont", 17, 11)):
    st, data = api("POST", "/api/ai/pptx", jbody({"client_id": cid}),
                   {"Content-Type": "application/json"}, raw=True)
    check(f"PPTX {label} 200", st == 200, f"{st}")
    if st != 200:
        print("     ", str(data)[:200])
        continue
    prs = Presentation(io.BytesIO(data))
    slides = list(prs.slides)
    charts = sum(1 for s in slides for sh in s.shapes if sh.has_chart)
    pics = sum(1 for s in slides for sh in s.shapes if sh.shape_type == 13)
    tables = sum(1 for s in slides for sh in s.shapes if sh.has_table)
    check(f"{label}: {nb_slides} diapos", len(slides) == nb_slides, str(len(slides)))
    check(f"{label}: >= {min_charts} graphiques", charts >= min_charts, str(charts))
    check(f"{label}: tableaux", tables >= 6, str(tables))
    check(f"{label}: logo sur chaque diapo", pics == len(slides), f"{pics}/{len(slides)}")
    check(f"{label}: 16:9", round(prs.slide_width / prs.slide_height, 3) == 1.778,
          str(round(prs.slide_width / prs.slide_height, 3)))
    # charte appliquee : la couverture est de la couleur primaire
    fill = slides[0].shapes[0].fill.fore_color.rgb
    check(f"{label}: couleur de couverture = primaire", str(fill) == "1B3A5C", str(fill))
    # police de la charte
    from pptx.util import Pt
    fonts = {r.font.name for s in slides for sh in s.shapes if sh.has_text_frame
             for p in sh.text_frame.paragraphs for r in p.runs if r.text.strip()}
    check(f"{label}: police Georgia", "Georgia" in fonts, str(sorted(fonts))[:80])
    # pied de page de la charte
    texts = [sh.text_frame.text for s in slides for sh in s.shapes if sh.has_text_frame]
    check(f"{label}: pied de page de marque",
          any("Cabinet Meridian — confidentiel" in t for t in texts))
    check(f"{label}: societe en couverture",
          any("Cabinet Meridian" in t and "Conseillers" in t for t in texts))
    open(f"brand_{label}.pptx", "wb").write(data)
    print(f"       -> {len(data)//1024} Ko, {charts} graphiques, {tables} tableaux")

print("\n== Retrait du logo et du modele")
st, b = api("POST", "/api/ai/brand/logo", *multipart({"remove": "true"}, "", b"", ""))
check("retrait logo 200", st == 200 and b["brand"]["logo_present"] is False, str(st))
st, b = api("POST", "/api/ai/brand/template", *multipart({"remove": "true"}, "", b"", ""))
check("retrait modele 200", st == 200 and b["brand"]["template_present"] is False, str(st))
st, data = api("POST", "/api/ai/pptx", jbody({}), {"Content-Type": "application/json"}, raw=True)
prs = Presentation(io.BytesIO(data))
pics = sum(1 for s in prs.slides for sh in s.shapes if sh.shape_type == 13)
check("PPTX sans logo apres retrait", st == 200 and pics == 0, f"{st} {pics} images")

st, b = api("GET", "/api/ai/brand")
check("retour a la charte passee", b["primary"] == "1B3A5C", b["primary"])

# ------------------------------------------------------------------ nettoyage
# Ce test s'exécute sur l'instance réelle : il remet la charte à l'état
# neutre et efface les présentations produites, pour ne rien laisser derrière.
print("\n== Nettoyage")
st, b = api("POST", "/api/ai/brand/reset", jbody({}),
            {"Content-Type": "application/json"})
check("remise a zero 200", st == 200, str(st))
check("retour a la charte neutre", b["brand"]["primary"] == "0D6E4F",
      b.get("brand", {}).get("primary", st))
check("societe effacee", b["brand"]["company"] == "", repr(b["brand"]["company"]))
check("mention effacee", b["brand"]["footer"] == "", repr(b["brand"]["footer"]))
check("fichier de charte supprime", not Path("pptx_brand.json").exists())
left = sorted(p.name for p in Path(".").glob("brand_*.pptx"))
for p in Path(".").glob("brand_*.pptx"):
    p.unlink()
check("présentations de test effacées", not list(Path(".").glob("brand_*.pptx")),
      f"{len(left)} fichier(s) : " + (", ".join(left) or "aucun"))

print(f"\n{ok} assertions OK, {fail} echecs")
sys.exit(1 if fail else 0)