"""Comparaison de parité entre l'ancien endpoint Flask et le nouveau endpoint FastAPI.

Usage :  python tests/parity_check.py
Nécessite l'ancien serveur Flask (`legacy_flask_app.py` ou `app.py`).
"""

import importlib.util
import json
import os
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))

from fastapi.testclient import TestClient  # noqa: E402

GET_ENDPOINTS = [
    "/api/me",
    "/api/meta",
    "/api/clients",
    "/api/accounts",
    "/api/holdings",
    "/api/valuation",
    "/api/dashboard",
    "/api/dashboard?client_id=cl_roche",
    "/api/report",
    "/api/report?period=ytd",
    "/api/report?period=1y",
    "/api/report?start=2026-01-01&end=2026-09-30",
    "/api/report?client_id=cl_dupont",
    "/api/accounts?client_id=cl_dupont",
    "/api/holdings?client_id=cl_dupont",
    "/api/holdings?account_id=acc_001",
    "/api/valuation?client_id=cl_dupont",
    "/api/config/datasource",
]

# Clés dont la valeur dépend de l'horodatage / du chemin absolu.
VOLATILE = {"generated_at", "resolved", "configured", "base_dir", "config", "tables"}

# Clés ajoutées côté FastAPI après la migration : l'ancien Flask ne les
# connaît pas. L'écart est voulu, ce n'est pas un défaut de parité — mais il
# reste signalé si la clé disparaît côté Flask, d'où le filtrage unilatéral.
AJOUTS_FASTAPI = {"model"}


def _body(resp):
    """Corps brut de la réponse (`.data` chez Werkzeug, `.content` chez Starlette)."""
    body = getattr(resp, "data", None)
    if body is None:
        body = getattr(resp, "content", b"")
    return body


def as_json(resp):
    """Charge utile JSON, quelle que soit la lib (Flask ou Starlette)."""
    try:
        return json.loads(_body(resp))
    except Exception:  # noqa: BLE001
        return None


def as_text(resp) -> str:
    body = _body(resp)
    return body.decode("utf-8") if isinstance(body, (bytes, bytearray)) else str(body)


def scrub(obj, drop=frozenset()):
    """Retire les valeurs non déterministes pour une comparaison stable."""
    if isinstance(obj, dict):
        volatile = VOLATILE | drop
        return {k: scrub(v, drop) for k, v in obj.items() if k not in volatile}
    if isinstance(obj, list):
        return [scrub(v, drop) for v in obj]
    return obj


def _load_legacy_flask():
    """Charge l'ancien module Flask (renommé `legacy_flask_app.py` après migration)."""
    for candidate in ("app.py", "legacy_flask_app.py"):
        path = PROJECT / candidate
        if not path.exists():
            continue
        spec = importlib.util.spec_from_file_location("legacy_flask_app", path)
        module = importlib.util.module_from_spec(spec)
        sys.modules["legacy_flask_app"] = module
        spec.loader.exec_module(module)
        return module
    raise SystemExit(
        "Ancien module Flask introuvable (app.py / legacy_flask_app.py).")


def main() -> int:
    flask_app = _load_legacy_flask()

    from wm.main import create_app

    # --- ancien ---
    fc = flask_app.app.test_client()
    fc.post("/api/login", json={"username": "admin", "password": "admin123"})

    # --- nouveau ---
    nc = TestClient(create_app())
    nc.post("/api/login", json={"username": "admin", "password": "admin123"})

    failures = 0
    for url in GET_ENDPOINTS:
        f = fc.get(url)
        n = nc.get(url)
        if f.status_code != n.status_code:
            print(f"✗ {url}: status {f.status_code} != {n.status_code}")
            failures += 1
            continue
        if url == "/api/me":
            continue
        fj = scrub(as_json(f))
        nj = scrub(as_json(n), AJOUTS_FASTAPI)
        if fj is None or nj is None:
            print(f"? {url}: réponse non JSON")
            continue
        if fj == nj:
            print(f"✓ {url}")
        else:
            failures += 1
            print(f"✗ {url}: charge utile différente")
            if isinstance(fj, dict) and isinstance(nj, dict):
                for k in sorted(set(fj) | set(nj)):
                    if fj.get(k) != nj.get(k):
                        print(f"    clé « {k} » :")
                        print(f"      flask : {str(fj.get(k))[:180]}")
                        print(f"      fastapi: {str(nj.get(k))[:180]}")

    # --- exports CSV (comparaison textuelle) ---
    for kind in ("holdings", "clients", "accounts", "client_detail"):
        url = f"/api/export?kind={kind}"
        f, n = fc.get(url), nc.get(url)
        same = f.status_code == n.status_code == 200
        if same:
            same = as_text(f) == as_text(n)
        print(("✓ " if same else "✗ ") + url)
        failures += 0 if same else 1

    print("\n" + ("PARITÉ OK" if failures == 0 else f"{failures} DIFFÉRENCE(S)"))
    return 1 if failures else 0


if __name__ == "__main__":
    os.chdir(PROJECT)
    raise SystemExit(main())
