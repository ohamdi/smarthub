"""Teste les endpoints d'écriture (POST/PUT/DELETE) sur des données jetables.

Usage :  python tests/test_write.py
Les fichiers Parquet sont sauvegardés puis restaurés en finally.
"""

import shutil
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))

from fastapi.testclient import TestClient  # noqa: E402

from wm.main import create_app  # noqa: E402
from wm import config  # noqa: E402

BACKUP = Path(tempfile.mkdtemp(prefix="wm_backup_"))
TABLES = [config.CLIENTS_PATH, config.ACCOUNTS_PATH, config.HOLDINGS_PATH,
          config.VALUATION_PATH, config.ACCOUNT_PERF_PATH, config.REFERENCE_PATH]

passed = 0
failed = 0


def check(label, cond, extra=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  ✓ {label}")
    else:
        failed += 1
        print(f"  ✗ {label} {extra}")


def backup():
    for t in TABLES:
        if t.exists():
            shutil.copy2(t, BACKUP / t.name)


def restore():
    for t in TABLES:
        if (BACKUP / t.name).exists():
            shutil.copy2(BACKUP / t.name, t)
    shutil.rmtree(BACKUP, ignore_errors=True)


def main() -> int:
    backup()
    try:
        c = TestClient(create_app())
        with c:
            c.post("/api/login", json={"username": "admin", "password": "admin123"})

            # ---------------- clients ----------------
            print("clients")
            r = c.post("/api/clients", json={"name": "Client Test", "risk_profile": "dynamique"})
            check("POST /api/clients -> 201", r.status_code == 201, r.text[:120])
            cid = r.json().get("id")
            check("id généré", bool(cid))
            check("créé par la réponse",
                  any(x["id"] == cid for x in c.get("/api/clients").json()))

            r = c.put(f"/api/clients/{cid}", json={"name": "Renommé", "advisor": "M. X"})
            check("PUT /api/clients -> 200", r.status_code == 200, r.text[:120])
            row = next((x for x in c.get("/api/clients").json() if x["id"] == cid), None)
            check("nom mis à jour", row and row["name"] == "Renommé", str(row))
            check("conseiller mis à jour", row and row["advisor"] == "M. X", str(row))

            # ---------------- accounts ----------------
            print("accounts")
            r = c.post("/api/accounts", json={"client_id": cid, "account_name": "Compte test",
                                              "account_type": "pea", "cash": 1234.56})
            check("POST /api/accounts -> 201", r.status_code == 201, r.text[:120])
            aid = r.json().get("id")
            check("compte visible", any(a["id"] == aid for a in c.get("/api/accounts").json()))

            r = c.put(f"/api/accounts/{aid}", json={"cash": 9999.99})
            check("PUT /api/accounts -> 200", r.status_code == 200, r.text[:120])
            row = next((a for a in c.get("/api/accounts").json() if a["id"] == aid), None)
            check("cash mis à jour", row and abs(float(row["cash"]) - 9999.99) < 0.01, str(row))

            # ---------------- holdings ----------------
            print("holdings")
            r = c.post("/api/holdings", json={"account_id": aid, "ticker": "AIR.PA",
                                              "name": "Airbus SE", "quantity": 10,
                                              "unit_cost": 100.0, "unit_price": 150.0,
                                              "asset_class": "Action", "sector": "Aéronautique"})
            check("POST /api/holdings -> 201", r.status_code == 201, r.text[:120])
            hid = r.json().get("id")
            hs = c.get("/api/holdings?account_id=" + aid).json()
            check("holding filtré par compte", len(hs) == 1 and hs[0]["id"] == hid, str(hs)[:150])

            r = c.put(f"/api/holdings/{hid}", json={"quantity": 20})
            check("PUT /api/holdings -> 200", r.status_code == 200, r.text[:120])
            hs = c.get("/api/holdings?account_id=" + aid).json()
            check("quantité mise à jour", hs and abs(float(hs[0]["quantity"]) - 20) < 1e-6,
                  str(hs)[:150])

            r = c.delete(f"/api/holdings/{hid}")
            check("DELETE /api/holdings -> 200", r.status_code == 200, r.text[:120])
            check("holding supprimé", not c.get("/api/holdings?account_id=" + aid).json())

            # cascade
            r = c.delete(f"/api/accounts/{aid}")
            check("DELETE /api/accounts -> 200", r.status_code == 200, r.text[:120])
            check("compte supprimé", not any(a["id"] == aid
                                              for a in c.get("/api/accounts").json()))

            r = c.delete(f"/api/clients/{cid}")
            check("DELETE /api/clients -> 200", r.status_code == 200, r.text[:120])
            check("client supprimé", not any(x["id"] == cid
                                             for x in c.get("/api/clients").json()))

            # ---------------- Factsheet ----------------
            print("factsheet")
            r = c.get("/api/report/excel")
            check("GET /api/report/excel", r.status_code == 200
                  and r.content[:2] == b"PK", r.headers.get("content-type", ""))
            r = c.get("/api/report/pdf")
            check("GET /api/report/pdf", r.status_code == 200
                  and r.content[:4] == b"%PDF", r.headers.get("content-type", ""))

        # ---------------- auth ----------------
        print("auth")
        anon = TestClient(create_app())
        r = anon.post("/api/login", json={"username": "admin", "password": "wrong"})
        check("login refusé -> 401", r.status_code == 401, r.text[:120])
        check("message d'erreur", r.json().get("error") == "Identifiants invalides", r.text[:120])
        r = anon.get("/api/dashboard")
        check("route protégée -> 401", r.status_code == 401, r.text[:120])
        check("login_required dans le corps", r.json().get("login_required") is True, r.text[:120])
        r = anon.get("/api/report/excel")
        check("factsheet protégé -> 401", r.status_code == 401, r.text[:120])

        r = anon.post("/api/login", json={"username": "GESTIONNAIRE",
                                          "password": "wealth123"})
        check("casse insensible", r.status_code == 200, r.text[:120])
        check("rôle gestionnaire", r.json().get("role") == "user", r.text[:120])

        # ---------------- DataSource ----------------
        print("datasource")
        d = TestClient(create_app())
        with d:
            d.post("/api/login", json={"username": "admin", "password": "admin123"})
            r = d.get("/api/config/datasource")
            check("GET /api/config/datasource", r.status_code == 200, r.text[:120])
            body = r.json()
            check("tables exposées", set(body["tables"]) == {
                k for k, _, _ in config.DS_FIELDS}, str(list(body["tables"])))
            check("base_dir", body["base_dir"] == str(config.PROJECT_DIR), body["base_dir"])
            for t in body["tables"].values():
                check(f"  {t['label']} : fichier présent",
                      t["exists"] and t["rows"] > 0, str(t)[:120])

            r = d.post("/api/config/datasource",
                       json={"clients_path": str(PROJECT / "clients.parquet")})
            check("POST config save", r.status_code == 200, r.text[:120])
            check("config écrite", config.CONFIG_PATH.exists())
            r = d.get("/api/config/datasource")
            check("config relue", r.json()["config"].get("clients_path", "")
                  == str(PROJECT / "clients.parquet"), r.text[:200])
            config.CONFIG_PATH.unlink(missing_ok=True)

            r = d.post("/api/config/datasource", json={"action": "reset"})
            check("POST reset -> 200", r.status_code == 200, r.text[:200])
            check("message de reset", "régénérées" in (r.json().get("message") or ""),
                  r.text[:200])
            check("clients régénérés", config.CLIENTS_PATH.exists())
    finally:
        restore()

    print(f"\n{passed} test(s) réussi(s), {failed} échec(s)")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
