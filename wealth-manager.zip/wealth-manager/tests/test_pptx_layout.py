"""Contrôle géométrique du PPTX : rien ne doit déborder ni se chevaucher.

    python tests/test_pptx_layout.py

python-pptx ne rend pas les diapositives : on vérifie donc les *boîtes*
(left/top/width/height, en pouces) de chaque forme, ainsi que la présence des
données attendues dans chaque graphique.
"""

from __future__ import annotations

import io
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import Image  # noqa: E402
from pptx import Presentation  # noqa: E402
from pptx.util import Emu  # noqa: E402

from wm.ai import brand  # noqa: E402
from wm.ai.context import build_context  # noqa: E402
from wm.ai.pptx_report import build_pptx  # noqa: E402

SLIDE_W, SLIDE_H = 13.333, 7.5
#: zone utile : marges de 0,4" et pied de page réservé
SAFE = (0.4, 0.3, SLIDE_W - 0.4, SLIDE_H - 0.55)

OK, KO = 0, 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global OK, KO
    if condition:
        OK += 1
        print(f"  OK   {label}")
    else:
        KO += 1
        print(f"  ECHEC {label} {detail}")


def inches(value) -> float:
    return Emu(int(value)).inches


def boxes(slide):
    """Formes porteuses de contenu (hors texte de fond et pied de page)."""
    out = []
    for sh in slide.shapes:
        kind = "chart" if sh.has_chart else (
            "table" if getattr(sh, "has_table", False) and sh.has_table else None)
        if kind is None:
            continue
        out.append((kind, inches(sh.left), inches(sh.top),
                    inches(sh.left) + inches(sh.width),
                    inches(sh.top) + inches(sh.height)))
    return out


def text_boxes(slide):
    """Zones de texte libres : elles ne doivent pas non plus recouvrir
    un graphique ou un tableau (en-tête, légende, note de bas de diapositive)."""
    out = []
    for sh in slide.shapes:
        if sh.has_chart or (getattr(sh, "has_table", False) and sh.has_table):
            continue
        if not sh.has_text_frame or not sh.text_frame.text.strip():
            continue
        if sh.shape_type is not None and "TEXT_BOX" not in str(sh.shape_type):
            continue
        out.append(("texte", inches(sh.left), inches(sh.top),
                    inches(sh.left) + inches(sh.width),
                    inches(sh.top) + inches(sh.height)))
    return out


def overlaps(a, b) -> bool:
    return (a[1] < b[3] and b[1] < a[3] and a[2] < b[4] and b[2] < a[4])


def audit(prs, label: str) -> None:
    print(f"\n=== {label} — {len(prs.slides)} diapositives")
    for i, slide in enumerate(prs.slides, 1):
        bs = boxes(slide)
        for kind, x1, y1, x2, y2 in bs:
            inside = (x1 >= SAFE[0] and y1 >= SAFE[1]
                      and x2 <= SAFE[2] and y2 <= SAFE[3])
            check(f"diapo {i} : {kind} dans la zone utile", inside,
                  f"({x1:.2f},{y1:.2f})->({x2:.2f},{y2:.2f})")
        for n, a in enumerate(bs):
            for b in bs[n + 1:]:
                check(f"diapo {i} : pas de chevauchement {a[0]}/{b[0]}",
                      not overlaps(a, b),
                      f"{a[1:]} vs {b[1:]}")
        for t in text_boxes(slide):
            for b in bs:
                check(f"diapo {i} : texte hors {b[0]}", not overlaps(t, b),
                      f"{t[1:]} vs {b[1:]}")


def audit_charts(prs, label: str) -> None:
    print(f"\n=== {label} — contenu des graphiques")
    n = 0
    for i, slide in enumerate(prs.slides, 1):
        for sh in slide.shapes:
            if not sh.has_chart:
                continue
            n += 1
            chart = sh.chart
            cats = [str(c) for c in chart.plots[0].categories]
            series = [(s.name, list(s.values)) for s in chart.series]
            check(f"diapo {i} : graphique alimenté", bool(cats) and bool(series),
                  f"{cats[:3]} / {series[:1]}")
            check(f"diapo {i} : toutes les séries dimensionnées",
                  all(len(v) == len(cats) for _, v in series),
                  str([(nm, len(v)) for nm, v in series]))
            if len(series) == 1:
                check(f"diapo {i} : valeurs non nulles",
                      any(abs(float(v or 0)) > 0 for v in series[0][1]),
                      str(series[0][1][:5]))
    check("au moins 10 graphiques", n >= 10, str(n))
    print(f"  ({n} graphiques audités)")


def main() -> int:
    facts = build_context()["facts"]
    print("Contrôle géométrique du PPTX")

    data, _ = build_pptx(commentary="SYNTHESE — Test\n- un point")
    prs = Presentation(io.BytesIO(data))
    audit(prs, "deck global")
    audit_charts(prs, "deck global")

    data2, _ = build_pptx(client_id=facts["clients_detail"][0]["id"])
    audit(Presentation(io.BytesIO(data2)), "deck client")

    # série temporelle : les libellés de mois doivent être uniques (l'axe
    # affichait « 2025-11 » deux fois avant l'agrégation par mois)
    evo = [sh.chart for s in prs.slides for sh in s.shapes
           if sh.has_chart and "LINE" in str(sh.chart.chart_type)]
    check("une courbe d'évolution", len(evo) == 1, str(len(evo)))
    if evo:
        labels = [str(c) for c in evo[0].plots[0].categories]
        check("libellés mensuels uniques", len(labels) == len(set(labels)), str(labels))
        check("deux séries minimum", len(evo[0].series) == 3,
              str([s.name for s in evo[0].series]))

    # Charte avec logo : le logo occupe le coin droit, il ne doit chevaucher
    # ni le titre, ni le pied de page, ni sortir de la zone utile.
    print("\n=== deck avec logo et modèle corporate")
    tmp = Path(tempfile.mkdtemp(prefix="wm_layout_"))
    original = (brand.BRAND_PATH, brand.ASSETS_DIR, brand.TEMPLATES_DIR)
    try:
        brand.BRAND_PATH = tmp / "pptx_brand.json"
        brand.ASSETS_DIR = tmp / "assets"
        brand.TEMPLATES_DIR = tmp / "templates"
        # logo panoramique (courant) et logo vertical (cas défavorable)
        brand.ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        Image.new("RGB", (1200, 400), (27, 58, 92)).save(brand.ASSETS_DIR / "logo.png", "PNG")
        brand.save_brand({"logo": "logo.png", "company": "Cabinet Meridian",
                          "primary": "1B3A5C", "font": "Georgia"})
        branded = Presentation(io.BytesIO(build_pptx()[0]))
        audit(branded, "deck avec logo")
        for i, slide in enumerate(branded.slides, 1):
            pics = [sh for sh in slide.shapes if sh.shape_type == 13]
            check(f"diapo {i} : logo posé", len(pics) == 1, str(len(pics)))
            if not pics:
                continue
            pic = pics[0]
            box = ("logo", inches(pic.left), inches(pic.top),
                   inches(pic.left) + inches(pic.width),
                   inches(pic.top) + inches(pic.height))
            check(f"diapo {i} : logo dans la zone utile",
                  box[1] >= SAFE[0] and box[2] >= SAFE[1]
                  and box[3] <= SAFE[2] and box[4] <= SLIDE_H,
                  f"{box[1]:.2f},{box[2]:.2f} {box[3]-box[1]:.2f}x{box[4]-box[2]:.2f}")
            for t in text_boxes(slide):
                check(f"diapo {i} : texte hors logo", not overlaps(t, box), str(t[1:]))

        Image.new("RGB", (200, 1600), (200, 30, 30)).save(brand.ASSETS_DIR / "logo.png", "PNG")
        brand.save_brand({"logo": "logo.png"})
        tall = Presentation(io.BytesIO(build_pptx()[0]))
        tallpics = [sh for s in tall.slides for sh in s.shapes if sh.shape_type == 13]
        check("logo vertical : un logo par diapositive",
              len(tallpics) == len(list(tall.slides)), str(len(tallpics)))
        # La couverture centre un logo plus grand que l'en-tête des autres.
        check("logo vertical : hauteur bornée",
              all(inches(p.height) <= 1.1 for p in tallpics),
              str(max((round(inches(p.height), 2) for p in tallpics), default=0)))
        audit(tall, "deck logo vertical")
    finally:
        brand.BRAND_PATH, brand.ASSETS_DIR, brand.TEMPLATES_DIR = original
        shutil.rmtree(tmp, ignore_errors=True)

    print(f"\n{'='*46}\n{OK} assertions OK, {KO} echecs")
    return 1 if KO else 0


if __name__ == "__main__":
    raise SystemExit(main())
