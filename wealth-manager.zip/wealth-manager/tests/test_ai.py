"""Tests du module IA — sans charger de modèle (donc rapides).

    python tests/test_ai.py

Couvre : construction du contexte et de ses niveaux de détail, contrôle des
chiffres cités, découpage des rubriques de commentaire, génération PPTX et
routes HTTP (statut, contexte, config, PPTX sans IA).
"""

from __future__ import annotations

import io
import sys
import tempfile
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient  # noqa: E402

from wm.ai import verify  # noqa: E402
from wm.ai.config import DEFAULT_MODEL, expand, list_models, load_ai_config  # noqa: E402
from wm.ai.context import DETAIL_LEVELS, build_context  # noqa: E402
from wm.ai.pptx_report import build_pptx  # noqa: E402
from wm.main import create_app  # noqa: E402

OK, KO = 0, 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global OK, KO
    if condition:
        OK += 1
        print(f"  OK   {label}")
    else:
        KO += 1
        print(f"  ECHEC {label} {detail}")


def section(title: str) -> None:
    print(f"\n=== {title}")


# ------------------------------------------------------------------ contexte
def test_context() -> None:
    section("Contexte métier")
    ctx = build_context()
    facts = ctx["facts"]
    text = ctx["text"]

    check("périmètre global", ctx["scope"] == "Tous les clients", ctx["scope"])
    check("AuM = titres + liquidites",
          abs(facts["aum"] - (facts["market_value"] + facts["cash"])) < 0.01)
    check("volumetrie non nulle",
          facts["clients"] > 0 and facts["accounts"] > 0 and facts["positions"] > 0)
    check("P&L cohérent avec le ratio",
          facts["pnl_pct"] is None or abs(facts["pnl"]) > 0)
    check("allocation par classe presente", bool(facts["by_class"]))
    check("positions classées", bool(facts["top_positions"]))
    check("somme des classes = valorisation des titres",
          abs(sum(r["value"] for r in facts["by_class"]) - facts["market_value"]) < 1.0)

    # ---- types de compte ----
    types = facts["by_account_type"]
    check("types de compte calcules", len(types) >= 2, str(len(types)))
    check("somme des types de compte = AuM",
          abs(sum(t["total_value"] for t in types) - facts["aum"]) < 1.0,
          f"{sum(t['total_value'] for t in types)} vs {facts['aum']}")
    check("somme des poids = 100 %",
          abs(sum(t["weight"] for t in types) - 100) < 0.5,
          str(sum(t["weight"] for t in types)))
    check("comptes par type = total des comptes",
          sum(t["accounts"] for t in types) == facts["accounts"])
    check("positions par type = total des positions",
          sum(t["positions"] for t in types) == facts["positions"])
    check("titres + liquidites = total par type",
          all(abs(t["market_value"] + t["cash"] - t["total_value"]) < 1.0 for t in types))
    check("types tries par taille decroissante",
          all(types[i]["total_value"] >= types[i + 1]["total_value"]
              for i in range(len(types) - 1)))
    check("types libelles",
          all(t["label"] and t["label"] != t["key"].upper() or t["label"] == t["key"].upper()
              for t in types), str([t["label"] for t in types]))
    check("section type de compte presente dans le contexte",
          "PAR TYPE DE COMPTE" in text)
    check("le mot enveloppe a disparu du contexte",
          "enveloppe" not in text.lower() and "ENVELOPPE" not in text)
    check("nom d'un type de compte cite dans le contexte",
          any(t["label"] in text for t in types), str([t["label"] for t in types]))
    check("top par type renseigne", bool(facts["top_by_account_type"]))
    check("poids d'un titre borne a son type de compte",
          all(0 <= r["weight"] <= 100 for r in facts["top_by_account_type"]))
    check("matrice de performance par type presente",
          bool(facts["performance_by_account_type"]))
    check("le texte contient les indicateurs", "INDICATEURS" in text)
    check("aucune section vide", ":\n\n-" not in text)
    check("aucune section vide cote types de compte", "type de compte\n\n" not in text)
    check("le contexte ne dépasse pas le budget",
          len(text) <= DETAIL_LEVELS[ctx["detail"]]["max_chars"] + 300,
          f"{len(text)} caractères")

    # niveaux de détail
    sizes = {}
    for level in DETAIL_LEVELS:
        c = build_context(detail=level)
        sizes[level] = len(c["text"])
    check("niveaux ordonnés par taille croissante",
          sizes["rapide"] <= sizes["standard"] <= sizes["complet"], str(sizes))
    check("niveau inconnu -> repli sur standard",
          build_context(detail="inexistant")["detail"] == "standard")

    # périmètre client
    first = facts["clients_detail"][0]
    scoped = build_context(client_id=first["id"])
    check("périmètre client restreint",
          0 < scoped["facts"]["aum"] < facts["aum"],
          f"{scoped['facts']['aum']} vs {facts['aum']}")
    check("nom du client dans le périmètre", first["name"] in scoped["text"])
    try:
        build_context(client_id="client_inexistant")
        check("client inconnu rejeté", False, "aucune exception levée")
    except ValueError:
        check("client inconnu rejeté", True)


# ------------------------------------------------------------------ vérification
def test_verify() -> None:
    section("Contrôle des chiffres")
    ctx = build_context()
    tickers = [h.get("ticker", "") for h in ctx["report"]["holdings"]]
    text, facts = ctx["text"], ctx["facts"]
    aum = facts["aum"]
    pnl = facts["pnl"]
    top = facts["by_class"][0]

    def fmt(v: float) -> str:
        return f"{v:,.2f}".replace(",", " ").replace(".", ",")

    cases_ok = [
        ("montant exact repris", f"L'AuM s'eleve a {fmt(aum)} EUR et le P&L a {fmt(pnl)} EUR."),
        ("arrondi legitime", f"Environ {round(aum / 1000):.0f} k EUR de patrimoine."),
        ("ticker connu", "AIR.PA et NVDA sont les premieres positions."),
        ("sigle present dans les noms de fonds", "Le fonds MSCI World domine l'allocation ETF."),
        ("titres de section", "**SYNTHESE** — **RISQUES** — **ALLOCATION** : rien de notable."),
        ("unites et acronymes", "Les positions sont libelles en EUR, avec un P&L YTD et des ETF."),
        ("montant par type de compte repris",
         f"Le PEA detient {fmt(facts['by_account_type'][0]['total_value'])} EUR."),
    ]
    for label, answer in cases_ok:
        r = verify.check(answer, text, facts, tickers)
        check(f"accepte : {label}", r["ok"], str(verify.warning(r)))

    cases_ko = [
        ("montant ampute d'un chiffre", "Les actions dominent avec 766 784 EUR.",
         lambda r: any("766" in n["value"] for n in r["unverified_numbers"])),
        ("montant invente", "Le portefeuille vaut 1 500 000 000 EUR.",
         lambda r: bool(r["unverified_numbers"])),
        ("ventilation par type inventee", "Le PEA totalise 9 999 999 EUR.",
         lambda r: bool(r["unverified_numbers"])),
        ("ticker invente", "Le portefeuille detient GOOGL et TESLA.",
         lambda r: set(r["unknown_tickers"]) == {"GOOGL", "TESLA"}),
        ("ticker mal orthographie", f"{top['label']} est en tete via NVDIA.",
         lambda r: "NVDIA" in r["unknown_tickers"]),
    ]
    for label, answer, predicate in cases_ko:
        r = verify.check(answer, text, facts, tickers)
        check(f"detecte : {label}", not r["ok"] and predicate(r), str(r))
        check(f"avertissement : {label}", verify.warning(r).startswith("À vérifier"))

    check("aucun avertissement quand tout est bon",
          verify.warning(verify.check(f"AuM {fmt(aum)} EUR.", text, facts, tickers)) == "")

    # les nombres sous 1000 ne sont pas contrôlés (pourcentages, jours)
    r = verify.check("Le portefeuille a gained 12 % sur 5 jours.", text, facts, tickers)
    check("petits nombres ignores", r["ok"] and r["numbers_checked"] == 0, str(r))


# ------------------------------------------------------------------ rubriques
def test_commentary_blocks() -> None:
    section("Découpage du commentaire")
    raw = ("**SYNTHESE** — Le portefeuille atteint 16 021 506,71 EUR.\n"
           "**ALLOCATION** — Les actions dominent.\n"
           "- 54,9 % en actions\n"
           "- 28,3 % en ETF\n"
           "**RISQUES** — Concentration sectorielle forte.\n")
    blocks = verify.commentary_blocks(raw, ["SYNTHESE", "ALLOCATION", "RISQUES"])
    titles = [b["title"] for b in blocks]
    check("trois rubriques détectées", len(blocks) == 3, str(titles))
    check("titres reconnus", titles == ["SYNTHESE", "ALLOCATION", "RISQUES"], str(titles))
    check("puces conservées", "54,9 %" in blocks[1]["text"], blocks[1]["text"])
    check("gras retiré du texte", "**" not in blocks[0]["text"])

    check("texte vide toléré", verify.commentary_blocks("") == [])
    free = verify.commentary_blocks("Un paragraphe libre sans rubrique du tout.")
    check("texte libre non vide", len(free) == 1 and free[0]["text"], str(free))
    check("markdown épuré",
          verify.commentary_blocks("## ALLOCATION\n- 50 % actions")[0]["title"] == "ALLOCATION")


# ------------------------------------------------------------------ PPTX
def test_pptx() -> None:
    section("Présentation PPTX")
    from pptx import Presentation

    commentary = ("SYNTHESE — Le portefeuille progresse.\n"
                  "ALLOCATION — Les actions dominent a 54,9 %.\n"
                  "- Forte concentration sectorielle\n")
    data, name = build_pptx(commentary=commentary)
    check("fichier produit", len(data) > 10_000, f"{len(data)} octets")
    check("nom de fichier cohérent", name.startswith("synthese-global-") and name.endswith(".pptx"), name)

    prs = Presentation(io.BytesIO(data))
    check("format 16:9", round(prs.slide_width / prs.slide_height, 2) == 1.78,
          f"{prs.slide_width}x{prs.slide_height}")
    # 43 diapositives : couverture, périmètre, sommaire, types de compte, un
    # inventaire par compte titres, historique mensuel, analyse, commentaire.
    check("deck global complet", len(prs.slides) == 44, str(len(prs.slides)))
    charts = sum(1 for s in prs.slides for sh in s.shapes if sh.has_chart)
    tables = sum(1 for s in prs.slides for sh in s.shapes
                 if getattr(sh, "has_table", False) and sh.has_table)
    check("graphiques présents", charts >= 12, str(charts))
    check("tableaux présents", tables >= 8, str(tables))
    # les types de compte doivent disposer de leurs propres diapositives
    titles = [" ".join(sh.text_frame.text for sh in s.shapes if sh.has_text_frame)
              for s in prs.slides]
    check("slides dédiées aux types de compte",
          any("Repartition par type de compte" in t for t in titles)
          and any("Contenu par type de compte" in t for t in titles))
    check("le mot enveloppe a disparu du deck",
          not any("nveloppe" in t for t in titles))
    check("slide de concentration presente",
          any("CONCENTRATION" in t for t in titles))
    check("tous les graphiques sont alimentes",
          all(list(sh.chart.plots[0].categories)
              for s in prs.slides for sh in s.shapes if sh.has_chart))

    facts = build_context()["facts"]
    data2, name2 = build_pptx(client_id=facts["clients_detail"][0]["id"], commentary=None)
    prs2 = Presentation(io.BytesIO(data2))
    # Le deck client a le même plan, sans la synthèse multi-clients, et son
    # inventaire ne couvre que les comptes du client sélectionné.
    check("deck client : synthèse multi-clients retirée",
          len(prs2.slides) == 17, str(len(prs2.slides)))
    charts2 = sum(1 for s in prs2.slides for sh in s.shapes if sh.has_chart)
    check("deck client : graphiques conserves", charts2 >= 11, str(charts2))
    type_names = [t["label"] for t in facts["by_account_type"]]
    body = " ".join(sh.text_frame.text for s in prs2.slides for sh in s.shapes
                    if sh.has_text_frame)
    check("noms de types de compte dans le deck client",
          any(n in body for n in type_names), str(type_names))
    check("deck client plus léger", len(data2) < len(data), f"{len(data2)} vs {len(data)}")

    data3, name3 = build_pptx()
    check("generation sans commentaire", len(data3) > 10_000)
    check("cover : titre et date du jour", "Synthese des actifs"
          in " ".join(sh.text_frame.text for sh in prs.slides[0].shapes
                      if sh.has_text_frame)
          and datetime.now().strftime("%d/%m/%Y")
          in " ".join(sh.text_frame.text for sh in prs.slides[0].shapes
                      if sh.has_text_frame))
    check("cover : les chiffres sont en page 2", "16 021" not in
          " ".join(sh.text_frame.text for sh in prs.slides[0].shapes
                   if sh.has_text_frame))


# ------------------------------------------------------------------ configuration
def test_config() -> None:
    section("Configuration et détection de modèles")
    from wm.ai.config import save_ai_config

    cfg = load_ai_config()
    check("modèle par défaut défini", bool(cfg["model_path"]))
    check("le modèle par défaut est un GGUF", expand(cfg["model_path"]).name.endswith(".gguf"))
    check("n_ctx suffisant", cfg["n_ctx"] >= 4096, str(cfg["n_ctx"]))
    check("n_threads automatique", cfg["n_threads"] == 0)

    models = list_models()
    check("des modèles sont détectés", len(models) > 0, f"{len(models)} trouvés")
    check("entrées complètes", all({"name", "path", "size_mb"} <= set(m) for m in models))
    check("pas de doublon", len({m["path"] for m in models}) == len(models))
    check("modèle par défaut listé",
          any(m["path"] == str(expand(cfg["model_path"])) for m in models)
          or not expand(cfg["model_path"]).exists())

    # écriture non destructive : on restaure le fichier après coup
    with tempfile.TemporaryDirectory() as tmp:
        from wm.ai import config as ai_config
        original = ai_config.AI_CONFIG_PATH
        try:
            ai_config.AI_CONFIG_PATH = Path(tmp) / "ai_config.json"
            save_ai_config({"model_path": "/tmp/autre.gguf", "n_ctx": 4096})
            back = load_ai_config()
            check("valeur enregistrée", back["model_path"] == "/tmp/autre.gguf")
            check("clés inconnues ignorées",
                  save_ai_config({"inconnu": 1}).get("inconnu") is None)
            check("n_ctx enregistré", back["n_ctx"] == 4096)
        finally:
            ai_config.AI_CONFIG_PATH = original


# ------------------------------------------------------------------ routes
def test_routes() -> None:
    section("Routes HTTP")
    from wm.ai import config as ai_config
    from wm.ai import engine

    # On pointe la configuration vers un modèle inexistant : les routes qui
    # demandent une génération doivent répondre 503 sans lancer d'inférence.
    original = ai_config.AI_CONFIG_PATH
    tmp = Path(tempfile.mkdtemp())
    try:
        ai_config.AI_CONFIG_PATH = tmp / "ai_config.json"
        save_ai_config_helper(ai_config, {"model_path": str(tmp / "absent.gguf")})
        engine.unload()

        client = TestClient(create_app())
        check("401 sans session", client.get("/api/ai/status").status_code == 401)

        login = client.post("/api/login",
                            json={"username": "admin", "password": "admin123"})
        check("connexion OK", login.status_code == 200, str(login.status_code))

        r = client.get("/api/ai/status")
        check("status 200", r.status_code == 200)
        body = r.json()
        check("modèle déclaré", bool(body.get("model_name")))
        check("modèle absent signalé", body.get("available") is False)
        check("niveaux de détail exposés", len(body.get("detail_levels", [])) == 3)
        check("modèles réellement présents listés", isinstance(body.get("models"), list))
        check("moteur non chargé au repos", body.get("loaded") is False)

        r = client.get("/api/ai/context?detail=rapide")
        check("contexte 200", r.status_code == 200)
        check("contexte non vide", len(r.json().get("context", "")) > 500)

        r = client.get("/api/ai/context?client_id=inexistant")
        check("client inconnu -> 422", r.status_code == 422, str(r.status_code))

        for path, payload in (("/api/ai/chat", {"message": "test"}),
                              ("/api/ai/commentary", {}),
                              ("/api/ai/estimate", {"message": "test"}),
                              ("/api/ai/warmup", {})):
            r = client.post(path, json=payload)
            check(f"{path} sans modèle -> 503 (pas 500)",
                  r.status_code == 503, str(r.status_code))
            check(f"{path} message d'erreur lisible", "error" in r.json())

        r = client.post("/api/ai/chat", json={"message": ""})
        check("question vide -> 422", r.status_code == 422, str(r.status_code))

        # La génération du PPTX est purement calculatoire : elle doit
        # fonctionner même sans modèle disponible.
        r = client.post("/api/ai/pptx", json={"commentary": "SYNTHESE — Test."})
        check("pptx sans modèle 200 (génération pure)", r.status_code == 200,
              str(r.status_code))
        check("type MIME pptx", "presentationml" in r.headers.get("content-type", ""))
        check("taille plausible", len(r.content) > 10_000)
        check("Content-Disposition",
              "attachment" in r.headers.get("content-disposition", ""))

        r = client.get("/api/ai/config")
        check("config 200", r.status_code == 200 and "model_path" in r.json())

        # un périmètre inexistant est une erreur de requête, pas une panne
        r = client.post("/api/ai/pptx", json={"client_id": "client_inexistant"})
        check("pptx client inconnu -> 422 (pas 500)", r.status_code == 422,
              str(r.status_code))
        check("pptx client inconnu : message explicite",
              "Client inconnu" in r.json().get("error", ""), str(r.json()))
    finally:
        ai_config.AI_CONFIG_PATH = original
        engine.unload()


def save_ai_config_helper(ai_config, values: dict) -> None:
    ai_config.save_ai_config(values)


# --------------------------------------------------------------- datasource
def test_datasource_model() -> None:
    """Le chemin du modèle est paramétrable depuis l'onglet DataSource."""
    section("DataSource : chemin du modèle IA")
    from wm import config as app_config
    from wm.ai import config as ai_config
    from wm.ai.config import DEFAULT_MODEL, load_ai_config
    from wm.routers.datasource import _resolved_model

    # l'onglet DataSource et l'onglet Analyse IA lisent la même valeur
    described = _resolved_model()
    check("modèle décrit par le DataSource",
          described["configured"] == load_ai_config()["model_path"])
    check("chemin résolu en absolu", Path(described["resolved"]).is_absolute())
    check("existence cohérente avec le disque",
          described["exists"] == Path(described["resolved"]).is_file())

    client = TestClient(create_app())
    client.post("/api/login", json={"username": "admin", "password": "admin123"})

    # Écriture dans des fichiers temporaires : ni `ai_config.json` ni
    # `datasource_config.json` du projet ne doivent être touchés par les tests.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        originals = (ai_config.AI_CONFIG_PATH, app_config.CONFIG_PATH)
        try:
            ai_config.AI_CONFIG_PATH = tmp / "ai_config.json"
            app_config.CONFIG_PATH = tmp / "datasource_config.json"

            r = client.get("/api/config/datasource")
            check("GET 200", r.status_code == 200, str(r.status_code))
            check("modèle décrit dans la réponse",
                  set(r.json().get("model", {}))
                  == {"label", "configured", "resolved", "exists", "size_mb"},
                  str(sorted(r.json().get("model", {}))))
            check("modèle par défaut proposé",
                  r.json()["model"]["configured"] == DEFAULT_MODEL)

            # un corps sans `model_path` ne doit pas toucher au réglage
            before = load_ai_config()["model_path"]
            r = client.post("/api/config/datasource",
                            json={"clients_path": "clients.parquet"})
            check("POST 200", r.status_code == 200, str(r.status_code))
            check("modèle inchangé si le champ est absent",
                  load_ai_config()["model_path"] == before)
            check("le message annonce le redémarrage des tables",
                  "redémarrage du serveur" in r.json()["message"], r.json()["message"])

            r = client.post("/api/config/datasource",
                            json={"model_path": "/tmp/perso.gguf"})
            check("modèle enregistré",
                  load_ai_config()["model_path"] == "/tmp/perso.gguf")
            check("le même réglage est relu par l'onglet Analyse IA",
                  client.get("/api/ai/config").json()["model_path"] == "/tmp/perso.gguf")
            served = client.get("/api/config/datasource").json()["model"]
            check("le chemin personnalisé est renvoyé au DataSource",
                  served["configured"] == "/tmp/perso.gguf")
            check("un fichier absent est signalé", served["exists"] is False)
            check("aucun redémarrage annoncé pour le modèle",
                  "redémarrage" not in r.json()["message"], r.json()["message"])

            # un champ vide rétablit le modèle par défaut
            client.post("/api/config/datasource", json={"model_path": ""})
            check("champ vide = modèle par défaut",
                  load_ai_config()["model_path"] == DEFAULT_MODEL)

            r = client.post("/api/config/datasource", json={})
            check("rien à changer -> message neutre",
                  "aucun changement" in r.json()["message"], r.json()["message"])
        finally:
            ai_config.AI_CONFIG_PATH, app_config.CONFIG_PATH = originals


def main() -> int:
    print("Tests du module IA (sans modèle)")
    test_context()
    test_verify()
    test_commentary_blocks()
    test_pptx()
    test_config()
    test_datasource_model()
    test_routes()
    print(f"\n{'='*46}\n{OK} assertions OK, {KO} echecs")
    return 1 if KO else 0


if __name__ == "__main__":
    raise SystemExit(main())
