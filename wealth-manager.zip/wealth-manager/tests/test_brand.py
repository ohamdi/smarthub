"""Tests de la charte PPTX et du modèle corporate — sans charger de modèle.

    python tests/test_brand.py

Couvre : couleurs et contraste, normalisation et persistance de la charte,
dépôt/retrait d'un logo et d'un modèle corporate, application effective de la
charte au PPTX (couleur de couverture, police, logo, pied de page) et routes
HTTP associées.

Le module `wm.ai.brand` lit des chemins de module (`BRAND_PATH`, `ASSETS_DIR`,
`TEMPLATES_DIR`) : les tests les redirigent vers un répertoire temporaire et
n'altèrent jamais la charte réelle du poste.
"""

from __future__ import annotations

import io
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient  # noqa: E402
from PIL import Image  # noqa: E402
from pptx import Presentation  # noqa: E402
from pptx.util import Emu  # noqa: E402

from wm.ai import brand as B  # noqa: E402
from wm.ai.pptx_report import build_pptx  # noqa: E402
from wm.main import create_app  # noqa: E402

OK, KO = 0, 0
TMP: Path = Path()


def check(label: str, condition: bool, detail: str = "") -> None:
    global OK, KO
    if condition:
        OK += 1
        print(f"  OK   {label}")
    else:
        KO += 1
        print(f"  ECHEC {label} {detail}")


def section(title: str) -> None:
    print(f"\n=== {title}")


def redirect_brand(tmp: Path) -> None:
    """Isole la charte : aucun fichier réel n'est lu ni écrit."""
    B.BRAND_PATH = tmp / "pptx_brand.json"
    B.ASSETS_DIR = tmp / "assets"
    B.TEMPLATES_DIR = tmp / "templates"


def png_bytes(width: int = 900, height: int = 300,
              color: tuple = (13, 110, 79)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (width, height), color).save(buf, "PNG")
    return buf.getvalue()


# ------------------------------------------------------------------ couleurs
def test_colors() -> None:
    section("Couleurs")
    check("hex 6 digits normalisé", B.clean_hex("0d6e4f", "000000") == "0D6E4F")
    check("avec dièse", B.clean_hex("#0D6E4F", "000000") == "0D6E4F")
    check("format court développé", B.clean_hex("#0d6", "000000") == "00DD66")
    check("valeur illisible -> repli", B.clean_hex("zzz", "ABCDEF") == "ABCDEF")
    check("vide -> repli", B.clean_hex("", "ABCDEF") == "ABCDEF")
    check("contraste blanc sur vert", B.contrast_ok("0D6E4F", "FFFFFF"))
    check("contraste blanc sur bleu fonce", B.contrast_ok("1B3A5C", "FFFFFF"))
    check("contraste blanc sur or d'accent", B.contrast_ok("C8A34B", "FFFFFF"))
    check("blanc sur blanc refusé", not B.contrast_ok("FFFFFF", "FFFFFF"))
    check("blanc sur gris tres clair refusé", not B.contrast_ok("F9F9F9", "FFFFFF"))
    check("blanc sur gris moyen refusé", not B.contrast_ok("DDDDDD", "FFFFFF"))


# ------------------------------------------------------------------ charte
def test_brand_config() -> None:
    section("Charte : enregistrement")
    b = B.load_brand()
    check("champs par défaut présents",
          all(k in b for k in ("company", "tagline", "primary", "accent", "ink",
                               "muted", "surface", "negative", "font", "footer",
                               "show_footer", "logo", "template")))
    check("police par défaut", b["font"] == "Calibri", b["font"])
    check("société vide par défaut (deck inchangé)", b["company"] == "", repr(b["company"]))
    check("mention vide par défaut (repli historique)",
          b["footer"] == "", repr(b["footer"]))
    check("vert d'origine", b["primary"] == "0D6E4F", b["primary"])

    saved = B.save_brand({"company": "Cabinet Meridian", "primary": "#1b3a5c",
                          "font": "Georgia", "show_footer": False})
    check("société enregistrée", saved["company"] == "Cabinet Meridian")
    check("couleur normalisée", saved["primary"] == "1B3A5C", saved["primary"])
    check("police enregistrée", saved["font"] == "Georgia")
    check("pied de page désactivé", saved["show_footer"] is False)
    check("relecture depuis le disque", B.load_brand()["company"] == "Cabinet Meridian")
    check("champ inconnu ignoré",
          B.save_brand({"champ_bidon": "x"}).get("champ_bidon") is None)

    # Un champ non fourni conserve sa valeur : enregistrement partiel.
    B.save_brand({"company": "Autre Soc"})
    check("enregistrement partiel", B.load_brand()["primary"] == "1B3A5C",
          B.load_brand()["primary"])

    for value, label in (("fffff", "5 chiffres"), ("zzz", "non-hex"),
                         ("", "vide"), ("#00d6e", "7 caractères")):
        try:
            B.save_brand({"primary": value})
            check(f"couleur invalide refusée ({label})", False, f"{value} accepté")
        except B.BrandError as exc:
            check(f"couleur invalide refusée ({label})", "Format attendu" in str(exc))
    check("format court accepté et développé",
          B.save_brand({"primary": "#0d6"})["primary"] == "00DD66")
    B.save_brand({"primary": "1B3A5C"})

    for value, champ in (("F9F9F9", "primary"), ("EEEEEE", "accent")):
        try:
            B.save_brand({champ: value})
            check(f"contraste insuffisant refusé ({champ})", False, value)
        except B.BrandError as exc:
            check(f"contraste insuffisant refusé ({champ})", "trop claire" in str(exc))

    check("valeur refusée non écrite",
          B.load_brand()["primary"] == "1B3A5C", B.load_brand()["primary"])

    reset = B.reset_brand()
    check("réinitialisation : société", reset["company"] == B.DEFAULT_BRAND["company"])
    check("réinitialisation : couleur", reset["primary"] == B.DEFAULT_BRAND["primary"])
    check("réinitialisation : logo", reset["logo"] == "")
    check("réinitialisation : modèle", reset["template"] == "")


# ------------------------------------------------------------------ logo
def test_logo() -> None:
    section("Logo")
    check("aucun logo au départ", B.logo_path() is None)

    saved = B.store_logo(png_bytes(), "mon-logo.png")
    path = B.logo_path()
    check("logo enregistré", path is not None and path.exists())
    check("nom de fichier assaini", path.name == "mon-logo.png", path.name)
    check("charte pointant sur le logo", saved["logo"] == "mon-logo.png", saved["logo"])

    saved = B.store_logo(png_bytes(400, 400), "../../evasion.png")
    check("traversée de répertoire neutralisée",
          saved["logo"] == "evasion.png" and B.ASSETS_DIR in B.logo_path().parents,
          saved["logo"])
    check("fichier précédent effacé au remplacement",
          sorted(p.name for p in B.ASSETS_DIR.glob("*.png")) == ["evasion.png"],
          str(sorted(p.name for p in B.ASSETS_DIR.glob("*.png"))))

    for name, data, label in (
            ("x.svg", b"<svg/>", "SVG (non supporté par python-pptx)"),
            ("x.txt", b"texte", "extension inconnue"),
            ("corrompu.png", b"pas une image", "image illisible"),
            ("vide.png", b"", "fichier vide")):
        try:
            B.store_logo(data, name)
            check(f"logo refusé : {label}", False, "accepté")
        except B.BrandError:
            check(f"logo refusé : {label}", True)

    too_big = b"\x89PNG\r\n\x1a\n" + b"0" * (B.MAX_LOGO_BYTES + 1)
    try:
        B.store_logo(too_big, "gros.png")
        check("logo trop lourd refusé", False)
    except B.BrandError as exc:
        check("logo trop lourd refusé", "trop lourd" in str(exc))

    B.save_brand({"logo": ""})
    check("logo retiré", B.logo_path() is None)
    B.reset_brand()
    check("fichiers logo effacés à la réinitialisation",
          not list(B.ASSETS_DIR.glob("*.png")) if B.ASSETS_DIR.exists() else True)


# ------------------------------------------------------------------ modèle
def test_template() -> None:
    section("Modèle corporate")
    check("aucun modèle au départ", B.template_path() is None)

    # Un modèle de démonstration : 4 mises en page et 3 diapos à retirer.
    source = Presentation()
    source.slide_width, source.slide_height = Emu(12192000), Emu(6858000)
    blank = source.slide_layouts[6]
    for _ in range(3):
        source.slides.add_slide(blank)
    buf = io.BytesIO()
    source.save(buf)
    data = buf.getvalue()

    saved = B.store_template(data, "corporate.pptx")
    path = B.template_path()
    check("modèle enregistré", path is not None and path.exists())
    check("charte pointant sur le modèle", saved["template"] == "corporate.pptx")

    theme = B.theme_palette(path)
    check("couleurs du thème relues", len(theme) == 6, str(theme[:3]))
    check("palette du modèle utilisée", B.public_brand()["palette"] == theme)
    check("drapeau couleurs du modèle", B.public_brand()["template_colors"] is True)
    check("taille du modèle annoncée",
          B.public_brand()["template_size_kb"] == round(path.stat().st_size / 1024))
    check("pas de modèle -> palette dérivée de la charte",
          B.theme_palette(None) == [])

    for name, payload, label in (
            ("x.ppt", data, "extension non supportée"),
            ("x.pptx", b"pas un zip", "fichier illisible")):
        try:
            B.store_template(payload, name)
            check(f"modèle refusé : {label}", False, "accepté")
        except B.BrandError:
            check(f"modèle refusé : {label}", True)

    B.save_brand({"template": ""})
    check("modèle retiré", B.template_path() is None)
    B.reset_brand()
    check("fichier modèle effacé à la réinitialisation",
          not list(B.TEMPLATES_DIR.glob("*.pptx")) if B.TEMPLATES_DIR.exists() else True)


# ------------------------------------------------------------------ application
def _deck_stats(data: bytes) -> dict:
    prs = Presentation(io.BytesIO(data))
    slides = list(prs.slides)
    texts = [sh.text_frame.text for s in slides for sh in s.shapes if sh.has_text_frame]
    fonts = {r.font.name for s in slides for sh in s.shapes if sh.has_text_frame
             for p in sh.text_frame.paragraphs for r in p.runs if r.text.strip()}
    return {
        "prs": prs,
        "slides": slides,
        "pictures": sum(1 for s in slides for sh in s.shapes if sh.shape_type == 13),
        "charts": sum(1 for s in slides for sh in s.shapes if sh.has_chart),
        "cover_fill": str(slides[0].shapes[0].fill.fore_color.rgb),
        "fonts": fonts,
        "texts": texts,
        "ratio": round(prs.slide_width / prs.slide_height, 3),
        "width": prs.slide_width,
        "layouts": len(prs.slide_layouts),
    }


def test_pptx_brand() -> None:
    section("Application de la charte au PPTX")
    B.reset_brand()
    base = _deck_stats(build_pptx()[0])
    check("format 16:9 inchangé", base["ratio"] == 1.778, str(base["ratio"]))
    # Structure du deck : couverture, périmètre, sommaire, types de compte, un
    # inventaire par compte, historique mensuel, puis l'analyse existante.
    check("structure inchangée", len(base["slides"]) == 43,
          str(len(base["slides"])))
    check("graphiques inchangés", base["charts"] >= 12, str(base["charts"]))
    check("aucun logo sans charte", base["pictures"] == 0, str(base["pictures"]))
    check("police par défaut", base["fonts"] == {"Calibri"}, str(base["fonts"]))
    # Sans configuration, la présentation doit être celle d'origine.
    from wm.ai.pptx import FOOTER
    check("pied de page de repli d'origine",
          sum(1 for t in base["texts"] if t == FOOTER) >= 40,
          str(sum(1 for t in base["texts"] if t == FOOTER)))
    check("mention de couverture d'origine",
          any(t == "Document confidentiel. Ne constitue pas un conseil en "
                   "investissement." for t in base["texts"]))
    check("aucune raison sociale sans configuration",
          not any("Cabinet" in t for t in base["texts"])
          and not any(t.startswith("Synthese de gestion") for t in base["texts"]))
    check("couverture épurée : 5 formes",
          len(base["slides"][0].shapes) == 5,
          str(len(base["slides"][0].shapes)))

    # --- charte modifiée
    B.save_brand({"company": "Cabinet Meridian", "tagline": "Conseillers",
                  "primary": "1B3A5C", "accent": "C8A34B", "font": "Georgia",
                  "footer": "Cabinet Meridian — diffusion restreinte",
                  "logo": str(B.ASSETS_DIR / "logo.png")})
    (B.ASSETS_DIR / "logo.png").write_bytes(png_bytes(1200, 400, (27, 58, 92)))
    data, name = build_pptx()
    branded = _deck_stats(data)
    # La couverture est blanche : le filet de tête porte la couleur de marque.
    check("filet de couverture = primaire", branded["cover_fill"] == "1B3A5C",
          branded["cover_fill"])
    check("police de la charte", branded["fonts"] == {"Georgia"}, str(branded["fonts"]))
    check("logo sur chaque diapositive",
          branded["pictures"] == len(branded["slides"]),
          f"{branded['pictures']}/{len(branded['slides'])}")
    check("logo centré en couverture",
          abs(branded["slides"][0].shapes[1].left
              - (base["width"] - branded["slides"][0].shapes[1].width) // 2) <= 9144)
    check("société en couverture",
          any("Cabinet Meridian" in t and "Conseillers" in t for t in branded["texts"]))
    check("pied de page de la charte",
          sum(1 for t in branded["texts"] if "Cabinet Meridian — diffusion" in t) >= 2)
    check("nom de fichier global", name.startswith("synthese-global-"), name)

    # Les couleurs du graphique suivent la charte.
    palette = B.public_brand()["palette"]
    check("palette dérivée de la primaire", palette[0] == "1B3A5C", palette[0])
    check("palette variée", len(set(palette)) >= 10, str(len(set(palette))))

    # --- pied de page désactivé
    B.save_brand({"show_footer": False})
    off = _deck_stats(build_pptx()[0])
    check("pied de page absent",
          not any("diffusion restreinte" in t for t in off["texts"]))

    # --- modèle corporate : le deck garde la charte mais change de base
    B.save_brand({"show_footer": True})
    source = Presentation()
    source.slide_width = Emu(9144000)  # 4:3 : doit être normalisé en 16:9
    source.slides.add_slide(source.slide_layouts[6])
    buf = io.BytesIO()
    source.save(buf)
    B.store_template(buf.getvalue(), "corporate.pptx")
    with_model = _deck_stats(build_pptx()[0])
    check("modèle : diapos du modèle retirées",
          len(with_model["slides"]) == 43, str(len(with_model["slides"])))
    check("modèle : 16:9 normalisé", with_model["ratio"] == 1.778, str(with_model["ratio"]))
    check("modèle : mises en page conservées", with_model["layouts"] > 1,
          str(with_model["layouts"]))
    check("modèle : charte toujours appliquée", with_model["cover_fill"] == "1B3A5C",
          with_model["cover_fill"])
    check("modèle : logo toujours posé",
          with_model["pictures"] == len(with_model["slides"]),
          str(with_model["pictures"]))
    check("modèle : graphiques au thème du modèle",
          B.public_brand()["charts_source"] == "Modèle corporate",
          B.public_brand()["charts_source"])

    # La charte peut reprendre la main sur la palette des graphiques.
    B.save_brand({"charts_from_template": False})
    info = B.public_brand()
    check("palette du modèle disponible mais écartée",
          info["template_palette_available"] is True and info["template_colors"] is False)
    check("palette des graphiques = charte", info["palette"][0] == "1B3A5C",
          info["palette"][0])
    check("origine annoncée", info["charts_source"] == "Charte intégrée")
    B.save_brand({"charts_from_template": True})

    # --- le logo doit rester dans son cadre, même très vertical
    B.save_brand({"logo": ""})
    (B.ASSETS_DIR / "vertical.png").write_bytes(png_bytes(200, 1600, (200, 30, 30)))
    B.save_brand({"logo": str(B.ASSETS_DIR / "vertical.png")})
    vertical = _deck_stats(build_pptx()[0])
    tall = [sh for s in vertical["slides"] for sh in s.shapes if sh.shape_type == 13]
    check("logo vertical détecté", len(tall) > 0)
    # La couverturecentre un logo plus grand que l'en-tête des autres diapos.
    check("logo vertical borné en hauteur",
          all(sh.height <= Emu(int(1.1 * 914400)) for sh in tall),
          str(max((sh.height for sh in tall), default=0)))

    B.reset_brand()


# ------------------------------------------------------------------ routes
def test_routes() -> None:
    section("Routes HTTP")
    client = TestClient(create_app())
    check("401 sans session", client.get("/api/ai/brand").status_code == 401)
    login = client.post("/api/login", json={"username": "admin", "password": "admin123"})
    check("connexion OK", login.status_code == 200, str(login.status_code))

    r = client.get("/api/ai/brand")
    check("GET /brand 200", r.status_code == 200, str(r.status_code))
    body = r.json()
    check("charte exposée", body["company"] == B.DEFAULT_BRAND["company"], body["company"])
    check("palette exposée", len(body["palette"]) >= 6, str(len(body["palette"])))
    check("formats de logo exposés", ".png" in body["logo_extensions"])
    check("formats de modèle exposés", ".pptx" in body["template_extensions"])
    check("pas de logo", body["logo_present"] is False)
    check("pas de modèle", body["template_present"] is False)
    check("GET /brand/logo sans logo -> 404",
          client.get("/api/ai/brand/logo").status_code == 404)

    r = client.post("/api/ai/brand", json={"company": "Cabinet Meridian",
                                           "primary": "1b3a5c", "font": "Georgia"})
    check("POST /brand 200", r.status_code == 200, str(r.status_code))
    check("valeurs enregistrées", r.json()["brand"]["primary"] == "1B3A5C",
          str(r.json()["brand"]["primary"]))

    r = client.post("/api/ai/brand", json={"primary": "f9f9f9"})
    check("contraste insuffisant -> 422", r.status_code == 422, str(r.status_code))
    check("message explicite", "trop claire" in r.json().get("error", ""), r.text[:80])
    r = client.post("/api/ai/brand", json={"primary": "nope"})
    check("couleur illisible -> 422", r.status_code == 422, str(r.status_code))

    r = client.post("/api/ai/brand/logo",
                    files={"file": ("logo.png", png_bytes(), "image/png")})
    check("dépôt de logo 200", r.status_code == 200, str(r.status_code))
    check("logo signalé", r.json()["brand"]["logo_present"] is True)
    url = r.json()["brand"]["logo_url"]
    check("URL du logo servie", url.startswith("/api/ai/brand/logo"), url)
    r = client.get("/api/ai/brand/logo")
    check("GET du logo 200 + PNG", r.status_code == 200 and r.content[:4] == b"\x89PNG",
          str(r.status_code))

    r = client.post("/api/ai/brand/logo", files={"file": ("x.svg", b"<svg/>", "image/svg+xml")})
    check("SVG -> 422", r.status_code == 422, str(r.status_code))

    src = Presentation()
    src.slides.add_slide(src.slide_layouts[6])
    buf = io.BytesIO()
    src.save(buf)
    r = client.post("/api/ai/brand/template",
                    files={"file": ("corporate.pptx", buf.getvalue(),
                                    "application/vnd.openxmlformats-officedocument"
                                    ".presentationml.presentation")})
    check("dépôt de modèle 200", r.status_code == 200, str(r.status_code))
    check("modèle signalé", r.json()["brand"]["template_present"] is True)
    check("couleurs du thème exploitées", r.json()["brand"]["template_colors"] is True)

    # Le PPTX produit doit refléter logo + modèle sans erreur.
    r = client.post("/api/ai/pptx", json={})
    check("pptx avec charte et modèle 200", r.status_code == 200, str(r.status_code))
    stats = _deck_stats(r.content)
    check("pptx : 43 diapos", len(stats["slides"]) == 43, str(len(stats["slides"])))
    check("pptx : logo sur chaque diapo", stats["pictures"] == 43,
          str(stats["pictures"]))
    check("pptx : couverture à la couleur de la charte", stats["cover_fill"] == "1B3A5C",
          stats["cover_fill"])

    r = client.post("/api/ai/brand/logo", data={"remove": "true"})
    check("retrait du logo 200", r.status_code == 200, str(r.status_code))
    check("logo absent après retrait", r.json()["brand"]["logo_present"] is False)
    r = client.post("/api/ai/brand/template", data={"remove": "true"})
    check("retrait du modèle 200", r.status_code == 200, str(r.status_code))
    check("modèle absent après retrait", r.json()["brand"]["template_present"] is False)
    check("GET /brand/logo sans logo -> 404 (après retrait)",
          client.get("/api/ai/brand/logo").status_code == 404)

    # La remise à zéro doit tout effacer, fichiers compris.
    client.post("/api/ai/brand/logo",
                files={"file": ("logo.png", png_bytes(), "image/png")})
    client.post("/api/ai/brand", json={"company": "Cabinet Meridian",
                                       "primary": "1B3A5C", "font": "Georgia"})
    r = client.post("/api/ai/brand/reset", json={})
    check("remise à zéro 200", r.status_code == 200, str(r.status_code))
    body = r.json()["brand"]
    check("charte neutre restaurée",
          (body["primary"], body["font"], body["company"]) == ("0D6E4F", "Calibri", ""),
          f"{body['primary']} {body['font']} {body['company']!r}")
    check("logo effacé par la remise à zéro", body["logo_present"] is False)
    check("modèle effacé par la remise à zéro", body["template_present"] is False)
    check("fichier de charte supprimé", not B.BRAND_PATH.exists())
    check("répertoire assets vidé",
          not list(B.ASSETS_DIR.glob("*")) if B.ASSETS_DIR.exists() else True)

    # Un corps tronqué ne doit pas produire de 500.
    r = client.post("/api/ai/brand/logo", content=b"pas un multipart",
                    headers={"Content-Type": "multipart/form-data; boundary=absente"})
    check("corps multipart invalide -> 4xx (pas 500)", 400 <= r.status_code < 500,
          str(r.status_code))
    r = client.post("/api/ai/brand/logo", data={})
    check("dépôt sans fichier -> 422", r.status_code == 422, str(r.status_code))

    B.reset_brand()


def main() -> int:
    global TMP
    TMP = Path(tempfile.mkdtemp(prefix="wm_brand_"))
    redirect_brand(TMP)
    print("Tests de la charte PPTX (sans modèle)")
    try:
        test_colors()
        test_brand_config()
        test_logo()
        test_template()
        test_pptx_brand()
        test_routes()
    finally:
        redirect_brand(B.config.PROJECT_DIR)
        shutil.rmtree(TMP, ignore_errors=True)
    print(f"\n{'='*46}\n{OK} assertions OK, {KO} echecs")
    return 1 if KO else 0


if __name__ == "__main__":
    raise SystemExit(main())