import csv
import random
import os
from datetime import datetime, timedelta

SECTORS = [
    "Technology",
    "Healthcare",
    "Financials",
    "Consumer",
    "Energy",
    "Industrials",
    "Materials",
    "Utilities",
]
GEOGRAPHIES = ["US", "Europe", "Japan", "Emerging Markets", "UK", "Asia Pacific"]
ASSET_CLASSES = ["Equity", "Fixed Income", "Cash", "Commodities", "Real Estate"]
CURRENCIES = ["EUR", "USD"]

POSITIONS = [
    {"ticker": "AAPL", "name": "Apple Inc.", "sector": "Technology", "geography": "US"},
    {
        "ticker": "MSFT",
        "name": "Microsoft Corp.",
        "sector": "Technology",
        "geography": "US",
    },
    {
        "ticker": "GOOGL",
        "name": "Alphabet Inc.",
        "sector": "Technology",
        "geography": "US",
    },
    {
        "ticker": "AMZN",
        "name": "Amazon.com Inc.",
        "sector": "Consumer",
        "geography": "US",
    },
    {
        "ticker": "NVDA",
        "name": "NVIDIA Corp.",
        "sector": "Technology",
        "geography": "US",
    },
    {
        "ticker": "META",
        "name": "Meta Platforms",
        "sector": "Technology",
        "geography": "US",
    },
    {"ticker": "TSLA", "name": "Tesla Inc.", "sector": "Consumer", "geography": "US"},
    {
        "ticker": "BRK.B",
        "name": "Berkshire Hathaway",
        "sector": "Financials",
        "geography": "US",
    },
    {
        "ticker": "JPM",
        "name": "JPMorgan Chase",
        "sector": "Financials",
        "geography": "US",
    },
    {
        "ticker": "JNJ",
        "name": "Johnson & Johnson",
        "sector": "Healthcare",
        "geography": "US",
    },
    {
        "ticker": "UNH",
        "name": "UnitedHealth",
        "sector": "Healthcare",
        "geography": "US",
    },
    {
        "ticker": "PG",
        "name": "Procter & Gamble",
        "sector": "Consumer",
        "geography": "US",
    },
    {"ticker": "V", "name": "Visa Inc.", "sector": "Financials", "geography": "US"},
    {"ticker": "MA", "name": "Mastercard", "sector": "Financials", "geography": "US"},
    {"ticker": "HD", "name": "Home Depot", "sector": "Consumer", "geography": "US"},
    {
        "ticker": "ASML",
        "name": "ASML Holding",
        "sector": "Technology",
        "geography": "Europe",
    },
    {
        "ticker": "NESN",
        "name": "Nestle SA",
        "sector": "Consumer",
        "geography": "Europe",
    },
    {
        "ticker": "ROG",
        "name": "Roche Holding",
        "sector": "Healthcare",
        "geography": "Europe",
    },
    {"ticker": "SAP", "name": "SAP SE", "sector": "Technology", "geography": "Europe"},
    {"ticker": "BP", "name": "BP PLC", "sector": "Energy", "geography": "UK"},
    {"ticker": "SHELL", "name": "Shell PLC", "sector": "Energy", "geography": "UK"},
    {
        "ticker": "HSBC",
        "name": "HSBC Holdings",
        "sector": "Financials",
        "geography": "UK",
    },
    {
        "ticker": "7203",
        "name": "Toyota Motor",
        "sector": "Consumer",
        "geography": "Japan",
    },
    {
        "ticker": "9984",
        "name": "SoftBank",
        "sector": "Financials",
        "geography": "Japan",
    },
    {
        "ticker": "6752",
        "name": "Panasonic",
        "sector": "Technology",
        "geography": "Japan",
    },
    {
        "ticker": "BABA",
        "name": "Alibaba Group",
        "sector": "Consumer",
        "geography": "Asia Pacific",
    },
    {
        "ticker": "TSM",
        "name": "TSMC",
        "sector": "Technology",
        "geography": "Asia Pacific",
    },
    {"ticker": "XOM", "name": "Exxon Mobil", "sector": "Energy", "geography": "US"},
    {"ticker": "CVX", "name": "Chevron Corp.", "sector": "Energy", "geography": "US"},
    {
        "ticker": "BAC",
        "name": "Bank of America",
        "sector": "Financials",
        "geography": "US",
    },
    {"ticker": "WFC", "name": "Wells Fargo", "sector": "Financials", "geography": "US"},
    {"ticker": "DIS", "name": "Walt Disney", "sector": "Consumer", "geography": "US"},
    {"ticker": "NFLX", "name": "Netflix Inc.", "sector": "Consumer", "geography": "US"},
    {"ticker": "KO", "name": "Coca-Cola", "sector": "Consumer", "geography": "US"},
    {"ticker": "PEP", "name": "PepsiCo Inc.", "sector": "Consumer", "geography": "US"},
    {"ticker": "MRK", "name": "Merck & Co.", "sector": "Healthcare", "geography": "US"},
    {
        "ticker": "ABBV",
        "name": "AbbVie Inc.",
        "sector": "Healthcare",
        "geography": "US",
    },
    {"ticker": "PFE", "name": "Pfizer Inc.", "sector": "Healthcare", "geography": "US"},
    {
        "ticker": "TMO",
        "name": "Thermo Fisher",
        "sector": "Healthcare",
        "geography": "US",
    },
    {
        "ticker": "CAT",
        "name": "Caterpillar",
        "sector": "Industrials",
        "geography": "US",
    },
    {"ticker": "BA", "name": "Boeing Co.", "sector": "Industrials", "geography": "US"},
    {
        "ticker": "GE",
        "name": "General Electric",
        "sector": "Industrials",
        "geography": "US",
    },
    {"ticker": "LIN", "name": "Linde PLC", "sector": "Materials", "geography": "US"},
    {"ticker": "APD", "name": "Air Products", "sector": "Materials", "geography": "US"},
    {
        "ticker": "NEE",
        "name": "NextEra Energy",
        "sector": "Utilities",
        "geography": "US",
    },
    {"ticker": "DUK", "name": "Duke Energy", "sector": "Utilities", "geography": "US"},
    {
        "ticker": "LIN",
        "name": "Linde PLC",
        "sector": "Materials",
        "geography": "Europe",
    },
    {
        "ticker": "UL",
        "name": "Unilever PLC",
        "sector": "Consumer",
        "geography": "Europe",
    },
    {
        "ticker": "NOVN",
        "name": "Novartis AG",
        "sector": "Healthcare",
        "geography": "Europe",
    },
]


def generate_isin(ticker):
    return f"{ticker[:3]}{random.randint(100000000, 999999999)}{random.randint(10, 99)}"


def generate_transactions(positions, start_date, end_date):
    transactions = []
    for pos in positions:
        num_txns = random.randint(5, 20)
        for _ in range(num_txns):
            days_offset = random.randint(0, (end_date - start_date).days)
            txn_date = start_date + timedelta(days=days_offset)
            txn_type = random.choice(["BUY", "SELL"])
            shares = random.randint(10, 500) * 10
            price = random.uniform(50, 500)
            fees = random.uniform(5, 50)
            transactions.append(
                {
                    "date": txn_date.strftime("%Y-%m-%d"),
                    "ticker": pos["ticker"],
                    "type": txn_type,
                    "shares": shares,
                    "price": round(price, 2),
                    "amount": round(shares * price, 2),
                    "fees": round(fees, 2),
                }
            )
    transactions.sort(key=lambda x: x["date"], reverse=True)
    return transactions


def load_data():
    data = {"portfolios": []}
    start_date = datetime(2023, 1, 1)
    end_date = datetime(2025, 4, 8)

    fundmanagers = [
        {"name": "Alpha Capital", "portfolios": ["Alpha Growth", "Alpha Value"]},
        {"name": "Beta Investments", "portfolios": ["Beta Tech", "Beta Balanced"]},
        {"name": "Gamma Partners", "portfolios": ["Gamma Europe", "Gamma Emerging"]},
    ]

    for i, fm in enumerate(fundmanagers):
        for j, pf_name in enumerate(fm["portfolios"]):
            portfolio_id = f"pf_{i}_{j}"
            num_positions = random.randint(20, 35)
            selected_positions = random.sample(POSITIONS, num_positions)

            base_aum = random.uniform(500_000_000, 2_000_000_000)
            aum = base_aum * random.uniform(0.9, 1.1)

            positions = []
            remaining_weight = 100.0
            for k, pos_info in enumerate(selected_positions):
                if k == len(selected_positions) - 1:
                    weight = remaining_weight
                else:
                    weight = random.uniform(0.5, min(remaining_weight - 0.5, 15))
                remaining_weight -= weight

                isin = generate_isin(pos_info["ticker"])
                entry_price = random.uniform(50, 500)
                current_price = entry_price * random.uniform(0.7, 1.4)
                shares = int(aum * (weight / 100) / current_price)
                market_value = shares * current_price
                unrealized_pnl = (current_price - entry_price) * shares
                unrealized_pnl_pct = ((current_price / entry_price) - 1) * 100

                asset_class = random.choice(ASSET_CLASSES)

                positions.append(
                    {
                        "isin": isin,
                        "ticker": pos_info["ticker"],
                        "name": pos_info["name"],
                        "sector": pos_info["sector"],
                        "geography": pos_info["geography"],
                        "asset_class": asset_class,
                        "shares": shares,
                        "entry_price": round(entry_price, 2),
                        "current_price": round(current_price, 2),
                        "market_value": round(market_value, 2),
                        "unrealized_pnl": round(unrealized_pnl, 2),
                        "unrealized_pnl_pct": round(unrealized_pnl_pct, 2),
                        "weight": round(weight, 2),
                    }
                )

            transactions = generate_transactions(positions, start_date, end_date)

            ytd_return = random.uniform(-15, 25)
            max_dd = random.uniform(-25, -5)

            portfolio = {
                "id": portfolio_id,
                "name": pf_name,
                "fundmanager": fm["name"],
                "code_ug": f"UG{random.randint(1000, 9999)}",
                "code_og": f"OG{random.randint(100, 999)}",
                "currency": random.choice(CURRENCIES),
                "aum": round(aum, 2),
                "ytd_return": round(ytd_return, 2),
                "max_dd": round(max_dd, 2),
                "positions": positions,
                "transactions": transactions,
            }
            data["portfolios"].append(portfolio)

    return data


if __name__ == "__main__":
    data = load_data()
    print(f"Generated {len(data['portfolios'])} portfolios")
    for p in data["portfolios"]:
        print(
            f"  {p['name']} ({p['fundmanager']}): {len(p['positions'])} positions, AUM: €{p['aum'] / 1e6:.1f}M"
        )
