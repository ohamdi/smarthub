import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from data.demo_data import load_data

st.set_page_config(page_title="FundExplorer", page_icon="📊", layout="wide")

data = load_data()


def format_currency(value):
    if abs(value) >= 1_000_000_000:
        return f"${abs(value) / 1_000_000_000:.2f}B"
    elif abs(value) >= 1_000_000:
        return f"${abs(value) / 1_000_000:.1f}M"
    elif abs(value) >= 1_000:
        return f"${abs(value) / 1_000:.1f}K"
    return f"${value:.0f}"


def format_pct(value):
    return f"{value:+.2f}%"


st.markdown(
    """
<style>
    .main-header {
        font-size: 2rem;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 1rem;
    }
    .card {
        background: white;
        border-radius: 10px;
        padding: 1.5rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
    }
    .card-header {
        font-size: 1rem;
        font-weight: 600;
        color: #16213e;
        margin-bottom: 1rem;
        border-bottom: 2px solid #87CEEB;
        padding-bottom: 0.5rem;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.85rem;
    }
    th {
        background-color: #87CEEB;
        color: #212529;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 0.7rem;
        padding: 10px 12px;
        text-align: left;
        border: none;
    }
    td {
        padding: 8px 12px;
        border-bottom: 1px solid #dee2e6;
        color: #212529;
    }
    tr:nth-child(even) {
        background-color: #E8F4FC;
    }
    tr:hover {
        background-color: #D4EDDA;
    }
    .positive { color: #198754; }
    .negative { color: #dc3545; }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        padding: 1.5rem;
        text-align: center;
    }
    .metric-value {
        font-size: 1.8rem;
        font-weight: 700;
    }
    .metric-label {
        font-size: 0.9rem;
        opacity: 0.9;
    }
    .pivot-header {
        background-color: #87CEEB !important;
        color: #212529 !important;
    }
    .pivot-row-label {
        background-color: #f8f9fa;
        font-weight: 600;
    }
    .pivot-total {
        background-color: #28a745 !important;
        color: white !important;
        font-weight: bold;
    }
</style>
""",
    unsafe_allow_html=True,
)


st.sidebar.markdown("## 📊 FundExplorer")
st.sidebar.markdown("---")

page = st.sidebar.radio("Navigation", ["📈 Overview", "💼 Holdings"])

if page == "📈 Overview":
    st.markdown(
        '<p class="main-header">Overview - FundManager Dashboard</p>',
        unsafe_allow_html=True,
    )

    fm_stats = {}
    for p in data["portfolios"]:
        fm = p["fundmanager"]
        if fm not in fm_stats:
            fm_stats[fm] = {"aum": 0, "portfolios": [], "positions": 0, "total_pnl": 0}
        fm_stats[fm]["aum"] += p["aum"]
        fm_stats[fm]["portfolios"].append(p["name"])
        fm_stats[fm]["positions"] += len(p["positions"])
        fm_stats[fm]["total_pnl"] += sum(
            pos["unrealized_pnl"] for pos in p["positions"]
        )

    col1, col2, col3 = st.columns(3)
    for i, fm in enumerate(fm_stats):
        with [col1, col2, col3][i % 3]:
            st.metric(
                label=fm,
                value=format_currency(fm_stats[fm]["aum"]),
                delta=f"{len(fm_stats[fm]['portfolios'])} portfolios",
            )

    st.markdown("---")

    col_left, col_right = st.columns([2, 1])

    with col_left:
        st.markdown("### Portfolio Performance")
        perf_data = []
        for p in data["portfolios"]:
            perf_data.append(
                {
                    "Portfolio": p["name"],
                    "FundManager": p["fundmanager"],
                    "Code UG": p["code_ug"],
                    "Code OG": p["code_og"],
                    "Currency": p.get("currency", "EUR"),
                    "AUM": format_currency(p["aum"]),
                    "YTD": format_pct(p["ytd_return"]),
                    "Max DD": format_pct(p["max_dd"]),
                }
            )
        st.dataframe(pd.DataFrame(perf_data), width="stretch", hide_index=True)

    with col_right:
        st.markdown("### Asset Class Distribution")
        asset_totals = {}
        for p in data["portfolios"]:
            for pos in p["positions"]:
                ac = pos.get("asset_class", "Unknown")
                asset_totals[ac] = asset_totals.get(ac, 0) + pos.get("market_value", 0)

        fig = px.pie(
            values=list(asset_totals.values()),
            names=list(asset_totals.keys()),
            hole=0.4,
        )
        fig.update_layout(
            paper_bgcolor="white",
            margin=dict(t=20, b=20),
            legend=dict(orientation="h", yanchor="bottom", y=-0.2),
        )
        st.plotly_chart(fig, width="stretch")

    st.markdown("---")
    st.markdown("### Top Holdings")
    top_data = []
    for p in data["portfolios"]:
        for pos in sorted(p["positions"], key=lambda x: x["weight"], reverse=True)[:3]:
            top_data.append(
                {
                    "Ticker": pos["ticker"],
                    "Name": pos["name"],
                    "FundManager": pos.get("fundmanager", p["fundmanager"]),
                    "Weight": f"{pos['weight']:.2f}%",
                    "Market Value": format_currency(pos["market_value"]),
                }
            )
    top_data = top_data[:10]
    st.dataframe(pd.DataFrame(top_data), width="stretch", hide_index=True)

    st.markdown("---")
    st.markdown("### Pivot Table - ISIN Weights by Portfolio")

    all_positions = []
    for p in data["portfolios"]:
        for pos in p["positions"]:
            all_positions.append(
                {
                    "isin": pos.get("isin", pos["ticker"]),
                    "ticker": pos["ticker"],
                    "portfolio": p["name"],
                    "weight": pos["weight"],
                    "asset_class": pos.get("asset_class", "Unknown"),
                }
            )

    pos_df = pd.DataFrame(all_positions)
    portfolios = list(pos_df["portfolio"].unique())
    asset_classes = sorted(list(pos_df["asset_class"].unique()))

    html_table = "<table><thead><tr><th class='pivot-header'>Asset Class</th><th class='pivot-header'>ISIN</th><th class='pivot-header'>Ticker</th>"
    for p in portfolios:
        html_table += f"<th class='pivot-header' style='text-align:center'>{p}</th>"
    html_table += "</tr></thead><tbody>"

    for ac in asset_classes:
        ac_df = pos_df[pos_df["asset_class"] == ac]
        grouped = (
            ac_df.groupby(["isin", "ticker"])
            .agg({"weight": "sum"})
            .reset_index()
            .sort_values("weight", ascending=False)
        )

        first_row = True
        for _, row in grouped.iterrows():
            isin_val = row["isin"]
            ticker_val = row["ticker"]

            row_bg = "#f0f8ff" if first_row else "#ffffff"
            html_table += f"<tr style='background-color:{row_bg}'>"

            if first_row:
                html_table += f"<td rowspan='{len(grouped)}' style='background-color:#b8d4e8;font-weight:bold;vertical-align:middle'>{ac}</td>"

            html_table += (
                f"<td style='font-family:monospace;color:#0d6efd'>{isin_val}</td>"
            )
            html_table += f"<td style='font-weight:bold'>{ticker_val}</td>"

            for p in portfolios:
                val = ac_df[(ac_df["isin"] == isin_val) & (ac_df["portfolio"] == p)][
                    "weight"
                ].sum()
                if val > 0:
                    html_table += f"<td style='text-align:right;background-color:#e7f5ff'>{val:.2f}%</td>"
                else:
                    html_table += "<td style='text-align:center;color:#999'>-</td>"

            html_table += "</tr>"
            first_row = False

        html_table += "<tr class='pivot-total'>"
        html_table += f"<td colspan='3' style='background-color:#28a745;color:white;font-weight:bold'>Sous-total {ac}</td>"
        for p in portfolios:
            val = ac_df[ac_df["portfolio"] == p]["weight"].sum()
            html_table += f"<td style='text-align:right;background-color:#28a745;color:white;font-weight:bold'>{val:.2f}%</td>"
        html_table += "</tr>"

    html_table += "</tbody></table>"
    st.markdown(html_table, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### Asset Class by Portfolio")

    fig = go.Figure()
    colors = [
        "#0d6efd",
        "#198754",
        "#dc3545",
        "#ffc107",
        "#17a2b8",
        "#6c757d",
        "#20c997",
        "#d63384",
    ]

    for i, p in enumerate(data["portfolios"]):
        asset_weights = {}
        for pos in p["positions"]:
            ac = pos.get("asset_class", "Unknown")
            asset_weights[ac] = asset_weights.get(ac, 0) + pos["weight"]

        if asset_weights:
            fig.add_trace(
                go.Pie(
                    labels=list(asset_weights.keys()),
                    values=list(asset_weights.values()),
                    name=p["name"],
                    hole=0.3,
                    marker=dict(colors=colors[: len(asset_weights)]),
                    textinfo="label+percent",
                    textposition="inside",
                )
            )

    fig.update_layout(
        height=400,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.3),
        margin=dict(t=20, b=60),
        paper_bgcolor="white",
    )
    st.plotly_chart(fig, width="stretch")

elif page == "💼 Holdings":
    st.markdown('<p class="main-header">Portfolio Holdings</p>', unsafe_allow_html=True)

    portfolio_options = {p["name"]: p["id"] for p in data["portfolios"]}
    selected_portfolio_name = st.selectbox(
        "Select Portfolio", list(portfolio_options.keys())
    )
    selected_portfolio = next(
        p
        for p in data["portfolios"]
        if p["id"] == portfolio_options[selected_portfolio_name]
    )

    currency = selected_portfolio.get("currency", "EUR")

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("FundManager", selected_portfolio["fundmanager"])
    with col2:
        st.metric("Code UG", selected_portfolio["code_ug"])
    with col3:
        st.metric("Code OG", selected_portfolio["code_og"])
    with col4:
        st.metric("Currency", currency)

    st.markdown("---")

    positions = sorted(
        selected_portfolio["positions"], key=lambda x: x["weight"], reverse=True
    )

    col_left, col_right = st.columns([3, 1])

    with col_left:
        st.markdown(f"### Holdings - {len(positions)} positions")
        holdings_data = []
        for pos in positions:
            pnl_class = "positive" if pos["unrealized_pnl"] >= 0 else "negative"
            holdings_data.append(
                {
                    "ISIN": pos["isin"],
                    "Ticker": pos["ticker"],
                    "Sector": pos["sector"],
                    "Geo": pos["geography"],
                    "Asset Class": pos.get("asset_class", ""),
                    "Qty": f"{pos['shares']:,}",
                    "Entry": f"{pos['entry_price']:.2f}",
                    "Current": f"{pos['current_price']:.2f}",
                    "Market Value": format_currency(pos["market_value"]),
                    "+/- Val": format_currency(pos["unrealized_pnl"]),
                    "+/- %": format_pct(pos["unrealized_pnl_pct"]),
                    "Weight": f"{pos['weight']:.2f}%",
                }
            )
        st.dataframe(pd.DataFrame(holdings_data), width="stretch", hide_index=True)

    with col_right:
        st.markdown("### Asset Class Distribution")
        asset_weights = {}
        for pos in positions:
            ac = pos.get("asset_class", "Unknown")
            asset_weights[ac] = asset_weights.get(ac, 0) + pos["weight"]

        fig = px.pie(
            values=list(asset_weights.values()),
            names=list(asset_weights.keys()),
            hole=0.4,
        )
        fig.update_layout(
            paper_bgcolor="white",
            margin=dict(t=10, b=10),
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.2),
        )
        st.plotly_chart(fig, width="stretch")

    st.markdown("---")
    st.markdown("### Sector / ISIN Heatmap")

    sectors = sorted(list(set(p["sector"] for p in positions)))
    isins = [p.get("isin", p["ticker"]) for p in positions[:15]]

    z_data = []
    for pos in positions[:15]:
        row = [pos["weight"] if pos["sector"] == s else 0 for s in sectors]
        z_data.append(row)

    fig = go.Figure(
        data=go.Heatmap(
            z=z_data,
            x=sectors,
            y=isins,
            colorscale="Blues",
            showscale=True,
            colorbar=dict(title="Weight %"),
        )
    )
    fig.update_layout(
        height=max(400, len(isins) * 25),
        margin=dict(l=120, r=50, t=30, b=80),
        paper_bgcolor="#f8f9fa",
        xaxis=dict(tickangle=-45),
    )
    st.plotly_chart(fig, width="stretch")

    st.markdown("---")
    st.markdown("### Transactions")
    transactions = selected_portfolio.get("transactions", [])[:50]

    txn_data = []
    for t in transactions:
        txn_data.append(
            {
                "Date": t["date"],
                "Ticker": t["ticker"],
                "Type": t["type"],
                "Shares": f"{t['shares']:,}",
                "Price": f"{t['price']:.2f}",
                "Amount": format_currency(t["amount"]),
                "Fees": format_currency(t["fees"]),
            }
        )

    if txn_data:
        st.dataframe(pd.DataFrame(txn_data), width="stretch", hide_index=True)
    else:
        st.info("No transactions available")

    st.markdown("---")
    st.markdown("### Pivot Tables - Weights")

    df = pd.DataFrame(positions)

    pivot_sector = df.pivot_table(
        values="weight",
        index="geography",
        columns="sector",
        aggfunc="sum",
        fill_value=0,
    ).round(2)
    pivot_geo = df.pivot_table(
        values="weight",
        index="sector",
        columns="geography",
        aggfunc="sum",
        fill_value=0,
    ).round(2)
    pivot_isin = df.pivot_table(
        values="weight",
        index="isin",
        columns="asset_class",
        aggfunc="sum",
        fill_value=0,
    ).round(2)

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("**ISIN × Asset Class**")
        st.dataframe(
            pivot_isin.style.background_gradient(cmap="Blues", axis=None),
            width="stretch",
        )
    with col2:
        st.markdown("**Sector × Geography**")
        st.dataframe(
            pivot_sector.style.background_gradient(cmap="Blues", axis=None),
            width="stretch",
        )
    with col3:
        st.markdown("**Geography × Sector**")
        st.dataframe(
            pivot_geo.style.background_gradient(cmap="Blues", axis=None),
            width="stretch",
        )
