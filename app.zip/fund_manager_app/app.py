"""FundExplorer - Portfolio Management Application (Dash)"""

import dash
from dash import html, dcc
import dash_bootstrap_components as dbc

app = dash.Dash(
    __name__,
    use_pages=True,
    external_stylesheets=[
        dbc.themes.BOOTSTRAP,
        "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css",
        "/assets/styles.css?v=3",
    ],
    suppress_callback_exceptions=True,
)

app.layout = html.Div(
    [
        dcc.Store(id="portfolio-store", data={}),
        dcc.Store(id="settings-store", data={}),
        dcc.Download(id="download-overview-csv"),
        dcc.Download(id="download-overview-xlsx"),
        dcc.Download(id="download-holdings-csv"),
        dcc.Download(id="download-holdings-xlsx"),
        html.Div(
            [
                html.Div(
                    [
                        html.Div(
                            [
                                html.Div("FE", className="logo-icon"),
                                html.Div("FundExplorer", className="logo-text"),
                            ],
                            className="logo",
                        ),
                        html.Hr(className="sidebar-divider"),
                        dbc.Nav(
                            [
                                dbc.NavLink(
                                    [
                                        html.I(className="fas fa-chart-pie me-2"),
                                        "Overview",
                                    ],
                                    href="/",
                                    active="exact",
                                    className="nav-link-custom",
                                ),
                                dbc.NavLink(
                                    [
                                        html.I(className="fas fa-briefcase me-2"),
                                        "Holdings",
                                    ],
                                    href="/holdings",
                                    active="exact",
                                    className="nav-link-custom",
                                ),
                            ],
                            vertical=True,
                            pills=True,
                            className="sidebar-nav",
                        ),
                    ],
                    className="sidebar",
                ),
                html.Div(
                    [
                        html.Div(
                            [
                                html.H4("FundExplorer", className="header-title mb-0"),
                                html.Div(
                                    [
                                        dcc.DatePickerRange(
                                            id="global-date-range",
                                            start_date="2024-01-01",
                                            end_date="2025-04-08",
                                            className="date-picker-custom",
                                        ),
                                        dbc.Button(
                                            [
                                                html.I(
                                                    className="fas fa-download me-1"
                                                ),
                                                "Export",
                                            ],
                                            color="outline-secondary",
                                            size="sm",
                                            className="ms-2",
                                        ),
                                    ],
                                    className="header-actions",
                                ),
                            ],
                            className="d-flex justify-content-between align-items-center",
                        )
                    ],
                    className="page-header",
                ),
                html.Div([dash.page_container], className="page-content"),
            ],
            className="main-content",
        ),
    ]
)

if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=8050)
