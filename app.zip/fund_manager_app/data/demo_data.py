import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import sys

np.random.seed(42)

SECTORS = [
    "Technology",
    "Healthcare",
    "Financials",
    "Consumer Discretionary",
    "Industrials",
    "Energy",
    "Materials",
    "Utilities",
    "Real Estate",
    "Communication",
]
GEOGRAPHIES = ["North America", "Europe", "Asia Pacific", "Emerging Markets"]
ASSET_CLASSES = ["Equities", "Fixed Income", "Alternatives", "Cash", "Commodities"]

TICKERS = [
    "AAPL",
    "MSFT",
    "GOOGL",
    "AMZN",
    "NVDA",
    "META",
    "TSLA",
    "BRK.B",
    "JPM",
    "JNJ",
    "UNH",
    "HD",
    "PG",
    "MA",
    "DIS",
    "PYPL",
    "NFLX",
    "ADBE",
    "CRM",
    "INTC",
    "VZ",
    "T",
    "PFE",
    "MRK",
    "KO",
    "PEP",
    "WMT",
    "COST",
    "NKE",
    "MCD",
    "XOM",
    "CVX",
    "BAC",
    "C",
    "GS",
    "MS",
    "BLK",
    "AXP",
    "V",
    "SQ",
]

PORTFOLIOS_DATA = [
    {
        "id": "P001",
        "fundmanager": "Jean Dupont",
        "code_ug": "UG001",
        "code_og": "OG-A",
        "name": "Alpha Growth Fund",
        "type": "Long/Short Equity",
        "aum": 245_000_000,
        "currency": "EUR",
        "benchmark": "S&P 500",
        "inception": "2019-01-15",
        "ytd_return": 12.4,
        "total_return": 87.3,
        "max_dd": -8.2,
    },
    {
        "id": "P002",
        "fundmanager": "Marie Martin",
        "code_ug": "UG002",
        "code_og": "OG-B",
        "name": "Fixed Income Plus",
        "type": "Fixed Income",
        "aum": 180_000_000,
        "currency": "USD",
        "benchmark": "Bloomberg Agg",
        "inception": "2018-06-01",
        "ytd_return": 4.2,
        "total_return": 32.1,
        "max_dd": -3.1,
    },
    {
        "id": "P003",
        "fundmanager": "Pierre Durand",
        "code_ug": "UG001",
        "code_og": "OG-A",
        "name": "Global Macro Fund",
        "type": "Global Macro",
        "aum": 320_000_000,
        "currency": "EUR",
        "benchmark": "HFRI Macro",
        "inception": "2017-03-20",
        "ytd_return": 8.7,
        "total_return": 156.4,
        "max_dd": -12.5,
    },
    {
        "id": "P004",
        "fundmanager": "Sophie Bernard",
        "code_ug": "UG003",
        "code_og": "OG-C",
        "name": "Tech Innovation Fund",
        "type": "Growth Equity",
        "aum": 95_000_000,
        "currency": "USD",
        "benchmark": "NASDAQ 100",
        "inception": "2021-09-10",
        "ytd_return": 18.9,
        "total_return": 34.2,
        "max_dd": -15.8,
    },
    {
        "id": "P005",
        "fundmanager": "Jean Dupont",
        "code_ug": "UG001",
        "code_og": "OG-B",
        "name": "Diversified Multi-Strategy",
        "type": "Multi-Strategy",
        "aum": 450_000_000,
        "currency": "EUR",
        "benchmark": "HFRI Fund Weighted",
        "inception": "2016-01-04",
        "ytd_return": 7.3,
        "total_return": 198.7,
        "max_dd": -6.4,
    },
]


def get_data_dir():
    if getattr(sys, "frozen", False):
        return os.path.join(sys._MEIPASS, "data")
    return os.path.dirname(os.path.abspath(__file__))


def generate_positions_data(
    portfolio_id, fundmanager, code_ug, code_og, currency="EUR"
):
    n_positions = np.random.randint(15, 35)
    positions = []

    for i in range(min(n_positions, len(TICKERS))):
        ticker = TICKERS[i]
        sector = np.random.choice(SECTORS)
        geo = np.random.choice(GEOGRAPHIES, p=[0.45, 0.25, 0.2, 0.1])
        asset_class = np.random.choice(ASSET_CLASSES)
        weight = np.random.uniform(1, 12)
        entry_price = np.random.uniform(20, 500)
        current_price = entry_price * (1 + np.random.uniform(-0.3, 0.5))
        shares = np.random.randint(100, 10000)

        isin_base = ["US", "EU", "FR", "DE", "GB", "CH", "NL"][i % 7]
        isin = (
            f"{isin_base}{ticker.replace('.', '')}{np.random.randint(100000, 999999)}"
        )

        market_value = shares * current_price
        unrealized_pnl = shares * (current_price - entry_price)
        unrealized_pnl_pct = (current_price / entry_price - 1) * 100

        positions.append(
            {
                "id": f"{portfolio_id}-POS-{i + 1:03d}",
                "portfolio_id": portfolio_id,
                "ticker": ticker,
                "isin": isin,
                "name": f"{ticker} Inc.",
                "sector": sector,
                "geography": geo,
                "asset_class": asset_class,
                "weight": round(weight, 2),
                "shares": shares,
                "entry_price": round(entry_price, 2),
                "current_price": round(current_price, 2),
                "market_value": round(market_value, 2),
                "unrealized_pnl": round(unrealized_pnl, 2),
                "unrealized_pnl_pct": round(unrealized_pnl_pct, 2),
                "status": "Active" if np.random.random() > 0.1 else "Exited",
                "fundmanager": fundmanager,
                "code_ug": code_ug,
                "code_og": code_og,
                "currency": currency,
            }
        )

    total_weight = sum(p["weight"] for p in positions)
    for p in positions:
        p["weight"] = round(p["weight"] / total_weight * 100, 2)

    return sorted(positions, key=lambda x: x["weight"], reverse=True)


def generate_performance_data(portfolio_id, days=365):
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    dates = pd.date_range(start=start_date, end=end_date, freq="D")
    dates = [d for d in dates if d.weekday() < 5]

    returns = np.random.normal(0.0005, 0.015, len(dates))
    cumulative = (1 + returns).cumprod()
    benchmark_returns = np.random.normal(0.0004, 0.012, len(dates))
    benchmark_cumulative = (1 + benchmark_returns).cumprod()

    records = []
    for i, d in enumerate(dates):
        records.append(
            {
                "portfolio_id": portfolio_id,
                "date": d.strftime("%Y-%m-%d"),
                "portfolio_value": round(cumulative[i] * 100, 2),
                "benchmark_value": round(benchmark_cumulative[i] * 100, 2),
                "portfolio_return": round((cumulative[i] / cumulative[0] - 1) * 100, 2),
                "benchmark_return": round(
                    (benchmark_cumulative[i] / benchmark_cumulative[0] - 1) * 100, 2
                ),
            }
        )
    return records


def generate_transactions_data(portfolio_id, n_trans=50):
    transactions = []
    for i in range(n_trans):
        date = datetime.now() - timedelta(days=np.random.randint(1, 365))
        ticker = np.random.choice(TICKERS[:10])
        shares = np.random.randint(50, 500)
        price = round(np.random.uniform(50, 400), 2)
        fees = round(np.random.uniform(1, 50), 2)

        transactions.append(
            {
                "id": f"{portfolio_id}-TXN-{i + 1:04d}",
                "portfolio_id": portfolio_id,
                "date": date.strftime("%Y-%m-%d"),
                "ticker": ticker,
                "type": np.random.choice(["BUY", "SELL"], p=[0.6, 0.4]),
                "shares": shares,
                "price": price,
                "amount": round(shares * price + fees, 2),
                "fees": fees,
            }
        )
    return sorted(transactions, key=lambda x: x["date"], reverse=True)


def save_data():
    data_dir = get_data_dir()
    os.makedirs(data_dir, exist_ok=True)

    all_portfolios = []
    all_positions = []
    all_transactions = []
    all_performance = []

    for p in PORTFOLIOS_DATA:
        portfolio = p.copy()
        all_portfolios.append(portfolio)

        positions = generate_positions_data(
            p["id"],
            p["fundmanager"],
            p["code_ug"],
            p["code_og"],
            p.get("currency", "EUR"),
        )
        all_positions.extend(positions)

        performance = generate_performance_data(p["id"])
        all_performance.extend(performance)

        transactions = generate_transactions_data(p["id"])
        all_transactions.extend(transactions)

    pd.DataFrame(all_portfolios).to_csv(
        os.path.join(data_dir, "portfolios.csv"), index=False
    )
    pd.DataFrame(all_positions).to_csv(
        os.path.join(data_dir, "positions.csv"), index=False
    )
    pd.DataFrame(all_transactions).to_csv(
        os.path.join(data_dir, "transactions.csv"), index=False
    )
    pd.DataFrame(all_performance).to_csv(
        os.path.join(data_dir, "performance.csv"), index=False
    )

    return load_data()


def load_data():
    data_dir = get_data_dir()
    portfolios_path = os.path.join(data_dir, "portfolios.csv")

    if not os.path.exists(portfolios_path):
        return save_data()

    portfolios_df = pd.read_csv(portfolios_path)
    positions_df = pd.read_csv(os.path.join(data_dir, "positions.csv"))
    transactions_df = pd.read_csv(os.path.join(data_dir, "transactions.csv"))
    performance_df = pd.read_csv(os.path.join(data_dir, "performance.csv"))

    portfolios = []
    for _, p in portfolios_df.iterrows():
        portfolio = p.to_dict()
        portfolio["positions"] = positions_df[
            positions_df["portfolio_id"] == portfolio["id"]
        ].to_dict("records")
        portfolio["transactions"] = transactions_df[
            transactions_df["portfolio_id"] == portfolio["id"]
        ].to_dict("records")
        portfolio["performance"] = performance_df[
            performance_df["portfolio_id"] == portfolio["id"]
        ].to_dict("records")

        sector_alloc = (
            positions_df[positions_df["portfolio_id"] == portfolio["id"]]
            .groupby("sector")["weight"]
            .sum()
            .reset_index()
        )
        sector_alloc.columns = ["sector", "weight"]
        portfolio["allocation"] = {
            "sector": sector_alloc.to_dict("records"),
            "geography": positions_df[positions_df["portfolio_id"] == portfolio["id"]]
            .groupby("geography")["weight"]
            .sum()
            .reset_index()
            .rename(columns={"geography": "geography", "weight": "weight"})
            .to_dict("records"),
        }

        portfolios.append(portfolio)

    return {"portfolios": portfolios}


if __name__ == "__main__":
    data = save_data()
    print(f"Generated {len(data['portfolios'])} portfolios")
    for p in data["portfolios"]:
        print(f"  - {p['name']} ({p['fundmanager']}, {p['code_ug']}, {p['code_og']})")
