import os
import sys
import subprocess
import shutil


def build_exe():
    # Vérifie que PyInstaller est installé
    try:
        import PyInstaller
    except ImportError:
        print("Installation de PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])

    # Nettoie les anciens builds
    for folder in ["build", "dist"]:
        if os.path.exists(folder):
            shutil.rmtree(folder)

    # Lance PyInstaller
    print("Création de l'executable...")
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "PyInstaller",
            "--onefile",
            "--windowed",
            "--name",
            "FundExplorer",
            "--add-data",
            "assets:assets",
            "--add-data",
            "data:data",
            "--hidden-import",
            "dash",
            "--hidden-import",
            "dash_bootstrap_components",
            "--hidden-import",
            "plotly",
            "--hidden-import",
            "pandas",
            "--hidden-import",
            "numpy",
            "app.py",
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode == 0:
        print("✓ Executable créé dans dist/FundExplorer")
    else:
        print("Erreur:", result.stderr)


if __name__ == "__main__":
    build_exe()
