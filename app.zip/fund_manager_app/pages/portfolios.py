"""Portfolios page - List and manage portfolios"""

import dash
from dash import html, dcc, callback, Output, Input, State
import dash_bootstrap_components as dbc

dash.register_page(__name__, path="/portfolios", name="Portfolios", order=1)
from components.components import PortfolioCard
from data.demo_data import load_data

data = load_data()

layout = html.Div(
    [
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Portfolio Management",
                                    className="card-header-custom",
                                ),
                                dbc.CardBody(
                                    [
                                        dbc.Button(
                                            [
                                                html.I(className="fas fa-plus me-2"),
                                                "New Portfolio",
                                            ],
                                            id="new-portfolio-btn",
                                            color="primary",
                                            size="sm",
                                        ),
                                    ],
                                    className="d-flex justify-content-end",
                                ),
                            ],
                            className="card-custom mb-4",
                        )
                    ],
                    width=12,
                )
            ]
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        html.H5("All Portfolios", className="section-title"),
                    ]
                )
            ]
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardBody(
                                    [
                                        dbc.Row(
                                            [
                                                dbc.Col(PortfolioCard(p), width=4)
                                                for p in data["portfolios"]
                                            ],
                                            className="g-4",
                                        )
                                    ]
                                )
                            ],
                            className="card-custom",
                        )
                    ],
                    width=12,
                )
            ],
            className="mb-4",
        ),
        dbc.Modal(
            [
                dbc.ModalHeader("Create New Portfolio"),
                dbc.ModalBody(
                    [
                        dbc.Form(
                            [
                                html.Div(
                                    [
                                        dbc.Label("Portfolio Name"),
                                        dbc.Input(
                                            type="text",
                                            id="portfolio-name-input",
                                            placeholder="Enter portfolio name",
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label("Strategy Type"),
                                        dbc.Select(
                                            id="portfolio-type-input",
                                            options=[
                                                {
                                                    "label": "Long/Short Equity",
                                                    "value": "Long/Short Equity",
                                                },
                                                {
                                                    "label": "Fixed Income",
                                                    "value": "Fixed Income",
                                                },
                                                {
                                                    "label": "Global Macro",
                                                    "value": "Global Macro",
                                                },
                                                {
                                                    "label": "Growth Equity",
                                                    "value": "Growth Equity",
                                                },
                                                {
                                                    "label": "Multi-Strategy",
                                                    "value": "Multi-Strategy",
                                                },
                                            ],
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label("Benchmark"),
                                        dbc.Input(
                                            type="text",
                                            id="portfolio-benchmark-input",
                                            placeholder="e.g., S&P 500",
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label("Target AUM"),
                                        dbc.Input(
                                            type="number",
                                            id="portfolio-aum-input",
                                            placeholder="100000000",
                                        ),
                                    ]
                                ),
                            ]
                        )
                    ]
                ),
                dbc.ModalFooter(
                    [
                        dbc.Button(
                            "Cancel",
                            id="close-modal-btn",
                            color="secondary",
                            className="me-2",
                        ),
                        dbc.Button(
                            "Create", id="create-portfolio-btn", color="primary"
                        ),
                    ]
                ),
            ],
            id="create-portfolio-modal",
            is_open=False,
        ),
    ],
    className="fade-in",
)


@callback(
    Output("create-portfolio-modal", "is_open"),
    [Input("new-portfolio-btn", "n_clicks"), Input("close-modal-btn", "n_clicks")],
    [State("create-portfolio-modal", "is_open")],
)
def toggle_modal(n1, n2, is_open):
    if n1 or n2:
        return not is_open
    return is_open
