"""Holdings page - Select portfolio to view detailed positions"""

import dash
from dash import html, dcc, callback, Output, Input, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from data.demo_data import load_data
import pandas as pd
from io import BytesIO

dash.register_page(__name__, path="/holdings", name="Holdings", order=1)

data = load_data()
portfolio_options = [{"label": p["name"], "value": p["id"]} for p in data["portfolios"]]


def format_currency(value, currency="EUR"):
    symbol = "€" if currency == "EUR" else "$"
    prefix = "-" if value < 0 else ""
    value = abs(value)
    if value >= 1_000_000_000:
        return f"{prefix}{symbol}{value / 1_000_000_000:.2f}B"
    elif value >= 1_000_000:
        return f"{prefix}{symbol}{value / 1_000_000:.1f}M"
    elif value >= 1_000:
        return f"{prefix}{symbol}{value / 1_000:.1f}K"
    return f"{prefix}{symbol}{value:.0f}"


def format_pct(value):
    return f"{value:+.2f}%"


def get_color_class(value, max_val):
    if value == 0:
        return "pivot-cell-zero"
    pct = (value / max_val) * 100 if max_val > 0 else 0
    if pct >= 70:
        return "pivot-cell-high"
    elif pct >= 30:
        return "pivot-cell-medium"
    else:
        return "pivot-cell-low"


def create_asset_class_pie(positions):
    asset_weights = {}
    for pos in positions:
        ac = pos.get("asset_class", "Unknown")
        asset_weights[ac] = asset_weights.get(ac, 0) + pos["weight"]

    colors = ["#0d6efd", "#198754", "#dc3545", "#ffc107", "#17a2b8", "#6c757d"]

    fig = go.Figure(
        data=[
            go.Pie(
                labels=list(asset_weights.keys()),
                values=list(asset_weights.values()),
                hole=0.4,
                marker=dict(colors=colors[: len(asset_weights)]),
                textinfo="label+percent",
                textposition="inside",
                textfont=dict(size=11),
            )
        ]
    )

    fig.update_layout(
        height=280,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.2),
        margin=dict(t=10, b=30, l=10, r=10),
        paper_bgcolor="white",
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def create_heatmap(positions):
    sectors = sorted(list(set(p["sector"] for p in positions)))
    isins = [p.get("isin", p["ticker"]) for p in positions[:15]]

    z_data = []
    for pos in positions[:15]:
        row = [pos["weight"] if pos["sector"] == s else None for s in sectors]
        z_data.append(row)

    text_data = [
        [f"{pos['weight']:.1f}%" if pos["sector"] == s else "" for s in sectors]
        for pos in positions[:15]
    ]

    fig = go.Figure(
        data=go.Heatmap(
            z=z_data,
            x=sectors,
            y=isins,
            colorscale="Blues",
            showscale=True,
            colorbar=dict(title="Weight %"),
            text=text_data,
            texttemplate="%{text}",
            textfont={"size": 8, "color": "white"},
            hovertemplate="ISIN: %{y}<br>Sector: %{x}<br>Weight: %{z:.2f}%<extra></extra>",
            connectgaps=False,
        )
    )

    fig.update_layout(
        height=max(350, len(isins) * 30),
        margin=dict(l=120, r=50, t=30, b=80),
        paper_bgcolor="#f8f9fa",
        font=dict(size=9, color="#212529"),
        xaxis=dict(tickangle=-45, gridcolor="#dee2e6"),
        yaxis=dict(autorange="reversed", gridcolor="#dee2e6"),
    )
    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def create_positions_table(positions, currency="EUR"):
    rows = [
        html.Tr(
            [
                html.Th("ISIN"),
                html.Th("Ticker"),
                html.Th("Sector"),
                html.Th("Geo"),
                html.Th("Asset Class"),
                html.Th("Qty", className="text-end"),
                html.Th("Entry", className="text-end"),
                html.Th("Current", className="text-end"),
                html.Th("Market Value", className="text-end"),
                html.Th("+/- Val", className="text-end"),
                html.Th("+/- %", className="text-end"),
                html.Th("Weight", className="text-end"),
            ]
        )
    ]
    for pos in positions:
        pnl_class = "text-success" if pos["unrealized_pnl"] >= 0 else "text-danger"
        rows.append(
            html.Tr(
                [
                    html.Td(
                        html.Span(
                            pos.get("isin", ""),
                            style={
                                "backgroundColor": "#E8F4FC",
                                "color": "#0d6efd",
                                "padding": "2px 6px",
                                "borderRadius": "3px",
                                "fontSize": "0.65rem",
                                "fontFamily": "monospace",
                            },
                        )
                    ),
                    html.Td(
                        pos["ticker"],
                        style={"fontSize": "0.75rem", "color": "#000000 !important"},
                    ),
                    html.Td(
                        pos["sector"],
                        style={
                            "fontSize": "0.75rem",
                            "color": "#495057 !important",
                            "fontWeight": "500",
                        },
                    ),
                    html.Td(
                        pos["geography"],
                        style={
                            "fontSize": "0.75rem",
                            "color": "#495057 !important",
                            "fontWeight": "500",
                        },
                    ),
                    html.Td(
                        pos.get("asset_class", ""),
                        style={
                            "fontSize": "0.75rem",
                            "color": "#000000 !important",
                            "fontWeight": "500",
                        },
                    ),
                    html.Td(
                        f"{pos['shares']:,}",
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(pos["entry_price"], currency),
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(pos["current_price"], currency),
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(pos["market_value"], currency),
                        className="text-end fw-bold",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(pos["unrealized_pnl"], currency),
                        className=f"text-end {pnl_class}",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_pct(pos["unrealized_pnl_pct"]),
                        className=f"text-end {pnl_class}",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        f"{pos['weight']:.2f}%",
                        className="text-end fw-bold",
                        style={"fontSize": "0.75rem"},
                    ),
                ]
            )
        )
    return dbc.Table(
        rows, bordered=True, hover=True, size="sm", className="holdings-table"
    )


def create_transactions_table(transactions, currency="EUR"):
    rows = [
        html.Tr(
            [
                html.Th("Date"),
                html.Th("Ticker"),
                html.Th("Type"),
                html.Th("Shares", className="text-end"),
                html.Th("Price", className="text-end"),
                html.Th("Amount", className="text-end"),
                html.Th("Fees", className="text-end"),
            ]
        )
    ]
    for t in transactions[:50]:
        type_class = "text-success" if t["type"] == "BUY" else "text-danger"
        rows.append(
            html.Tr(
                [
                    html.Td(
                        t["date"],
                        style={"fontSize": "0.75rem", "color": "#000000 !important"},
                    ),
                    html.Td(
                        t["ticker"],
                        style={"fontSize": "0.75rem", "color": "#000000 !important"},
                    ),
                    html.Td(
                        html.Strong(t["type"]),
                        className=type_class,
                        style={
                            "fontSize": "0.75rem",
                            "color": "#28a745 !important"
                            if t["type"] == "BUY"
                            else "#dc3545 !important",
                        },
                    ),
                    html.Td(
                        f"{t['shares']:,}",
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(t["price"], currency),
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(t["amount"], currency),
                        className="text-end fw-bold",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(t["fees"], currency),
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                ]
            )
        )

    if not transactions:
        rows.append(
            html.Tr(
                html.Td(
                    "No transactions", colSpan=7, className="text-center text-muted"
                )
            )
        )

    return dbc.Table(
        rows, bordered=True, hover=True, size="sm", className="transactions-table"
    )


def create_pivot_tables(positions):
    if not positions:
        return html.Div(
            "No positions to display", className="text-muted text-center p-3"
        )

    df = pd.DataFrame(positions)

    pivot_sector = df.pivot_table(
        values="weight",
        index="geography",
        columns="sector",
        aggfunc="sum",
        fill_value=0,
    ).round(2)
    pivot_geo = df.pivot_table(
        values="weight",
        index="sector",
        columns="geography",
        aggfunc="sum",
        fill_value=0,
    ).round(2)
    pivot_isin = df.pivot_table(
        values="weight",
        index="isin",
        columns="asset_class",
        aggfunc="sum",
        fill_value=0,
    ).round(2)

    max_val = (
        max(pivot_sector.max().max(), pivot_geo.max().max(), pivot_isin.max().max())
        if len(pivot_sector) > 0
        else 15
    )

    def get_bg_color(val, max_v):
        if val == 0:
            return "#ffffff"
        pct = val / max_v if max_v > 0 else 0
        if pct >= 0.7:
            return "#b8daff"
        elif pct >= 0.3:
            return "#d4edff"
        else:
            return "#e7f5ff"

    def make_pivot_table(pivot_df, row_label, col_label):
        header_row = html.Tr(
            [html.Th(row_label, className="bg-info text-white")]
            + [
                html.Th(col, className="bg-info text-white text-center")
                for col in pivot_df.columns
            ]
        )
        rows = [header_row]

        for idx in pivot_df.index:
            row_cells = [
                html.Td(
                    html.Strong(str(idx)),
                    style={
                        "fontSize": "0.7rem",
                        "backgroundColor": "#87CEEB",
                        "color": "#000000",
                        "fontWeight": "bold",
                    },
                )
            ]
            for col in pivot_df.columns:
                val = pivot_df.loc[idx, col]
                bg = get_bg_color(val, max_val)
                if val > 0:
                    row_cells.append(
                        html.Td(
                            f"{val:.2f}%",
                            style={
                                "backgroundColor": bg,
                                "textAlign": "right",
                                "fontSize": "0.7rem",
                                "fontWeight": "bold" if val > 10 else "normal",
                                "color": "#212529",
                            },
                        )
                    )
                else:
                    row_cells.append(
                        html.Td(
                            "-",
                            style={
                                "textAlign": "center",
                                "color": "#999",
                                "fontSize": "0.7rem",
                                "backgroundColor": "#ffffff",
                            },
                        )
                    )
            rows.append(html.Tr(row_cells))

        col_totals = pivot_df.sum()
        total_row_cells = [
            html.Td(
                html.Strong("TOTAL"),
                style={
                    "fontSize": "0.7rem",
                    "backgroundColor": "#28a745",
                    "color": "#ffffff",
                    "fontWeight": "bold",
                },
            )
        ]
        for col in pivot_df.columns:
            val = col_totals[col]
            total_row_cells.append(
                html.Td(
                    f"{val:.2f}%",
                    style={
                        "backgroundColor": "#28a745",
                        "color": "#ffffff",
                        "textAlign": "right",
                        "fontSize": "0.7rem",
                        "fontWeight": "bold",
                    },
                )
            )
        rows.append(html.Tr(total_row_cells))

        return dbc.Table(
            rows,
            bordered=True,
            size="sm",
            className="pivot-table",
            style={"color": "#212529"},
        )

    return html.Div(
        [
            dbc.ButtonGroup(
                [
                    dbc.Button(
                        [html.I(className="fas fa-file-csv me-1"), "CSV"],
                        id="export-holdings-csv",
                        color="primary",
                        size="sm",
                        className="me-2",
                    ),
                    dbc.Button(
                        [html.I(className="fas fa-file-excel me-1"), "Excel"],
                        id="export-holdings-excel",
                        color="success",
                        size="sm",
                    ),
                ],
                className="mb-3",
            ),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            html.H6("ISIN × Asset Class", className="mb-2 fw-bold"),
                            make_pivot_table(pivot_isin, "ISIN ↓", "Asset Class →"),
                        ],
                        width=4,
                    ),
                    dbc.Col(
                        [
                            html.H6("Sector × Geography", className="mb-2 fw-bold"),
                            make_pivot_table(pivot_sector, "Sector ↓", "Geo →"),
                        ],
                        width=4,
                    ),
                    dbc.Col(
                        [
                            html.H6("Geography × Sector", className="mb-2 fw-bold"),
                            make_pivot_table(pivot_geo, "Geo ↓", "Sector →"),
                        ],
                        width=4,
                    ),
                ]
            ),
        ]
    )


initial_portfolio = data["portfolios"][0]
initial_currency = initial_portfolio.get("currency", "EUR")
initial_positions = sorted(
    initial_portfolio["positions"], key=lambda x: x["weight"], reverse=True
)
initial_transactions = initial_portfolio.get("transactions", [])
initial_isin_options = [
    {
        "label": f"{p['ticker']} ({p.get('isin', '')})",
        "value": p.get("isin", p["ticker"]),
    }
    for p in initial_positions
]

initial_total_mv = sum(p["market_value"] for p in initial_positions)
initial_total_pnl = sum(p["unrealized_pnl"] for p in initial_positions)
initial_winners = len([p for p in initial_positions if p["unrealized_pnl"] > 0])
initial_losers = len([p for p in initial_positions if p["unrealized_pnl"] < 0])
initial_pnl_color = "text-success" if initial_total_pnl >= 0 else "text-danger"


layout = html.Div(
    [
        html.H4("Portfolio Holdings", className="mb-3"),
        dbc.Card(
            [
                dbc.CardBody(
                    [
                        dbc.Row(
                            [
                                dbc.Col(
                                    [
                                        html.Label(
                                            "Select Portfolio", className="fw-bold"
                                        ),
                                        dbc.Select(
                                            id="portfolio-selector",
                                            options=portfolio_options,
                                            value=initial_portfolio["id"],
                                        ),
                                    ],
                                    width=3,
                                ),
                                dbc.Col(
                                    [
                                        html.Label(
                                            "Filter by ISIN / Ticker",
                                            className="fw-bold",
                                        ),
                                        dcc.Dropdown(
                                            id="isin-selector",
                                            options=initial_isin_options,
                                            value=None,
                                            placeholder="All positions",
                                            clearable=True,
                                        ),
                                    ],
                                    width=4,
                                ),
                                dbc.Col(
                                    [
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    [
                                                        html.Span(
                                                            "FundManager: ",
                                                            className="text-muted",
                                                        ),
                                                        html.Strong(
                                                            initial_portfolio[
                                                                "fundmanager"
                                                            ]
                                                        ),
                                                    ],
                                                    className="border-end text-center p-2",
                                                ),
                                                dbc.Col(
                                                    [
                                                        html.Span(
                                                            "UG: ",
                                                            className="text-muted",
                                                        ),
                                                        html.Strong(
                                                            initial_portfolio["code_ug"]
                                                        ),
                                                    ],
                                                    className="border-end text-center p-2",
                                                ),
                                                dbc.Col(
                                                    [
                                                        html.Span(
                                                            "OG: ",
                                                            className="text-muted",
                                                        ),
                                                        html.Strong(
                                                            initial_portfolio["code_og"]
                                                        ),
                                                    ],
                                                    className="border-end text-center p-2",
                                                ),
                                                dbc.Col(
                                                    [
                                                        html.Span(
                                                            "Currency: ",
                                                            className="text-muted",
                                                        ),
                                                        html.Strong(initial_currency),
                                                    ],
                                                    className="text-center p-2",
                                                ),
                                            ]
                                        ),
                                    ],
                                    width=5,
                                ),
                            ]
                        ),
                    ]
                )
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    [
                                        html.Span("Holdings - ", className="fw-bold"),
                                        html.Span(
                                            id="holdings-count", className="text-muted"
                                        ),
                                    ],
                                    className="d-flex justify-content-between",
                                ),
                                dbc.CardBody(
                                    [
                                        html.Div(
                                            id="holdings-table-container",
                                            children=[
                                                create_positions_table(
                                                    initial_positions, initial_currency
                                                )
                                            ],
                                            style={
                                                "maxHeight": "300px",
                                                "overflowY": "auto",
                                            },
                                        )
                                    ]
                                ),
                            ]
                        ),
                    ],
                    width=8,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Asset Class Distribution", className="fw-bold"
                                ),
                                dbc.CardBody(
                                    [
                                        html.Div(
                                            id="pie-container",
                                            children=[
                                                create_asset_class_pie(
                                                    initial_positions
                                                )
                                            ],
                                        )
                                    ]
                                ),
                            ]
                        ),
                    ],
                    width=4,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Sector / ISIN Heatmap", className="fw-bold"
                                ),
                                dbc.CardBody(
                                    [
                                        html.Div(
                                            id="heatmap-container",
                                            children=[
                                                create_heatmap(initial_positions)
                                            ],
                                        )
                                    ]
                                ),
                            ]
                        ),
                    ]
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    [
                                        html.Span(
                                            "Transactions - ", className="fw-bold"
                                        ),
                                        html.Span(
                                            id="txn-count", className="text-muted"
                                        ),
                                    ],
                                    className="d-flex justify-content-between",
                                ),
                                dbc.CardBody(
                                    [
                                        html.Div(
                                            id="transactions-table-container",
                                            children=[
                                                create_transactions_table(
                                                    initial_transactions,
                                                    initial_currency,
                                                )
                                            ],
                                            style={
                                                "maxHeight": "200px",
                                                "overflowY": "auto",
                                            },
                                        )
                                    ]
                                ),
                            ]
                        ),
                    ]
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Pivot Tables - Weights", className="fw-bold"
                                ),
                                dbc.CardBody(
                                    [
                                        html.Div(
                                            id="pivot-container",
                                            children=[
                                                create_pivot_tables(initial_positions)
                                            ],
                                        )
                                    ]
                                ),
                            ]
                        ),
                    ]
                ),
            ]
        ),
    ]
)


@callback(
    [
        Output("isin-selector", "options"),
        Output("isin-selector", "value"),
        Output("holdings-table-container", "children"),
        Output("holdings-count", "children"),
        Output("pie-container", "children"),
        Output("heatmap-container", "children"),
        Output("transactions-table-container", "children"),
        Output("txn-count", "children"),
        Output("pivot-container", "children"),
    ],
    [
        Input("portfolio-selector", "value"),
        Input("isin-selector", "value"),
    ],
)
def update_display(portfolio_id, selected_isin):
    portfolio = next(
        (p for p in data["portfolios"] if p["id"] == portfolio_id),
        data["portfolios"][0],
    )
    currency = portfolio.get("currency", "EUR")
    positions = sorted(portfolio["positions"], key=lambda x: x["weight"], reverse=True)
    transactions = portfolio.get("transactions", [])

    isin_options = [
        {
            "label": f"{p['ticker']} ({p.get('isin', '')})",
            "value": p.get("isin", p["ticker"]),
        }
        for p in positions
    ]

    if selected_isin:
        positions = [
            p
            for p in positions
            if p.get("isin") == selected_isin or p.get("ticker") == selected_isin
        ]
        transactions = [
            t
            for t in transactions
            if t.get("ticker") == selected_isin or t.get("isin") == selected_isin
        ]

    total_mv = sum(p["market_value"] for p in positions)
    total_pnl = sum(p["unrealized_pnl"] for p in positions)
    winners = len([p for p in positions if p["unrealized_pnl"] > 0])
    losers = len([p for p in positions if p["unrealized_pnl"] > 0])
    pnl_color = "text-success" if total_pnl >= 0 else "text-danger"

    return (
        isin_options,
        selected_isin,
        create_positions_table(positions, currency),
        f"{len(positions)} positions"
        + (f" - {selected_isin}" if selected_isin else ""),
        create_asset_class_pie(positions),
        create_heatmap(positions),
        create_transactions_table(transactions, currency),
        f"{len(transactions)} transactions"
        + (f" - {selected_isin}" if selected_isin else ""),
        create_pivot_tables(positions),
    )


def get_holdings_pivot_dataframe(positions):
    if not positions:
        return pd.DataFrame()

    df = pd.DataFrame(positions)

    pivot_sector = df.pivot_table(
        values="weight",
        index="geography",
        columns="sector",
        aggfunc="sum",
        fill_value=0,
    ).round(2)

    pivot_geo = df.pivot_table(
        values="weight",
        index="sector",
        columns="geography",
        aggfunc="sum",
        fill_value=0,
    ).round(2)

    pivot_isin = df.pivot_table(
        values="weight",
        index="isin",
        columns="asset_class",
        aggfunc="sum",
        fill_value=0,
    ).round(2)

    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        pivot_sector.to_excel(writer, sheet_name="Sector x Geo")
        pivot_geo.to_excel(writer, sheet_name="Geo x Sector")
        pivot_isin.to_excel(writer, sheet_name="ISIN x AssetClass")
    output.seek(0)
    return output


@callback(
    Output("download-holdings-csv", "data"),
    Input("export-holdings-csv", "n_clicks"),
    State("portfolio-selector", "value"),
    prevent_initial_call=True,
)
def export_holdings_csv(n_clicks, portfolio_id):
    portfolio = next(
        (p for p in data["portfolios"] if p["id"] == portfolio_id),
        data["portfolios"][0],
    )
    positions = portfolio["positions"]

    if not positions:
        return None

    df = pd.DataFrame(positions)
    export_df = df[
        [
            "isin",
            "ticker",
            "name",
            "sector",
            "geography",
            "asset_class",
            "shares",
            "weight",
            "market_value",
            "entry_price",
            "current_price",
            "unrealized_pnl",
            "unrealized_pnl_pct",
        ]
    ].copy()
    export_df.columns = [
        "ISIN",
        "Ticker",
        "Name",
        "Sector",
        "Geography",
        "Asset Class",
        "Shares",
        "Weight (%)",
        "Market Value",
        "Entry Price",
        "Current Price",
        "P&L",
        "P&L (%)",
    ]
    return dcc.send_data_frame(export_df.to_csv, "holdings_export.csv", index=False)


@callback(
    Output("download-holdings-xlsx", "data"),
    Input("export-holdings-excel", "n_clicks"),
    State("portfolio-selector", "value"),
    prevent_initial_call=True,
)
def export_holdings_excel(n_clicks, portfolio_id):
    portfolio = next(
        (p for p in data["portfolios"] if p["id"] == portfolio_id),
        data["portfolios"][0],
    )
    positions = portfolio["positions"]

    if not positions:
        return None

    df = pd.DataFrame(positions)

    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df[
            [
                "isin",
                "ticker",
                "name",
                "sector",
                "geography",
                "asset_class",
                "shares",
                "weight",
                "market_value",
                "entry_price",
                "current_price",
                "unrealized_pnl",
                "unrealized_pnl_pct",
            ]
        ].to_excel(writer, sheet_name="Holdings", index=False)

        pivot_sector = df.pivot_table(
            values="weight",
            index="geography",
            columns="sector",
            aggfunc="sum",
            fill_value=0,
        ).round(2)
        pivot_sector.to_excel(writer, sheet_name="Sector x Geo")

        pivot_geo = df.pivot_table(
            values="weight",
            index="sector",
            columns="geography",
            aggfunc="sum",
            fill_value=0,
        ).round(2)
        pivot_geo.to_excel(writer, sheet_name="Geo x Sector")

        pivot_isin = df.pivot_table(
            values="weight",
            index="isin",
            columns="asset_class",
            aggfunc="sum",
            fill_value=0,
        ).round(2)
        pivot_isin.to_excel(writer, sheet_name="ISIN x AssetClass")

    output.seek(0)
    return dcc.send_bytes(output.getvalue(), "holdings_export.xlsx")
