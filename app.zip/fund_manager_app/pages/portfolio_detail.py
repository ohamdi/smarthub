"""Portfolio Detail page - Detailed view of a single portfolio"""

from dash import html, dcc, callback, Output, Input, State
import dash_bootstrap_components as dbc
from components.components import (
    MetricCard,
    PerformanceChart,
    AllocationDonut,
    PositionsTable,
    TransactionsTable,
    format_currency,
    format_pct,
)
from data.demo_data import load_data

data = load_data()


def get_portfolio(portfolio_id):
    for p in data["portfolios"]:
        if p["id"] == portfolio_id:
            return p
    return None


layout = html.Div(
    [
        dcc.Location(id="url", refresh=False),
        dcc.Store(id="selected-portfolio-id", data="P001"),
        html.Div(id="portfolio-detail-content"),
    ],
    className="fade-in",
)


@callback(
    Output("selected-portfolio-id", "data"),
    Input("url", "pathname"),
)
def update_selected_portfolio(pathname):
    if pathname and "/portfolio/" in pathname:
        portfolio_id = pathname.split("/portfolio/")[-1]
        return portfolio_id
    return "P001"


@callback(
    Output("portfolio-detail-content", "children"),
    Input("selected-portfolio-id", "data"),
)
def render_portfolio_detail(portfolio_id):
    portfolio = get_portfolio(portfolio_id)

    if not portfolio:
        return html.Div(
            [
                dbc.Alert("Portfolio not found", color="danger"),
                dbc.Button("Back to Portfolios", href="/portfolios", color="primary"),
            ],
            className="p-4",
        )

    return html.Div(
        [
            dbc.Row(
                [
                    dbc.Col(
                        [
                            dbc.Breadcrumb(
                                [
                                    dbc.BreadcrumbItem(
                                        "Portfolios", href="/portfolios"
                                    ),
                                    dbc.BreadcrumbItem(portfolio["name"], active=True),
                                ]
                            )
                        ],
                        width=12,
                    )
                ],
                className="mb-3",
            ),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            html.H4(portfolio["name"], className="mb-1"),
                            html.Span(
                                portfolio["type"], className="badge bg-secondary"
                            ),
                        ]
                    ),
                    dbc.Col(
                        [
                            dbc.Button(
                                [html.I(className="fas fa-edit me-1"), "Edit"],
                                color="outline-secondary",
                                size="sm",
                                className="me-2",
                            ),
                            dbc.Button(
                                [html.I(className="fas fa-download me-1"), "Export"],
                                color="outline-secondary",
                                size="sm",
                            ),
                        ],
                        className="text-end",
                    ),
                ],
                className="mb-4",
            ),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            MetricCard(
                                "AUM",
                                format_currency(portfolio["aum"]),
                                delta=f"${portfolio['aum'] * 0.023:,.0f} MTD",
                                delta_type="positive",
                            )
                        ],
                        width=2,
                    ),
                    dbc.Col(
                        [
                            MetricCard(
                                "YTD Return",
                                format_pct(portfolio["ytd_return"]),
                                delta=f"{portfolio['ytd_return'] - 8.2:.1f}% vs benchmark",
                                delta_type="positive"
                                if portfolio["ytd_return"] > 0
                                else "negative",
                            )
                        ],
                        width=2,
                    ),
                    dbc.Col(
                        [
                            MetricCard(
                                "Total Return",
                                format_pct(portfolio["total_return"]),
                                delta="Since inception",
                                delta_type="positive",
                            )
                        ],
                        width=2,
                    ),
                    dbc.Col(
                        [
                            MetricCard(
                                "Sharpe Ratio",
                                f"{portfolio['sharpe']:.2f}",
                                delta="Above target",
                                delta_type="positive",
                            )
                        ],
                        width=2,
                    ),
                    dbc.Col(
                        [
                            MetricCard(
                                "Max Drawdown",
                                format_pct(portfolio["max_dd"]),
                                delta="Within risk",
                                delta_type="neutral",
                            )
                        ],
                        width=2,
                    ),
                    dbc.Col(
                        [
                            MetricCard(
                                "Positions",
                                str(len(portfolio["positions"])),
                                delta="Active",
                                delta_type="neutral",
                            )
                        ],
                        width=2,
                    ),
                ],
                className="mb-4",
            ),
            dbc.Tabs(
                [
                    dbc.Tab(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            dbc.Card(
                                                [
                                                    dbc.CardHeader(
                                                        "Performance (1Y)",
                                                        className="card-header-custom",
                                                    ),
                                                    dbc.CardBody(
                                                        [
                                                            PerformanceChart(
                                                                portfolio[
                                                                    "performance"
                                                                ],
                                                                height=380,
                                                            )
                                                        ]
                                                    ),
                                                ],
                                                className="card-custom",
                                            )
                                        ],
                                        width=8,
                                    ),
                                    dbc.Col(
                                        [
                                            dbc.Card(
                                                [
                                                    dbc.CardHeader(
                                                        "Sector Allocation",
                                                        className="card-header-custom",
                                                    ),
                                                    dbc.CardBody(
                                                        [
                                                            AllocationDonut(
                                                                portfolio["allocation"][
                                                                    "sector"
                                                                ]
                                                            )
                                                        ]
                                                    ),
                                                ],
                                                className="card-custom mb-3",
                                            ),
                                            dbc.Card(
                                                [
                                                    dbc.CardHeader(
                                                        "Geographic Allocation",
                                                        className="card-header-custom",
                                                    ),
                                                    dbc.CardBody(
                                                        [
                                                            AllocationDonut(
                                                                portfolio["allocation"][
                                                                    "geography"
                                                                ]
                                                            )
                                                        ]
                                                    ),
                                                ],
                                                className="card-custom",
                                            ),
                                        ],
                                        width=4,
                                    ),
                                ],
                                className="mb-4",
                            ),
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            dbc.Card(
                                                [
                                                    dbc.CardHeader(
                                                        [
                                                            html.Span("Top Positions"),
                                                            dbc.Button(
                                                                "View All",
                                                                size="sm",
                                                                color="link",
                                                                className="float-end",
                                                            ),
                                                        ],
                                                        className="card-header-custom",
                                                    ),
                                                    dbc.CardBody(
                                                        [
                                                            PositionsTable(
                                                                portfolio["positions"],
                                                                max_rows=12,
                                                            )
                                                        ],
                                                        style={
                                                            "maxHeight": "450px",
                                                            "overflowY": "auto",
                                                        },
                                                    ),
                                                ],
                                                className="card-custom",
                                            )
                                        ],
                                        width=12,
                                    ),
                                ],
                                className="mb-4",
                            ),
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            dbc.Card(
                                                [
                                                    dbc.CardHeader(
                                                        "Recent Transactions",
                                                        className="card-header-custom",
                                                    ),
                                                    dbc.CardBody(
                                                        [
                                                            TransactionsTable(
                                                                portfolio[
                                                                    "transactions"
                                                                ],
                                                                max_rows=8,
                                                            )
                                                        ],
                                                        style={
                                                            "maxHeight": "350px",
                                                            "overflowY": "auto",
                                                        },
                                                    ),
                                                ],
                                                className="card-custom",
                                            )
                                        ],
                                        width=12,
                                    ),
                                ]
                            ),
                        ],
                        label="Overview",
                    ),
                    dbc.Tab(
                        [
                            html.Div(
                                [
                                    dbc.Card(
                                        [
                                            dbc.CardHeader(
                                                "Risk Metrics",
                                                className="card-header-custom",
                                            ),
                                            dbc.CardBody(
                                                [
                                                    dbc.Row(
                                                        [
                                                            dbc.Col(
                                                                [
                                                                    html.Div(
                                                                        "Volatility (Ann.)",
                                                                        className="risk-label",
                                                                    ),
                                                                    html.Div(
                                                                        "14.2%",
                                                                        className="risk-value",
                                                                    ),
                                                                ],
                                                                width=3,
                                                            ),
                                                            dbc.Col(
                                                                [
                                                                    html.Div(
                                                                        "Max Drawdown",
                                                                        className="risk-label",
                                                                    ),
                                                                    html.Div(
                                                                        f"{portfolio['max_dd']:.1f}%",
                                                                        className="risk-value text-danger",
                                                                    ),
                                                                ],
                                                                width=3,
                                                            ),
                                                            dbc.Col(
                                                                [
                                                                    html.Div(
                                                                        "VaR (95%)",
                                                                        className="risk-label",
                                                                    ),
                                                                    html.Div(
                                                                        "-2.8%",
                                                                        className="risk-value",
                                                                    ),
                                                                ],
                                                                width=3,
                                                            ),
                                                            dbc.Col(
                                                                [
                                                                    html.Div(
                                                                        "Sortino Ratio",
                                                                        className="risk-label",
                                                                    ),
                                                                    html.Div(
                                                                        "1.45",
                                                                        className="risk-value",
                                                                    ),
                                                                ],
                                                                width=3,
                                                            ),
                                                            dbc.Col(
                                                                [
                                                                    html.Div(
                                                                        "Beta",
                                                                        className="risk-label",
                                                                    ),
                                                                    html.Div(
                                                                        "0.87",
                                                                        className="risk-value",
                                                                    ),
                                                                ],
                                                                width=3,
                                                            ),
                                                            dbc.Col(
                                                                [
                                                                    html.Div(
                                                                        "Alpha",
                                                                        className="risk-label",
                                                                    ),
                                                                    html.Div(
                                                                        "3.2%",
                                                                        className="risk-value text-success",
                                                                    ),
                                                                ],
                                                                width=3,
                                                            ),
                                                        ]
                                                    )
                                                ]
                                            ),
                                        ],
                                        className="card-custom mb-4",
                                    )
                                ]
                            )
                        ],
                        label="Risk",
                    ),
                    dbc.Tab(
                        [
                            html.Div(
                                [
                                    dbc.Card(
                                        [
                                            dbc.CardHeader(
                                                "Performance Attribution",
                                                className="card-header-custom",
                                            ),
                                            dbc.CardBody(
                                                [
                                                    dbc.Row(
                                                        [
                                                            dbc.Col(
                                                                [
                                                                    html.Div(
                                                                        "Top Contributors",
                                                                        className="attribution-title mb-3",
                                                                    ),
                                                                    dbc.ListGroup(
                                                                        [
                                                                            dbc.ListGroupItem(
                                                                                [
                                                                                    html.Div(
                                                                                        "NVDA",
                                                                                        className="fw-bold me-auto",
                                                                                    ),
                                                                                    html.Small(
                                                                                        "+4.2%",
                                                                                        className="text-success",
                                                                                    ),
                                                                                ],
                                                                                className="d-flex justify-content-between",
                                                                            ),
                                                                            dbc.ListGroupItem(
                                                                                [
                                                                                    html.Div(
                                                                                        "AAPL",
                                                                                        className="fw-bold me-auto",
                                                                                    ),
                                                                                    html.Small(
                                                                                        "+2.8%",
                                                                                        className="text-success",
                                                                                    ),
                                                                                ],
                                                                                className="d-flex justify-content-between",
                                                                            ),
                                                                            dbc.ListGroupItem(
                                                                                [
                                                                                    html.Div(
                                                                                        "MSFT",
                                                                                        className="fw-bold me-auto",
                                                                                    ),
                                                                                    html.Small(
                                                                                        "+1.9%",
                                                                                        className="text-success",
                                                                                    ),
                                                                                ],
                                                                                className="d-flex justify-content-between",
                                                                            ),
                                                                        ]
                                                                    ),
                                                                ],
                                                                width=6,
                                                            ),
                                                            dbc.Col(
                                                                [
                                                                    html.Div(
                                                                        "Top Detractors",
                                                                        className="attribution-title mb-3",
                                                                    ),
                                                                    dbc.ListGroup(
                                                                        [
                                                                            dbc.ListGroupItem(
                                                                                [
                                                                                    html.Div(
                                                                                        "META",
                                                                                        className="fw-bold me-auto",
                                                                                    ),
                                                                                    html.Small(
                                                                                        "-1.2%",
                                                                                        className="text-danger",
                                                                                    ),
                                                                                ],
                                                                                className="d-flex justify-content-between",
                                                                            ),
                                                                            dbc.ListGroupItem(
                                                                                [
                                                                                    html.Div(
                                                                                        "TSLA",
                                                                                        className="fw-bold me-auto",
                                                                                    ),
                                                                                    html.Small(
                                                                                        "-0.8%",
                                                                                        className="text-danger",
                                                                                    ),
                                                                                ],
                                                                                className="d-flex justify-content-between",
                                                                            ),
                                                                        ]
                                                                    ),
                                                                ],
                                                                width=6,
                                                            ),
                                                        ]
                                                    )
                                                ]
                                            ),
                                        ],
                                        className="card-custom",
                                    )
                                ]
                            )
                        ],
                        label="Attribution",
                    ),
                ]
            ),
        ]
    )
