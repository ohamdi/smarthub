"""Overview page - KPIs by FundManager"""

import dash
from dash import html, dcc, callback, Output, Input, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from data.demo_data import load_data
import pandas as pd
from io import BytesIO

dash.register_page(__name__, path="/", name="Overview", order=0)

data = load_data()


def format_currency(value):
    if abs(value) >= 1_000_000_000:
        return f"${abs(value) / 1_000_000_000:.2f}B"
    elif abs(value) >= 1_000_000:
        return f"${abs(value) / 1_000_000:.1f}M"
    elif abs(value) >= 1_000:
        return f"${abs(value) / 1_000:.1f}K"
    return f"${value:.0f}"


def format_pct(value):
    return f"{value:+.2f}%"


def get_fundmanager_stats(data):
    fm_stats = {}
    for p in data["portfolios"]:
        fm = p["fundmanager"]
        if fm not in fm_stats:
            fm_stats[fm] = {"aum": 0, "portfolios": [], "positions": 0, "ytd": 0}
        fm_stats[fm]["aum"] += p["aum"]
        fm_stats[fm]["portfolios"].append(p["name"])
        fm_stats[fm]["positions"] += len(p["positions"])
        total_pnl = sum(pos["unrealized_pnl"] for pos in p["positions"])
        fm_stats[fm]["total_pnl"] = total_pnl
    for fm in fm_stats:
        fm_stats[fm]["avg_ytd"] = sum(
            p["ytd_return"] for p in data["portfolios"] if p["fundmanager"] == fm
        ) / len([p for p in data["portfolios"] if p["fundmanager"] == fm])
    return fm_stats


fm_stats = get_fundmanager_stats(data)


def make_table(headers, rows):
    header_cells = [html.Th(h) for h in headers]
    body_rows = []
    for row_data in rows:
        cells = []
        for cell in row_data:
            if hasattr(cell, "__class__") and (
                "Span" in str(cell.__class__) or "Strong" in str(cell.__class__)
            ):
                cells.append(html.Td(cell))
            elif isinstance(cell, (html.Span, html.Strong)):
                cells.append(html.Td(cell))
            else:
                cells.append(html.Td(str(cell)))
        body_rows.append(html.Tr(cells))
    return html.Table(
        [html.Thead([html.Tr(header_cells)]), html.Tbody(body_rows)],
        className="custom-table",
    )


def create_pivot_table(data):
    all_positions = []
    for p in data["portfolios"]:
        for pos in p["positions"]:
            all_positions.append(
                {
                    "isin": pos.get("isin", pos["ticker"]),
                    "ticker": pos["ticker"],
                    "portfolio": p["name"],
                    "weight": pos["weight"],
                    "asset_class": pos.get("asset_class", "Unknown"),
                }
            )

    if not all_positions:
        return html.Div("No positions data", className="text-muted")

    pos_df = pd.DataFrame(all_positions)
    portfolios = list(pos_df["portfolio"].unique())
    asset_classes = sorted(list(pos_df["asset_class"].unique()))

    max_val = 15

    header_row = html.Tr(
        [
            html.Th(
                "Asset Class",
                className="bg-info text-white",
                style={"minWidth": "120px"},
            )
        ]
        + [html.Th("ISIN", className="bg-info text-white", style={"minWidth": "100px"})]
        + [
            html.Th(
                "Ticker", className="bg-info text-white", style={"minWidth": "60px"}
            )
        ]
        + [
            html.Th(
                col,
                className="bg-info text-white text-center",
                style={"minWidth": "80px"},
            )
            for col in portfolios
        ]
    )

    rows = []
    for ac in asset_classes:
        ac_df = pos_df[pos_df["asset_class"] == ac]
        grouped = (
            ac_df.groupby(["isin", "ticker"])
            .agg({"weight": "sum"})
            .reset_index()
            .sort_values("weight", ascending=False)
        )

        first_row = True
        for _, row in grouped.iterrows():
            isin_val = row["isin"]
            ticker_val = row["ticker"]

            portfolio_weights = {}
            for p in portfolios:
                val = ac_df[(ac_df["isin"] == isin_val) & (ac_df["portfolio"] == p)][
                    "weight"
                ].sum()
                portfolio_weights[p] = val

            cells = [
                html.Td(
                    html.Strong(ac),
                    style={
                        "backgroundColor": "#b8d4e8",
                        "fontWeight": "bold",
                        "verticalAlign": "middle",
                    },
                )
                if first_row
                else html.Td("", style={"backgroundColor": "#b8d4e8"}),
                html.Td(
                    isin_val,
                    style={
                        "fontFamily": "monospace",
                        "fontSize": "0.7rem",
                        "color": "#0d6efd",
                    },
                ),
                html.Td(ticker_val, style={"fontWeight": "bold"}),
            ]

            for p in portfolios:
                val = portfolio_weights[p]
                if val > 0:
                    color_intensity = min(int(val / max_val * 255), 200)
                    bg_color = f"rgb({200 - color_intensity}, {230 - color_intensity * 0.5}, 255)"
                    cells.append(
                        html.Td(
                            f"{val:.2f}%",
                            style={
                                "backgroundColor": bg_color,
                                "textAlign": "right",
                                "color": "#212529",
                            },
                        )
                    )
                else:
                    cells.append(
                        html.Td(
                            "-",
                            style={
                                "textAlign": "center",
                                "color": "#999",
                                "backgroundColor": "#ffffff",
                            },
                        )
                    )

            rows.append(
                html.Tr(
                    cells,
                    style={
                        "backgroundColor": "#ffffff" if not first_row else "#f0f8ff"
                    },
                )
            )
            first_row = False

        subtotal_cells = [
            html.Td(
                html.Strong(f"Sous-total {ac}"),
                colSpan=3,
                style={
                    "backgroundColor": "#28a745",
                    "color": "white",
                    "fontWeight": "bold",
                },
            )
        ]
        for p in portfolios:
            val = ac_df[ac_df["portfolio"] == p]["weight"].sum()
            subtotal_cells.append(
                html.Td(
                    f"{val:.2f}%",
                    style={
                        "backgroundColor": "#28a745",
                        "color": "white",
                        "textAlign": "right",
                        "fontWeight": "bold",
                    },
                )
            )
        rows.append(html.Tr(subtotal_cells))

    return html.Div(
        [
            dbc.ButtonGroup(
                [
                    dbc.Button(
                        [html.I(className="fas fa-file-csv me-1"), "CSV"],
                        id="export-csv",
                        color="primary",
                        size="sm",
                        className="me-2",
                    ),
                    dbc.Button(
                        [html.I(className="fas fa-file-excel me-1"), "Excel"],
                        id="export-excel",
                        color="success",
                        size="sm",
                    ),
                ],
                className="mb-3",
            ),
            html.Table(
                [html.Thead([header_row]), html.Tbody(rows)],
                className="custom-table",
                style={"fontSize": "0.8rem", "width": "100%", "color": "#212529"},
            ),
        ],
        style={"maxHeight": "600px", "overflowY": "auto"},
    )


def get_pivot_dataframe(data):
    all_positions = []
    for p in data["portfolios"]:
        for pos in p["positions"]:
            all_positions.append(
                {
                    "ISIN": pos.get("isin", pos["ticker"]),
                    "Ticker": pos["ticker"],
                    "Asset Class": pos.get("asset_class", "Unknown"),
                    "Portfolio": p["name"],
                    "Weight (%)": pos["weight"],
                }
            )

    if not all_positions:
        return pd.DataFrame()

    df = pd.DataFrame(all_positions)
    pivot = df.pivot_table(
        values="Weight (%)",
        index=["Asset Class", "ISIN", "Ticker"],
        columns="Portfolio",
        aggfunc="sum",
        fill_value=0,
    ).reset_index()

    pivot.columns.name = None
    return pivot


def create_asset_class_pie(data):
    fig = go.Figure()

    colors = [
        "#0d6efd",
        "#198754",
        "#dc3545",
        "#ffc107",
        "#17a2b8",
        "#6c757d",
        "#20c997",
        "#d63384",
        "#6610f2",
        "#fd7e14",
    ]

    for i, p in enumerate(data["portfolios"]):
        asset_weights = {}
        for pos in p["positions"]:
            ac = pos.get("asset_class", "Unknown")
            asset_weights[ac] = asset_weights.get(ac, 0) + pos["weight"]

        if asset_weights:
            fig.add_trace(
                go.Pie(
                    labels=list(asset_weights.keys()),
                    values=list(asset_weights.values()),
                    name=p["name"],
                    hole=0.3,
                    marker=dict(colors=colors[: len(asset_weights)]),
                    textinfo="label+percent",
                    textposition="inside",
                )
            )

    fig.update_layout(
        height=300,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.3),
        margin=dict(t=20, b=60),
        paper_bgcolor="white",
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def create_holding_pie(data):
    fig = go.Figure()

    colors = ["#0d6efd", "#198754", "#dc3545", "#ffc107", "#17a2b8", "#6c757d"]

    asset_totals = {}
    for p in data["portfolios"]:
        for pos in p["positions"]:
            ac = pos.get("asset_class", "Unknown")
            asset_totals[ac] = asset_totals.get(ac, 0) + pos.get("market_value", 0)

    fig.add_trace(
        go.Pie(
            labels=list(asset_totals.keys()),
            values=list(asset_totals.values()),
            name="All Holdings",
            hole=0.4,
            marker=dict(colors=colors[: len(asset_totals)]),
            textinfo="label+percent",
            textposition="inside",
            textfont=dict(size=10),
        )
    )

    fig.update_layout(
        height=300,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.2),
        margin=dict(t=20, b=40),
        paper_bgcolor="white",
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})


fm_headers = ["FundManager", "AUM", "Portfolios", "Positions", "Total P&L"]
fm_rows = []
for fm in fm_stats:
    pnl_class = "text-success" if fm_stats[fm]["total_pnl"] >= 0 else "text-danger"
    fm_rows.append(
        [
            html.Strong(fm),
            format_currency(fm_stats[fm]["aum"]),
            len(fm_stats[fm]["portfolios"]),
            fm_stats[fm]["positions"],
            html.Span(format_currency(fm_stats[fm]["total_pnl"]), className=pnl_class),
        ]
    )

perf_headers = [
    "Portfolio",
    "FundManager",
    "Code UG",
    "Code OG",
    "Currency",
    "AUM",
    "YTD",
    "Max DD",
]
perf_rows = []
for p in data["portfolios"]:
    ytd_class = "text-success" if p["ytd_return"] > 0 else "text-danger"
    perf_rows.append(
        [
            p["name"],
            p["fundmanager"],
            p["code_ug"],
            p["code_og"],
            p.get("currency", "EUR"),
            format_currency(p["aum"]),
            html.Span(format_pct(p["ytd_return"]), className=ytd_class),
            html.Span(format_pct(p["max_dd"]), className="text-danger"),
        ]
    )

top_headers = ["Ticker", "Name", "FundManager", "Weight", "Market Value"]
top_rows = []
for p in data["portfolios"]:
    for pos in sorted(p["positions"], key=lambda x: x["weight"], reverse=True)[:5]:
        top_rows.append(
            [
                pos["ticker"],
                pos["name"],
                pos["fundmanager"],
                f"{pos['weight']:.2f}%",
                format_currency(pos["market_value"]),
            ]
        )
top_rows = top_rows[:10]


layout = html.Div(
    [
        html.H4("Overview - FundManager Dashboard", className="mb-3"),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader("Fund Managers", className="fw-bold"),
                                dbc.CardBody(
                                    [
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    [
                                                        html.Div(
                                                            [
                                                                html.H5(
                                                                    fm,
                                                                    style={
                                                                        "color": "#212529"
                                                                    },
                                                                ),
                                                                html.Small(
                                                                    f"{len(fm_stats[fm]['portfolios'])} portfolios",
                                                                    className="text-muted",
                                                                ),
                                                            ],
                                                            className="mb-3",
                                                        )
                                                    ]
                                                )
                                                for fm in fm_stats
                                            ]
                                        ),
                                        make_table(fm_headers, fm_rows),
                                    ]
                                ),
                            ]
                        )
                    ],
                    width=12,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Portfolio Performance", className="fw-bold"
                                ),
                                dbc.CardBody([make_table(perf_headers, perf_rows)]),
                            ]
                        )
                    ],
                    width=8,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Asset Class Distribution (All)",
                                    className="fw-bold",
                                ),
                                dbc.CardBody([create_holding_pie(data)]),
                            ]
                        )
                    ],
                    width=4,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader("Top Holdings", className="fw-bold"),
                                dbc.CardBody([make_table(top_headers, top_rows)]),
                            ]
                        )
                    ]
                )
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Pivot Table - ISIN Weights by Portfolio",
                                    className="fw-bold",
                                ),
                                dbc.CardBody(
                                    [
                                        html.Div(
                                            style={
                                                "maxHeight": "400px",
                                                "overflowY": "auto",
                                            },
                                            children=[create_pivot_table(data)],
                                        )
                                    ]
                                ),
                            ]
                        )
                    ]
                )
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Asset Class by Portfolio", className="fw-bold"
                                ),
                                dbc.CardBody([create_asset_class_pie(data)]),
                            ]
                        )
                    ]
                )
            ]
        ),
    ]
)


@callback(
    Output("download-overview-csv", "data"),
    Input("export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_csv(n_clicks):
    pivot_df = get_pivot_dataframe(data)
    if not pivot_df.empty:
        return dcc.send_data_frame(pivot_df.to_csv, "pivot_export.csv", index=False)


@callback(
    Output("download-overview-xlsx", "data"),
    Input("export-excel", "n_clicks"),
    prevent_initial_call=True,
)
def export_excel(n_clicks):
    pivot_df = get_pivot_dataframe(data)
    if not pivot_df.empty:
        output = BytesIO()
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            pivot_df.to_excel(writer, sheet_name="Pivot", index=False)
        output.seek(0)
        return dcc.send_bytes(output.getvalue(), "pivot_export.xlsx")
