"""Reusable components for Fund Manager app"""

from dash import html, dcc
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
from dash.dependencies import Input, Output
import pandas as pd


def format_currency(value, decimals=0):
    """Format number as currency"""
    if abs(value) >= 1_000_000_000:
        return f"${value / 1_000_000_000:.2f}B"
    elif abs(value) >= 1_000_000:
        return f"${value / 1_000_000:.1f}M"
    elif abs(value) >= 1_000:
        return f"${value / 1_000:.1f}K"
    return f"${value:,.0f}"


def format_pct(value, decimals=2):
    """Format number as percentage"""
    sign = "+" if value >= 0 else ""
    return f"{sign}{value:.2f}%"


def MetricCard(title, value, delta=None, delta_type="neutral", icon=None):
    """KPI metric card component"""
    delta_class = {
        "positive": "text-success",
        "negative": "text-danger",
        "neutral": "text-muted",
    }.get(delta_type, "text-muted")

    delta_arrow = ""
    if delta is not None:
        if delta_type == "positive":
            delta_arrow = "↑"
        elif delta_type == "negative":
            delta_arrow = "↓"

    return dbc.Card(
        [
            dbc.CardBody(
                [
                    html.Div(title, className="metric-title"),
                    html.Div(value, className="metric-value"),
                    html.Div(
                        [
                            html.Span(
                                f"{delta_arrow} {delta}" if delta else "",
                                className=f"metric-delta {delta_class}",
                            )
                        ],
                        className="metric-delta-container",
                    )
                    if delta
                    else None,
                ]
            )
        ],
        className="metric-card",
    )


def PortfolioCard(portfolio, clickable=True):
    """Portfolio summary card"""
    perf_class = "text-success" if portfolio["ytd_return"] >= 0 else "text-danger"
    perf_sign = "+" if portfolio["ytd_return"] >= 0 else ""

    card_content = [
        html.Div(
            [
                html.Div(portfolio["name"], className="portfolio-name"),
                html.Div(portfolio["type"], className="portfolio-type"),
            ],
            className="portfolio-header",
        ),
        html.Div(
            [
                html.Div(
                    [
                        html.Span("AUM", className="portfolio-label"),
                        html.Span(
                            format_currency(portfolio["aum"]),
                            className="portfolio-value",
                        ),
                    ],
                    className="portfolio-metric",
                ),
                html.Div(
                    [
                        html.Span("YTD", className="portfolio-label"),
                        html.Span(
                            f"{perf_sign}{portfolio['ytd_return']:.1f}%",
                            className=f"portfolio-value {perf_class}",
                        ),
                    ],
                    className="portfolio-metric",
                ),
            ],
            className="portfolio-metrics",
        ),
        dbc.Progress(
            value=min(100, abs(portfolio["ytd_return"]) * 5),
            color="success" if portfolio["ytd_return"] >= 0 else "danger",
            className="portfolio-progress",
        ),
    ]

    if clickable:
        return dbc.Card(
            dbc.CardBody(
                [
                    html.A(
                        card_content,
                        href=f"/portfolio/{portfolio['id']}",
                        style={"textDecoration": "none", "color": "inherit"},
                    )
                ],
                className="portfolio-card-body",
            ),
            className="portfolio-card",
            id=f"portfolio-card-{portfolio['id']}",
        )
    else:
        return dbc.Card(
            [
                dbc.CardBody(card_content),
            ],
            className="portfolio-card",
        )


def PerformanceChart(data, height=400):
    """Cumulative performance line chart"""
    if not data:
        return html.Div("No data available", className="text-muted")

    df = pd.DataFrame(data)
    df["date"] = pd.to_datetime(df["date"])

    fig = go.Figure()

    fig.add_trace(
        go.Scatter(
            x=df["date"],
            y=df["portfolio_value"],
            name="Portfolio",
            line=dict(color="#58a6ff", width=2),
            fill="tozeroy",
            fillcolor="rgba(88, 166, 255, 0.1)",
        )
    )

    fig.add_trace(
        go.Scatter(
            x=df["date"],
            y=df["benchmark_value"],
            name="Benchmark",
            line=dict(color="#8b949e", width=1.5, dash="dash"),
        )
    )

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=height,
        margin=dict(l=0, r=0, t=20, b=0),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1,
            font=dict(color="#c9d1d9"),
        ),
        xaxis=dict(showgrid=True, gridcolor="rgba(48, 54, 61, 0.5)", color="#8b949e"),
        yaxis=dict(
            showgrid=True,
            gridcolor="rgba(48, 54, 61, 0.5)",
            color="#8b949e",
            tickformat=".1f",
        ),
        hovermode="x unified",
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def AllocationDonut(data, title="Allocation"):
    """Donut chart for allocation"""
    if not data:
        return html.Div("No data available", className="text-muted")

    colors = px.colors.qualitative.Set3 + px.colors.qualitative.Pastel

    fig = go.Figure(
        data=[
            go.Pie(
                labels=[d["sector"] if "sector" in d else d["geography"] for d in data],
                values=[d["weight"] for d in data],
                hole=0.6,
                marker=dict(colors=colors),
                textinfo="percent",
                textfont=dict(color="#c9d1d9", size=11),
                hovertemplate="%{label}<br>%{percent}<br>%{value:.1f}%<extra></extra>",
            )
        ]
    )

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        height=300,
        margin=dict(l=0, r=0, t=10, b=0),
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.3,
            xanchor="center",
            x=0.5,
            font=dict(color="#8b949e", size=10),
        ),
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def PositionsTable(positions, max_rows=15):
    """Data table for positions"""
    if not positions:
        return html.Div("No positions", className="text-muted")

    df = pd.DataFrame(positions[:max_rows])

    return dbc.Table(
        [
            html.Thead(
                html.Tr(
                    [
                        html.Th("Ticker", className="table-header"),
                        html.Th("Name", className="table-header"),
                        html.Th("Sector", className="table-header"),
                        html.Th("Weight", className="table-header text-end"),
                        html.Th("Price", className="table-header text-end"),
                        html.Th("Value", className="table-header text-end"),
                        html.Th("P&L", className="table-header text-end"),
                        html.Th("P&L %", className="table-header text-end"),
                    ]
                )
            ),
            html.Tbody(
                [
                    html.Tr(
                        [
                            html.Td(html.Strong(row["ticker"]), className="fw-bold"),
                            html.Td(
                                row["name"][:25] + "..."
                                if len(row["name"]) > 25
                                else row["name"]
                            ),
                            html.Td(row["sector"]),
                            html.Td(f"{row['weight']:.2f}%", className="text-end"),
                            html.Td(
                                f"${row['current_price']:.2f}", className="text-end"
                            ),
                            html.Td(
                                format_currency(row["market_value"]),
                                className="text-end",
                            ),
                            html.Td(
                                f"{'+' if row['unrealized_pnl'] >= 0 else ''}{format_currency(row['unrealized_pnl'])}",
                                className=f"text-end {'text-success' if row['unrealized_pnl'] >= 0 else 'text-danger'}",
                            ),
                            html.Td(
                                f"{'+' if row['unrealized_pnl_pct'] >= 0 else ''}{row['unrealized_pnl_pct']:.2f}%",
                                className=f"text-end {'text-success' if row['unrealized_pnl_pct'] >= 0 else 'text-danger'}",
                            ),
                        ]
                    )
                    for row in df.to_dict("records")
                ]
            ),
        ],
        bordered=False,
        hover=True,
        responsive=True,
        className="positions-table",
    )


def TransactionsTable(transactions, max_rows=10):
    """Transactions history table"""
    if not transactions:
        return html.Div("No transactions", className="text-muted")

    df = pd.DataFrame(transactions[:max_rows])

    return dbc.Table(
        [
            html.Thead(
                html.Tr(
                    [
                        html.Th("Date", className="table-header"),
                        html.Th("Ticker", className="table-header"),
                        html.Th("Type", className="table-header"),
                        html.Th("Shares", className="table-header text-end"),
                        html.Th("Price", className="table-header text-end"),
                        html.Th("Amount", className="table-header text-end"),
                    ]
                )
            ),
            html.Tbody(
                [
                    html.Tr(
                        [
                            html.Td(row["date"]),
                            html.Td(html.Strong(row["ticker"]), className="fw-bold"),
                            html.Td(
                                row["type"],
                                className=f"{'text-success' if row['type'] == 'BUY' else 'text-danger'} fw-bold",
                            ),
                            html.Td(f"{row['shares']:,}", className="text-end"),
                            html.Td(f"${row['price']:.2f}", className="text-end"),
                            html.Td(
                                format_currency(row["amount"]), className="text-end"
                            ),
                        ]
                    )
                    for row in df.to_dict("records")
                ]
            ),
        ],
        bordered=False,
        hover=True,
        responsive=True,
        className="transactions-table",
    )


def Sidebar():
    """Application sidebar"""
    return dbc.Navbar(
        [
            dbc.Container(
                [
                    html.Div(
                        [
                            html.Div("FM", className="logo-icon"),
                            html.Div("FundManager", className="logo-text"),
                        ],
                        className="logo",
                    ),
                    html.Hr(className="sidebar-divider"),
                    dbc.Nav(
                        [
                            dbc.NavLink(
                                [html.I(className="fas fa-chart-pie me-2"), "Overview"],
                                href="/",
                                active="exact",
                                className="nav-link-custom",
                            ),
                            dbc.NavLink(
                                [
                                    html.I(className="fas fa-briefcase me-2"),
                                    "Portfolios",
                                ],
                                href="/portfolios",
                                active="exact",
                                className="nav-link-custom",
                            ),
                            dbc.NavLink(
                                [
                                    html.I(className="fas fa-chart-line me-2"),
                                    "Analytics",
                                ],
                                href="/analytics",
                                active="exact",
                                className="nav-link-custom",
                            ),
                        ],
                        vertical=True,
                        pills=True,
                        className="sidebar-nav",
                    ),
                ],
                fluid=True,
            )
        ],
        color="dark",
        dark=True,
        className="sidebar",
    )


def Header(title):
    """Page header"""
    return dbc.Navbar(
        [
            dbc.Container(
                [
                    html.H4(title, className="header-title mb-0"),
                    html.Div(
                        [
                            dcc.DatePickerRange(
                                id="date-range",
                                start_date="2024-01-01",
                                end_date="2025-04-08",
                                className="date-picker-custom",
                            ),
                            html.Button(
                                [html.I(className="fas fa-download me-1"), "Export"],
                                className="btn btn-outline-secondary btn-sm ms-2",
                            ),
                        ],
                        className="header-actions",
                    ),
                ],
                fluid=True,
            )
        ],
        color="dark",
        dark=True,
        className="page-header",
    )


def RiskMetricsCard(metrics):
    """Risk metrics summary card"""
    return dbc.Card(
        [
            dbc.CardHeader("Risk Metrics", className="card-header-custom"),
            dbc.CardBody(
                [
                    dbc.Row(
                        [
                            dbc.Col(
                                [
                                    html.Div("Volatility", className="risk-label"),
                                    html.Div(
                                        f"{metrics.get('volatility', 0):.2f}%",
                                        className="risk-value",
                                    ),
                                ],
                                width=3,
                            ),
                            dbc.Col(
                                [
                                    html.Div("Max Drawdown", className="risk-label"),
                                    html.Div(
                                        f"{metrics.get('max_drawdown', 0):.2f}%",
                                        className="risk-value text-danger",
                                    ),
                                ],
                                width=3,
                            ),
                            dbc.Col(
                                [
                                    html.Div("VaR (95%)", className="risk-label"),
                                    html.Div(
                                        f"{metrics.get('var', 0):.2f}%",
                                        className="risk-value",
                                    ),
                                ],
                                width=3,
                            ),
                            dbc.Col(
                                [
                                    html.Div("Sharpe Ratio", className="risk-label"),
                                    html.Div(
                                        f"{metrics.get('sharpe', 0):.2f}",
                                        className="risk-value",
                                    ),
                                ],
                                width=3,
                            ),
                        ]
                    )
                ]
            ),
        ],
        className="risk-card",
    )
