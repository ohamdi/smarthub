"""Point d'entrée de compatibilité pour l'application FastAPI SmartWealthReporting.

Lancement possible par::

    uvicorn smartwealthreporting.main:app --host 0.0.0.0 --port 5050
    python app.py
"""

from __future__ import annotations

import os

import uvicorn

from smartwealthreporting.main import app

__all__ = ["app"]


if __name__ == "__main__":
    uvicorn.run(
        app,
        host=os.getenv("SWR_HOST", "0.0.0.0"),
        port=int(os.getenv("SWR_PORT", "5050")),
    )
