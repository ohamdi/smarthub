# SmartWealthReporting — Documentation technique

> SmartWealthReporting : application web de **reporting Private Wealth Management** piloté par IA locale.
> Le serveur calcule tous les chiffres, le modèle local (GGUF) rédige uniquement les commentaires,
> et le PPTX est rendu depuis un template professionnel remplaçable.

- **Stack** : Python 3 + **FastAPI** + pydantic + Pandas (backend), HTML/CSS/JS monofichier + Bootstrap 5 (frontend)
- **Stockage** : fichiers **Parquet / CSV / Excel / JSON** (pas de base de données)
- **Rendu** : **python-pptx** à partir d'un `template.pptx` à zones nommées
- **Entrée ASGI** : `smartwealthreporting.main:app` (`app.py` reste un lanceur de compatibilité)
- **Langue du code** : en anglais (identifiants, docstrings), commentaires métier et interface en français ; cette doc est en français

> **Règle fondatrice du produit** : *aucun chiffre ne vient du modèle*. Tout ce qui apparaît
> dans une slide est calculé par `metrics.py` à partir des datasets. Le modèle ne produit
> que du texte, dont chaque montant cité est vérifié contre les faits réellement envoyés.

### Démarrage

```bash
cd ~/Documents/SmartWealthReporting
python -m venv --system-site-packages .venv            # optionnel
.venv/bin/pip install -r requirements-dev.txt         # application + tests
.venv/bin/pip install -r requirements-llm.txt         # optionnel : GGUF (llama-cpp-python)
.venv/bin/python app.py                                # http://0.0.0.0:5050
# ou : .venv/bin/uvicorn smartwealthreporting.main:app --reload --port 5050
# ou : .venv/bin/python -m smartwealthreporting --port 5050
```

La documentation interactive de l'API est sur `/docs`, le schéma OpenAPI sur `/openapi.json`.
Comptes de démonstration : `admin/admin123`, `conseiller/conseiller123`, `rm.lille/lille2026`
(les deux derniers sont restreints au portfolio du conseiller).

### Configuration d'exécution

- `SWR_SECRET_KEY` : secret de signature des sessions ; **à définir en production**.
- `SWR_SESSION_MAX_AGE` : durée de session en secondes (28800 par défaut).
- `SWR_COOKIE_SECURE=true` : cookies uniquement en HTTPS.
- `SWR_AUTO_START_LLAMAFILE=false` : désactiver le démarrage automatique du serveur Llamafile.
- `SWR_BASE_DIR` et `SWR_CONFIG_PATH` : racine du projet et fichier `datasource_config.json`.
- `SWR_HOST`, `SWR_PORT` (5050), `SWR_LOG_LEVEL` : écoute et journalisation du serveur.

---

## 1. Analyse de l'application

### 1.1 Architecture globale

```
SmartWealthReporting/
├── app.py                       # Lanceur de compatibilité (uvicorn)
├── __main__.py                  # python -m smartwealthreporting → CLI
├── smartwealthreporting/        # Package ASGI FastAPI
│   ├── config.py                # Settings (env SWR_*) + DataSourceConfig (datasource_config.json)
│   ├── ai_config.py             # ai_config.json : réglages de génération et bornes
│   ├── storage.py               # Lecture/écriture Parquet, CSV, Excel, JSON (atomique)
│   ├── auth.py                  # Session + dataset `users`, Principal (client_id restreint)
│   ├── metrics.py               # FAITS : KPI, allocations, performance, ESG, flux, risques
│   ├── context.py               # Rendu texte des faits envoyés au modèle (format français)
│   ├── verify.py                # Garde-fou numérique : tout montant cité existe-t-il ?
│   ├── narrative.py             # Extraction du JSON des réponses du modèle + nettoyage
│   ├── prompting.py             # prompt.md + contrat de format + règles de prudence
│   ├── llm.py                   # Service IA paresseux (GGUF llama.cpp / Llamafile)
│   ├── templates.py             # Template PPTX par défaut, zones nommées, palette
│   ├── pptx_builder.py          # Rendu du deck : duplication des slides modèles, remplissage
│   ├── reportings.py            # Bibliothèque des reportings (dossiers reportings/<id>/)
│   ├── schemas.py               # Modèles pydantic (definition.json + payloads API)
│   ├── services.py              # Orchestration : périmètre → faits → narration → PPTX
│   ├── routes.py                # Endpoints /api/*
│   ├── main.py                  # create_app(), lifespan, gestion des erreurs, /health
│   └── cli.py                   # Serveur + --check / --init-templates / --generate
├── datasource_config.json       # Chemins des datasets + moteur IA
├── ai_config.json               # n_ctx, temperature, max_slides_per_call…
├── data/                        # clients, portfolios, holdings, performance, transactions,
│                                # users, esg_ratings (xlsx), benchmark_curves (csv)
├── reportings/<id>/             # definition.json + prompt.md + template.pptx
├── outputs/<id>/                # .pptx générés + sidecar .json
├── scripts/seed_data.py         # Génère le jeu de démonstration
├── scripts/check_overlap.py     # Détecte les zones superposées d'un PPTX rendu
├── static/index.html            # TOUT le frontend
└── tests/                       # 368 tests pytest (jamais sur data/ du projet)
```

> Aucun journal n'est écrit sur le disque : la sortie va sur la sortie standard du processus.
> Les tests travaillent tous dans un `tmp_path` : `data/` et `reportings/` du projet ne sont
> jamais touchés par la suite de tests.

**Modèle d'exécution d'une génération** :

```
navigateur ──POST /api/reportings/<id>/generate──► routes.py
                                                       │
                                     services.generate()│
             ┌─────────────────────────────────────────┴──────────────────────────────────┐
             ▼                     ▼                        ▼                    ▼
   metrics.build(scope)      context.render()      prompting + llm.chat()    pptx_builder.render()
     (les chiffres)          (le texte des faits)    (la narration JSON)      (le .pptx)
             └─────────────────────────► verify.check() ◄──────────────────────┘
                                       (chiffres cités ∈ faits ?)
                                                       │
                                                       ▼
                                       outputs/<id>/<fichier>.pptx + .json
```

### 1.2 Fonctionnalités

| Onglet | Fonctionnalité | État |
|---|---|---|
| Reportings | Liste des reportings, édition `definition.json` (slides, KPI, graphiques, tableaux, charte), éditeur `prompt.md`, aperçu du contexte envoyé au modèle, téléchargement/installation du template, génération et téléchargement du deck | ✅ fonctionnel |
| Données | État des datasets (lignes, colonnes, poids), aperçu des premières lignes, édition des chemins, remise à zéro, liste des modèles `.gguf` détectés | ✅ fonctionnel |
| Générations | Historique relu depuis les sidecars JSON, téléchargement, sources de chaque commentaire (`ia` / `vide` / `desactivee` / `erreur`), avertissements de vérification | ✅ fonctionnel |
| Moteur IA | État du moteur, réglages `ai_config.json` (bornés), warmup, retouche assistée d'un commentaire (`/api/ai/chat`) | ✅ GGUF / Llamafile ; Llamafile optionnel |
| Utilisateurs | CRUD utilisateurs (visible uniquement pour un `admin`), avec rattachement facultatif à un `client_id` | ✅ fonctionnel |

### 1.3 Backend — endpoints API (`smartwealthreporting/routes.py`)

| Méthode | Route | Rôle | Auth |
|---|---|---|---|
| POST | `/api/login` | Authentification (crée la session) | non |
| POST | `/api/logout` | Vide la session | non |
| GET | `/api/me` | Identité et périmètre de l'utilisateur connecté | oui |
| GET/POST | `/api/users` | Liste / création d'un utilisateur | oui |
| PUT/DELETE | `/api/users/<username>` | Modification / suppression | oui |
| GET | `/api/datasets` | État de chaque dataset (existe, lignes, colonnes, poids) | oui |
| POST | `/api/datasets/preview` | Aperçu des premières lignes d'un dataset | oui |
| GET | `/api/clients` | Clients visibles par l'utilisateur, avec actif calculé | oui |
| GET/POST | `/api/reportings` | Liste / création d'un reporting (crée aussi son template) | oui |
| GET/PUT/DELETE | `/api/reportings/<id>` | Détail / écriture de `definition.json` / suppression | oui |
| PUT | `/api/reportings/<id>/prompt` | Écriture de `prompt.md` | oui |
| GET | `/api/reportings/<id>/template.pptx` | Téléchargement du template (généré à la volée si absent) | oui |
| POST | `/api/reportings/<id>/template/install` | (Ré)écrit un template PWM par défaut | oui |
| GET | `/api/reportings/<id>/context` | Contexte **exactement** envoyé au modèle (faits + prompt système) | oui |
| POST | `/api/reportings/<id>/context` | Idem avec un corps `GenerateRequest` | oui |
| POST | `/api/reportings/<id>/generate` | Génération complète : narration + PPTX + sidecar JSON | oui |
| GET | `/api/runs` | Historique (`?reporting_id=`, `?limit=`) | oui |
| GET | `/api/runs/<reporting_id>/<filename>` | Téléchargement d'un deck généré | oui |
| GET | `/api/ai/status` | État du moteur + modèles détectés + réglages effectifs | oui |
| GET/POST | `/api/ai/config` | Lire / écrire `ai_config.json` (valeurs hors bornes ignorées) | oui |
| POST | `/api/ai/warmup` | Précharge le modèle avant la première génération | oui |
| POST | `/api/ai/chat` | Retouche assistée d'un commentaire (texte seul, chiffres vérifiés) | oui |
| GET | `/api/config/datasource` | Chemins des datasets + réglages du moteur IA | oui |
| POST | `/api/config/datasource` | Écriture de `datasource_config.json` | oui |
| POST | `/api/config/datasets/<name>/reset` | Rétablit le chemin par défaut d'un dataset | oui |
| GET | `/health` | Statut, version, nombre de datasets et de reportings | non |
| GET | `/api/inexistant` | **404** : toute route `/api/*` inconnue reste un 404 | non |
| GET | `/<chemin>` | SPA : `index.html` pour toute route inconnue hors `/api/` | non |

Codes d'erreur : `401` (session), `403` (client non attribué), `404` (inconnu), `422`
(définition/payload invalide, template illisible), `500` (erreur d'exécution),
`503` (moteur IA indisponible). Le corps est toujours `{"error": "..."}`.

### 1.4 Frontend (`static/index.html`)

Tout est dans un seul fichier : `state` global, helper `api()`, `fmt()`/`esc()`,
et une fonction de rendu par onglet (`renderReportingsTab`, `loadDatasets`, `loadRuns`,
`renderIaTab`, `loadUsers`). Panneaux : `#tab-reportings`, `#tab-donnees`, `#tab-generations`,
`#tab-ia`, `#tab-utilisateurs`.

Points clés avant modification :
- `switchTab(tab)` pilote l'affichage ; l'onglet Utilisateurs n'est visible que pour un `admin`.
- La génération appelle `POST /api/reportings/<id>/generate` puis affiche, par slide, la source
  du commentaire et le résultat de la vérification numérique.
- Le contexte envoyé au modèle est affiché tel quel (bouton « contexte »), pas reconstruit.
- Aucune dépendance CDN n'est nécessaire hors Bootstrap/Icons ; sans réseau, l'application reste
  fonctionnelle pour les données et la génération.

---

## 2. Sources de données — champs par source

Chemins par défaut dans `datasource_config.json` ; le format est **déduit de l'extension**
(`.parquet`, `.csv`, `.xlsx`/`.xlsm`, `.json`). Une même table peut donc être livrée par un
système amont en Parquet puis exportée en CSV sans changer une ligne de code.

| Dataset | Format du projet | Clé de périmètre | Colonnes lues par l'application |
|---|---|---|---|
| `clients` | Parquet | `client_id` | `client_id`, `client_name`, `segment`, `domicile`, `relationship_manager`, `base_ccy`, `risk_profile`, `objectives` |
| `portfolios` | Parquet | `client_id` / `portfolio_id` | `portfolio_id`, `client_id`, `portfolio_name`, `mandate_type`, `strategy`, `base_ccy`, `aum`, `inception_date`, `management_fee_pct`, `risk_level` |
| `holdings` | Parquet | `client_id` / `portfolio_id` | `as_of`, `isin`, `instrument_name`, `asset_class`, `category`, `sector`, `country`, `currency`, `rating`, `quantity`, `price`, `market_value`, `cost_basis`, `pnl_unrealised`, `coupon`, `yield`, `cash_value`, `esg_score`, `esg_e`, `esg_s`, `esg_g`, `currency_hedge`, `issuer`, `maturity`, `mod_duration` |
| `performance` | Parquet | `client_id` ou `portfolio_id` | `date`, `portfolio_cum`, `benchmark_cum`, `aum`, `volatility`, `sharpe`, `max_drawdown`, `period_label` |
| `transactions` | Parquet | `client_id` / `portfolio_id` | `trade_date`, `transaction_type` (`BUY`, `SELL`, `DIVIDEND`, `INTEREST`, `FEE`, `SUBSCRIPTION`, `WITHDRAWAL`…), `instrument_name`, `isin`, `quantity`, `price`, `amount`, `fees`, `realised_pnl`, `income`, `comment` |
| `users` | JSON | — | `username`, `password`, `role` (`admin`/`user`), `client_id` (périmètre restreint) |
| `esg_ratings` | Excel | `asset_class`+`sector` | barème de référence du fournisseur (non utilisé pour le score client) |
| `benchmark_curves` | CSV | `mandate_type` | courbes de référence par type de mandat |

Règles de tolérance :
- Une table **sans `client_id`** est résolue via `portfolios` : le périmètre client est converti
  en liste de `portfolio_id` (indispensable pour `performance` ou `holdings` indexés par mandat).
- Les positions sont retenues à la **dernière date d'arrêté** disponible (`as_of` max).
- Les colonnes sont reconnues par leur nom ; les colonnes absentes font disparaître le bloc
  correspondant (pas d'erreur, les KPIs indisponibles valent simplement `None`).
- **Colonnes obligataires** (`holdings`) : `issuer` est la seule qui décide de l'appartenance
  au bloc obligataire — une ligne sans émetteur est une action, un fonds ou du monétaire.
  `maturity` (date d'échéance) et `mod_duration` (duration modifiée) n'alimentent que la vie
  moyenne, la sensibilité et le profil de maturité ; `coupon` et `yield` le TRA et les coupons.
  Une ligne dont l'échéance est dépassée à la date d'arrêté quitte le profil de risque, sans
  disparaître du tableau des positions.
- Un fichier illisible est signalé (`exists: false`, `MANQUANT` dans `--check`) sans faire échouer
  l'application ; un CSV illisible est journalisé et renvoyé vide.

### 2.1 `datasource_config.json` — chemins et moteur IA

| Clé | Rôle |
|---|---|
| `clients`, `portfolios`, `holdings`, `performance`, `transactions`, `users` | Chemins des datasets PWM (défauts dans `config.DEFAULT_DATASETS`) |
| `esg_ratings`, `benchmark_curves`, … | Datasets additionnels : toute clé chaîne inconnue devient un dataset lisible |
| `llm_backend` | `gguf` (llama.cpp local) ou `llamafile` (serveur HTTP) |
| `gguf_path` | Chemin du modèle GGUF (absolu, `~` ou relatif à la base) |
| `llamafile_path`, `llamafile_port`, `llamafile_url` | Serveur Llamafile optionnel |

Écriture atomique (fichier temporaire + `os.replace`) ; lecture tolérante (fichier absent ou
corrompu ⇒ défauts).

### 2.2 `ai_config.json` — paramètres de génération

| Clé | Défaut | Borne | Rôle |
|---|---|---|---|
| `n_ctx` | 8192 | 2048–131072 | Contexte du modèle (incompatible en charge : son changement libère le modèle) |
| `n_threads` | 0 (tous cœurs) | 0–256 | Threads de génération |
| `n_batch` | 2048 | 32–8192 | Taille de batch |
| `temperature` | 0.3 | — | Température (surchargée par `ai.temperature` d'une définition) |
| `max_tokens` | 700 | 16–8192 | Tokens max par réponse |
| `top_p`, `repeat_penalty` | 0.9 / 1.1 | — | Échantillonnage |
| `max_context_chars` | 24000 | 2000–200000 | Plafond du bloc de faits avant troncature |
| `narrative_min_chars` | 60 | 0–1000 | Longueur minimale d'un commentaire (réponse tronquée) |
| `narrative_max_chars` | 700 | 100–4000 | Longueur maximale d'un commentaire |
| `max_slides_per_call` | 3 | 1–12 | Slides narratives par appel au modèle |
| `retries` | 1 | 0–5 | Nouvelle tentative quand une réponse est incomplète |

Une valeur hors bornes **n'est pas écrite** : la configuration reste utilisable au lieu de
casser le chargement du modèle au démarrage suivant.

### 2.3 Constantes métier hardcodées

| Constante | Fichier | Valeur | Rôle |
|---|---|---|---|
| `ALLOCATION_SLICES` | `metrics.py` | 12 | Au-delà, les petites catégories sont repliées dans « Autres » |
| `RISK_FREE_RATE` | `metrics.py` | 2 % | Taux sans risque du ratio de Sharpe recalculé (`_curve_sharpe`) ; le générateur du jeu de démonstration en use la même valeur |
| `RATING_SCALE`, `INVESTMENT_GRADE_MAX_RANK` | `metrics.py` | 22 grades, 10 | Échelle de notation ; BBB- (rang 10) est le plancher de l'investment grade |
| `MATURITY_BUCKETS` | `metrics.py` | 6 tranches | Profil de maturité du portefeuille obligataire |
| `RATING_CORRESPONDENCE` | `metrics.py` | 22 lignes | Correspondance S&P / Moody's / Fitch pour l'annexe pédagogique |
| `TOTAL_PREFIXES` | `pptx_builder.py` | `total` | Libellés qui font passer une ligne de tableau en gras |
| `PANEL_AREA`, `PANEL_GAP` | `pptx_builder.py` | grille 2×2 | Géométrie des petits multiples |
| `CONCENTRATION_WARN` / `CONCENTRATION_ALERT` | `metrics.py` | 25 % / 35 % | Seuils des points de vigilance sur le poids d'une position |
| `CASH_DRAG_WARN` | `metrics.py` | 10 % | Seuil d'alerte sur la trésorerie |
| `MONTHS_FR` / `MONTHS_FR_SHORT` | `metrics.py` | 12 mois | Libellés de période (« Septembre 2026 », « sept. 26 ») |
| `SECTION_TITLES`, `KPI_LABELS`, `ALLOCATION_LABELS`, `FACT_LABELS` | `context.py` | — | Libellés français du contexte envoyé au modèle |
| `THIN_SPACE` | `context.py` | U+202F | Séparateur de milliers français (posé explicitement) |
| `SIGNIFICANT_THRESHOLD` | `verify.py` | 1000 | En dessous, un entier (« 3 positions ») n'est pas contrôlé |
| `DEFAULT_LAYOUTS`, `SLIDE_WIDTH_IN`, `DEFAULT_ZONES` | `templates.py` | 8 layouts, 13,333 × 7,5 po | Gabarit du template par défaut et géométrie de repli |
| `RUN_HISTORY_LIMIT` | `services.py` | 50 | Générations conservées en mémoire |
| `DEFAULT_USERS` | `auth.py` | admin/conseiller | Comptes utilisés si `users` est absent ou vide |

---

## 3. Flux de données & références croisées

```
clients ──client_id──► portfolios ──portfolio_id──► holdings ──► KPI, allocations, P&L, ESG, concentration
                            │                            │                └──► facts["bonds"] : lignes dont
                            │                            │                     `issuer` est renseigné
                            │                            │                     (TRA, durée, notation,
                            │                            │                      échéances, émetteurs)
                            │                            │
                            └──portfolio_id──► performance ──► courbe, benchmark, volatilité, Sharpe
                                         └──► transactions ──► flux, activité, P&L réalisé, frais, coupons
users ──client_id──► périmètre (restriction d'accès)
```

- Le **périmètre** (`ReportScope`) est verrouillé sur l'utilisateur connecté : un `user` avec
  `client_id` ne peut ni voir (`GET /api/clients`) ni générer pour un autre client — le serveur
  répond `403` avant tout calcul.
- Les **faits** sont produits par `metrics.MetricsEngine.build(scope)` : même périmètre + mêmes
  données ⇒ chiffres identiques (garantie de reproductibilité des tests et des re-runs).
- Le **contexte** (`context.render`) est une projection texte de ces faits, sectionnable et
  tronqué ; c'est la seule chose que le modèle reçoit.
- Le **garde-fou** (`verify.build_registry` puis `verify.check`) indexe tous les nombres du
  contexte et signale ceux que la narration cite sans correspondre.
- La **sortie** est un `.pptx` accompagné d'un sidecar `.json` (résumé de la génération,
  avertissements, source de chaque commentaire) qui reconstruit l'historique après redémarrage.

---

## 4. Guide de modification / ajout

### 4.1 Lancer l'application et les outils

```bash
.venv/bin/python app.py                                   # serveur
.venv/bin/python -m smartwealthreporting --list-reportings # inventaire
.venv/bin/python -m smartwealthreporting --check           # diagnostic (code 1 si un point bloque)
.venv/bin/python -m smartwealthreporting --init-templates  # crée les templates manquants
.venv/bin/python -m smartwealthreporting --generate monthly_client_review --client C001 --no-ai
.venv/bin/python -m pytest tests/ -q                       # 368 tests
```

### 4.2 Ajouter ou remplacer une donnée (sans code)

1. Déposer le fichier dans `data/` (Parquet, CSV, Excel ou JSON).
2. Onglet **Données** (ou `POST /api/config/datasource`) pour pointer le chemin ; le cache du
   dépôt est invalidé immédiatement, aucun redémarrage n'est nécessaire.
3. Vérifier avec `--check` : le dataset doit apparaître `ok` avec son nombre de lignes et de colonnes.

### 4.3 Ajouter un reporting (sans code)

1. Créer `reportings/<id>/` (identifiant en `a-z`, `0-9`, `-`, `_`).
2. Écrire `definition.json` (schéma §4.4) et `prompt.md`.
3. `POST /api/reportings/<id>/template/install` ou `--init-templates` pour le template par défaut.
4. Le reporting apparaît immédiatement dans l'interface (découverte à la volée, aucun cache).

> `--init-templates` **n'écrit que les templates absents** : pour reprendre une charte
> modifiée dans le code, supprimer d'abord `reportings/*/template.pptx`.

Les trois reportings livrés servent de référence :

| Reporting | Structure | Ce qu'il montre |
|---|---|---|
| `monthly_client_review` | 9 slides | le rendu standard : KPI, performance, allocation, positions, activité |
| `quarterly_esg_review` | 7 slides | un cas métier particulier, avec seuil de couverture ESG |
| `rapport_gestion` | 14 slides | la charte de banque privée : couverture, avertissement méthodologique, performance, méthode TWR, KPI obligataires, typologies, positions, totaux, émetteurs, répartitions analytiques en petits multiples, coupons, annexe de notation, définitions, avertissement final |

### 4.4 `definition.json` — le contrat d'un reporting

```jsonc
{
  "id": "mensuel",                     // forcé par le nom du dossier
  "name": "Revue mensuelle", "language": "fr", "audience": "client",
  "period": { "type": "ytd", "label": "" },          // month | quarter | year | ytd
  "default_client_id": "C001",
  "brand": { "primary": "16324F", "accent": "2E5C8A", "ink": "2B2B2B",
             "neutral": "6B7280", "rule": "D9DEE7", "surface": "F7F9FC",
             "positive": "4E8F75", "negative": "B85C5C",
             "font_title": "Arial", "font_body": "Arial",
             "house": "SDG GESTION", "legal_entity": "CA Indosuez Gestion",
             "tagline": "Architects of Wealth",
             "confidentiality": "Personnel et confidentiel",
             "report_label": "Rapport de gestion" },
  "context": { "sections": ["kpis", "esg"], "detail": "standard" },
  "ai": { "required": false, "temperature": 0.3, "max_tokens": 700 },
  "disclaimer": "Document établi au {as_of}…",      // le modèle ne l'écrit jamais
  "slides": [ /* ci-dessous */ ]
}
```

**Slide** (`schemas.SlideDefinition`) :

| Champ | Valeurs | Rôle |
|---|---|---|
| `id` | `^[a-z0-9_-]+$`, unique | Clé de la narration et de la vérification |
| `layout` | `cover`, `section`, `kpis`, `chart`, `table`, `narrative`, `text`, `disclaimer` | Gabarit du template |
| `title`, `subtitle`, `text`, `footer` | texte, placeholders `{{…}}` autorisés | Titres et textes fixes |
| `narrative` | booléen | `true` ⇒ le modèle rédige un commentaire pour cette slide |
| `focus`, `min_words`, `max_words` | texte, 0–400, 5–600 | Consigne donnée au modèle pour cette slide |
| `kpis` | `{key, label, format, decimals, suffix}` | Cases d'indicateurs (`format` : `currency`, `percent`, `share`, `number`, `text`) |
| `chart` | `{kind, source, dimension, measure, series, limit, show_values, show_legend}` | Graphique natif PowerPoint |
| `panels` | liste de `chart` | Petits multiples : 2 à 4 graphiques en grille 2×2 sur une slide |
| `table` | `{source, columns, limit, dimension}` | Tableau |

`percent` signe les valeurs positives (`+4,80 %`) : il est réservé aux **variations**
(performance, écart, plus-value). Un **poids** ou un **taux** se déclare en `share`
(`34,18 %`), sans signe — « +34,18 % de l'actif » se lit mal.

- `chart.source` ∈ `allocation`, `performance`, `top_holdings`, `pnl`, `bond_maturities`,
  `bond_ratings`, `bond_issuers`, `bond_categories`, `bond_sectors`, `bond_countries` ;
  `chart.kind` ∈ `doughnut`, `pie`, `bar`, `barh`, `column`, `stacked_bar`, `stacked_area`,
  `line`, `area` ; `chart.dimension` ∈ `asset_class`, `sector`, `country`, `currency`,
  `category`.
  `barh` inverse l'axe des catégories : la plus grande valeur est en haut.
  Les six sources `bond_*` sont des répartitions en % de l'encours obligataire.
- `table.source` ∈ `top_holdings`, `portfolios`, `risks`, `allocations`, `flows`, `esg`,
  `activity`, `pnl`, `bond_positions`, `bond_totals`, `bond_maturities`, `bond_ratings`,
  `bond_issuers`, `coupons`, `rating_scale`.
- Une ligne de tableau est mise en gras quand elle porte `"total": true` ou quand son
  libellé commence par `total` (`pptx_builder._is_total_row`) : c'est ainsi que les lignes
  de clôture du tableau obligataire se distinguent.
- `kpi.key` accepte une clé plate (`aum_total`, `score`) ou un chemin (`esg.score`,
  `concentration.top5_pct`) : `pptx_builder.resolve_metric()` cherche d'abord dans
  `facts["kpis"]`, puis dans chaque bloc.

Placeholders disponibles dans les titres et textes :
`{{client_name}}`, `{{client_id}}`, `{{segment}}`, `{{domicile}}`, `{{risk_profile}}`,
`{{relationship_manager}}`, `{{portfolio_id}}`, `{{portfolio_name}}`, `{{mandate_type}}`,
`{{strategy}}`, `{{inception_date}}`, `{{period_label}}`, `{{as_of}}`, `{{as_of_fr}}`,
`{{currency}}`, `{{report_name}}`, `{{audience}}`, `{{aum}}`, `{{performance}}`, `{{year}}`,
`{{generated_at}}`.
Un placeholder inconnu est laissé tel quel plutôt que remplacé par une chaîne vide.

**Identité de marque** (`BrandSpec`) — les cinq derniers champs ne pilotent pas une couleur
mais l'identité affichée : `house` et `tagline` composent le rappel de marque en haut des
slides de contenu (`templates.brand_mark`), `legal_entity`, `report_label` et
`confidentiality` composent le bandeau de pied fixe (`pptx_builder.footer_band`), qui
remplace le nom du client. Sans eux, le bandeau retombe sur `definition_footer(facts)`.

### 4.5 Le template PPTX — contrat de zones

Le rendu duplique la slide modèle correspondant au `layout` de chaque slide, puis remplit les
formes **nommées** :

| Zone | Contenu |
|---|---|
| `SWR_LAYOUT` | Marqueur d'une slide modèle (jamais livrée au client) |
| `SWR_TITLE`, `SWR_SUBTITLE`, `SWR_META` | Titre, sous-titre, bandeau d'identité (couverture) |
| `SWR_KPI_1` … `SWR_KPI_4` (et au-delà) | Cases d'indicateurs, remplies avec valeur + libellé |
| `SWR_CHART` | Zone du graphique natif ; `SWR_TABLE` zone du tableau |
| `SWR_TEXT` | Commentaire IA ou texte fixe |
| `SWR_SOURCE`, `SWR_FOOTER`, `SWR_PAGE` | Mention de source, pied de page, numéro de page |

- Un template **sans** slide `SWR_LAYOUT` (marqué avec un fichier vierge ou une charte
  maison) reste utilisable : le rendu bascule sur le gabarit par défaut et journalise
  « Template without SWR_LAYOUT slides ».
- Une zone absente est positionnée par la géométrie de repli `templates.DEFAULT_ZONES`.
- Un template illisible est une erreur explicite (`422`, `TemplateError`) — pas un deck vide.
- Remplacer la charte de la maison = remplacer le `template.pptx` du dossier, rien d'autre.

**Zones de texte par composition** — la position de `SWR_TEXT` dépend de ce que porte
la slide, sinon la narration recouvrirait les cartes ou la mention de source :

| Clé de `DEFAULT_ZONES` | Position (haut → bas) | Utilisée par |
|---|---|---|
| `text_wide` | 1.75 → 6.65 | slide « text » sans indicateur |
| `text_below_kpis` | 3.45 → 6.50 | slide « kpis », 1 à 4 indicateurs |
| `text_below_kpi_second_row` | 5.20 → 6.52 | slide « kpis », 5 à 8 indicateurs |
| `text_below_table` | 6.14 → 6.58 | slide « table » |
| — (`_stacked_zones`) | 3.42 → 6.62 | indicateurs posés sur une autre slide |

Le nombre de colonnes du bandeau est `templates.KPI_COLUMNS` (4) : au-delà, les cartes
passent à la seconde rangée et `pptx_builder._kpi_layout_zones` repousse la zone texte.
Les petits multiples (`panels`) sortent de cette composition : la grille 2×2 occupe la zone
utile, les zones `SWR_CHART` et `SWR_TEXT` du template sont supprimées, et une note de
lecture (`text` ou narration) est posée sous la grille en la raccourcissant.

**Charter notes** — la charte par défaut est celle d'un rapport de gestion de banque privée :
fond blanc, filets fins gris (`palette.rule`), en-têtes de tableau clairs et non colorés,
titres en bleu `16324F` sur fond blanc, jamais de serif. Deux zones en dépendent :
`title_with_brand` (le titre s'arrête avant le rappel de marque) et `cover_title`
(le titre de couverture descend au tiers inférieur pour laisser la marque au-dessus).
`tests/test_pptx.py` vérifie qu'aucune slide ne superpose deux zones de contenu.

### 4.6 Ajouter une source de tableau ou de graphique

1. **Tableau** : ajouter la source dans `pptx_builder._table_rows` (une fonction par bloc de faits,
   clés en français via `context.FACT_LABELS`), puis l'ajouter à `TableSpec.source`
   (`schemas.py`) et, si besoin, à `context.SECTION_TITLES`.
2. **Graphique** : ajouter la source dans `pptx_builder._chart_data` et dans `ChartSpec.source`.
3. Tester dans `tests/test_pptx.py` : la donnée et le rendu sont relus avec python-pptx.

### 4.7 Ajouter un fait calculé (KPI, risque, indicateur)

1. Calculer la valeur dans `metrics.py` (fonction pure, aucun accès réseau ni au modèle).
2. L'exposer dans le dictionnaire de faits (`build()`).
3. Donner son libellé français dans `context.KPI_LABELS` (ou `FACT_LABELS` pour un bloc tabulaire).
4. Le utiliser dans une définition via `kpis: [{"key": "<cle>"}]` — aucune autre modification.
5. Couvrir le calcul dans `tests/test_metrics.py` et le rendu dans `tests/test_pptx.py`.

### 4.8 Modifier le prompt ou le contrat du modèle

- **Voix / audience / prudence** : `reportings/<id>/prompt.md` (modifiable depuis l'interface).
- **Contrat technique** : `prompting.py` (`FORMAT_CONTRACT`, `SAFETY_RULES`) — ne pas y mettre de
  donnée : le modèle ne doit recevoir que `prompt.md` + les faits.
- **Robustesse des réponses** : `narrative.parse_reply` (extraction JSON, réparation des virgules
  finales, récupération d'un objet tronqué, retrait du Markdown) et `verify.check`.
- **Réglage du comportement** : `ai_config.json` (lots, retries, bornes de longueur, température).

### 4.9 Ajouter un endpoint API

```python
@router.get("/exemple")
def exemple(_user: CurrentUser, service: Service) -> dict[str, Any]:
    return {"ok": True}
```

Le frontend l'appelle via `await api('GET', '/api/exemple')`. Toute route `/api/*` inconnue
retourne un **404** (le repli SPA ne s'applique qu'hors `/api/`), et toute route
`/api/*` sans `CurrentUser` renvoie `401` avec `login_required: true`.

### 4.10 Modifier l'authentification ou les utilisateurs

Les utilisateurs vivent dans le dataset `users` (JSON) et sont administrables depuis l'onglet
**Utilisateurs** ou `POST /api/users`. Un `user` peut être rattaché à un `client_id` : il ne voit
alors que ce client et ne peut générer pour aucun autre (`403`). Les mots de passe sont stockés
**en clair** (compatibilité avec le format livré par les équipes source) : à protéger par le
secret de session, HTTPS et `SWR_COOKIE_SECURE` avant toute mise en production.

### 4.11 Pilotage du moteur IA

| Levier | Effet |
|---|---|
| `POST /api/ai/warmup` (onglet Moteur IA) | Charge le modèle hors du chemin critique de la génération |
| `max_slides_per_call` ↓ (1–2) | Plus fiable avec un petit modèle : chaque appel demande moins de clés |
| `retries` ↑ | Relance une réponse incomplète en redemandant **seulement** les slides manquantes |
| `temperature` ↓ | Narration plus neutre (0,2–0,3 pour un deck client) |
| `max_context_chars` ↓ | Contexte plus court, attention plus concentrée |
| `use_ai: false` | Génération « chiffres seuls » : aucun appel au modèle, deck livrable |
| `llm_backend: llamafile` | Modèle servi par un Llamafile distant (CPU/GPU dédié) |

Une génération est **robuste par construction** : si le modèle est absent, renvoie du texte non
JSON ou citant un montant absent des faits, le deck est **produit quand même** ; seuls les
commentaires concernés restent vides (`narrative_source: erreur`) et l'avertissement remonte dans
la réponse et dans l'historique. `ok: false` n'est positionné que si une slide est réellement en
erreur.

---

## 5. Limites & points d'attention

- **Pas de base de données** : chaque accès relit le fichier ; `DatasetRepository` tient un cache
  invalidé par `invalidate()`, mais le produit reste mono-processus (pas de concurrence forte).
- **Mots de passe en clair** dans `users.json` ; `SWR_SECRET_KEY` est régénéré à chaque démarrage
  si non défini, ce qui invalide les sessions.
- **Garde-fou numérique ≠ exactitude** : `verify` signale un montant cité qui ne figure pas dans
  les faits envoyés ; il ne prouve pas la justesse d'un chiffre repris correctement (ni son
  unité). Les nombres inférieurs à 1000 et les décimales réécrites différemment (« 81,2 % » dans
  les faits contre « 81,25 % » dans la narration) ne sont pas signalés — la relecture humaine
  reste le dernier contrôle.
- **Modèle local** : 3B en Q4 sur CPU, la génération d'un reporting complet prend de l'ordre de
  deux minutes (chargement inclus). Un lot échoué est retenté une fois ; au-delà, la slide reste
  vide plutôt que le deck entier d'échec.
- **Colonnes de risque non cumulables** : `volatility`, `sharpe` et `max_drawdown` décrivent
  **un** portefeuille. Dès que le périmètre couvre plusieurs portefeuilles, ces trois mesures
  sont recalculées sur la courbe consolidée (`_risk_measures`) ; en dessous, les colonnes de la
  source sont reprises telles quelles. Un périmètre à un seul portefeuille garde donc exactement
  les chiffres publiés par la source, tandis qu'un périmètre multi-portefeuilles n'hérite pas du
  risque d'un portefeuille choisi par le tri.
- **Contexte tronqué** : au-delà de `max_context_chars`, la fin du bloc de faits est remplacée par
  `[contexte tronque]` ; préférer `context.sections` (liste blanche) à une troncature.
- **Bloc obligataire conditionné aux données** : une ligne n'entre dans `facts["bonds"]` que si sa
  colonne `issuer` est renseignée, et son profil de maturité que si `maturity` l'est. Un export
  client sans ces colonnes produit un portefeuille à 0 % d'obligataire — résultat cohérent, mais
  muet : c'est au relecteur de savoir si le portefeuille en contenait. Le jeu de démonstration
  (`scripts/seed_data.py`, `BOND_METADATA`) fournit ces colonnes pour huit titres obligataires.
- **Coupons** : `coupons_received` ne compte que les écritures de type `INTEREST`, `COUPON` ou
  `DIVIDEND` tombant dans la période demandée. Le jeu de démonstration paie ses coupons en
  janvier : un arrêté trimestriel en affiche donc légitimement zéro.
- **Noms de colonnes** : les faits reposent sur les noms de colonnes standard (`market_value`,
  `cost_basis`, `portfolio_cum`, `benchmark_cum`, `esg_score`…). Une table renommée sans adapter
  `metrics.py` produit un deck vide — `--check` ne le détecte pas (il vérifie des fichiers, pas
  des schémas).
- **Périmètre** : un reporting sans `default_client_id` et sans `client_id` à la génération
  consolide tous les clients ; pour un deck client, renseigner `default_client_id`.
- **Excel** : seule la première feuille est lue (`openpyxl`), et `.xls` n'est pas supporté.
- **Outputs** : `outputs/<id>/` n'est pas purgé automatiquement ; l'historique est reconstruit
  depuis les sidecars JSON, donc supprimer un `.pptx` supprime aussi son historique.
- **Template** : la duplication de slides modèles repose sur python-pptx ; un template produit
  par un outil tiers avec des zones à taille nulle peut décaler le contenu (les zones nommées
  doivent rester dimensionnées).
- **Chevauchement des zones** : la position de `SWR_TEXT` est imposée par le moteur selon la
  composition de la slide (§4.5). Un template maison qui placerait `SWR_TEXT` au milieu de la
  diapositive peut donc être corrigé, mais un texte **plus long que la zone** déborde sans être
  détecté. Après une modification de `DEFAULT_ZONES` ou d'un gabarit, contrôler avec
  `python scripts/check_overlap.py <deck.pptx>` : il compare les rectangles réels et sort en
  erreur dès que deux zones de contenu se recouvrent.
- **LLM optionnel** : sans `requirements-llm.txt`, `/api/ai/status` répond `available: false` et
  les routes IA répondent `503` ; la génération sans IA reste pleinement fonctionnelle.

---

## 6. Exemple de bout en bout

```bash
# 1. Diagnostic
.venv/bin/python -m smartwealthreporting --check

# 2. Créer un reporting à partir d'un modèle et lui donner son template
.venv/bin/python - <<'PY'
from pathlib import Path
from smartwealthreporting.config import Settings
from smartwealthreporting.main import build_service
service = build_service(Settings.from_env())
service.create_reporting("revue_trimestrielle", "Revue trimestrielle", copy_template="quarterly_esg_review")
PY

# 3. Générer en chiffres seuls (sans IA), puis télécharger
.venv/bin/python -m smartwealthreporting --generate revue_trimestrielle --client C004 --no-ai

# 4. Générer avec narration IA + vérification numérique
.venv/bin/python -m smartwealthreporting --generate monthly_client_review --client C001 --json | \
  python -c "import json,sys; d=json.load(sys.stdin); print(d['warnings'], d['ok'])"
```

Côté API, la même génération :

```bash
curl -c cookies -X POST localhost:5050/api/login \
  -H 'Content-Type: application/json' -d '{"username":"admin","password":"admin123"}'
curl -b cookies -X POST localhost:5050/api/reportings/monthly_client_review/generate \
  -H 'Content-Type: application/json' -d '{"client_id":"C001","use_ai":true}'
curl -b cookies -OJ localhost:5050/api/runs/monthly_client_review/<fichier>.pptx
```