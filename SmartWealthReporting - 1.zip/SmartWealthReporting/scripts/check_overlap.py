"""Détecte les chevauchements réels de formes dans un PPTX rendu.

Pour chaque slide, compare les rectangles (gauche, haut, largeur, hauteur) des
formes porteuses de contenu et signale les paires qui se recouvrent de plus de
la tolérance. Les fonds pleine page et les accents décoratifs sont ignorés.
"""

from __future__ import annotations

import sys
from pathlib import Path

from pptx import Presentation

EMU_IN = 914400.0

#: Formes décoratives / fonds : jamais du contenu, donc jamais un conflit.
BACKGROUND_HINTS = ("header", "band", "accent", "rule", "bg", "footer_line")


def rect(shape):
    try:
        if shape.left is None or shape.top is None:
            return None
        return (
            shape.left / EMU_IN,
            shape.top / EMU_IN,
            (shape.width or 0) / EMU_IN,
            (shape.height or 0) / EMU_IN,
        )
    except Exception:
        return None


def is_background(shape, r) -> bool:
    name = (shape.name or "").lower()
    if any(h in name for h in BACKGROUND_HINTS):
        return True
    # Une forme qui couvre presque toute la slide est un fond.
    return r[2] > 12.0 and r[3] > 6.5


def has_content(shape) -> bool:
    if getattr(shape, "has_table", False):
        return True
    if shape.has_text_frame:
        return bool(shape.text_frame.text.strip())
    return False


def overlap(a, b, tol=0.04) -> float:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    ix = min(ax + aw, bx + bw) - max(ax, bx)
    iy = min(ay + ah, by + bh) - max(ay, by)
    if ix <= tol or iy <= tol:
        return 0.0
    return ix * iy


def main(paths: list[str]) -> int:
    bad = 0
    for p in paths:
        prs = Presentation(p)
        print(f"\n=== {Path(p).name} — {len(prs.slides)} slides ===")
        for idx, slide in enumerate(prs.slides, 1):
            shapes = []
            for shape in slide.shapes:
                r = rect(shape)
                if r is None or not has_content(shape) or is_background(shape, r):
                    continue
                shapes.append((shape.name, r))
            hits = []
            for i in range(len(shapes)):
                for j in range(i + 1, len(shapes)):
                    area = overlap(shapes[i][1], shapes[j][1])
                    if area > 0.05:
                        hits.append((shapes[i][0], shapes[j][0], area))
            if hits:
                bad += len(hits)
                print(f"  slide {idx}: {len(hits)} chevauchement(s)")
                for a, b, area in hits:
                    print(f"     - {a}  x  {b}   ({area:.2f} po2)")
    print(f"\nTOTAL chevauchements : {bad}")
    return bad


if __name__ == "__main__":
    sys.exit(1 if main(sys.argv[1:]) else 0)