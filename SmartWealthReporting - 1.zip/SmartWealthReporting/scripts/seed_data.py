#!/usr/bin/env python3
"""Génère un jeu de données PWM de démonstration dans `data/`.

Le jeu produit volontairement plusieurs formats pour illustrer la lecture
multi-format du dépôt : Parquet pour les tables de gestion, JSON pour les
utilisateurs, Excel pour les notations ESG et CSV pour les courbes de référence.

    python scripts/seed_data.py              # écrit data/
    python scripts/seed_data.py --force      # écrase des fichiers existants
    python scripts/seed_data.py --format csv # tout en CSV

Les données sont déterministes (graine fixe) : deux exécutions produisent les
mêmes chiffres, ce qui rend les captures d'écran et les tests reproductibles.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import sys
from datetime import date, timedelta
from pathlib import Path
from typing import Any

import pandas as pd

SEED = 20260930

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from smartwealthreporting.auth import DEFAULT_USERS  # noqa: E402
from smartwealthreporting.storage import write_frame  # noqa: E402

#: Date de référence du jeu : dernier jour du mois écoulé.
AS_OF = date(2026, 9, 30)
MONTHS = 24

# --------------------------------------------------------------------- Clients

CLIENTS: list[dict[str, Any]] = [
    {
        "client_id": "C001",
        "client_name": "Sophie Marchand",
        "segment": "Privé",
        "domicile": "Paris 8e",
        "relationship_manager": "Claire Dubois",
        "base_ccy": "EUR",
        "risk_profile": "Modéré",
        "onboarding_date": "2019-04-15",
        "objectives": "Capitalisation long terme, revenus regulariers",
    },
    {
        "client_id": "C002",
        "client_name": "Famille Lambert",
        "segment": "Family Office",
        "domicile": "Lyon 6e",
        "relationship_manager": "Claire Dubois",
        "base_ccy": "EUR",
        "risk_profile": "Prudent",
        "onboarding_date": "2015-09-02",
        "objectives": "Transmission, income Court terme",
    },
    {
        "client_id": "C003",
        "client_name": "Alexandre Nguyen",
        "segment": "Entrepreneur",
        "domicile": "Paris 17e",
        "relationship_manager": "Marc Ferrand",
        "base_ccy": "EUR",
        "risk_profile": "Dynamique",
        "onboarding_date": "2021-06-21",
        "objectives": "Liquidite entrepreneuriale, exposition internationale",
    },
    {
        "client_id": "C004",
        "client_name": "Famille Rossi",
        "segment": "Privé",
        "domicile": "Nice",
        "relationship_manager": "Marc Ferrand",
        "base_ccy": "EUR",
        "risk_profile": "Modéré",
        "onboarding_date": "2018-02-12",
        "objectives": "Diversification globale, philanthropy",
    },
    {
        "client_id": "C005",
        "client_name": "Isabelle Petit",
        "segment": "Privé",
        "domicile": "Bordeaux",
        "relationship_manager": "Claire Dubois",
        "base_ccy": "EUR",
        "risk_profile": "Prudent",
        "onboarding_date": "2020-11-05",
        "objectives": "Retraite progressive, preverance",
    },
    {
        "client_id": "C006",
        "client_name": "Hugues Mercier",
        "segment": "Dirigeant",
        "domicile": "Lille",
        "relationship_manager": "Marc Ferrand",
        "base_ccy": "EUR",
        "risk_profile": "Dynamique",
        "onboarding_date": "2016-10-19",
        "objectives": "Concentre, performance benchmarkee",
    },
]

# --------------------------------------------------------------- Instruments
# Chaque entrée est le dictionnaire décrivant une ligne de l'univers d'outils.

#: Métadonnées obligataires absentes de `INSTRUMENTS` : émetteur, coupon nominal,
#: échéance, duration modifiée et TRA brut théorique. Elles alimentent les
#: indicateurs obligataires du rapport de gestion (vie moyenne, sensibilité,
#: nombre d'émetteurs, répartition par maturité). Les non-obligations reçoivent
#: ces colonnes vides.
#:
#: `tra_pct` est fixé par ligne, puis le cours est recalculé par
#: `price = 100 - (tra - coupon) x duration` : le titre se comporte alors comme
#: un vrai obligataire, à la prime ou au discote selon son rendement.
BOND_METADATA: dict[str, dict[str, Any]] = {
    "oat_2031": dict(issuer="République Française", coupon=3.00, maturity="2031-10-15",
                     mod_duration=4.6, tra_pct=2.92),
    "oat_2030": dict(issuer="République Française", coupon=2.50, maturity="2030-05-15",
                     mod_duration=3.4, tra_pct=2.46),
    "bund_2032": dict(issuer="République Fédérale d'Allemagne", coupon=2.10, maturity="2032-08-15",
                      mod_duration=5.1, tra_pct=2.18),
    "btp_2036": dict(issuer="République Italienne", coupon=3.75, maturity="2036-09-01",
                     mod_duration=7.8, tra_pct=3.94),
    "schneider_bond": dict(issuer="Schneider Electric SE", coupon=2.50, maturity="2031-06-15",
                           mod_duration=3.9, tra_pct=2.71),
    "socgen_bond": dict(issuer="Societe Generale SA", coupon=3.00, maturity="2029-12-01",
                        mod_duration=2.7, tra_pct=3.38),
    "pfizer_bond": dict(issuer="Pfizer Inc", coupon=2.125, maturity="2030-05-15",
                        mod_duration=3.2, tra_pct=2.34),
    "us_treasury": dict(issuer="États-Unis (Treasury)", coupon=3.375, maturity="2032-02-15",
                        mod_duration=5.4, tra_pct=3.62),
}

INSTRUMENTS: dict[str, dict[str, Any]] = {
    # ---- Actions France
    "air_liquide": dict(
        name="Air Liquide", isin="FR0000120078", asset_class="Actions", category="Actions France",
        sector="Industrie", country="France", currency="EUR", rating="BBB+", esg=78, y=72, s=84, g=76,
    ),
    "lvmh": dict(
        name="LVMH", isin="FR0000121014", asset_class="Actions", category="Actions France",
        sector="Luxe", country="France", currency="EUR", rating="BBB+", esg=64, y=61, s=70, g=61,
    ),
    "totalenergies": dict(
        name="TotalEnergies", isin="FR0000120271", asset_class="Actions", category="Actions France",
        sector="Énergie", country="France", currency="EUR", rating="A+", esg=62, y=58, s=66, g=63,
    ),
    "loreal": dict(
        name="L'Oreal", isin="FR0000120107", asset_class="Actions", category="Actions France",
        sector="Luxe", country="France", currency="EUR", rating="BBB+", esg=71, y=68, s=78, g=67,
    ),
    "sanofi": dict(
        name="Sanofi", isin="FR0000120579", asset_class="Actions", category="Actions France",
        sector="Santé", country="France", currency="EUR", rating="A", esg=76, y=72, s=82, g=74,
    ),
    "schneider": dict(
        name="Schneider Electric", isin="FR0000121972", asset_class="Actions", category="Actions France",
        sector="Industrie", country="France", currency="EUR", rating="BBB+", esg=84, y=79, s=88, g=85,
    ),
    "vinci": dict(
        name="Vinci", isin="FR0000123008", asset_class="Actions", category="Actions France",
        sector="Services", country="France", currency="EUR", rating="BBB+", esg=80, y=75, s=84, g=81,
    ),
    "axa": dict(
        name="AXA", isin="FR0000120621", asset_class="Actions", category="Actions France",
        sector="Finance", country="France", currency="EUR", rating="A", esg=73, y=70, s=80, g=69,
    ),
    "bnp": dict(
        name="BNP Paribas", isin="FR0000131104", asset_class="Actions", category="Actions France",
        sector="Finance", country="France", currency="EUR", rating="A-", esg=68, y=65, s=76, g=63,
    ),
    "capgemini": dict(
        name="Capgemini", isin="FR0000125338", asset_class="Actions", category="Actions France",
        sector="Technologies", country="France", currency="EUR", rating="BBB", esg=79, y=74, s=83, g=80,
    ),
    "pernod": dict(
        name="Pernod Ricard", isin="FR0000124003", asset_class="Actions", category="Actions France",
        sector="Agroalimentaire", country="France", currency="EUR", rating="BBB", esg=58, y=55, s=66, g=53,
    ),
    "danone": dict(
        name="Danone", isin="FR0000120647", asset_class="Actions", category="Actions France",
        sector="Agroalimentaire", country="France", currency="EUR", rating="BBB+", esg=81, y=76, s=86, g=81,
    ),
    "stmicro": dict(
        name="STMicroelectronics", isin="FR0000125474", asset_class="Actions", category="Actions France",
        sector="Technologies", country="France", currency="EUR", rating="BBB", esg=75, y=71, s=80, g=74,
    ),
    "hermes": dict(
        name="Hermes International", isin="FR0000061029", asset_class="Actions", category="Actions France",
        sector="Luxe", country="France", currency="EUR", rating="BBB+", esg=70, y=66, s=76, g=68,
    ),
    "essilor": dict(
        name="EssilorLuxottica", isin="FR0000120798", asset_class="Actions", category="Actions France",
        sector="Santé", country="France", currency="EUR", rating="BBB", esg=74, y=70, s=80, g=72,
    ),
    # ---- Actions Europe / monde
    "asml": dict(
        name="ASML Holding", isin="NL0010273215", asset_class="Actions", category="Actions Europe",
        sector="Technologies", country="Pays-Bas", currency="EUR", rating="BBB+", esg=77, y=72, s=82, g=77,
    ),
    "nestle": dict(
        name="Nestle", isin="CH0038863350", asset_class="Actions", category="Actions Europe",
        sector="Agroalimentaire", country="Suisse", currency="CHF", rating="AA-", esg=72, y=68, s=80, g=68,
    ),
    "novo": dict(
        name="Novo Nordisk", isin="DK0060534915", asset_class="Actions", category="Actions Europe",
        sector="Santé", country="Danemark", currency="DKK", rating="BBB+", esg=71, y=66, s=78, g=69,
    ),
    "siemens": dict(
        name="Siemens", isin="DE0007236101", asset_class="Actions", category="Actions Europe",
        sector="Industrie", country="Allemagne", currency="EUR", rating="A+", esg=82, y=77, s=86, g=83,
    ),
    "allianz": dict(
        name="Allianz", isin="DE0008404005", asset_class="Actions", category="Actions Europe",
        sector="Finance", country="Allemagne", currency="EUR", rating="A+", esg=79, y=74, s=84, g=79,
    ),
    # ---- Fonds
    "msci_world": dict(
        name="Amundi ETF MSCI World", isin="FR0000989626", asset_class="Fonds", category="Fonds Actions Monde",
        sector="Diversifié", country="Monde", currency="EUR", rating="Non note", esg=69, y=65, s=76, g=66,
    ),
    "europe_value": dict(
        name="Candriam Equities LUX Europe", isin="LU0993179174", asset_class="Fonds",
        category="Fonds Actions Europe", sector="Diversifié", country="Luxembourg", currency="EUR",
        rating="Non note", esg=67, y=63, s=73, g=65,
    ),
    "quality_income": dict(
        name="Fidelity Global Quality Income", isin="LU0070178082", asset_class="Fonds",
        category="Fonds diversifiés", sector="Diversifié", country="Luxembourg", currency="USD",
        rating="Non note", esg=71, y=67, s=78, g=68,
    ),
    "abs_return": dict(
        name="Eurizon Absolute Return", isin="FR0000989626", asset_class="Fonds",
        category="Fonds diversifiés", sector="Diversifié", country="France", currency="EUR",
        rating="Non note", esg=64, y=60, s=72, g=60,
    ),
    "monetaire": dict(
        name="Amundi Money Market", isin="FR0000996564", asset_class="Monetaire",
        category="OPCVM Monétaire", sector="Cash", country="France", currency="EUR",
        rating="AAA", esg=0, y=0, s=0, g=0,
    ),
    "compte_term": dict(
        name="Compte a terme EUR 3 mois", isin="—", asset_class="Monetaire",
        category="Monétaire", sector="Cash", country="France", currency="EUR",
        rating="A+", esg=0, y=0, s=0, g=0,
    ),
    "livret": dict(
        name="Livret bancaire", isin="—", asset_class="Monetaire", category="Monétaire",
        sector="Cash", country="France", currency="EUR", rating="A", esg=0, y=0, s=0, g=0,
    ),
    # ---- Obligations
    "oat_2031": dict(
        name="OAT 3.00% Oct 2031", isin="FR0000199679", asset_class="Obligations",
        category="Obligations Souveraines", sector="Souverain", country="France", currency="EUR",
        rating="AA", esg=0, y=0, s=0, g=0,
    ),
    "oat_2030": dict(
        name="OAT 2.50% Mai 2030", isin="FR0000499800", asset_class="Obligations",
        category="Obligations Souveraines", sector="Souverain", country="France", currency="EUR",
        rating="AA", esg=0, y=0, s=0, g=0,
    ),
    "bund_2032": dict(
        name="Bund 2.10% Aug 2032", isin="DE0001102564", asset_class="Obligations",
        category="Obligations Souveraines", sector="Souverain", country="Allemagne", currency="EUR",
        rating="AAA", esg=0, y=0, s=0, g=0,
    ),
    "btp_2036": dict(
        name="BTP 3.75% Sep 2036", isin="IT0005453644", asset_class="Obligations",
        category="Obligations Souveraines", sector="Souverain", country="Italie", currency="EUR",
        rating="BBB+", esg=0, y=0, s=0, g=0,
    ),
    "schneider_bond": dict(
        name="Schneider Electric 2.50% 2031", isin="FR0010337793", asset_class="Obligations",
        category="Obligations Entreprises", sector="Industrie", country="France", currency="EUR",
        rating="A+", esg=80, y=76, s=85, g=79,
    ),
    "socgen_bond": dict(
        name="Societe Generale 3.00% 2029", isin="FR0010891405", asset_class="Obligations",
        category="Obligations Entreprises", sector="Finance", country="France", currency="EUR",
        rating="A", esg=74, y=70, s=80, g=72,
    ),
    "pfizer_bond": dict(
        name="Pfizer 2.125% 2030", isin="US717068JW32", asset_class="Obligations",
        category="Obligations Entreprises", sector="Santé", country="États-Unis", currency="USD",
        rating="A+", esg=78, y=74, s=84, g=76,
    ),
    "us_treasury": dict(
        name="US Treasury 3.375% 2032", isin="US91282CJL67", asset_class="Obligations",
        category="Obligations Souveraines", sector="Souverain", country="États-Unis", currency="USD",
        rating="AA+", esg=0, y=0, s=0, g=0,
    ),
    # ---- Immobilier
    "scpi_retail": dict(
        name="SCPI Europe Retail", isin="FR0010791160", asset_class="Immobilier",
        category="SCPI", sector="Immobilier", country="Europe", currency="EUR", rating="Non note",
        esg=66, y=55, s=74, g=69,
    ),
    "scpi_logement": dict(
        name="SCPI Logements", isin="FR0011443642", asset_class="Immobilier", category="SCPI",
        sector="Immobilier", country="France", currency="EUR", rating="Non note",
        esg=68, y=56, s=76, g=72,
    ),
    "fonciere": dict(
        name="Fonds Immobilier Europe", isin="FR0010510224", asset_class="Immobilier",
        category="Fonds Immobilier", sector="Immobilier", country="Luxembourg", currency="EUR",
        rating="Non note", esg=64, y=54, s=72, g=66,
    ),
    # ---- Alternatifs
    "private_equity": dict(
        name="Fonds Private Equity Europe", isin="LU1234567890", asset_class="Alternatifs",
        category="Marchés privés", sector="Diversifié", country="Europe", currency="EUR",
        rating="Non note", esg=61, y=57, s=68, g=58,
    ),
    "infrastructure": dict(
        name="SCV Infrastructure", isin="LU0987654321", asset_class="Alternatifs",
        category="Infrastructure", sector="Services", country="Europe", currency="EUR",
        rating="Non note", esg=73, y=66, s=78, g=75,
    ),
    "or_physique": dict(
        name="Or physique 99,5%", isin="—", asset_class="Alternatifs", category="Matières premières",
        sector="Diversifié", country="Monde", currency="EUR", rating="Non note",
        esg=32, y=20, s=40, g=36,
    ),
}

#: Nomenclature : poids par clé d'instrument dans chaque portefeuille.
PORTFOLIO_TEMPLATES: dict[str, list[tuple[str, float]]] = {
    "obl": [
        ("oat_2031", 22.0), ("oat_2030", 18.0), ("bund_2032", 16.0), ("schneider_bond", 14.0),
        ("socgen_bond", 10.0), ("btp_2036", 6.0), ("pfizer_bond", 5.0), ("monetaire", 6.0),
        ("livret", 3.0),
    ],
    "act": [
        ("lvmh", 14.0), ("air_liquide", 11.0), ("schneider", 9.0), ("sanofi", 8.0),
        ("totalenergies", 7.0), ("vinci", 6.0), ("asml", 6.0), ("siemens", 5.0),
        ("nestle", 4.0), ("novo", 4.0), ("allianz", 4.0), ("msci_world", 10.0),
        ("monetaire", 8.0), ("livret", 4.0),
    ],
    "mon": [
        ("monetaire", 58.0), ("compte_term", 22.0), ("livret", 12.0), ("oat_2030", 8.0),
    ],
    "alt": [
        ("scpi_retail", 20.0), ("scpi_logement", 16.0), ("private_equity", 15.0),
        ("infrastructure", 13.0), ("fonciere", 12.0), ("or_physique", 5.0),
        ("us_treasury", 11.0), ("compte_term", 8.0),
    ],
    "diversifie": [
        ("msci_world", 30.0), ("quality_income", 14.0), ("europe_value", 12.0),
        ("abs_return", 10.0), ("schneider_bond", 8.0), ("oat_2031", 6.0),
        ("us_treasury", 5.0), ("compte_term", 8.0), ("or_physique", 4.0), ("livret", 3.0),
    ],
}

#: (client_id, suffixe, nom de portefeuille, mandat, stratégie, aum cible M EUR, inception, template)
PORTFOLIOS: list[tuple[str, str, str, str, str, float, str, str]] = [
    ("C001", "OBL", "Marche obligataire", "Obligataire", "Defensive", 1.35, "2019-05-20", "obl"),
    ("C001", "ACT", "Actions Europe", "Actions", "Growth", 1.90, "2019-05-20", "act"),
    ("C001", "MON", "Tresorerie EUR", "Monetaire", "Cash", 0.45, "2020-01-15", "mon"),
    ("C002", "OBL", "Patrimoine obligataire", "Obligataire", "Prudent", 2.60, "2015-10-01", "obl"),
    ("C002", "ALT", "Alternatifs et immobilier", "Alternatifs", "Diversifiant", 1.15, "2017-03-10", "alt"),
    ("C003", "ACT", "Actions monde", "Actions", "Growth", 3.40, "2021-07-01", "act"),
    ("C003", "DVS", "Patrimoine diversifie", "Gestion libre", "Equilibre", 2.20, "2021-07-01", "diversifie"),
    ("C004", "DVS", "Patrimoine mondial", "Gestion libre", "Equilibre", 4.10, "2018-03-01", "diversifie"),
    ("C004", "ALT", "SCPI et opportunites", "Alternatifs", "Diversifiant", 1.05, "2020-06-01", "alt"),
    ("C005", "OBL", "Obligations europeennes", "Obligataire", "Prudent", 1.05, "2020-12-01", "obl"),
    ("C005", "ACT", "Actions France", "Actions", "Growth", 0.95, "2020-12-01", "act"),
    ("C005", "MON", "Liquidites", "Monetaire", "Cash", 0.35, "2021-01-15", "mon"),
    ("C006", "ACT", "Actions Europe concentrees", "Actions", "Growth", 2.75, "2016-11-01", "act"),
    ("C006", "OBL", "Souverains et credit", "Obligataire", "Prudent", 1.60, "2016-11-01", "obl"),
]

#: Couleurs/attentes de performance par type de mandat : (performance, benchmark, vol, drift mensuel)
#: Taux sans risque du ratio de Sharpe, aligne sur `metrics.RISK_FREE_RATE`.
#: Ce generateur n'importe pas le paquet de l'application — il doit pouvoir
#: regenerer le jeu de demonstration sans celle-ci — mais les deux valeurs
#: doivent rester egales : un Sharpe calcule sur 2 % et publie sur 1,5 % serait
#: illisible cote client.
RISK_FREE_RATE = 2.0

MANDATE_PROFILE: dict[str, tuple[float, float, float, float]] = {
    "Obligataire": (2.9, 2.6, 2.4, 0.12),
    "Actions": (16.4, 12.8, 13.5, 0.55),
    "Monetaire": (2.2, 1.9, 0.2, 0.09),
    "Alternatifs": (9.3, 7.1, 6.4, 0.34),
    "Gestion libre": (13.1, 11.0, 9.6, 0.45),
}


# ------------------------------------------------------------------ Generation


def build_portfolios(rng: random.Random) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for client_id, suffix, name, mandate, strategy, aum_m, inception, _template in PORTFOLIOS:
        rows.append(
            {
                "portfolio_id": f"PF-{client_id}-{suffix}",
                "client_id": client_id,
                "portfolio_name": name,
                "mandate_type": mandate,
                "strategy": strategy,
                "base_ccy": "EUR",
                "aum": round(aum_m * 1_000_000, 2),
                "inception_date": inception,
                "management_fee_pct": round(rng.uniform(0.35, 0.85), 2),
                "risk_level": {"Obligataire": 2, "Monetaire": 1, "Alternatifs": 3,
                               "Gestion libre": 4, "Actions": 5}[mandate],
            }
        )
    return pd.DataFrame(rows)


def build_holdings(rng: random.Random, portfolios: pd.DataFrame) -> pd.DataFrame:
    aum_by_portfolio = {record["portfolio_id"]: record["aum"] for record in portfolios.to_dict("records")}
    rows: list[dict[str, Any]] = []
    for client_id, suffix, _name, _mandate, _strategy, _aum, _inception, template in PORTFOLIOS:
        portfolio_id = f"PF-{client_id}-{suffix}"
        total = aum_by_portfolio[portfolio_id]
        for key, weight in PORTFOLIO_TEMPLATES[template]:
            if key not in INSTRUMENTS or weight <= 0:
                continue
            instrument = INSTRUMENTS[key]
            value = total * weight / 100.0
            # Métadonnées obligataires : vides pour les autres classes d'actifs.
            bond = BOND_METADATA.get(key, {})
            # Cours et quantite : arrondis de facon credible pour un portefeuille.
            price = {
                "Actions": rng.uniform(40, 980),
                "Fonds": rng.uniform(90, 620),
                "Obligations": 100.0,  # recalcule plus bas d'après le TRA
                "Immobilier": rng.uniform(520, 1900),
                "Alternatifs": rng.uniform(60, 340),
                "Monetaire": 1.0,
            }.get(str(instrument["asset_class"]), 100.0)
            if instrument["asset_class"] == "Obligations":
                # Prime si le rendement est sous le coupon, discote s'il est au-dessus.
                duration = float(bond.get("mod_duration") or 1.0)
                price = 100.0 - (
                    float(bond.get("tra_pct", 0.0)) - float(bond.get("coupon", 0.0))
                ) * duration
            if instrument["asset_class"] == "Monetaire":
                price = 1.0
            quantity = round(value / price, 2)
            price = round(price, 4)
            market_value = round(quantity * price, 2)
            if instrument["asset_class"] == "Obligations":
                # Coupon nominal du titre : il figure dans son libellé.
                coupon = float(bond.get("coupon", 0.0))
            elif instrument["asset_class"] == "Monetaire":
                coupon = round(rng.uniform(1.5, 3.6), 3)
            elif instrument["asset_class"] == "Immobilier":
                coupon = round(rng.uniform(3.4, 5.2), 3)
            else:
                coupon = round(rng.uniform(0.6, 3.8), 3)
            # Performance non realisee : dispersion par classe d'actifs.
            drift = {
                "Actions": rng.uniform(-18, 42), "Fonds": rng.uniform(-14, 34),
                "Obligations": rng.uniform(-4.5, 3.5), "Immobilier": rng.uniform(-6, 8),
                "Alternatifs": rng.uniform(-9, 16), "Monetaire": 0.0,
            }[instrument["asset_class"]]
            cost_basis = round(market_value / (1 + drift / 100), 2)
            # TRA : rendement du titre. Pour une obligation c'est celui de la
            # metadata (le cours en découle), ailleurs c'est le rendement simple.
            tra = float(bond["tra_pct"]) if bond.get("tra_pct") is not None else coupon
            rows.append(
                {
                    "as_of": AS_OF.isoformat(),
                    "client_id": client_id,
                    "portfolio_id": portfolio_id,
                    "isin": instrument["isin"],
                    "instrument_name": instrument["name"],
                    "issuer": bond.get("issuer"),
                    "asset_class": instrument["asset_class"],
                    "category": instrument["category"],
                    "sector": instrument["sector"],
                    "country": instrument["country"],
                    "currency": instrument["currency"],
                    "rating": instrument["rating"],
                    "quantity": quantity,
                    "price": price,
                    "market_value": market_value,
                    "cost_basis": cost_basis,
                    "pnl_unrealised": round(market_value - cost_basis, 2),
                    "coupon": coupon,
                    "yield": tra,
                    "maturity": bond.get("maturity"),
                    "mod_duration": bond.get("mod_duration"),
                    "cash_value": market_value if instrument["asset_class"] == "Monetaire" else 0.0,
                    "esg_score": instrument["esg"],
                    "esg_e": instrument["y"],
                    "esg_s": instrument["s"],
                    "esg_g": instrument["g"],
                    "currency_hedge": "Oui" if instrument["currency"] not in {"EUR", "—"} else "Non",
                }
            )
    frame = pd.DataFrame(rows)
    # Les montants ponderes par instrument doivent reconstituer l'encours du portefeuille.
    frame["market_value"] = frame["market_value"].round(2)
    return frame


def _month_ends(count: int, end: date) -> list[date]:
    dates: list[date] = []
    year, month = end.year, end.month
    for _ in range(count):
        last_day = (date(year + month // 12, month % 12 + 1, 1) - timedelta(days=1))
        dates.append(last_day)
        month -= 1
        if month == 0:
            month, year = 12, year - 1
    return list(reversed(dates))


def build_performance(rng: random.Random, portfolios: pd.DataFrame) -> pd.DataFrame:
    """Courbes mensuelles de performance par portefeuille, coherentes avec les mandats."""
    dates = _month_ends(MONTHS, AS_OF)
    rows: list[dict[str, Any]] = []
    for record in portfolios.to_dict("records"):
        portfolio_id = str(record["portfolio_id"])
        mandate = str(record["mandate_type"])
        total, benchmark_total, volatility, drift = MANDATE_PROFILE[mandate]
        # Le bruit est engendre une fois par portefeuille, puis la forme est
        # recalee sur la volatilite du mandat (voir `_shape_curve`).
        raw_portfolio = [rng.gauss(drift, volatility / math.sqrt(12)) for _ in range(MONTHS)]
        raw_benchmark = [rng.gauss(drift * 0.82, volatility / math.sqrt(12) * 1.1) for _ in range(MONTHS)]
        portfolio_cum = _shape_curve(raw_portfolio, total, volatility)
        benchmark_cum = _shape_curve(raw_benchmark, benchmark_total, volatility * 1.1)

        aum = float(record["aum"])
        # Un rendement par intervalles, en fraction : pas de zéro initial, qui
        # fausserait la moyenne et donc l'écart-type annualisé.
        monthly_returns = [
            (portfolio_cum[index] - portfolio_cum[index - 1]) / 100.0
            for index in range(1, len(portfolio_cum))
        ]
        annualised = _annualised_vol(monthly_returns)
        sharpe = (
            round((total / 100.0 - RISK_FREE_RATE / 100.0) / (annualised / 100.0), 2)
            if annualised
            else 0.0
        )
        drawdown = _max_drawdown(portfolio_cum)

        for index, day in enumerate(dates):
            # Derive de l'encours coherente avec la performance mensuelle :
            # le rendement est deja une fraction, il ne se divise pas une seconde fois.
            if index:
                aum = aum * (1 + monthly_returns[index - 1])
            rows.append(
                {
                    "portfolio_id": portfolio_id,
                    "client_id": str(record["client_id"]),
                    "date": day.isoformat(),
                    "portfolio_cum": portfolio_cum[index],
                    "benchmark_cum": benchmark_cum[index],
                    "aum": round(aum, 2),
                    "volatility": round(annualised, 2),
                    "sharpe": sharpe,
                    "max_drawdown": drawdown,
                    "period_label": day.strftime("%b %y"),
                }
            )
    return pd.DataFrame(rows)


def _normalise_curve(raw: list[float], target: float) -> list[float]:
    """Ramene une serie de rendements mensuels sur un cumul cible, en gardant la forme.

    Le niveau est compose multiplicativement depuis 1 : composer le cumul
    lui-meme produirait une courbe quadratique, donc parfaitement lisse, et la
    volatilité calculée ensuite tomberait a zero.
    """
    if not raw:
        return []
    level = 1.0
    levels = [level]
    for value in raw:
        level *= 1 + value / 100.0
        levels.append(level)
    curve = [(value - levels[0]) * 100.0 for value in levels]
    realised = curve[-1]
    if abs(realised) < 1e-9:
        return [round(index * target / len(curve), 2) for index in range(len(curve))]
    return [round(value * target / realised, 2) for value in curve]


def _annualised_vol(returns: list[float]) -> float:
    if len(returns) < 3:
        return 0.0
    mean = sum(returns) / len(returns)
    variance = sum((value - mean) ** 2 for value in returns) / (len(returns) - 1)
    return round(math.sqrt(variance) * math.sqrt(12) * 100, 2)


def _shape_curve(raw: list[float], total: float, volatility: float) -> list[float]:
    """Courbe de performance : tendance lineaire et residu dose a la volatilite.

    Un tirage de marche aleatoire impose le point d'arrivee mais laisse la courbe
    s'ecarter de plusieurs points en cours de periode : un portefeuille
    obligataire qui monte a 7 % avant de revenir a 2,9 % n'a pas d'allegance
    d'un rapport de gestion. La forme est donc reconstruite — une tendance vers
    la cible, plus un residu dont l'amplitude est calee sur la volatilite annoncee
    du mandat, ce qui rend le risque publie coherent avec la courbe publiee.
    """
    walk = _normalise_curve(raw, total)
    if len(walk) < 3:
        return walk
    count = len(walk) - 1
    trend = [index * total / count for index in range(count + 1)]
    residual = [value - base for value, base in zip(walk, trend)]
    # `_annualised_vol` attend des rendements en fraction, comme partout ailleurs.
    returns = [
        (residual[index] - residual[index - 1]) / 100.0 for index in range(1, count + 1)
    ]
    spread = _annualised_vol(returns)
    if spread > 0:
        residual = [value * volatility / spread for value in residual]
    return [round(base + value, 2) for base, value in zip(trend, residual)]


def _max_drawdown(curve: list[float]) -> float:
    """Plus forte baisse depuis un sommet, en pourcentage du niveau de reference.

    Le calcul passe par le facteur de croissance (1 + cumul), dont le sommet
    vaut au moins 1 : diviser par un cumul negatif ou nul donnerait une baisse
    superieure a -100 %, ce qui n'a pas de sens.
    """
    if not curve:
        return 0.0
    peak = 1.0
    worst = 0.0
    for value in curve:
        level = 1 + value / 100.0
        peak = max(peak, level)
        if peak > 0:
            worst = min(worst, (level - peak) / peak * 100)
    return round(worst, 2)


def build_transactions(rng: random.Random, holdings: pd.DataFrame) -> pd.DataFrame:
    """Operations de l'annee en cours : souscriptions, trades, dividendes, frais."""
    positions = holdings.to_dict("records")
    by_portfolio: dict[str, list[dict[str, Any]]] = {}
    for record in positions:
        by_portfolio.setdefault(str(record["portfolio_id"]), []).append(record)

    rows: list[dict[str, Any]] = []
    for portfolio_id, records in by_portfolio.items():
        client_id = str(records[0]["client_id"])
        # Flux de tresorerie : 1 a 2 versements ou retraits par portefeuille.
        for _ in range(rng.randint(1, 2)):
            day = _business_day(rng, AS_OF.year, 1)
            amount = round(rng.uniform(40_000, 320_000), 2)
            kind = rng.choice(["DEPOSIT", "WITHDRAWAL"])
            rows.append(
                {
                    "client_id": client_id,
                    "portfolio_id": portfolio_id,
                    "trade_date": day.isoformat(),
                    "transaction_type": kind,
                    "instrument_name": "Flux de tresorerie",
                    "isin": "—",
                    "quantity": 0.0,
                    "price": 0.0,
                    "amount": amount if kind == "DEPOSIT" else -amount,
                    "fees": 0.0,
                    "realised_pnl": 0.0,
                    "income": 0.0,
                    "comment": "Operation de tresorerie",
                }
            )
        # Trades sur instruments actions ou obligations.
        tradable = [
            record
            for record in records
            if record["asset_class"] in {"Actions", "Obligations", "Fonds"}
        ]
        for record in tradable:
            for _ in range(rng.randint(0, 2)):
                day = _business_day(rng, AS_OF.year, 9)
                kind = rng.choice(["BUY", "SELL"])
                price = float(record["price"])
                quantity = round(rng.uniform(20, max(40.0, float(record["quantity"]) * 0.12)), 2)
                amount = round(price * quantity, 2)
                fee = round(amount * 0.00035, 2)
                realised = 0.0
                if kind == "SELL" and float(record["cost_basis"]):
                    invested = float(record["cost_basis"]) / max(1.0, float(record["quantity"]))
                    realised = round((price - invested) * quantity, 2)
                rows.append(
                    {
                        "client_id": client_id,
                        "portfolio_id": portfolio_id,
                        "trade_date": day.isoformat(),
                        "transaction_type": kind,
                        "instrument_name": record["instrument_name"],
                        "isin": record["isin"],
                        "quantity": quantity,
                        "price": round(price, 4),
                        "amount": amount if kind == "BUY" else -amount,
                        "fees": fee,
                        "realised_pnl": realised,
                        "income": 0.0,
                        "comment": "Ajustement de ponderation",
                    }
                )
            # Revenus: dividendes pour les actions, coupons pour les obligations.
            if record["asset_class"] == "Actions" and rng.random() < 0.55:
                rows.append(
                    {
                        "client_id": client_id,
                        "portfolio_id": portfolio_id,
                        "trade_date": _business_day(rng, AS_OF.year, 5).isoformat(),
                        "transaction_type": "DIVIDEND",
                        "instrument_name": record["instrument_name"],
                        "isin": record["isin"],
                        "quantity": 0.0,
                        "price": 0.0,
                        "amount": round(float(record["market_value"]) * rng.uniform(0.002, 0.012), 2),
                        "fees": 0.0,
                        "realised_pnl": 0.0,
                        "income": round(float(record["market_value"]) * rng.uniform(0.002, 0.012), 2),
                        "comment": "Dividende",
                    }
                )
            if record["asset_class"] == "Obligations":
                rows.append(
                    {
                        "client_id": client_id,
                        "portfolio_id": portfolio_id,
                        "trade_date": _business_day(rng, AS_OF.year, 1).isoformat(),
                        "transaction_type": "INTEREST",
                        "instrument_name": record["instrument_name"],
                        "isin": record["isin"],
                        "quantity": 0.0,
                        "price": 0.0,
                        "amount": round(float(record["market_value"]) * float(record["coupon"]) / 100, 2),
                        "fees": 0.0,
                        "realised_pnl": 0.0,
                        "income": round(float(record["market_value"]) * float(record["coupon"]) / 100, 2),
                        "comment": "Coupon",
                    }
                )
        # Frais de gestion.
        rows.append(
            {
                "client_id": client_id,
                "portfolio_id": portfolio_id,
                "trade_date": _business_day(rng, AS_OF.year, 1).isoformat(),
                "transaction_type": "FEE",
                "instrument_name": "Frais de gestion",
                "isin": "—",
                "quantity": 0.0,
                "price": 0.0,
                "amount": -round(
                    sum(float(record["market_value"]) for record in records)
                    * rng.uniform(0.0020, 0.0065),
                    2,
                ),
                "fees": round(
                    sum(float(record["market_value"]) for record in records)
                    * rng.uniform(0.0020, 0.0065),
                    2,
                ),
                "realised_pnl": 0.0,
                "income": 0.0,
                "comment": "Frais annuels de gestion",
            }
        )
    frame = pd.DataFrame(rows).sort_values("trade_date")
    frame.loc[frame["trade_date"] > AS_OF.isoformat(), "trade_date"] = AS_OF.isoformat()
    return frame.reset_index(drop=True)


def _business_day(rng: random.Random, year: int, last_month: int) -> date:
    day = date(year, last_month, 1) + timedelta(days=rng.randint(0, 27))
    while day.weekday() >= 5:
        day += timedelta(days=1)
    return min(day, AS_OF)


def build_esg_workbook(holdings: pd.DataFrame) -> pd.DataFrame:
    """Table de notations ESG (Excel), detailee et non chiffree pour les slides ESG."""
    covered = holdings[holdings["esg_score"] > 0]
    grouped = (
        covered.groupby(["asset_class", "sector"], as_index=False)
        .agg(
            market_value=("market_value", "sum"),
            esg_score=("esg_score", "mean"),
            esg_e=("esg_e", "mean"),
            esg_s=("esg_s", "mean"),
            esg_g=("esg_g", "mean"),
            nb_lignes=("isin", "count"),
        )
        .sort_values("market_value", ascending=False)
    )
    for column in ("esg_score", "esg_e", "esg_s", "esg_g"):
        grouped[column] = grouped[column].round(1)
    grouped["market_value"] = grouped["market_value"].round(2)
    grouped["rating_esg"] = [
        "Premium" if score >= 78 else ("Solide" if score >= 70 else ("Neutre" if score >= 60 else "Sous surveillance"))
        for score in grouped["esg_score"]
    ]
    return grouped.reset_index(drop=True)


def build_benchmarks_csv(performance: pd.DataFrame) -> pd.DataFrame:
    """Consolidation mensuelle par mandat (CSV) : reference de comparaison."""
    portfolios = pd.DataFrame(
        [
            {"portfolio_id": f"PF-{client_id}-{suffix}", "mandate_type": mandate}
            for client_id, suffix, _name, mandate, _strategy, _aum, _inception, _template
            in PORTFOLIOS
        ]
    )
    merged = performance.merge(portfolios, on="portfolio_id", how="left")
    grouped = (
        merged.groupby(["date", "mandate_type"], as_index=False)
        .agg(
            portfolio_cum=("portfolio_cum", "mean"),
            benchmark_cum=("benchmark_cum", "mean"),
            sharpe=("sharpe", "mean"),
        )
        .sort_values(["date", "mandate_type"])
    )
    for column in ("portfolio_cum", "benchmark_cum", "sharpe"):
        grouped[column] = grouped[column].round(2)
    return grouped.reset_index(drop=True)


def build_users() -> list[dict[str, Any]]:
    users = [dict(user) for user in DEFAULT_USERS]
    users.append(
        {
            "username": "rm.lille",
            "password": "lille2026",
            "role": "user",
            "client_id": "C006",
        }
    )
    return users


# ----------------------------------------------------------------------- CLI


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Jeu de donnees PWM de demonstration.")
    parser.add_argument("--base-dir", default=str(ROOT), help="racine du projet")
    parser.add_argument("--seed", type=int, default=SEED, help="graine aleatoire")
    parser.add_argument("--format", default="parquet", choices=["parquet", "csv", "excel"], help="format des tables de gestion")
    parser.add_argument("--force", action="store_true", help="ecrase les fichiers existants")
    args = parser.parse_args(argv)

    base = Path(args.base_dir).resolve()
    data_dir = base / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)

    suffix = {"parquet": "parquet", "csv": "csv", "excel": "xlsx"}[args.format]
    tables: dict[str, pd.DataFrame] = {
        "clients": pd.DataFrame(CLIENTS),
        "portfolios": build_portfolios(rng),
    }
    holdings = build_holdings(rng, tables["portfolios"])
    tables["holdings"] = holdings
    performance = build_performance(rng, tables["portfolios"])
    tables["performance"] = performance
    tables["transactions"] = build_transactions(rng, holdings)

    for name, frame in tables.items():
        target = data_dir / f"{name}.{suffix}"
        if target.exists() and not args.force:
            print(f"  {name:<13} {target.name} existe (utilisez --force)")
            continue
        write_frame(frame, target)
        print(f"  {name:<13} {target.name:<22} {len(frame):>5} lignes")

    esg_target = data_dir / "esg_ratings.xlsx"
    if not esg_target.exists() or args.force:
        write_frame(build_esg_workbook(holdings), esg_target)
        print(f"  {'esg_ratings':<13} {esg_target.name:<22} (Excel, table annexe)")

    bench_target = data_dir / "benchmark_curves.csv"
    if not bench_target.exists() or args.force:
        write_frame(build_benchmarks_csv(performance), bench_target)
        print(f"  {'benchmarks':<13} {bench_target.name:<22} (CSV, reference)")

    users_target = data_dir / "users.json"
    users = build_users()
    if not users_target.exists() or args.force:
        users_target.write_text(
            json.dumps(users, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print(f"  {'users':<13} {users_target.name:<22} {len(users)} comptes")

    print(f"\nJeu de donnees ecrit dans {data_dir} (reference au {AS_OF.isoformat()}).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
