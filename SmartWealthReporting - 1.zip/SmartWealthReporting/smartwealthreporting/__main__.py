"""`python -m smartwealthreporting` — same CLI as the `smartwealthreporting` script."""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    main()
