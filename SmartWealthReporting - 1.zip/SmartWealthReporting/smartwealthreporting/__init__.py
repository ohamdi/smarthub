"""SmartWealthReporting — reporting Private Wealth Management piloté par IA locale.

L'architecture reprend celle de SmartPMS : configuration JSON versionnée sur disque,
dépôt de données tabular (Parquet / CSV / Excel), service IA GGUF, garde-fou de
vérification des chiffres cités, et API FastAPI qui sert une SPA statique.

Le principe directeur est le même : **le modèle ne produit aucun chiffre**. Il rédige
la narration de chaque slide à partir de faits calculés par le serveur ; le moteur de
mots-clés et le générateur PPTX remplissent tout le reste.
"""

from __future__ import annotations

__version__ = "1.0.0"

__all__ = ["__version__"]
