"""CLI : serveur web, diagnostic et génération hors interface.

Le serveur est le cas par défaut ; les sous-commandes servent à la mise en place
(`--init-templates`, `--check`) et à la production de reportings en batch
(`--generate`), avec exactement la même chaîne de calcul que l'API — un deck
généré en ligne de commande est identique à celui téléchargé depuis le navigateur.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from typing import Any

from .auth import Principal
from .config import Settings
from .errors import APIError
from .main import build_service
from .schemas import GenerateRequest

logger = logging.getLogger(__name__)

DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = 5050


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="smartwealthreporting",
        description="Serveur et outils SmartWealthReporting (reporting PWM par IA locale).",
    )
    parser.add_argument("--host", default=os.getenv("SWR_HOST", DEFAULT_HOST), help="interface d'écoute")
    parser.add_argument(
        "--port", type=int, default=int(os.getenv("SWR_PORT", str(DEFAULT_PORT))), help="port d'écoute"
    )
    parser.add_argument("--reload", action="store_true", help="rechargement à chaud (développement)")
    parser.add_argument("--base-dir", default="", help="racine du projet (défaut : dossier du package parent)")
    parser.add_argument("--log-level", default=os.getenv("SWR_LOG_LEVEL", "info"), help="niveau de log")

    parser.add_argument(
        "--list-reportings", action="store_true", help="liste les reportings détectés puis quitte"
    )
    parser.add_argument(
        "--check", action="store_true", help="contrôle datasets, reportings et moteur IA puis quitte"
    )
    parser.add_argument(
        "--init-templates",
        action="store_true",
        help="écrit un template PPTX par défaut dans chaque reporting qui n'en a pas",
    )
    parser.add_argument("--generate", metavar="REPORTING_ID", default="", help="génère un deck puis quitte")
    parser.add_argument("--client", default="", help="client_id pour la génération en ligne de commande")
    parser.add_argument("--as-of", dest="as_of", default="", help="date d'arrêté (AAAA-MM-JJ)")
    parser.add_argument("--period", default="", choices=["", "month", "quarter", "year", "ytd"], help="type de période")
    parser.add_argument("--period-label", default="", help="libellé de période affiché dans le deck")
    parser.add_argument("--output-name", default="", help="nom du fichier .pptx produit")
    parser.add_argument("--no-ai", action="store_true", help="génère sans narration IA (chiffres seuls)")
    parser.add_argument("--json", action="store_true", dest="as_json", help="sortie JSON (machine)")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, str(args.log_level).upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )
    if args.base_dir:
        os.environ["SWR_BASE_DIR"] = str(args.base_dir)
    settings = Settings.from_env()

    try:
        if args.list_reportings:
            return _list_reportings(settings, as_json=args.as_json)
        if args.check:
            return _check(settings, as_json=args.as_json)
        if args.init_templates:
            return _init_templates(settings)
        if args.generate:
            return _generate(settings, args)
    except APIError as exc:
        print(f"Erreur : {exc.message}", file=sys.stderr)
        return 2

    return _serve(args)


# ------------------------------------------------------------------ Serveur


def _serve(args: argparse.Namespace) -> int:
    import uvicorn

    uvicorn.run(
        "smartwealthreporting.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level=str(args.log_level).lower(),
    )
    return 0


# ------------------------------------------------------------------- Outils


def _list_reportings(settings: Settings, as_json: bool = False) -> int:
    service = build_service(settings)
    references = [reference.model_dump() for reference in service.library.list()]
    if as_json:
        print(json.dumps(references, ensure_ascii=False, indent=2))
        return 0
    if not references:
        print("Aucun reporting. Créez un dossier dans reportings/ avec definition.json.")
        return 0
    for reference in references:
        template = "oui" if reference["has_template"] else "NON"
        print(
            f"{reference['id']:<28} {reference['slides']:>2} slides "
            f"({reference['narrative_slides']} narrées)  prompt {reference['prompt_chars']:>5} car.  "
            f"template {template}  {reference['modified_at']}"
        )
        if reference["name"]:
            print(f"{'':<28} {reference['name']}")
    return 0


def _check(settings: Settings, as_json: bool = False) -> int:
    service = build_service(settings)
    datasets = service.datasets()
    reportings = service.reportings()
    engine = service.ai_status()
    problems = 0
    lines: list[str] = []

    for entry in datasets:
        state = "ok" if entry["exists"] else "MANQUANT"
        if not entry["exists"]:
            problems += 1
        lines.append(f"[{state:>7}] {entry['name']:<12} {entry['path']}")
        if entry["exists"]:
            lines.append(f"{'':>9} {entry['rows']:>6} lignes, {len(entry['columns'])} colonnes")

    if not reportings:
        problems += 1
        lines.append("[   ALERTE] aucun reporting dans reportings/")
    for reference in reportings:
        state = "ok" if reference["has_template"] else "SANS TPL"
        lines.append(
            f"[{state:>7}] reporting {reference['id']} — {reference['slides']} slides, "
            f"{reference['narrative_slides']} narrées"
        )

    model_state = "ok" if engine.get("available") else "INDISPONIBLE"
    if not engine.get("available"):
        problems += 1
    lines.append(f"[{model_state:>11}] modèle {engine.get('model_name') or '(non configuré)'}")
    if engine.get("error"):
        lines.append(f"{'':>13} {engine['error']}")

    if as_json:
        print(
            json.dumps(
                {
                    "datasets": datasets,
                    "reportings": reportings,
                    "engine": engine,
                    "problems": problems,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    else:
        print("\n".join(lines))
        print(f"\n{problems} point(s) d'attention." if problems else "\nTout est en place.")
    return 0 if problems == 0 else 1


def _init_templates(settings: Settings) -> int:
    service = build_service(settings)
    identifiers = service.library.ids()
    if not identifiers:
        print("Aucun reporting : rien à initialiser.")
        return 0
    written = 0
    for identifier in identifiers:
        if service.library.has_template(identifier):
            print(f"  {identifier:<28} template existant, conservé")
            continue
        path = service.install_template(identifier)
        print(f"  {identifier:<28} template écrit : {path}")
        written += 1
    print(f"{written} template(s) créé(s), {len(identifiers) - written} conservé(s).")
    return 0


def _generate(settings: Settings, args: argparse.Namespace) -> int:
    service = build_service(settings)
    principal = Principal(username="cli", role="admin", client_id="")
    request = GenerateRequest(
        client_id=args.client,
        as_of=args.as_of,
        period=args.period or None,
        period_label=args.period_label,
        output_name=args.output_name,
        use_ai=not args.no_ai,
    )
    response = service.generate(args.generate, principal, request)

    if args.as_json:
        print(json.dumps(response.model_dump(), ensure_ascii=False, indent=2, default=str))
        return 0 if response.ok else 1

    target = service.output_path(response.reporting_id, response.filename)
    print(f"Reporting   : {response.reporting_id}")
    print(f"Client      : {response.client_id or '(tous)'}")
    print(f"Periode     : {response.period_label} au {response.as_of}")
    print(f"Fichier     : {target}")
    print(f"Duree       : {response.elapsed_seconds}s")
    narrated = sum(1 for slide in response.slides if slide.narrative_source == "ia")
    print(f"Slides      : {len(response.slides)} ({narrated} narrées par l'IA)")
    for slide in response.slides:
        flag = "IA " if slide.narrative_source == "ia" else f"({slide.narrative_source[:3]})"
        print(f"  - {flag} {slide.id:<22} {slide.title[:48]}")
        if slide.verification and not slide.verification.ok:
            print(f"      verification : {slide.verification.warning}")
    for warning in response.warnings:
        print(f"  ! {warning}")
    return 0 if response.ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
