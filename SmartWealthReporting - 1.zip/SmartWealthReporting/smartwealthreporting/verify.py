"""Garde-fou numérique : ce que la narration cite, ce que les faits contiennent.

`ok` ne signifie pas que la narration est juste — seulement que chaque montant
significatif cité se retrouve dans le contexte réellement envoyé au modèle. Un
modèle local hallucine facilement un « 1,8 % de rendement » crédible ; ce
contrôle le rend visible dans l'interface avant diffusion au client.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Iterable

#: Un nombre : signe optionnel, chiffres, séparateurs (français ou anglo-saxon),
#: marqueur de pourcentage et éventuel suffixe d'échelle (k, M, mds, Md).
NUMERIC_PATTERN = re.compile(
    r"[+-]?\d[\d\s\u00a0\u202f.,]*(?:[kKmM]\b)?\s*%?"
)

#: Multiplicateurs des suffixes d'échelle.
SCALES: dict[str, float] = {
    "k": 1_000.0,
    "m": 1_000_000.0,
    "md": 1_000_000.0,
    "bn": 1_000_000_000.0,
}

#: En dessous de ce seuil, un nombre entier est trop banal pour être un indice
#: d'hallucination (« 3 positions », « 2raftes ») : il n'est pas contrôlé.
SIGNIFICANT_THRESHOLD = 1000

#: Tolérance d'arrondi pour les montants écrits en abrégé (« 12,5 M€ »).
APPROX_ROUNDINGS = (2, 3)


@dataclass
class NumericRegistry:
    """Nombres présents dans le contexte, sous forme canonique."""

    exact: set[str] = field(default_factory=set)
    approx: set[str] = field(default_factory=set)

    def known(self, canonical: str) -> bool:
        if canonical in self.exact:
            return True
        return canonical in self.approx


def build_registry(context_text: str) -> NumericRegistry:
    """Indexe tous les nombres du contexte, y compris leurs formes arrondies."""
    registry = NumericRegistry()
    for value in _numeric_values(context_text):
        for decimals in (0, 1, 2, 3):
            registry.exact.add(_canonical(value, decimals))
            registry.exact.add(_canonical(-value, decimals))
        for digits in APPROX_ROUNDINGS:
            registry.approx.add(_canonical(value, digits, round_half=True))
            registry.approx.add(_canonical(-value, digits, round_half=True))
    return registry


def check(
    narrative: str,
    registry: NumericRegistry,
    *,
    max_reported: int = 8,
    allowed: Iterable[str] = (),
) -> dict[str, Any]:
    """Confronte les nombres cités par la narration au contexte envoyé."""
    permitted = {str(value) for value in allowed}
    unverified: list[dict[str, Any]] = []
    checked = 0
    seen: set[str] = set()
    for raw in extract_numbers(narrative):
        canonical = _canonical_value(raw)
        if canonical is None or canonical in seen:
            continue
        seen.add(canonical)
        checked += 1
        if registry.known(canonical) or canonical in permitted:
            continue
        if len(unverified) < max_reported:
            unverified.append({"value": raw, "canonical": canonical})
    return {
        "ok": not unverified,
        "numbers_checked": checked,
        "unverified_numbers": unverified,
        "warning": "",
    }


def warning(result: dict[str, Any]) -> str:
    """Message affiché à l'utilisateur quand la vérification échoue."""
    if result.get("ok", True):
        return ""
    values = ", ".join(
        str(item.get("value", "")).strip() for item in result.get("unverified_numbers", [])
    )
    return (
        f"{len(result.get('unverified_numbers', []))} valeur(s) citée(s) ne figurent pas dans "
        f"les faits calculés ({values}). À relire avant diffusion."
    )


def extract_numbers(text: str) -> list[str]:
    """Nombres d'un texte, sortie brute (utilisé par l'interface de diagnostic)."""
    return [match.group(0).strip() for match in NUMERIC_PATTERN.finditer(str(text or ""))]


def _numeric_values(text: str) -> list[float]:
    values: list[float] = []
    for token in NUMERIC_PATTERN.findall(str(text or "")):
        value = _parse(token)
        if value is not None:
            values.append(value)
    return values


def _parse(token: str) -> float | None:
    """Valeur numérique d'un token, avec son suffixe d'échelle éventuel."""
    cleaned = str(token or "").replace("\u00a0", " ").replace("\u202f", " ")
    cleaned = cleaned.strip()
    scale = 1.0
    suffix = re.search(r"([kK]|[mM][dD]?|[bB][nN])\s*$", cleaned)
    if suffix:
        scale = SCALES.get(suffix.group(1).lower(), 1.0)
        cleaned = cleaned[: suffix.start()].strip()
    cleaned = cleaned.rstrip("%").strip()
    negative = cleaned.startswith("-")
    cleaned = cleaned.lstrip("+-")
    # Les séparateurs français et anglo-saxons sont confondus : le token « 1 234,56 »
    # et le token « 1,234.56 » doivent donner la même valeur.
    digits = re.sub(r"[^\d]", "", cleaned)
    if not digits:
        return None
    value = float(digits) * scale
    return -value if negative else value


def _canonical_value(token: str) -> str | None:
    value = _parse(token)
    if value is None:
        return None
    canonical = _canonical(value, 2)
    # Un entier banal (« 3 positions ») n'est pas un indice d'hallucination.
    if abs(value) < SIGNIFICANT_THRESHOLD and canonical.isdigit():
        return None
    return canonical


def _canonical(value: float, decimals: int, *, round_half: bool = False) -> str:
    """Forme canonique : point décimal, pas de séparateur de milliers.

    `round_half` arrondit à un nombre de chiffres significatifs donné
    (12 456 789 → 12 000 000 à 2 chiffres), ce qui autorise les montants
    écrits en abrégé dans la narration (« 12 M€ »).
    """
    if round_half:
        value = _round_significant(value, decimals)
    text = f"{abs(value):.{decimals}f}"
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    if text in {"", "-"}:
        text = "0"
    sign = "-" if value < 0 and text != "0" else ""
    return f"{sign}{text}"


def _round_significant(value: float, digits: int) -> float:
    if value == 0:
        return 0.0
    # `factor` place la première chiffre significative sur l'unité : arrondir à
    # `digits` chiffres significatifs revient alors à arrondir `value/factor`
    # au chiffre le plus proche (12 456 789 → 12 000 000 pour 2 chiffres).
    exponent = math.floor(math.log10(abs(value)))
    factor = 10.0 ** (exponent - digits + 1)
    rounded = math.floor(abs(value) / factor + 0.5) * factor
    return rounded if value > 0 else -rounded
