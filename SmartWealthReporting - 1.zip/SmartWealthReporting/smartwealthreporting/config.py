from __future__ import annotations

import json
import os
import secrets
import threading
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

#: Jeux de données PWM attendus par défaut. Un nom peut pointer vers du Parquet,
#: du CSV, de l'Excel ou du JSON : le format est déduit de l'extension.
DEFAULT_DATASETS: dict[str, str] = {
    "clients": "data/clients.parquet",
    "portfolios": "data/portfolios.parquet",
    "holdings": "data/holdings.parquet",
    "performance": "data/performance.parquet",
    "transactions": "data/transactions.parquet",
    "users": "data/users.json",
}

#: Extensions acceptées par le dépôt de données.
SUPPORTED_SUFFIXES = (".parquet", ".csv", ".xlsx", ".xlsm", ".json")

#: Clés de `datasource_config.json` qui décrivent le moteur IA, pas une table.
LLM_KEYS = frozenset(
    {"llm_backend", "gguf_path", "llamafile_path", "llamafile_port", "llamafile_url"}
)

DEFAULT_LLM_SETTINGS: dict[str, Any] = {
    "llm_backend": "gguf",
    "gguf_path": "",
    "llamafile_path": "",
    "llamafile_port": 8080,
    "llamafile_url": "http://localhost:8080",
}


class DataSourceConfig:
    """Configuration JSON des sources de données et du moteur IA.

    Un seul fichier (`datasource_config.json`) porte les chemins, comme dans SmartPMS :
    ce sont des chemins de fichiers, éditables depuis l'onglet Data de l'interface.
    Les paramètres de génération (temperature, n_ctx…) restent dans `ai_config.json`.
    """

    def __init__(self, base_dir: Path, config_path: Path | None = None) -> None:
        self.base_dir = base_dir.resolve()
        self.path = (config_path or self.base_dir / "datasource_config.json").resolve()
        self._lock = threading.RLock()

    # ------------------------------------------------------------------ JSON

    def load(self) -> dict[str, Any]:
        with self._lock:
            try:
                with self.path.open("r", encoding="utf-8") as file:
                    data = json.load(file)
                return data if isinstance(data, dict) else {}
            except (FileNotFoundError, json.JSONDecodeError, OSError):
                return {}

    def save(self, data: dict[str, Any]) -> None:
        if not isinstance(data, dict):
            raise ValueError("La configuration doit être un objet JSON.")
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temp_path = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
            try:
                with temp_path.open("w", encoding="utf-8") as file:
                    json.dump(data, file, ensure_ascii=False, indent=2)
                    file.write("\n")
                os.replace(temp_path, self.path)
            finally:
                temp_path.unlink(missing_ok=True)

    def update(self, values: dict[str, Any]) -> dict[str, Any]:
        """Fusionne `values` dans la configuration et persiste le résultat."""
        current = self.load()
        for key, value in values.items():
            if value is None:
                continue
            current[key] = value
        self.save(current)
        return current

    # ------------------------------------------------------------- Datasets

    def resolve(self, value: str) -> Path:
        candidate = Path(str(value)).expanduser()
        if not candidate.is_absolute():
            candidate = self.base_dir / candidate
        return candidate.resolve()

    def dataset_paths(self) -> dict[str, str]:
        """Nom logique → chemin configuré, avec les défauts pour ce qui manque."""
        stored = self.load()
        paths: dict[str, str] = {}
        for name, default in DEFAULT_DATASETS.items():
            configured = str(stored.get(name) or "").strip()
            paths[name] = configured or default
        # Datasets additionnels déclarés dans le fichier : rien n'est caché, mais
        # les réglages du moteur IA ne sont pas des chemins de données.
        for key, value in stored.items():
            if key in DEFAULT_DATASETS or key in LLM_KEYS:
                continue
            if isinstance(value, str) and value.strip():
                paths[key] = value.strip()
        return paths

    def dataset_path(self, name: str) -> Path:
        paths = self.dataset_paths()
        if name not in paths:
            raise KeyError(f"Unknown datasource: {name}")
        return self.resolve(paths[name])

    # ------------------------------------------------------------------ LLM

    def llm_settings(self) -> dict[str, Any]:
        raw = self.load()
        settings = {**DEFAULT_LLM_SETTINGS, **raw}
        try:
            settings["llamafile_port"] = int(settings.get("llamafile_port", 8080))
        except (TypeError, ValueError):
            settings["llamafile_port"] = 8080
        settings["llamafile_url"] = str(
            settings.get("llamafile_url") or f"http://localhost:{settings['llamafile_port']}"
        ).rstrip("/")
        for key in ("gguf_path", "llamafile_path"):
            value = settings.get(key)
            settings[key] = str(self.resolve(value)) if value else ""
        settings["llm_backend"] = (
            "llamafile" if str(settings.get("llm_backend")) == "llamafile" else "gguf"
        )
        return settings

    def fingerprint(self) -> tuple[Any, ...]:
        llm = self.llm_settings()
        return (
            llm.get("llm_backend"),
            llm.get("gguf_path"),
            llm.get("llamafile_path"),
            llm.get("llamafile_port"),
            llm.get("llamafile_url"),
        )


@dataclass(frozen=True)
class Settings:
    base_dir: Path
    config_path: Path
    session_secret: str
    session_max_age: int = 8 * 60 * 60
    cookie_secure: bool = False
    auto_start_llamafile: bool = True

    @classmethod
    def from_env(cls) -> "Settings":
        base_dir = Path(
            os.getenv("SWR_BASE_DIR", Path(__file__).resolve().parent.parent)
        ).resolve()
        config_path = Path(
            os.getenv("SWR_CONFIG_PATH", base_dir / "datasource_config.json")
        ).resolve()
        return cls(
            base_dir=base_dir,
            config_path=config_path,
            session_secret=os.getenv("SWR_SECRET_KEY") or secrets.token_hex(32),
            session_max_age=max_age_seconds(),
            cookie_secure=env_flag("SWR_COOKIE_SECURE", False),
            auto_start_llamafile=env_flag("SWR_AUTO_START_LLAMAFILE", True),
        )

    @property
    def static_dir(self) -> Path:
        return self.base_dir / "static"

    @property
    def reportings_dir(self) -> Path:
        return self.base_dir / "reportings"

    @property
    def outputs_dir(self) -> Path:
        return self.base_dir / "outputs"


def env_flag(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def max_age_seconds() -> int:
    try:
        return int(os.getenv("SWR_SESSION_MAX_AGE", str(8 * 60 * 60)))
    except ValueError:
        return 8 * 60 * 60
