"""Point d'entrée FastAPI : câblage des composants et gestion des erreurs.

`create_app()` assemble l'objet applicatif à partir de trois objets seulement —
configuration, dépôt de données et bibliothèque de reportings — ce qui permet
aux tests de construire une application isolée avec ses propres données.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, Response
from starlette.concurrency import run_in_threadpool
from starlette.middleware.sessions import SessionMiddleware

from .config import DataSourceConfig, Settings
from .errors import APIError
from .llm import LLMService
from .metrics import MetricsEngine
from .reportings import ReportingLibrary
from .routes import router
from .services import ApplicationService
from .storage import DatasetRepository

logger = logging.getLogger(__name__)


def build_service(settings: Settings) -> ApplicationService:
    """Construit la chaîne complète : config → dépôt → reportings → métriques → IA."""
    config = DataSourceConfig(settings.base_dir, settings.config_path)
    repository = DatasetRepository(config)
    library = ReportingLibrary(settings.base_dir)
    metrics = MetricsEngine(repository=repository)
    service = ApplicationService(settings, config, repository, library, metrics)
    service.llm = LLMService(config)
    return service


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or Settings.from_env()
    service = build_service(app_settings)

    @asynccontextmanager
    async def lifespan(_application: FastAPI) -> AsyncIterator[None]:
        # Le modèle n'est pas chargé au démarrage : le premier reporting le
        # déclenche, et le warmup explicite absorbe ce coût quand on l'anticipe.
        if app_settings.auto_start_llamafile and service.llm is not None:
            await run_in_threadpool(service.llm.start_llamafile)
        logger.info(
            "SmartWealthReporting prêt — base=%s reportings=%s",
            app_settings.base_dir,
            service.library.ids() or "aucun",
        )
        yield
        # `llm` peut avoir été détaché (tests, mode données seules) : l'arrêt du
        # serveur Llamafile ne doit pas dépendre de l'IA pour fermer l'application.
        if service.llm is not None:
            await run_in_threadpool(service.llm.stop_llamafile)

    application = FastAPI(
        title="SmartWealthReporting API",
        version="1.0.0",
        description=(
            "Reporting Private Wealth Management piloté par IA locale. "
            "Le serveur calcule tous les chiffres, le modèle local rédige "
            "uniquement les commentaires, et le PPTX est rendu depuis un template."
        ),
        lifespan=lifespan,
    )
    application.state.settings = app_settings
    application.state.config = service.config
    application.state.repository = service.repository
    application.state.library = service.library
    application.state.llm = service.llm
    application.state.service = service

    application.add_middleware(
        SessionMiddleware,
        secret_key=app_settings.session_secret,
        max_age=app_settings.session_max_age,
        same_site="lax",
        https_only=app_settings.cookie_secure,
    )

    @application.exception_handler(APIError)
    async def api_error_handler(_request: Request, exc: APIError) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content=exc.payload())

    @application.exception_handler(RequestValidationError)
    async def validation_error_handler(
        _request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        message = "; ".join(
            f"{'.'.join(str(part) for part in error['loc'][1:])}: {error['msg']}"
            for error in exc.errors()
        )
        return JSONResponse(status_code=422, content={"error": message or "Requete invalide"})

    @application.get("/health", tags=["system"])
    async def health() -> dict[str, object]:
        return {
            "status": "ok",
            "version": application.version,
            "datasets": len(service.config.dataset_paths()),
            "reportings": len(service.library.ids()),
        }

    application.include_router(router)

    def not_found(message: str) -> JSONResponse:
        """404 du contrat applicatif : le corps reste `{"error": ...}`."""
        return JSONResponse(status_code=404, content={"error": message})

    @application.get("/{full_path:path}", include_in_schema=False)
    async def frontend(full_path: str) -> Response:
        """SPA mono-page : toute route inconnue retombe sur index.html."""
        if full_path.startswith("api/"):
            return not_found("API route not found")
        static_dir = app_settings.static_dir.resolve()
        candidate = (static_dir / full_path).resolve()
        try:
            candidate.relative_to(static_dir)
        except ValueError:
            return not_found("Not found")
        if candidate.is_file():
            return FileResponse(candidate)
        index = static_dir / "index.html"
        if not index.is_file():
            return not_found("Frontend not found")
        return FileResponse(index)

    return application


app = create_app()
