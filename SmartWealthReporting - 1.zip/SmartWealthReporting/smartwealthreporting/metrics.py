"""Calcul des faits chiffrés du reporting.

Règle fondatrice du produit : **aucun chiffre ne vient du modèle**. Tout ce qui
apparaît dans une slide est calculé ici, à partir des datasets, de façon
déterministe et traçable. Le module IA ne reçoit que le résultat de ces calculs
pour rédiger la narration.

Chaque fonction est pure : mêmes données + même périmètre ⇒ mêmes chiffres, ce
qui rend les tests et les re-runs reproductibles.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any, Iterable, Sequence

import pandas as pd

from .context import format_number, format_signed
from .storage import DatasetRepository

logger = logging.getLogger(__name__)

#: Pondération d'une répartition. En dessous, la catégorie est repliée dans
#: « Autres » : au-delà de 12 tranches un camembert devient illisible.
ALLOCATION_SLICES = 12

#: Seuils des alertes de concentration, en % de l'actif.
CONCENTRATION_WARN = 25.0
CONCENTRATION_ALERT = 35.0
CASH_DRAG_WARN = 10.0

_POSITIVE_COLUMNS = {
    "market_value",
    "weight",
    "quantity",
    "price",
    "cost_basis",
    "pnl_unrealised",
    "realised_pnl",
    "income",
    "amount",
    "esg_score",
    "yield",
    "coupon",
}


@dataclass(frozen=True)
class ReportScope:
    """Périmètre d'un reporting : un client, éventuellement quelques portefeuilles."""

    client_id: str = ""
    portfolio_ids: tuple[str, ...] = ()
    as_of: str = ""
    period_label: str = ""
    period: str = "ytd"

    @property
    def is_client_scoped(self) -> bool:
        return bool(self.client_id)


@dataclass
class MetricsEngine:
    """Construit le dictionnaire de faits à partir des datasets PWM."""

    repository: DatasetRepository
    concentration_limit: int = field(default=10, kw_only=True)

    # ------------------------------------------------------------ Entrées

    def client(self, scope: ReportScope) -> dict[str, Any]:
        if not scope.client_id:
            return {}
        frame = self.repository.frame("clients")
        if frame.empty:
            return {}
        rows = frame[frame["client_id"].astype(str) == scope.client_id] if "client_id" in frame else frame.head(0)
        if rows.empty:
            return {}
        return _clean_record(rows.iloc[0].to_dict())

    def portfolios(self, scope: ReportScope) -> pd.DataFrame:
        frame = self.repository.frame("portfolios")
        return _filter_scope(frame, scope, key_columns=("client_id", "portfolio_id"))

    def holdings(self, scope: ReportScope) -> pd.DataFrame:
        frame = self.repository.frame("holdings")
        frame = _filter_scope(frame, scope, key_columns=("client_id", "portfolio_id"))
        return _latest_positions(frame)

    def performance(self, scope: ReportScope) -> pd.DataFrame:
        """Courbes de performance du périmètre.

        La table peut être indexée par `client_id` ou ne porter que des
        `portfolio_id` : dans ce second cas, le périmètre client est résolu via
        la table des portefeuilles, sinon la courbe consolidée ressortirait vide.
        """
        frame = self.repository.frame("performance")
        if frame.empty:
            return frame
        wanted = {str(value) for value in scope.portfolio_ids if str(value)}
        if "portfolio_id" in frame and wanted:
            frame = frame[frame["portfolio_id"].astype(str).isin(wanted)]
        elif "client_id" in frame and scope.client_id:
            frame = frame[frame["client_id"].astype(str) == scope.client_id]
        elif "portfolio_id" in frame and scope.client_id:
            owned = self._portfolio_ids(scope)
            frame = frame[frame["portfolio_id"].astype(str).isin(owned)]
        return frame

    def _portfolio_ids(self, scope: ReportScope) -> set[str]:
        """Portefeuilles d'un client, déduits de la table `portfolios`."""
        frame = self.repository.frame("portfolios")
        if frame.empty or "portfolio_id" not in frame or "client_id" not in frame:
            return set()
        rows = frame[frame["client_id"].astype(str) == scope.client_id]
        return {str(value) for value in rows["portfolio_id"]}

    def transactions(self, scope: ReportScope) -> pd.DataFrame:
        frame = self.repository.frame("transactions")
        frame = _filter_scope(frame, scope, key_columns=("client_id", "portfolio_id"))
        return _within_period(frame, scope)

    # -------------------------------------------------------------- Faits

    def build(self, scope: ReportScope) -> dict[str, Any]:
        """Tous les faits du reporting, prêts pour le PPTX et pour le prompt."""
        client = self.client(scope)
        portfolios = self.portfolios(scope)
        holdings = self.holdings(scope)
        performance = self.performance(scope)
        transactions = self.transactions(scope)

        as_of = self._as_of(holdings, performance, scope)
        market_value = _sum(holdings, "market_value")
        total_cost = _sum(holdings, "cost_basis")
        cash = _cash(holdings)
        performance_facts = self._performance(performance, portfolios)
        bonds = self._bond_facts(holdings, as_of, transactions)

        facts: dict[str, Any] = {
            "client": client,
            "period": {
                "label": scope.period_label or _period_label(as_of, scope.period),
                "as_of": as_of,
                "period": scope.period,
                "base_currency": str(client.get("base_ccy", "") or "EUR"),
            },
            "kpis": {
                **self._kpis(
                    holdings, performance, transactions, performance_facts,
                    market_value, total_cost,
                ),
                **self._bond_kpis(bonds),
            },
            "allocations": {
                "asset_class": _allocation(holdings, "asset_class", "market_value"),
                "sector": _allocation(holdings, "sector", "market_value"),
                "country": _allocation(holdings, "country", "market_value"),
                "currency": _allocation(holdings, "currency", "market_value"),
                "category": _allocation(holdings, "category", "market_value"),
            },
            "performance": performance_facts,
            "bonds": bonds,
            "top_holdings": self._top_holdings(holdings, market_value),
            "pnl": self._pnl(holdings, transactions, total_cost),
            "esg": self._esg(holdings),
            "flows": self._flows(transactions),
            "activity": self._activity(transactions),
            "concentration": self._concentration(holdings),
            "portfolios": _portfolio_summary(portfolios),
        }
        facts["risks"] = self._risks(facts, market_value, cash)
        return facts

    # ------------------------------------------------------------ Blocs

    def _as_of(
        self, holdings: pd.DataFrame, performance: pd.DataFrame, scope: ReportScope
    ) -> str:
        if scope.as_of:
            return scope.as_of
        for frame, column in ((holdings, "as_of"), (performance, "date")):
            if column in frame and not frame.empty:
                value = _max_date(frame[column])
                if value:
                    return value
        return ""

    def _kpis(
        self,
        holdings: pd.DataFrame,
        performance: pd.DataFrame,
        transactions: pd.DataFrame,
        performance_facts: dict[str, Any],
        market_value: float,
        total_cost: float,
    ) -> dict[str, Any]:
        market_value = market_value or 0.0
        series = performance_facts.get("portfolio") or []
        kpis: dict[str, Any] = {
            "aum_total": market_value,
            "cost_basis": total_cost,
            "nb_positions": int(len(holdings)),
            "nb_portfolios": int(len(performance["portfolio_id"].unique()))
            if "portfolio_id" in performance and not performance.empty
            else 0,
            "cash_pct": round(_sum(holdings, "cash_value") / market_value * 100, 2)
            if market_value
            else 0.0,
            "unrealised_pct": round(_sum(holdings, "pnl_unrealised") / total_cost * 100, 2)
            if total_cost
            else 0.0,
            "yield_pct": round(_weighted_average(holdings, "yield", "market_value"), 2),
            "portfolio_cum_return": round(performance_facts.get("portfolio_total") or 0.0, 2),
            "benchmark_cum_return": round(performance_facts.get("benchmark_total") or 0.0, 2),
            "alpha": round(
                (performance_facts.get("portfolio_total") or 0.0)
                - (performance_facts.get("benchmark_total") or 0.0),
                2,
            ),
            "volatility": round(performance_facts.get("volatility") or 0.0, 2),
            "sharpe": round(performance_facts.get("sharpe") or 0.0, 2),
            "max_drawdown": round(performance_facts.get("max_drawdown") or 0.0, 2),
            "last_period_return": round(series[-1], 2) if series else 0.0,
            "nb_transactions": int(len(transactions)),
        }
        kpis["transactions_amount"] = round(
            float(transactions["amount"].abs().sum()) if "amount" in transactions else 0.0, 2
        )
        return kpis

    def _bond_kpis(self, bonds: dict[str, Any]) -> dict[str, Any]:
        """KPI obligataires exposés à plat, pour les slides de synthèse.

        Le rapport de gestion les affiche tels quels : TRA moyen, vie moyenne,
        sensibilité, notation moyenne, poids investment grade et haut rendement,
        nombre d'émetteurs, poids des non notés, coupons encaissés et estimés.
        """
        return {
            "bond_total": bonds["bond_total"],
            "bond_pct": bonds["bond_pct"],
            "cash_total": bonds["cash_total"],
            "tra_pct": bonds["tra_pct"],
            "life_years": bonds["life_years"],
            "duration_years": bonds["duration_years"],
            "sensitivity": bonds["sensitivity"],
            "rating_average": bonds["rating_average"],
            "investment_grade_pct": bonds["investment_grade_pct"],
            "high_yield_pct": bonds["high_yield_pct"],
            "unrated_pct": bonds["unrated_pct"],
            "nb_issuers": bonds["nb_issuers"],
            "nb_bonds": bonds["nb_bonds"],
            "coupons_received": bonds["coupons_received"],
            "coupons_expected": bonds["coupons_expected"],
        }

    def _performance(self, frame: pd.DataFrame, portfolios: pd.DataFrame) -> dict[str, Any]:
        """Série mensuelle agrégée, pondérée par l'encours de chaque portefeuille.

        La pondération évite qu'un petit portefeuille fasse dévier la courbe
        consolidée ; en l'absence de colonnes d'encours, la moyenne simple est
        utilisée et signalée par `weighted=False`.

        Volatilité, Sharpe et drawdown suivent la même logique : voir
        `_risk_measures`.
        """
        empty = {
            "labels": [],
            "portfolio": [],
            "benchmark": [],
            "portfolio_total": 0.0,
            "benchmark_total": 0.0,
            "volatility": 0.0,
            "sharpe": 0.0,
            "max_drawdown": 0.0,
            "weighted": False,
        }
        if frame.empty or "date" not in frame:
            return empty

        work = frame.copy()
        work["date"] = pd.to_datetime(work["date"], errors="coerce")
        work = work.dropna(subset=["date"]).sort_values("date")
        if work.empty:
            return empty

        weights = None
        if "aum" in work and portfolios is not None and "portfolio_id" in portfolios:
            aum = portfolios.groupby("portfolio_id")["aum"].sum() if "aum" in portfolios else None
            if aum is not None and not aum.empty and "portfolio_id" in work:
                work["_weight"] = work["portfolio_id"].map(aum)
                if work["_weight"].notna().any() and work["_weight"].sum() > 0:
                    weights = "_weight"

        portfolio = _aggregate_curve(work, "portfolio_cum", weights)
        benchmark = _aggregate_curve(work, "benchmark_cum", weights)
        # Les étiquettes suivent l'agrégation par date, pas les lignes du dataset :
        # avec plusieurs portefeuilles, une étiquette par ligne produirait un axe
        # de_categories deux fois trop long que les séries.
        grouped_dates = sorted({stamp for stamp in work["date"].tolist()})
        labels = [_month_label(value) for value in grouped_dates]
        series_length = min(
            [len(values) for values in (portfolio, benchmark) if values] or [0]
        )
        if series_length and series_length != len(labels):
            # Défense supplémentaire : un graphique PPTX refuse des séries de
            # longueurs différentes et échouerait la génération entière.
            labels = labels[-series_length:] if len(labels) > series_length else labels
            portfolio = portfolio[: len(labels)]
            benchmark = benchmark[: len(labels)]
        tail = work.tail(1).iloc[0]
        return {
            "labels": labels,
            "portfolio": portfolio,
            "benchmark": benchmark,
            "portfolio_total": round(_last_or_zero(portfolio), 2),
            "benchmark_total": round(_last_or_zero(benchmark), 2),
            **_risk_measures(work, portfolio),
            "weighted": weights is not None,
            "as_of": tail["date"].strftime("%Y-%m-%d") if hasattr(tail["date"], "strftime") else "",
        }

    def _top_holdings(self, holdings: pd.DataFrame, market_value: float) -> list[dict[str, Any]]:
        if holdings.empty:
            return []
        limit = max(1, int(self.concentration_limit))
        work = holdings.copy()
        work["market_value"] = _to_float_series(work, "market_value")
        work = work.sort_values("market_value", ascending=False).head(limit)
        rows: list[dict[str, Any]] = []
        for record in work.to_dict("records"):
            value = _to_float(record.get("market_value"))
            cost = _to_float(record.get("cost_basis"))
            rows.append(
                {
                    "instrument": str(record.get("instrument_name", "") or "—"),
                    "isin": str(record.get("isin", "") or "—"),
                    "asset_class": str(record.get("asset_class", "") or "—"),
                    "category": str(record.get("category", "") or "—"),
                    "sector": str(record.get("sector", "") or "—"),
                    "country": str(record.get("country", "") or "—"),
                    "currency": str(record.get("currency", "") or "—"),
                    "rating": str(record.get("rating", "") or "—"),
                    "market_value": round(value, 2),
                    "weight": round(value / market_value * 100, 2) if market_value else 0.0,
                    "pnl_pct": round(_to_float(record.get("pnl_unrealised")) / cost * 100, 2)
                    if cost
                    else 0.0,
                    "yield": round(_to_float(record.get("yield")), 2),
                    "esg_score": round(_to_float(record.get("esg_score")), 1),
                }
            )
        return rows

    def _pnl(
        self, holdings: pd.DataFrame, transactions: pd.DataFrame, total_cost: float
    ) -> dict[str, Any]:
        unrealised = _sum(holdings, "pnl_unrealised")
        realised = _sum(transactions, "realised_pnl")
        income = _sum(transactions, "income")
        fees = abs(_sum(transactions, "fees"))
        best = _best_position(holdings)
        worst = _worst_position(holdings)
        return {
            "unrealised_pnl": round(unrealised, 2),
            "unrealised_pct": round(unrealised / total_cost * 100, 2) if total_cost else 0.0,
            "realised_pnl": round(realised, 2),
            "income": round(income, 2),
            "fees": round(fees, 2),
            "net_pnl": round(unrealised + realised + income - fees, 2),
            "best": best,
            "worst": worst,
        }

    def _esg(self, holdings: pd.DataFrame) -> dict[str, Any]:
        if holdings.empty:
            return {"score": 0.0, "e": 0.0, "s": 0.0, "g": 0.0, "coverage_pct": 0.0}
        total = _sum(holdings, "market_value")
        covered = holdings[_to_float_series(holdings, "esg_score") > 0]
        covered_value = _sum(covered, "market_value")
        return {
            "score": round(_weighted_average(covered, "esg_score", "market_value"), 1),
            "e": round(_weighted_average(covered, "esg_e", "market_value"), 1),
            "s": round(_weighted_average(covered, "esg_s", "market_value"), 1),
            "g": round(_weighted_average(covered, "esg_g", "market_value"), 1),
            "coverage_pct": round(covered_value / total * 100, 1) if total else 0.0,
        }

    def _flows(self, transactions: pd.DataFrame) -> dict[str, Any]:
        flows = {"deposits": 0.0, "withdrawals": 0.0, "net": 0.0, "dividends": 0.0,
                 "interest": 0.0, "fees": 0.0, "subscriptions": 0, "redemptions": 0}
        if transactions.empty or "transaction_type" not in transactions:
            return {key: (round(value, 2) if isinstance(value, float) else value)
                    for key, value in flows.items()}
        amounts = _to_float_series(transactions, "amount")
        types = transactions["transaction_type"].astype(str).str.upper()
        for kind in ("DEPOSIT", "SUBSCRIPTION", "TRANSFER_IN"):
            flows["deposits"] += float(amounts[types == kind].sum())
            flows["subscriptions"] += int((types == kind).sum())
        for kind in ("WITHDRAWAL", "REDEMPTION", "TRANSFER_OUT"):
            flows["withdrawals"] += abs(float(amounts[types == kind].sum()))
            flows["redemptions"] += int((types == kind).sum())
        flows["dividends"] = round(float(amounts[types == "DIVIDEND"].sum()), 2)
        flows["interest"] = round(float(amounts[types == "INTEREST"].sum()), 2)
        flows["fees"] = round(abs(float(amounts[types == "FEE"].sum())), 2)
        flows["deposits"] = round(flows["deposits"], 2)
        flows["withdrawals"] = round(flows["withdrawals"], 2)
        flows["net"] = round(flows["deposits"] - flows["withdrawals"], 2)
        return flows

    def _activity(self, transactions: pd.DataFrame) -> dict[str, Any]:
        if transactions.empty:
            return {"trades": 0, "dividends": 0, "last_trade": "", "avg_trade_size": 0.0,
                    "buy_count": 0, "sell_count": 0}
        types = transactions["transaction_type"].astype(str).str.upper()
        trades = types.isin(["BUY", "SELL"])
        amounts = _to_float_series(transactions, "amount")
        return {
            "trades": int(trades.sum()),
            "buy_count": int((types == "BUY").sum()),
            "sell_count": int((types == "SELL").sum()),
            "dividends": int((types == "DIVIDEND").sum()),
            "last_trade": _max_date(transactions["trade_date"]) if "trade_date" in transactions else "",
            "avg_trade_size": round(float(amounts[trades].abs().mean()), 2) if trades.any() else 0.0,
        }

    def _concentration(self, holdings: pd.DataFrame) -> dict[str, Any]:
        if holdings.empty:
            return {"top5_pct": 0.0, "top10_pct": 0.0, "largest_position": "—",
                    "largest_weight_pct": 0.0, "nb_positions": 0}
        values = _to_float_series(holdings, "market_value").sort_values(ascending=False)
        total = float(values.sum()) or 0.0
        labels = holdings.assign(_mv=_to_float_series(holdings, "market_value"))
        labels = labels.sort_values("_mv", ascending=False)
        largest = str(labels.iloc[0].get("instrument_name", "") or "—") if len(labels) else "—"
        return {
            "top5_pct": round(float(values.head(5).sum()) / total * 100, 2) if total else 0.0,
            "top10_pct": round(float(values.head(10).sum()) / total * 100, 2) if total else 0.0,
            "largest_position": largest,
            "largest_weight_pct": round(float(values.iloc[0]) / total * 100, 2) if total else 0.0,
            "nb_positions": int(len(values)),
        }

    def _bond_facts(
        self, holdings: pd.DataFrame, as_of: str, transactions: pd.DataFrame
    ) -> dict[str, Any]:
        """Indicateurs obligataires d'un rapport de gestion.

        La lecture est celle d'un reporting obligataire classique : pondération
        par encours pour le TRA et la sensibilité, classement des notations,
        répartition par tranche de maturité. Une ligne sans `issuer` (action,
        fonds, monétaire) n'entre dans aucun de ces calculs.
        """
        total = _sum(holdings, "market_value")
        bonds = _bond_rows(holdings)
        bond_total = _sum(bonds, "market_value")
        cash_total = _sum(holdings, "cash_value")

        duration = _weighted_average(bonds, "mod_duration", "market_value") if "mod_duration" in bonds else 0.0
        grade = _rating_average(bonds, bond_total)
        coupons_received = _coupon_income(transactions)
        coupons_expected = 0.0
        if not bonds.empty and "coupon" in bonds and bond_total:
            coupons_expected = round(
                float((_to_float_series(bonds, "coupon") / 100.0 * _to_float_series(bonds, "market_value")).sum()),
                2,
            )
        return {
            "bond_total": round(bond_total, 2),
            "bond_pct": round(bond_total / total * 100, 2) if total else 0.0,
            "cash_total": round(max(cash_total, 0.0), 2),
            "cash_pct_of_total": round(cash_total / total * 100, 2) if total else 0.0,
            "tra_pct": round(_weighted_average(bonds, "yield", "market_value"), 2)
            if not bonds.empty
            else 0.0,
            "life_years": round(_years_to_maturity(bonds, as_of), 2),
            "duration_years": round(duration, 2),
            "sensitivity": round(duration, 2),
            "rating_average": grade["label"],
            "rating_average_rank": grade["rank"],
            "investment_grade_pct": grade["investment_grade_pct"],
            "high_yield_pct": grade["high_yield_pct"],
            "unrated_pct": grade["unrated_pct"],
            "nb_issuers": int(bonds["issuer"].nunique()) if "issuer" in bonds else 0,
            "nb_bonds": int(len(bonds)),
            "coupons_received": round(coupons_received, 2),
            "coupons_expected": coupons_expected,
            "ratings": _rating_distribution(bonds, bond_total),
            "maturities": _maturity_distribution(bonds, bond_total, as_of),
            "issuers": _issuer_ranking(bonds, bond_total),
            "categories": _allocation(bonds, "category", "market_value"),
            "sectors": _allocation(bonds, "sector", "market_value"),
            "countries": _allocation(bonds, "country", "market_value"),
            "positions": _bond_positions(bonds, total, bond_total),
            "totals": _bond_totals(bonds, total),
            "coupons": _coupon_lines(coupons_received, coupons_expected),
            "rating_scale": [dict(row) for row in RATING_CORRESPONDENCE],
        }

    def _risks(self, facts: dict[str, Any], market_value: float, cash: float) -> list[dict[str, Any]]:
        """Points de vigilance : ce que le serveur constate, pas ce que le modèle pense.

        Les chiffres sont mis en forme à la française (virgule décimale) comme
        le reste du deck : un `34.7 %` au milieu d'un slide français se voit.
        """
        risks: list[dict[str, Any]] = []
        concentration = facts["concentration"]
        if concentration["top5_pct"] >= CONCENTRATION_ALERT:
            level = "high"
        elif concentration["top5_pct"] >= CONCENTRATION_WARN:
            level = "medium"
        else:
            level = "low"
        risks.append(
            {
                "code": "concentration",
                "level": level,
                "label": "Concentration",
                "detail": (
                    f"Les 5 premières positions pèsent "
                    f"{_fr(concentration['top5_pct'], 1)} % de l'actif ; la plus lourde, "
                    f"{concentration['largest_position']}, "
                    f"{_fr(concentration['largest_weight_pct'], 1)} %."
                ),
            }
        )
        cash_pct = (cash / market_value * 100) if market_value else 0.0
        risks.append(
            {
                "code": "cash",
                "level": "medium" if cash_pct >= CASH_DRAG_WARN else "low",
                "label": "Trésorerie",
                "detail": f"La trésorerie représente {_fr(cash_pct, 1)} % de l'actif net.",
            }
        )
        kpis = facts["kpis"]
        risks.append(
            {
                "code": "performance",
                "level": "high" if kpis["alpha"] <= -3 else ("medium" if kpis["alpha"] < 0 else "low"),
                "label": "Performance relative",
                "detail": (
                    f"Le portefeuille affiche {_fr(kpis['portfolio_cum_return'], 2, signed=True)} % contre "
                    f"{_fr(kpis['benchmark_cum_return'], 2, signed=True)} % pour le benchmark, "
                    f"soit {_fr(kpis['alpha'], 2, signed=True)} points."
                ),
            }
        )
        risks.append(
            {
                "code": "esg",
                "level": "medium" if facts["esg"]["coverage_pct"] < 60 else "low",
                "label": "Couverture ESG",
                "detail": (
                    f"{_fr(facts['esg']['coverage_pct'], 0)} % de l'actif est noté, "
                    f"score moyen {_fr(facts['esg']['score'], 1)}/100."
                ),
            }
        )
        return risks


# --------------------------------------------------------------------- Outils


def _to_float(value: Any) -> float:
    if value is None:
        return 0.0
    if isinstance(value, bool):
        return 0.0
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0.0
    return number if math.isfinite(number) else 0.0


def _to_float_series(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        return pd.Series([0.0] * len(frame), index=frame.index, dtype="float64")
    return pd.to_numeric(frame[column], errors="coerce").fillna(0.0).astype("float64")


def _sum(frame: pd.DataFrame, column: str) -> float:
    if frame.empty or column not in frame:
        return 0.0
    return float(_to_float_series(frame, column).sum())


def _label(value: Any, default: str = "—") -> str:
    """Libellé lisible d'une valeur de dataset.

    pandas représente une cellule vide par `NaN` : `str(nan)` rendrait « nan »
    dans un tableau client. Toute valeur vide — `None`, `NaN`, chaîne blanche —
    prend donc la valeur de repli.
    """
    if value is None:
        return default
    text = str(value).strip()
    if not text or text in {"nan", "NaT", "None", "null"}:
        return default
    return text


def _fr(value: Any, decimals: int = 2, *, signed: bool = False) -> str:
    """Nombre au format français, pour un texte rédigé (et non un calcul)."""
    if signed:
        return format_signed(value, decimals=decimals)
    return format_number(value, decimals=decimals)


def _weighted_average(frame: pd.DataFrame, column: str, weight: str) -> float:
    """Moyenne pondérée par les valeurs ; à défaut, moyenne simple.

    Le poids est ramené à sa valeur absolue : un montant négatif (frais, position
    courte) ne doit pas inverser le poids de sa ligne.
    """
    if frame.empty:
        return 0.0
    values = _to_float_series(frame, column)
    weights = _to_float_series(frame, weight).abs()
    total = float(weights.sum())
    if total <= 0:
        return float(values.mean()) if len(values) else 0.0
    return float((values * weights).sum() / total)


def _clean_record(record: dict[str, Any]) -> dict[str, Any]:
    cleaned: dict[str, Any] = {}
    for key, value in record.items():
        if isinstance(value, (pd.Timestamp, datetime, date)):
            cleaned[key] = value.strftime("%Y-%m-%d")
        elif isinstance(value, float):
            cleaned[key] = None if not math.isfinite(value) else round(value, 4)
        else:
            cleaned[key] = value
    return cleaned


def _filter_scope(
    frame: pd.DataFrame, scope: ReportScope, key_columns: Sequence[str]
) -> pd.DataFrame:
    """Restreint un dataset au périmètre : client, portefeuilles, date de référence."""
    if frame.empty:
        return frame
    work = frame.copy()
    wanted = {str(value) for value in scope.portfolio_ids if str(value)}
    if wanted and "portfolio_id" in work:
        work = work[work["portfolio_id"].astype(str).isin(wanted)]
    elif scope.client_id:
        # Un identifiant client ne peut se trouver que dans une colonne client :
        # le comparer à `portfolio_id` viderait silencieusement le périmètre.
        candidates = [column for column in key_columns if column == "client_id"]
        candidates = [column for column in candidates if column in work]
        if candidates:
            work = work[work[candidates[0]].astype(str) == scope.client_id]
        elif "portfolio_id" in work:
            work = work.iloc[0:0]
    return work


def _latest_positions(frame: pd.DataFrame) -> pd.DataFrame:
    """Ne garde que la position la plus récente de chaque instrument.

    Les exports contiennent souvent plusieurs dates : additionner toutes les
    lignes gonflerait l'actif.
    """
    if frame.empty:
        return frame
    work = frame.copy()
    if "as_of" in work:
        work["_as_of"] = pd.to_datetime(work["as_of"], errors="coerce")
        keys = [
            column
            for column in ("portfolio_id", "isin", "instrument_name", "ticker")
            if column in work
        ]
        if keys:
            work = work.sort_values("_as_of").drop_duplicates(subset=keys, keep="last")
        work = work.drop(columns=["_as_of"])
    return work


def _within_period(frame: pd.DataFrame, scope: ReportScope) -> pd.DataFrame:
    """Restreint les transactions à la période demandée (YTD par défaut)."""
    if frame.empty or "trade_date" not in frame:
        return frame
    work = frame.copy()
    dates = pd.to_datetime(work["trade_date"], errors="coerce")
    work = work[dates.notna()]
    if work.empty:
        return work
    # Comparer une série `datetime64` à un `datetime.date` lève une TypeError sur
    # pandas 3 : la date d'arrêté demandée est donc normalisée en Timestamp avant
    # le filtrage, sinon un périmètre avec `as_of` explicite casserait la lecture.
    parsed = _as_of_date(scope.as_of)
    reference = pd.Timestamp(parsed) if parsed is not None else dates.max()
    if reference is None or pd.isna(reference):
        return work
    if scope.period == "month":
        start = reference.replace(day=1)
    elif scope.period == "quarter":
        month = 3 * ((reference.month - 1) // 3) + 1
        start = reference.replace(month=month, day=1)
    elif scope.period == "year":
        start = reference.replace(month=1, day=1)
    else:  # ytd
        start = reference.replace(month=1, day=1)
    mask = (dates >= start) & (dates <= reference)
    return work[mask]


def _as_of_date(value: str) -> date | None:
    if not value:
        return None
    try:
        return pd.to_datetime(value).date()
    except (TypeError, ValueError):
        return None


def _max_date(values: Iterable[Any]) -> str:
    parsed = pd.to_datetime(pd.Series(list(values)), errors="coerce")
    parsed = parsed.dropna()
    if parsed.empty:
        return ""
    return parsed.max().strftime("%Y-%m-%d")


#: Abréviations de mois pour les axes de graphiques.
MONTHS_FR_SHORT = (
    "janv.", "févr.", "mars", "avr.", "mai", "juin",
    "juil.", "août", "sept.", "oct.", "nov.", "déc.",
)


def _month_label(value: Any) -> str:
    try:
        stamp = pd.Timestamp(value)
    except (TypeError, ValueError):
        return str(value)
    return f"{MONTHS_FR_SHORT[stamp.month - 1]} {stamp.year % 100:02d}"


def _last_or_zero(values: Sequence[float]) -> float:
    return float(values[-1]) if len(values) else 0.0


def _column_values(frame: pd.DataFrame, column: str) -> list[float]:
    if column not in frame:
        return []
    return [float(value) for value in _to_float_series(frame, column)]


#: Taux sans risque retenu pour le ratio de Sharpe, en fraction annuelle.
#: Le même taux sert au générateur du jeu de démonstration : un Sharpe calculé
#: sur 2 % et publié sur 1,5 % serait illisible.
RISK_FREE_RATE = 2.0


def _curve_volatility(curve: Sequence[float]) -> float:
    """Volatilité annualisée d'un cumul mensuel, en pourcentage.

    L'écart-type des variations mensuelles est ramené à l'année par la racine
    de douze — approximation usuelle pour des rendements mensuels.
    """
    if len(curve) < 4:
        return 0.0
    variations = [(curve[index] - curve[index - 1]) / 100.0 for index in range(1, len(curve))]
    mean = sum(variations) / len(variations)
    variance = sum((value - mean) ** 2 for value in variations) / (len(variations) - 1)
    return round(math.sqrt(variance) * math.sqrt(12.0) * 100.0, 2)


def _curve_max_drawdown(curve: Sequence[float]) -> float:
    """Plus forte baisse depuis un sommet, en pourcentage du niveau de référence.

    Le calcul passe par le facteur de croissance (1 + cumul), dont le sommet
    vaut au moins 1 : diviser par un cumul négatif donnerait une baisse
    supérieure à -100 %, ce qui n'a pas de sens.
    """
    peak = 1.0
    worst = 0.0
    for value in curve:
        level = 1.0 + value / 100.0
        peak = max(peak, level)
        worst = min(worst, (level - peak) / peak * 100.0)
    return round(worst, 2)


def _curve_sharpe(total_return: float, volatility: float) -> float:
    if volatility <= 0:
        return 0.0
    return round((total_return / 100.0 - RISK_FREE_RATE / 100.0) / (volatility / 100.0), 2)


def _risk_measures(work: pd.DataFrame, curve: Sequence[float]) -> dict[str, float]:
    """Volatilité, Sharpe et drawdown du périmètre couvert.

    Les colonnes `volatility`, `sharpe` et `max_drawdown` décrivent **un**
    portefeuille : les cumuler donnerait le risque de l'avant-dernier, celui que
    le tri alphabétique laisse en tête — un portefeuille monétaire seLexerait
    alors comme le portefeuille entier. Dès que le périmètre couvre plusieurs
    portefeuilles, ces trois mesures sont donc recalculées sur la courbe
    consolidée, seule série qui appartienne vraiment au client.
    """
    columns = {
        "volatility": _last_or_zero(_column_values(work, "volatility")),
        "sharpe": _last_or_zero(_column_values(work, "sharpe")),
        "max_drawdown": _last_or_zero(_column_values(work, "max_drawdown")),
    }
    portfolios = work["portfolio_id"].nunique() if "portfolio_id" in work else 1
    if portfolios <= 1 or len(curve) < 4:
        return {name: round(value, 2) for name, value in columns.items()}
    volatility = _curve_volatility(curve)
    return {
        "volatility": volatility,
        "sharpe": _curve_sharpe(_last_or_zero(curve), volatility),
        "max_drawdown": _curve_max_drawdown(curve),
    }


def _aggregate_curve(frame: pd.DataFrame, column: str, weight: str | None) -> list[float]:
    """Moyenne pondérée par date : une courbe consolidée sur plusieurs portefeuilles."""
    if column not in frame:
        return []
    if weight:
        grouped = frame.groupby("date").apply(
            lambda group: float(
                (_to_float_series(group, column) * _to_float_series(group, weight)).sum()
                / (_to_float_series(group, weight).sum() or 1.0)
            ),
            include_groups=False,
        )
    else:
        grouped = frame.groupby("date")[column].mean()
    return [round(float(value), 2) for value in grouped.tolist()]


# ---------------------------------------------------------- Obligataire
#: Échelle de notation, de la plus élevée à la plus basse, avec le rang associé.
#: Le rang sert à moyenner deux notations et à trancher investment grade / haut
#: rendement sans refaire une comparaison lexicale (AAA > AA > A > BBB > B > C).
RATING_SCALE: tuple[tuple[str, int], ...] = (
    ("AAA", 1), ("AA+", 2), ("AA", 3), ("AA-", 4), ("A+", 5), ("A", 6), ("A-", 7),
    ("BBB+", 8), ("BBB", 9), ("BBB-", 10),
    ("BB+", 11), ("BB", 12), ("BB-", 13),
    ("B+", 14), ("B", 15), ("B-", 16),
    ("CCC+", 17), ("CCC", 18), ("CCC-", 19),
    ("CC", 20), ("C", 21), ("D", 22),
)

#: Rang au-delà duquel un titre n'est plus investment grade (BBB- est le plancher).
INVESTMENT_GRADE_MAX_RANK = 10

#: Tranches de maturité du profil obligataire, bornes en années.
MATURITY_BUCKETS: tuple[tuple[str, float, float | None], ...] = (
    ("Moins de 1 an", 0.0, 1.0),
    ("1 à 3 ans", 1.0, 3.0),
    ("3 à 5 ans", 3.0, 5.0),
    ("5 à 7 ans", 5.0, 7.0),
    ("7 à 10 ans", 7.0, 10.0),
    ("Plus de 10 ans", 10.0, None),
)

#: Correspondance des trois agences de notation, pour l'annexe pédagogique.
#: L'ordre suit `RATING_SCALE` : il est celui du tableau affiché, pas celui d'un
#: tri alphabétique.
_MOODY_ALIASES = {
    "AAA": "Aaa", "AA+": "Aa1", "AA": "Aa2", "AA-": "Aa3", "A+": "A1", "A": "A2",
    "A-": "A3", "BBB+": "Baa1", "BBB": "Baa2", "BBB-": "Baa3", "BB+": "Ba1",
    "BB": "Ba2", "BB-": "Ba3", "B+": "B1", "B": "B2", "B-": "B3", "CCC+": "Caa1",
    "CCC": "Caa2", "CCC-": "Caa3", "CC": "Ca", "C": "C", "D": "D",
}

RATING_CORRESPONDENCE: tuple[dict[str, str], ...] = tuple(
    {
        "sp": label,
        "moodys": _MOODY_ALIASES.get(label, label),
        "fitch": label,
        "bucket": (
            "Investment grade"
            if rank <= INVESTMENT_GRADE_MAX_RANK
            else "Haut rendement"
        ),
    }
    for label, rank in RATING_SCALE
)

_RATING_RANKS = {label: rank for label, rank in RATING_SCALE}
_RATING_BY_RANK = {rank: label for label, rank in RATING_SCALE}


def _bond_rows(holdings: pd.DataFrame) -> pd.DataFrame:
    """Lignes obligataires : celles qui portent un émetteur renseigné.

    Le filtre passe par `isna()` : convertir la colonne en chaînes transformerait
    les valeurs manquantes en `"None"` ou `"nan"` selon leur nature, et aucune
    ligne non obligataire ne serait alors exclue.
    """
    if holdings.empty or "issuer" not in holdings:
        return holdings.head(0)
    issuers = holdings["issuer"]
    mask = issuers.notna() & issuers.astype(str).str.strip().ne("")
    return holdings[mask]


def _rating_rank(value: Any) -> int | None:
    """Rang d'une notation, ou `None` si elle est absente ou « non notée »."""
    label = str(value or "").strip().upper()
    if not label or label in {"NON NOTE", "NON NOTÉ", "NON RATE", "NR", "NAN", "NONE"}:
        return None
    return _RATING_RANKS.get(label)


def _rating_average(bonds: pd.DataFrame, bond_total: float) -> dict[str, Any]:
    """Notation moyenne pondérée, et poids des trois grands buckets.

    Une moyenne de rangs arrondie puis traduite en notation lisible : un
    portefeuille ne se note pas « 7,4 », il se note « A ».
    """
    empty = {
        "label": "—", "rank": 0.0, "investment_grade_pct": 0.0,
        "high_yield_pct": 0.0, "unrated_pct": 0.0,
    }
    if bonds.empty or "rating" not in bonds or bond_total <= 0:
        return empty
    weights = _to_float_series(bonds, "market_value")
    rated_weight = 0.0
    rank_weight = 0.0
    ig_weight = 0.0
    hy_weight = 0.0
    unrated_weight = 0.0
    for rating, weight in zip(bonds["rating"].tolist(), weights.tolist()):
        rank = _rating_rank(rating)
        if rank is None:
            unrated_weight += weight
            continue
        rated_weight += weight
        rank_weight += rank * weight
        if rank <= INVESTMENT_GRADE_MAX_RANK:
            ig_weight += weight
        else:
            hy_weight += weight
    if rated_weight <= 0:
        return {**empty, "unrated_pct": 100.0}
    average_rank = rank_weight / rated_weight
    nearest_rank = min(_RATING_BY_RANK, key=lambda rank: (abs(rank - average_rank), rank))
    return {
        "label": _RATING_BY_RANK[nearest_rank],
        "rank": round(average_rank, 2),
        "investment_grade_pct": round(ig_weight / bond_total * 100, 2),
        "high_yield_pct": round(hy_weight / bond_total * 100, 2),
        "unrated_pct": round(unrated_weight / bond_total * 100, 2),
    }


def _rating_distribution(bonds: pd.DataFrame, bond_total: float) -> list[dict[str, Any]]:
    """Répartition par notation, de la meilleure à la moins bonne."""
    if bonds.empty or "rating" not in bonds or bond_total <= 0:
        return []
    weights = _to_float_series(bonds, "market_value")
    work = pd.DataFrame(
        {"label": [_label(value) for value in bonds["rating"]], "value": weights}
    )
    grouped = work.groupby("label")["value"].sum()
    slices: list[dict[str, Any]] = []
    for label, value in grouped.sort_values(ascending=False).items():
        rank = _rating_rank(label)
        slices.append(
            {
                "label": str(label),
                "value": round(float(value), 2),
                "pct": round(float(value) / bond_total * 100, 2),
                # Le tri suit l'échelle de notation, pas l'ordre alphabétique.
                "rank": rank if rank is not None else 99,
            }
        )
    slices.sort(key=lambda item: item["rank"])
    return slices


def _years_to_maturity(bonds: pd.DataFrame, as_of: str) -> float:
    """Vie moyenne pondérée : années restant à l'échéance à la date d'arrêté."""
    if bonds.empty or "maturity" not in bonds:
        return 0.0
    reference = _as_of_date(as_of)
    if reference is None:
        return 0.0
    maturities = pd.to_datetime(bonds["maturity"], errors="coerce")
    weights = _to_float_series(bonds, "market_value")
    total = float(weights.sum())
    if total <= 0:
        return 0.0
    remaining: list[float] = []
    values: list[float] = []
    for maturity, weight in zip(maturities.tolist(), weights.tolist()):
        if maturity is None or pd.isna(maturity):
            continue
        years = (maturity.date() - reference).days / 365.25
        if years <= 0:
            # Un titre échu ne pèse plus dans le profil de risque.
            continue
        remaining.append(years)
        values.append(float(weight))
    if not remaining:
        return 0.0
    return sum(y * w for y, w in zip(remaining, values)) / sum(values)


def _maturity_distribution(
    bonds: pd.DataFrame, bond_total: float, as_of: str
) -> list[dict[str, Any]]:
    """Profil de maturité par tranche, en % de l'encours obligataire."""
    if bonds.empty or "maturity" not in bonds or bond_total <= 0:
        return []
    reference = _as_of_date(as_of)
    if reference is None:
        return []
    maturities = pd.to_datetime(bonds["maturity"], errors="coerce")
    weights = _to_float_series(bonds, "market_value")
    buckets = {label: 0.0 for label, _low, _high in MATURITY_BUCKETS}
    for maturity, weight in zip(maturities.tolist(), weights.tolist()):
        if maturity is None or pd.isna(maturity):
            continue
        years = (maturity.date() - reference).days / 365.25
        if years <= 0:
            continue
        for label, low, high in MATURITY_BUCKETS:
            if years >= low and (high is None or years < high):
                buckets[label] += float(weight)
                break
    return [
        {
            "label": label,
            "value": round(buckets[label], 2),
            "pct": round(buckets[label] / bond_total * 100, 2),
        }
        for label, _low, _high in MATURITY_BUCKETS
    ]


def _issuer_ranking(bonds: pd.DataFrame, bond_total: float) -> list[dict[str, Any]]:
    """Principaux émetteurs, décroissants, avec leur part de l'obligataire."""
    if bonds.empty or "issuer" not in bonds or bond_total <= 0:
        return []
    work = pd.DataFrame(
        {
            "label": [_label(value) for value in bonds["issuer"]],
            "value": _to_float_series(bonds, "market_value"),
        }
    )
    grouped = work.groupby("label")["value"].sum().sort_values(ascending=False)
    return [
        {
            "label": str(label),
            "value": round(float(value), 2),
            "pct": round(float(value) / bond_total * 100, 2),
        }
        for label, value in grouped.items()
    ]


def _coupon_lines(received: float, expected: float) -> list[dict[str, Any]]:
    """Les trois lignes du focus coupons : encaissé, attendu, solde à recevoir.

    Le solde évite de répéter deux fois le même montant sous deux libellés : ce
    qui reste à percevoir est la différence entre l'attendu et l'encaissé.
    """
    return [
        {
            "label": "Coupons encaissés sur la période",
            "value": round(received, 2),
        },
        {
            "label": "Coupons attendus sur douze mois",
            "value": round(expected, 2),
        },
        {
            "label": "Solde à recevoir",
            "value": round(max(expected - received, 0.0), 2),
        },
    ]


def _bond_positions(
    bonds: pd.DataFrame, total: float, bond_total: float
) -> list[dict[str, Any]]:
    """Détail des lignes obligataires, décroissant par encours.

    Alimente le tableau de positions du rapport de gestion : typologie,
    émetteur, cours, quantité, plus-value latente, encours et poids. Les poids
    sont exprimés dans deux bases : l'actif net du client et l'obligataire seul.
    """
    if bonds.empty:
        return []
    work = bonds.copy()
    work["_mv"] = _to_float_series(work, "market_value")
    work = work.sort_values("_mv", ascending=False)
    rows: list[dict[str, Any]] = []
    for record in work.to_dict("records"):
        value = _to_float(record.get("market_value"))
        rows.append(
            {
                "typology": _label(record.get("category")),
                "instrument": _label(record.get("instrument_name")),
                "issuer": _label(record.get("issuer")),
                "rating": _label(record.get("rating")),
                "maturity": _label(record.get("maturity")),
                "coupon": round(_to_float(record.get("coupon")), 3),
                "tra": round(_to_float(record.get("yield")), 3),
                "price": round(_to_float(record.get("price")), 4),
                "quantity": round(_to_float(record.get("quantity")), 2),
                "currency": _label(record.get("currency")),
                "market_value": round(value, 2),
                "pnl_unrealised": round(_to_float(record.get("pnl_unrealised")), 2),
                "weight": round(value / total * 100, 2) if total else 0.0,
                "bond_weight": round(value / bond_total * 100, 2) if bond_total else 0.0,
                "duration": round(_to_float(record.get("mod_duration")), 2),
            }
        )
    return rows


def _bond_totals(bonds: pd.DataFrame, total: float) -> list[dict[str, Any]]:
    """Totaux de clôture : par typologie obligataire, puis monétaire et général.

    Chaque ligne porte l'encours et son poids, calculé dans l'actif net : c'est
    la présentation de synthèse qui clôt le tableau de positions.
    """
    rows: list[dict[str, Any]] = []
    if not bonds.empty:
        grouped = (
            pd.DataFrame(
                {
                    "label": [_label(value) for value in bonds["category"]],
                    "value": _to_float_series(bonds, "market_value"),
                }
            )
            .groupby("label")["value"]
            .sum()
            .sort_values(ascending=False)
        )
        for label, value in grouped.items():
            rows.append(
                {
                    "label": str(label),
                    "value": round(float(value), 2),
                    "pct": round(float(value) / total * 100, 2) if total else 0.0,
                }
            )
    return rows


def _coupon_income(transactions: pd.DataFrame) -> float:
    """Coupons effectivement encaissés sur la période (type INTEREST/COUPON)."""
    if transactions.empty or "transaction_type" not in transactions:
        return 0.0
    types = transactions["transaction_type"].astype(str).str.upper()
    coupons = transactions[types.isin({"INTEREST", "COUPON", "DIVIDEND"})]
    if "income" in coupons:
        return float(_to_float_series(coupons, "income").abs().sum())
    return float(_to_float_series(coupons, "amount").abs().sum()) if not coupons.empty else 0.0


def _allocation(frame: pd.DataFrame, dimension: str, measure: str) -> list[dict[str, Any]]:
    """Répartition en % de l'actif, catégories triées et tranches fusionnées."""
    if frame.empty or dimension not in frame:
        return []
    values = _to_float_series(frame, measure)
    total = float(values.sum())
    if total <= 0:
        return []
    work = pd.DataFrame({"label": frame[dimension].astype(str), "value": values})
    work.loc[work["label"].str.strip() == "", "label"] = "Non renseigné"
    grouped = work.groupby("label")["value"].sum().sort_values(ascending=False)
    slices: list[dict[str, Any]] = []
    for index, (label, value) in enumerate(grouped.items()):
        if index >= ALLOCATION_SLICES:
            break
        slices.append(
            {"label": str(label), "value": round(float(value), 2), "pct": round(float(value) / total * 100, 2)}
        )
    remainder = float(grouped.iloc[ALLOCATION_SLICES:].sum()) if len(grouped) > ALLOCATION_SLICES else 0.0
    if remainder > 0:
        slices.append(
            {
                "label": "Autres",
                "value": round(remainder, 2),
                "pct": round(remainder / total * 100, 2),
            }
        )
    return slices


def _cash(frame: pd.DataFrame) -> float:
    """Trésorerie : colonne dédiée si elle existe, sinon lignes classées « cash »."""
    if frame.empty:
        return 0.0
    if "cash_value" in frame:
        return float(_to_float_series(frame, "cash_value").sum())
    values = _to_float_series(frame, "market_value")
    if "asset_class" in frame:
        # Les sources clients écrivent tantôt « monétaire », tantôt « Monetaire » :
        # les deux graphies sont retenues, faute de quoi une trésorerie non
        # détectée disparaît du rapport sans que l'erreur soit visible.
        is_cash = frame["asset_class"].astype(str).str.lower().isin(
            [
                "cash", "liquidités", "liquides", "liquidites",
                "monétaire", "monetaire", "monétaires", "money market",
            ]
        )
        values = values.where(~is_cash, 0.0)
    return float(values.sum())


def _best_position(frame: pd.DataFrame) -> dict[str, Any]:
    return _extreme_position(frame, best=True)


def _worst_position(frame: pd.DataFrame) -> dict[str, Any]:
    return _extreme_position(frame, best=False)


def _extreme_position(frame: pd.DataFrame, *, best: bool) -> dict[str, Any]:
    if frame.empty or "pnl_unrealised" not in frame:
        return {"instrument": "—", "pnl_pct": 0.0}
    work = frame.copy()
    work["_pct"] = pd.Series(
        [
            _to_float(row.get("pnl_unrealised")) / _to_float(row.get("cost_basis")) * 100
            if _to_float(row.get("cost_basis"))
            else 0.0
            for row in work.to_dict("records")
        ],
        index=work.index,
        dtype="float64",
    )
    row = work.sort_values("_pct", ascending=not best).iloc[0]
    return {
        "instrument": str(row.get("instrument_name", "") or "—"),
        "pnl_pct": round(float(row["_pct"]), 2),
    }


def _portfolio_summary(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Un relevé par portefeuille : l'interface client aime le détail par mandat."""
    if frame.empty:
        return []
    rows: list[dict[str, Any]] = []
    for record in frame.to_dict("records"):
        rows.append(
            {
                "portfolio_id": _label(record.get("portfolio_id")),
                "name": _label(
                    record.get("portfolio_name") or record.get("portfolio_id")
                ),
                "mandate": _label(record.get("mandate_type")),
                "strategy": _label(record.get("strategy")),
                "base_ccy": _label(record.get("base_ccy")),
                "aum": round(_to_float(record.get("aum")), 2),
                "inception_date": str(record.get("inception_date", "") or ""),
            }
        )
    return rows


#: Libellés de mois en français : `strftime("%B")` suit la locale du système,
#: qui n'est pas forcément le français sur le poste du redacteur.
MONTHS_FR = (
    "janvier", "février", "mars", "avril", "mai", "juin",
    "juillet", "août", "septembre", "octobre", "novembre", "décembre",
)


def _period_label(as_of: str, period: str) -> str:
    reference = _as_of_date(as_of)
    if reference is None:
        return "Période courante"
    if period == "month":
        return f"{MONTHS_FR[reference.month - 1].capitalize()} {reference.year}"
    if period == "quarter":
        quarter = (reference.month - 1) // 3 + 1
        return f"T{quarter} {reference.year}"
    if period == "year":
        return str(reference.year)
    return f"Année {reference.year} (YTD)"
