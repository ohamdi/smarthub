from __future__ import annotations

import hmac
from dataclasses import dataclass
from typing import Any

from .errors import APIError
from .storage import DatasetRepository

DEFAULT_USERS = [
    {"username": "admin", "password": "admin123", "role": "admin", "client_id": ""},
    {
        "username": "conseiller",
        "password": "conseiller123",
        "role": "user",
        "client_id": "",
    },
]


@dataclass(frozen=True)
class Principal:
    username: str
    role: str
    client_id: str = ""

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"


class AuthService:
    """Authentification par session, adossée au dataset `users`.

    Un utilisateur `user` peut être restreint à un `client_id` : ses reportings
    sont alors calculés sur ce seul client, sans jamais voir les autres.
    """

    def __init__(self, repository: DatasetRepository) -> None:
        self.repository = repository

    def users(self) -> list[dict[str, Any]]:
        users = self.repository.records("users")
        return users or [dict(user) for user in DEFAULT_USERS]

    def authenticate(self, username: str, password: str) -> Principal:
        normalized = username.strip().lower()
        for user in self.users():
            stored_username = str(user.get("username", "")).strip().lower()
            stored_password = str(user.get("password", ""))
            if stored_username == normalized and hmac.compare_digest(
                stored_password.encode("utf-8"), password.encode("utf-8")
            ):
                return Principal(
                    username=normalized,
                    role=str(user.get("role", "user")),
                    client_id=str(user.get("client_id", "") or ""),
                )
        raise APIError(401, "Identifiants invalides")

    def list_public_users(self) -> list[dict[str, Any]]:
        return [
            {
                "username": str(user.get("username", "")),
                "role": str(user.get("role", "")),
                "client_id": str(user.get("client_id", "") or ""),
            }
            for user in self.users()
        ]

    def create_user(
        self, username: str, password: str, role: str, client_id: str
    ) -> None:
        normalized = username.strip().lower()
        if not normalized or not password.strip():
            raise APIError(400, "username et password sont obligatoires")
        users = self.users()
        if any(str(user.get("username", "")).strip().lower() == normalized for user in users):
            raise APIError(409, "Utilisateur déjà existant")
        users.append(
            {
                "username": normalized,
                "password": password.strip(),
                "role": role,
                "client_id": client_id.strip(),
            }
        )
        self.repository.save_records("users", users)

    def update_user(self, username: str, updates: dict[str, Any]) -> None:
        normalized = username.strip().lower()
        users = self.users()
        found = False
        for user in users:
            if str(user.get("username", "")).strip().lower() != normalized:
                continue
            if updates.get("password"):
                user["password"] = str(updates["password"]).strip()
            if updates.get("role") is not None:
                user["role"] = str(updates["role"]).strip()
            if updates.get("client_id") is not None:
                user["client_id"] = str(updates["client_id"]).strip()
            found = True
            break
        if not found:
            raise APIError(404, "Utilisateur introuvable")
        self.repository.save_records("users", users)

    def delete_user(self, username: str) -> None:
        normalized = username.strip().lower()
        users = [
            user
            for user in self.users()
            if str(user.get("username", "")).strip().lower() != normalized
        ]
        self.repository.save_records("users", users)


def principal_from_session(session: dict[str, Any]) -> Principal:
    username = session.get("user")
    if not username:
        raise APIError(401, "Non authentifié", login_required=True)
    return Principal(
        username=str(username),
        role=str(session.get("role", "user")),
        client_id=str(session.get("client_id", "") or ""),
    )
