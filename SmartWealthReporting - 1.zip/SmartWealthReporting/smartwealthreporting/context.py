"""Rendu textuel des faits pour le modèle.

Le contexte est un bloc texte déterministe, construit à partir des seuls faits
chiffrés : c'est la seule chose que l'IA voit. Il est affichable tel quel dans
l'interface (route `/reportings/{id}/context`) pour que l'utilisateur puisse
vérifier exactement ce qui est envoyé au modèle.
"""

from __future__ import annotations

from typing import Any

#: Libellés français par clé de fait, dans l'ordre d'affichage.
SECTION_TITLES: tuple[tuple[str, str], ...] = (
    ("kpis", "INDICATEURS CLES"),
    ("allocations", "ALLOCATIONS"),
    ("performance", "PERFORMANCE"),
    ("pnl", "RESULTAT"),
    ("top_holdings", "PRINCIPALES POSITIONS"),
    ("esg", "ESG"),
    ("flows", "FLUX ET OPERATIONS"),
    ("concentration", "CONCENTRATION"),
    ("risks", "POINTS DE VIGILANCE"),
    ("portfolios", "PORTEFEUILLES"),
    ("bonds", "PORTEFEUILLE OBLIGATAIRE"),
)

KPI_LABELS: dict[str, str] = {
    "aum_total": "Actif total",
    "cost_basis": "Cout de revient",
    "nb_positions": "Nombre de positions",
    "nb_portfolios": "Nombre de portefeuilles",
    "cash_pct": "Part tresorerie",
    "unrealised_pct": "P&L latent",
    "yield_pct": "Rendement pondere",
    "portfolio_cum_return": "Performance cumulee du portefeuille",
    "benchmark_cum_return": "Performance cumulee du benchmark",
    "alpha": "Ecart au benchmark",
    "volatility": "Volatilite",
    "sharpe": "Ratio de Sharpe",
    "max_drawdown": "Drawdown maximal",
    "last_period_return": "Performance du dernier mois",
    "nb_transactions": "Nombre d'operations",
    "transactions_amount": "Montant des operations",
    # obligataire
    "bond_total": "Encours obligataire",
    "bond_pct": "Part obligataire",
    "cash_total": "Encours monetaire",
    "tra_pct": "TRA moyen",
    "life_years": "Vie moyenne (annees)",
    "duration_years": "Duree modifiee",
    "sensitivity": "Sensibilite",
    "rating_average": "Notation moyenne",
    "investment_grade_pct": "Part investment grade",
    "high_yield_pct": "Part haut rendement",
    "unrated_pct": "Part non notee",
    "nb_issuers": "Nombre d'emetteurs",
    "nb_bonds": "Nombre de titres",
    "coupons_received": "Coupons encaisses",
    "coupons_expected": "Coupons attendus",
}

ALLOCATION_LABELS: dict[str, str] = {
    "asset_class": "par classe d'actifs",
    "sector": "par secteur",
    "country": "par pays",
    "currency": "par devise",
    "category": "par categorie",
}

RISK_LEVELS = {"high": "eleve", "medium": "moyen", "low": "faible"}

#: Libellés français des clés des blocs tabulaires (flux, activité, ESG, P&L).
#: Sans cette table, un tableau `flows` afficherait « Deposits », « Withdrawals »
#: au milieu d'un deck français.
FACT_LABELS: dict[str, str] = {
    # flux
    "deposits": "Apports",
    "withdrawals": "Retraits",
    "net": "Flux net",
    "dividends": "Dividendes",
    "interest": "Interets",
    "fees": "Frais",
    "subscriptions": "Souscriptions",
    "redemptions": "Rachats",
    # activité
    "trades": "Ordres",
    "buy_count": "Achats",
    "sell_count": "Ventes",
    "last_trade": "Derniere operation",
    "avg_trade_size": "Taille moyenne",
    # ESG
    "score": "Score ESG",
    "e": "Environnement",
    "s": "Social",
    "g": "Gouvernance",
    "coverage_pct": "Part notee",
    # résultat
    "unrealised_pnl": "P&L latent",
    "unrealised_pct": "P&L latent (%)",
    "realised_pnl": "P&L realise",
    "income": "Revenus",
    "net_pnl": "Resultat net",
    # concentration
    "top5_pct": "Cinq premieres positions",
    "top10_pct": "Dix premieres positions",
    "largest_position": "Premiere position",
    "largest_weight_pct": "Poids de la premiere position",
    "nb_positions": "Nombre de positions",
}

#: Séparateur de milliers. La typographie française veut une espace insécable
#: (fine) ; elle est posée explicitement plutôt que laissée au formatteur de
#: Python, dont le caractère a changé selon les versions (espace normale en
#: 3.11, fine insécable U+202F en 3.14).
THIN_SPACE = " "


def format_number(value: Any, *, decimals: int = 0, suffix: str = "") -> str:
    """Format français : fine espace comme séparateur de milliers, virgule décimale."""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    sign = "-" if number < 0 else ""
    integer, _, fraction = f"{abs(number):.{max(decimals, 0)}f}".partition(".")
    groups: list[str] = []
    while len(integer) > 3:
        groups.insert(0, integer[-3:])
        integer = integer[:-3]
    groups.insert(0, integer)
    rendered = THIN_SPACE.join(groups)
    if decimals > 0:
        rendered = f"{rendered},{fraction}"
    return f"{sign}{rendered}{suffix}"


def format_signed(value: Any, *, decimals: int = 2) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    sign = "+" if number > 0 else ""
    return f"{sign}{format_number(number, decimals=decimals)}"


def render(facts: dict[str, Any], *, max_chars: int = 24000, sections: tuple[str, ...] | None = None) -> dict[str, Any]:
    """Construit le bloc de contexte, tronqué proprement s'il dépasse le plafond.

    La troncature coupe entre deux lignes : un nombre coupé au milieu ferait
    échouer la vérification alors qu'il est légitime.
    """
    lines: list[str] = []
    wanted = set(sections) if sections else None

    def keep(section: str) -> bool:
        return wanted is None or section in wanted

    period = facts.get("period") or {}
    client = facts.get("client") or {}
    currency = str(period.get("base_currency", "") or "EUR")
    if keep("period"):
        lines.append(
            f"PERIODE ET CLIENT : {period.get('label', '')} — arrete au "
            f"{period.get('as_of', 'n/a')} — devise de consolidation : {currency}."
        )
        if client:
            details = " | ".join(
                f"{label} : {client.get(key, 'n/a')}"
                for key, label in (
                    ("client_name", "Nom"),
                    ("segment", "Segment"),
                    ("domicile", "Domicile"),
                    ("risk_profile", "Profil de risque"),
                    ("relationship_manager", "Conseiller"),
                    ("objectives", "Objectifs"),
                )
                if client.get(key)
            )
            lines.append(f"CLIENT : {details}.")

    for key, title in SECTION_TITLES:
        if not keep(key):
            continue
        block = _render_section(key, title, facts, currency)
        lines.extend(block)

    text = "\n".join(line for line in lines if line)
    truncated = False
    if len(text) > max_chars:
        text = _truncate_lines(lines, max_chars)
        truncated = True
    return {"text": text, "chars": len(text), "truncated": truncated, "sections": sorted(wanted) if wanted else []}


def _render_section(key: str, title: str, facts: dict[str, Any], currency: str) -> list[str]:
    if key == "kpis":
        kpis = facts.get("kpis") or {}
        if not kpis:
            return []
        rows = []
        for name, value in kpis.items():
            label = KPI_LABELS.get(name, name)
            rows.append(f"- {label} : {_kpi_value(name, value, currency)}")
        return [f"\n{title}"] + rows

    if key == "allocations":
        allocations = facts.get("allocations") or {}
        rows = []
        for name, slices in allocations.items():
            if not slices:
                continue
            label = ALLOCATION_LABELS.get(name, name)
            detail = ", ".join(
                f"{slice_['label']} {format_number(slice_['pct'], decimals=1)} %"
                for slice_ in slices
            )
            rows.append(f"- Repartition {label} : {detail}.")
        return [f"\n{title}"] + rows if rows else []

    if key == "performance":
        performance = facts.get("performance") or {}
        labels = performance.get("labels") or []
        portfolio = performance.get("portfolio") or []
        benchmark = performance.get("benchmark") or []
        if not labels:
            return []
        rows = [
            f"- Performance cumulee sur la periode : portefeuille "
            f"{format_signed(performance.get('portfolio_total'))} %, benchmark "
            f"{format_signed(performance.get('benchmark_total'))} %, ecart "
            f"{format_signed(performance.get('portfolio_total', 0) - performance.get('benchmark_total', 0))} points."
        ]
        step = max(1, len(labels) // 12)
        samples = list(range(0, len(labels), step))
        if samples[-1] != len(labels) - 1:
            samples.append(len(labels) - 1)
        for index in samples:
            rows.append(
                f"- {labels[index]} : {format_signed(portfolio[index] if index < len(portfolio) else 0)} % "
                f"(benchmark {format_signed(benchmark[index] if index < len(benchmark) else 0)} %)"
            )
        return [f"\n{title}"] + rows

    if key == "pnl":
        pnl = facts.get("pnl") or {}
        if not pnl:
            return []
        best = pnl.get("best") or {}
        worst = pnl.get("worst") or {}
        return [
            f"\n{title}",
            f"- P&L latent : {format_number(pnl.get('unrealised_pnl'))} {currency} "
            f"({format_signed(pnl.get('unrealised_pct'))} %).",
            f"- P&L realise : {format_number(pnl.get('realised_pnl'))} {currency}.",
            f"- Revenus encaisses (dividendes, interets) : {format_number(pnl.get('income'))} {currency}.",
            f"- Frais : {format_number(pnl.get('fees'))} {currency}.",
            f"- Resultat net : {format_number(pnl.get('net_pnl'))} {currency}.",
            f"- Meilleure position : {best.get('instrument', 'n/a')} "
            f"({format_signed(best.get('pnl_pct'))} %).",
            f"- Moins bonne position : {worst.get('instrument', 'n/a')} "
            f"({format_signed(worst.get('pnl_pct'))} %).",
        ]

    if key == "top_holdings":
        holdings = facts.get("top_holdings") or []
        if not holdings:
            return []
        rows = [
            f"- {index}. {holding.get('instrument')} ({holding.get('asset_class')}) : "
            f"{format_number(holding.get('market_value'))} {currency}, "
            f"{format_number(holding.get('weight'), decimals=2)} % de l'actif, "
            f"P&L {format_signed(holding.get('pnl_pct'))} %."
            for index, holding in enumerate(holdings, 1)
        ]
        return [f"\n{title}"] + rows

    if key == "esg":
        esg = facts.get("esg") or {}
        if not esg:
            return []
        return [
            f"\n{title}",
            f"- Score ESG moyen : {format_number(esg.get('score'), decimals=1)} / 100 "
            f"(E {format_number(esg.get('e'), decimals=1)}, S {format_number(esg.get('s'), decimals=1)}, "
            f"G {format_number(esg.get('g'), decimals=1)}).",
            f"- Part de l'actif notee : {format_number(esg.get('coverage_pct'), decimals=1)} %.",
        ]

    if key == "flows":
        flows = facts.get("flows") or {}
        activity = facts.get("activity") or {}
        if not flows:
            return []
        return [
            f"\n{title}",
            f"- Apports : {format_number(flows.get('deposits'))} {currency} "
            f"({flow_count(flows, 'subscriptions')} operations).",
            f"- Retraits : {format_number(flows.get('withdrawals'))} {currency} "
            f"({flow_count(flows, 'redemptions')} operations).",
            f"- Flux net : {format_number(flows.get('net'))} {currency}.",
            f"- Dividendes : {format_number(flows.get('dividends'))} {currency} ; "
            f"interets : {format_number(flows.get('interest'))} {currency}.",
            f"- Frais preleves : {format_number(flows.get('fees'))} {currency}.",
            f"- Ordres passes : {activity.get('trades', 0)} "
            f"({activity.get('buy_count', 0)} achats, {activity.get('sell_count', 0)} ventes), "
            f"derniere operation le {activity.get('last_trade') or 'n/a'}.",
        ]

    if key == "concentration":
        concentration = facts.get("concentration") or {}
        if not concentration:
            return []
        return [
            f"\n{title}",
            f"- Les 5 premieres positions representent "
            f"{format_number(concentration.get('top5_pct'), decimals=1)} % de l'actif.",
            f"- Les 10 premieres representent "
            f"{format_number(concentration.get('top10_pct'), decimals=1)} % de l'actif.",
            f"- Premiere position : {concentration.get('largest_position')} "
            f"({format_number(concentration.get('largest_weight_pct'), decimals=2)} %).",
        ]

    if key == "risks":
        risks = facts.get("risks") or []
        if not risks:
            return []
        rows = [
            f"- {RISK_LEVELS.get(str(risk.get('level')), 'n/a')} : {risk.get('label')} — "
            f"{risk.get('detail')}"
            for risk in risks
        ]
        return [f"\n{title}"] + rows

    if key == "portfolios":
        portfolios = facts.get("portfolios") or []
        if not portfolios:
            return []
        rows = [
            f"- {portfolio.get('name')} ({portfolio.get('mandate')}, {portfolio.get('strategy')}) : "
            f"{format_number(portfolio.get('aum'))} {currency}, devise {portfolio.get('base_ccy')}, "
            f"inception le {portfolio.get('inception_date') or 'n/a'}."
            for portfolio in portfolios
        ]
        return [f"\n{title}"] + rows

    if key == "bonds":
        return _bond_lines(facts.get("bonds") or {}, title, currency)

    return []


def _bond_lines(bonds: dict[str, Any], title: str, currency: str) -> list[str]:
    """Profil obligataire en prose : les répartitions qu'une narration peut citer.

    Le modèle n'écrit que du texte : lui donner les quatre répartitions en
    phrases prêtes à l'emploi évite qu'il reconstruise des pourcentages et se
    trompe. Rien n'est renvoyé si le client n'a pas de ligne obligataire.
    """
    if not bonds or not bonds.get("bond_total"):
        return []
    rows = [
        f"\n{title}",
        f"- Encours obligataire : {format_number(bonds.get('bond_total'))} {currency}, "
        f"soit {format_number(bonds.get('bond_pct'), decimals=2)} % de l'actif net ; "
        f"l'encours monetaire represente {format_number(bonds.get('cash_pct_of_total'), decimals=2)} %.",
        f"- {bonds.get('nb_bonds')} titres emis par {bonds.get('nb_issuers')} emetteurs ; "
        f"TRA brut theorique moyen {format_number(bonds.get('tra_pct'), decimals=2)} %.",
        f"- Vie moyenne : {format_number(bonds.get('life_years'), decimals=2)} annees ; "
        f"duree modifiee et sensibilite {format_number(bonds.get('sensitivity'), decimals=2)}.",
        f"- Notation moyenne {bonds.get('rating_average') or '—'} ; "
        f"investment grade {format_number(bonds.get('investment_grade_pct'), decimals=2)} %, "
        f"haut rendement {format_number(bonds.get('high_yield_pct'), decimals=2)} %, "
        f"non notes {format_number(bonds.get('unrated_pct'), decimals=2)} %.",
    ]
    for key, caption in (
        ("maturities", "tranche de maturite"),
        ("ratings", "notation"),
        ("categories", "typologie"),
        ("issuers", "emetteur"),
    ):
        slices = [row for row in bonds.get(key) or [] if float(row.get("pct", 0) or 0) > 0]
        if slices:
            detail = ", ".join(
                f"{row['label']} {format_number(row['pct'], decimals=1)} %" for row in slices
            )
            rows.append(f"- Repartition par {caption} : {detail}.")
    coupons = bonds.get("coupons") or []
    if coupons:
        rows.append(
            f"- Coupons encaisses sur la periode : "
            f"{format_number(coupons[0].get('value'))} {currency} ; "
            f"attendus sur douze mois {format_number(coupons[1].get('value'))} {currency}."
        )
    return rows


def flow_count(flows: dict[str, Any], key: str) -> int:
    try:
        return int(flows.get(key, 0) or 0)
    except (TypeError, ValueError):
        return 0


def _kpi_value(name: str, value: Any, currency: str) -> str:
    if name in {"portfolio_cum_return", "benchmark_cum_return", "alpha", "unrealised_pct",
                "cash_pct", "yield_pct", "last_period_return"}:
        return f"{format_signed(value)} %"
    if name in {"volatility", "max_drawdown"}:
        return f"{format_number(value, decimals=2)} %"
    if name in {"aum_total", "cost_basis", "transactions_amount", "bond_total",
                "cash_total", "coupons_received", "coupons_expected"}:
        return f"{format_number(value)} {currency}"
    if name == "sharpe":
        return format_number(value, decimals=2)
    # Un poids ou un taux obligataire se dit sans signe : « 34,18 % de l'actif ».
    if name in {"bond_pct", "tra_pct", "investment_grade_pct", "high_yield_pct",
                "unrated_pct"}:
        return f"{format_number(value, decimals=2)} %"
    if name in {"life_years", "duration_years", "sensitivity"}:
        return f"{format_number(value, decimals=2)}"
    if name == "rating_average":
        # Une notation est un grade, pas un nombre : elle se rend telle quelle.
        return str(value or "—")
    return format_number(value)


def _truncate_lines(lines: list[str], max_chars: int) -> str:
    marker = "[contexte tronque]"
    kept: list[str] = []
    total = 0
    for line in lines:
        # La marqueur de troncature est réservée dans le plafond : le contexte
        # rendu ne doit jamais le dépasser, sinon le prompt dépasse `n_ctx`.
        cost = len(line) + 1
        if total + cost + len(marker) + 1 > max_chars:
            break
        kept.append(line)
        total += cost
    if kept:
        kept.append(marker)
    return "\n".join(kept)
