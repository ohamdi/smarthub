"""Lecture de la réponse du modèle : JSON attendu, texte brut rendu.

Un modèle local de 3B ne respecte pas toujours le contrat de format. Plutôt que
de laisser remonter une réponse brute dans une slide, on extrait le JSON, on
nettoie chaque commentaire (pas de Markdown, pas de HTML, longueur bornée) et on
signale ce qui manque : le générateur PPTX laisse alors la zone vide et l'interface
affiche un avertissement.
"""

from __future__ import annotations

import json
import re
from typing import Any, Iterable

HTML_TAG = re.compile(r"<[^>]{1,80}>")
MARKDOWN_BULLET = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+", re.MULTILINE)
#: Les marqueurs sont remplacés par une espace, pas supprimés : `**Actif** : 3 M`
#: doit rendre « Actif : 3 M », pas « Actif: 3 M ». Les espaces doubles qui en
#: résultent sont fondus ensuite par `WHITESPACE`.
MARKDOWN_EMPHASIS = re.compile(r"\*{1,3}|_{1,3}|`+|#{1,6}")
WHITESPACE = re.compile(r"\s+")
FENCE = re.compile(r"```[a-zA-Z0-9]*")
TRAILING_COMMA = re.compile(r",\s*([}\]])")


def parse_json_object(text: str) -> dict[str, Any] | None:
    """Extrait le premier objet JSON d'une réponse, Markdown et prose comprises.

    Un modèle local produit volontiers `Voici : {"slides": {...}}`, encadré ou non,
    et coupe parfois sa réponse en plein objet. Une coupe est récupérée : sans
    cela, un commentaire déjà rédigé mais incomplet serait perdu.
    """
    raw = str(text or "").strip()
    if not raw:
        return None
    raw = FENCE.sub("", raw).strip()
    start = raw.find("{")
    while start != -1:
        end = _balanced_end(raw, start)
        # Un objet non refermé est fermeture au mieux, pas rejeté d'emblée.
        candidate = raw[start:] if end is None else raw[start:end]
        parsed = _loads(candidate)
        if isinstance(parsed, dict):
            return parsed
        start = raw.find("{", start + 1)
    return None


def _balanced_end(raw: str, start: int) -> int | None:
    """Index de fin de l'objet JSON balanced demarrant à `start`, sinon `None`."""
    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(raw)):
        char = raw[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return index + 1
    return None


def _loads(candidate: str) -> Any:
    """JSON strict, puis JSON réparé : virgule finale ou accolades manquantes."""
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass
    try:
        return json.loads(_repair(candidate))
    except json.JSONDecodeError:
        return None


def _repair(candidate: str) -> str:
    """Dernier resort d'un JSON tronqué ou malformé : virgules finales et accolades."""
    text = candidate.rstrip()
    while text and text[-1] in ",:":
        text = text[:-1]
    text = TRAILING_COMMA.sub(r"\1", text)
    opened = text.count("{") - text.count("}")
    return text + "}" * max(opened, 0)


def sanitise(value: Any, *, max_chars: int, min_chars: int) -> str:
    """Texte propre pour une zone de texte PPTX : prose, borné, sans balisage."""
    if not isinstance(value, str):
        return ""
    text = HTML_TAG.sub(" ", value)
    text = MARKDOWN_BULLET.sub("", text)
    text = MARKDOWN_EMPHASIS.sub(" ", text)
    # Les séquences échappées sont unwrappées avant la fusion des espaces, sinon
    # un `\n` devient une espace supplémentaire au milieu d'une phrase.
    text = text.replace('\\"', '"').replace("\\n", " ").replace("\\t", " ")
    text = WHITESPACE.sub(" ", text).strip()
    if len(text) > max_chars:
        cut = text[: max_chars].rsplit(" ", 1)[0]
        text = (cut or text[:max_chars]).rstrip(" ,;:") + "…"
    if min_chars and len(text) < min_chars:
        return ""
    return text


def parse_reply(raw: str, expected_ids: Iterable[str]) -> dict[str, Any]:
    """Réponse du modèle → `{slide_id: texte}` nettoyé, plus les clés manquantes."""
    expected = [str(identifier) for identifier in expected_ids]
    payload = parse_json_object(raw)
    slides: dict[str, str] = {}
    error = ""
    if payload is None:
        error = "Réponse du modèle sans objet JSON exploitable."
        return {"slides": slides, "missing": expected, "error": error, "raw": str(raw or "")[:400]}

    container = payload.get("slides")
    if isinstance(container, dict):
        items: Iterable[tuple[Any, Any]] = container.items()
    elif isinstance(container, list):
        items = [
            (item.get("id") or item.get("slide") or item.get("key"), item.get("text") or item.get("commentaire") or item.get("narrative"))
            for item in container
            if isinstance(item, dict)
        ]
    else:
        # Le modèle a parfois répondu directement {id: texte}.
        items = [
            (key, value)
            for key, value in payload.items()
            if key in expected and isinstance(value, str)
        ]

    for key, value in items:
        identifier = str(key or "").strip()
        if identifier not in expected:
            continue
        text = sanitise(value, max_chars=4000, min_chars=0)
        if text:
            slides[identifier] = text
    missing = [identifier for identifier in expected if identifier not in slides]
    if missing and not error:
        error = f"Réponse incomplète : {', '.join(missing)}."
    # `error` est informative ici : le lot a produit quelque chose, il n'est donc
    # pas rejeté. Le service n'en fait un échec que si aucun commentaire n'a survécu.
    return {"slides": slides, "missing": missing, "error": error, "raw": str(raw or "")[:400]}
