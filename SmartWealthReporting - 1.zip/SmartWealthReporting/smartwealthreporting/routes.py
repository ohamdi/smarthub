from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query, Request, Response
from urllib.parse import quote

from . import narrative as narrative_module
from . import prompting
from . import verify as verify_module
from .auth import Principal, principal_from_session
from .config import DEFAULT_DATASETS
from .errors import APIError
from .schemas import (
    AIConfigRequest,
    ChatRequest,
    ChatResponse,
    ContextResponse,
    DatasetPreviewRequest,
    DatasourceConfigRequest,
    DefinitionUpdateRequest,
    GenerateRequest,
    GenerationResponse,
    LoginRequest,
    PromptUpdateRequest,
    UserCreateRequest,
    UserUpdateRequest,
)
from .services import ApplicationService

PPTX_MIME = "application/vnd.openxmlformats-officedocument.presentationml.presentation"

router = APIRouter(prefix="/api")
logger = logging.getLogger(__name__)


def get_service(request: Request) -> ApplicationService:
    return request.app.state.service


def require_user(request: Request) -> Principal:
    return principal_from_session(request.session)


Service = Annotated[ApplicationService, Depends(get_service)]
CurrentUser = Annotated[Principal, Depends(require_user)]


# ------------------------------------------------------------------- Session


@router.post("/login")
def login(payload: LoginRequest, request: Request, service: Service) -> dict[str, Any]:
    principal = service.auth.authenticate(payload.username, payload.password)
    request.session.update(
        {
            "user": principal.username,
            "role": principal.role,
            "client_id": principal.client_id,
            "permanent": True,
        }
    )
    return {
        "username": principal.username,
        "role": principal.role,
        "client_id": principal.client_id,
    }


@router.post("/logout")
def logout(request: Request) -> dict[str, bool]:
    request.session.clear()
    return {"ok": True}


@router.get("/me")
def me(user: CurrentUser) -> dict[str, Any]:
    return {"username": user.username, "role": user.role, "client_id": user.client_id}


@router.get("/users")
def list_users(_user: CurrentUser, service: Service) -> list[dict[str, Any]]:
    return service.auth.list_public_users()


@router.post("/users", status_code=201)
def create_user(payload: UserCreateRequest, _user: CurrentUser, service: Service) -> dict[str, Any]:
    service.auth.create_user(payload.username, payload.password, payload.role, payload.client_id)
    return {"ok": True}


@router.put("/users/{username}")
def update_user(
    username: str, payload: UserUpdateRequest, _user: CurrentUser, service: Service
) -> dict[str, Any]:
    service.auth.update_user(username, payload.model_dump(exclude_none=True))
    return {"ok": True}


@router.delete("/users/{username}")
def delete_user(username: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    service.auth.delete_user(username)
    return {"ok": True}


# -------------------------------------------------------------------- Données


@router.get("/datasets")
def datasets(_user: CurrentUser, service: Service) -> list[dict[str, Any]]:
    return service.datasets()


@router.post("/datasets/preview")
def preview_dataset(
    payload: DatasetPreviewRequest, _user: CurrentUser, service: Service
) -> dict[str, Any]:
    return service.dataset_preview(payload.name, payload.limit)


@router.get("/clients")
def clients(user: CurrentUser, service: Service) -> list[dict[str, Any]]:
    return service.clients(user)


# ----------------------------------------------------------------- Reportings


@router.get("/reportings")
def list_reportings(_user: CurrentUser, service: Service) -> list[dict[str, Any]]:
    return service.reportings()


@router.post("/reportings", status_code=201)
def create_reporting(
    payload: dict[str, str],
    _user: CurrentUser,
    service: Service,
) -> dict[str, Any]:
    identifier = str(payload.get("id", "")).strip()
    if not identifier:
        raise APIError(400, "Identifiant de reporting obligatoire.")
    return service.create_reporting(
        identifier, str(payload.get("name", "")), str(payload.get("copy_template", ""))
    )


@router.get("/reportings/{reporting_id}")
def reporting_detail(reporting_id: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    return service.reporting_detail(reporting_id)


@router.put("/reportings/{reporting_id}")
def update_reporting(
    reporting_id: str,
    payload: DefinitionUpdateRequest,
    _user: CurrentUser,
    service: Service,
) -> dict[str, Any]:
    return service.save_definition(reporting_id, payload.definition)


@router.delete("/reportings/{reporting_id}")
def delete_reporting(reporting_id: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    service.delete_reporting(reporting_id)
    return {"ok": True}


@router.put("/reportings/{reporting_id}/prompt")
def update_prompt(
    reporting_id: str, payload: PromptUpdateRequest, _user: CurrentUser, service: Service
) -> dict[str, Any]:
    return service.save_prompt(reporting_id, payload.prompt)


@router.get("/reportings/{reporting_id}/template.pptx")
def download_template(reporting_id: str, _user: CurrentUser, service: Service) -> Response:
    payload = service.template_bytes(reporting_id)
    return Response(
        content=payload,
        media_type=PPTX_MIME,
        headers={
            "Content-Disposition": f'attachment; filename="{reporting_id}-template.pptx"'
        },
    )


@router.post("/reportings/{reporting_id}/template/install")
def install_template(reporting_id: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    path = service.install_template(reporting_id)
    return {"ok": True, "path": str(path)}


@router.get("/reportings/{reporting_id}/context", response_model=ContextResponse)
def reporting_context(
    reporting_id: str,
    user: CurrentUser,
    service: Service,
    client_id: str = "",
    as_of: str = "",
    period: str = "",
    period_label: str = "",
) -> dict[str, Any]:
    request = GenerateRequest(
        client_id=client_id, as_of=as_of, period=period or None, period_label=period_label
    )
    return service.context_payload(reporting_id, user, request).model_dump()


@router.post("/reportings/{reporting_id}/context", response_model=ContextResponse)
def reporting_context_post(
    reporting_id: str,
    payload: GenerateRequest,
    user: CurrentUser,
    service: Service,
) -> dict[str, Any]:
    return service.context_payload(reporting_id, user, payload).model_dump()


@router.post("/reportings/{reporting_id}/generate", response_model=GenerationResponse)
def generate(
    reporting_id: str,
    payload: GenerateRequest,
    user: CurrentUser,
    service: Service,
) -> dict[str, Any]:
    return service.generate(reporting_id, user, payload).model_dump()


# --------------------------------------------------------------- Historique


@router.get("/runs")
def list_runs(
    _user: CurrentUser,
    service: Service,
    reporting_id: str = "",
    limit: int = Query(default=50, ge=1, le=200),
) -> list[dict[str, Any]]:
    return service.runs(reporting_id, limit)


@router.get("/runs/{reporting_id}/{filename}")
def download_run(
    reporting_id: str, filename: str, _user: CurrentUser, service: Service
) -> Response:
    path = service.output_path(reporting_id, filename)
    return Response(
        content=path.read_bytes(),
        media_type=PPTX_MIME,
        headers={
            "Content-Disposition": f'attachment; filename="{quote(path.name)}"',
            "Content-Length": str(path.stat().st_size),
        },
    )


# ----------------------------------------------------------------- Moteur IA


@router.get("/ai/status")
def ai_status(_user: CurrentUser, service: Service) -> dict[str, Any]:
    return service.ai_status()


@router.get("/ai/config")
def get_ai_config(_user: CurrentUser, service: Service) -> dict[str, Any]:
    return service.ai_settings()


@router.post("/ai/config")
def update_ai_config(payload: AIConfigRequest, _user: CurrentUser, service: Service) -> dict[str, Any]:
    values = {key: value for key, value in payload.model_dump().items() if value is not None}
    if not values:
        return service.ai_settings()
    return service.update_ai_settings(values)


@router.post("/ai/warmup")
def ai_warmup(_user: CurrentUser, service: Service) -> dict[str, Any]:
    try:
        return service.warmup()
    except RuntimeError as exc:
        raise APIError(503, str(exc)) from exc


@router.post("/ai/chat", response_model=ChatResponse)
def ai_chat(
    payload: ChatRequest, user: CurrentUser, service: Service
) -> dict[str, Any]:
    """Retouche assistée d'un commentaire de reporting.

    Le modèle ne réécrit qu'un texte : ni chiffres, ni mise en forme. Les
    nombres cités sont vérifiés contre les faits du reporting.
    """
    if service.llm is None:
        raise APIError(503, "Service IA non initialisé.")
    context = service.context_payload(
        payload.reporting_id, user, GenerateRequest(client_id=payload.client_id)
    )
    definition = service.library.load(payload.reporting_id)
    system = prompting.system_prompt(
        service.library.load_prompt(payload.reporting_id),
        context.context_text,
        language=definition.language,
        audience=definition.audience,
    )
    messages = [
        {"role": "system", "content": system},
        {
            "role": "user",
            "content": (
                "Améliore ce commentaire de reporting pour "
                f"{payload.question.strip()}\n"
                'Réponds uniquement par {"slides":{"commentaire":"texte"}}'
            ),
        },
    ]
    try:
        raw = service.llm.chat(messages)
    except Exception as exc:
        logger.warning("AI chat failed", exc_info=exc)
        raise APIError(503, "Service IA momentanément indisponible.") from exc
    parsed = narrative_module.parse_reply(raw, ["commentaire"])
    text = parsed["slides"].get("commentaire", "")
    report = verify_module.check(text, verify_module.build_registry(context.context_text))
    return {
        "answer": text or parsed.get("error", "Réponse vide."),
        "slides": parsed["slides"],
        "verification": {**report, "warning": verify_module.warning(report)},
    }


# -------------------------------------------------------------- Configuration


@router.get("/config/datasource")
def get_datasource_config(_user: CurrentUser, service: Service) -> dict[str, Any]:
    raw = service.config.load()
    return {
        "datasets": service.config.dataset_paths(),
        "llm": service.config.llm_settings(),
        "raw": raw,
    }


@router.post("/config/datasource")
def update_datasource_config(
    payload: DatasourceConfigRequest, _user: CurrentUser, service: Service
) -> dict[str, Any]:
    values: dict[str, Any] = {}
    if payload.datasets:
        values.update({key: value for key, value in payload.datasets.items() if value})
    for key in ("gguf_path", "llm_backend", "llamafile_path", "llamafile_port", "llamafile_url"):
        value = getattr(payload, key)
        if value is not None:
            values[key] = value
    if not values:
        return get_datasource_config(_user, service)
    service.update_datasets(values)
    return get_datasource_config(_user, service)


@router.post("/config/datasets/{name}/reset")
def reset_dataset(name: str, _user: CurrentUser, service: Service) -> dict[str, Any]:
    if name not in DEFAULT_DATASETS:
        raise APIError(404, f"Dataset inconnu : {name}")
    service.update_datasets({name: DEFAULT_DATASETS[name]})
    return {"ok": True, "datasets": service.config.dataset_paths()}
