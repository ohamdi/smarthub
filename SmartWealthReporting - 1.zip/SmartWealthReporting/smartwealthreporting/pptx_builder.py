"""Rendu du deck : faits calculés + narration validée → PPTX final.

Deux chemins de rendu, sans Everett dans l'interface :

* **template à zones** — le template porte des slides modèles (`SWR_LAYOUT`) que le
  moteur duplique, ce qui conserve exactement la charte de la maison ;
* **repli sans zones** — un template de marque externe est exploité tel quel : les
  slides sont construites sur son layout vierge, aux positions par défaut.

Dans les deux cas, le contenu vient des faits du serveur. La narration n'est
qu'un texte : elle n'entre jamais dans un titre, un indicateur ou un graphique.
"""

from __future__ import annotations

import copy
import io
import logging
import re
from typing import Any

from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_TICK_LABEL_POSITION
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

from . import templates as T
from .context import FACT_LABELS, format_number
from .errors import TemplateError
from .schemas import ChartSpec, ReportingDefinition, SlideDefinition, TableSpec

logger = logging.getLogger(__name__)

PLACEHOLDER = re.compile(r"\{\{\s*([a-z0-9_.]+)\s*\}\}")

MONTHS_FR = {
    1: "janvier", 2: "février", 3: "mars", 4: "avril", 5: "mai", 6: "juin",
    7: "juillet", 8: "août", 9: "septembre", 10: "octobre", 11: "novembre",
    12: "décembre",
}

MONTHS_FR_SHORT = {
    1: "janv.", 2: "févr.", 3: "mars", 4: "avr.", 5: "mai", 6: "juin",
    7: "juil.", 8: "août", 9: "sept.", 10: "oct.", 11: "nov.", 12: "déc.",
}

CHART_TYPES = {
    "doughnut": XL_CHART_TYPE.DOUGHNUT,
    "pie": XL_CHART_TYPE.PIE,
    "bar": XL_CHART_TYPE.BAR_CLUSTERED,
    "barh": XL_CHART_TYPE.BAR_CLUSTERED,
    "column": XL_CHART_TYPE.COLUMN_CLUSTERED,
    "stacked_bar": XL_CHART_TYPE.COLUMN_STACKED,
    "stacked_area": XL_CHART_TYPE.AREA_STACKED,
    "line": XL_CHART_TYPE.LINE_MARKERS,
    "area": XL_CHART_TYPE.AREA,
}

#: Types tracés en contour plutôt qu'en aplat : pas de dégradé, pas de 3D.
_OUTLINE_KINDS = {"line", "area", "stacked_area"}


def format_date_fr(value: str) -> str:
    from datetime import date, datetime

    text = str(value or "").strip()
    for parse in (lambda t: datetime.strptime(t, "%Y-%m-%d"), lambda t: date.fromisoformat(t)):
        try:
            parsed = parse(text)
            return f"{parsed.day} {MONTHS_FR[parsed.month]} {parsed.year}"
        except (TypeError, ValueError):
            continue
    return text


def format_value(value: Any, fmt: str, *, decimals: int | None = None, suffix: str = "", currency: str = "EUR") -> str:
    """Mise en forme d'un indicateur ou d'une cellule, selon son format déclaré."""
    if value is None or value == "":
        return "—"
    if fmt == "text":
        return str(value)
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if fmt == "percent":
        digits = 2 if decimals is None else decimals
        rendered = format_number(number, decimals=digits)
        return f"{'+' if number > 0 else ''}{rendered}{suffix or ' %'}"
    if fmt == "share":
        digits = 2 if decimals is None else decimals
        rendered = format_number(number, decimals=digits)
        # Un poids ne porte pas de signe : « +34,18 % de l'actif » se lit mal.
        return f"{rendered}{suffix or ' %'}"
    if fmt == "currency":
        digits = 0 if decimals is None else decimals
        rendered = format_number(abs(number), decimals=digits)
        sign = "-" if number < 0 else ""
        symbol = "" if currency in {"", "—"} else f" {currency}"
        return f"{sign}{rendered}{symbol}{suffix}"
    digits = 2 if decimals is None else decimals
    if decimals == 0 or float(number).is_integer():
        return format_number(number, decimals=0) + suffix
    return f"{format_number(number, decimals=digits)}{suffix}"


def substitute(text: str, variables: dict[str, Any]) -> str:
    """Remplace les `{{client_name}}`, `{{period_label}}`… d'un titre ou d'un libellé."""
    if not text:
        return ""
    return PLACEHOLDER.sub(
        lambda match: str(variables.get(match.group(1), match.group(0)) or match.group(0)),
        str(text),
    )


def build_variables(definition: ReportingDefinition, facts: dict[str, Any]) -> dict[str, Any]:
    client = facts.get("client") or {}
    period = facts.get("period") or {}
    kpis = facts.get("kpis") or {}
    as_of = str(period.get("as_of") or "")
    portfolios = facts.get("portfolios") or []
    first = portfolios[0] if portfolios else {}
    variables: dict[str, Any] = {
        "client_name": client.get("client_name", "") or "Client",
        "client_id": client.get("client_id", ""),
        "segment": client.get("segment", ""),
        "domicile": client.get("domicile", ""),
        "risk_profile": client.get("risk_profile", ""),
        "relationship_manager": client.get("relationship_manager", ""),
        "period_label": period.get("label", ""),
        "as_of": as_of,
        "as_of_fr": format_date_fr(as_of),
        "currency": period.get("base_currency", "EUR"),
        "report_name": definition.name,
        "audience": definition.audience,
        "aum": format_number(kpis.get("aum_total"), decimals=0),
        "performance": f"{float(kpis.get('portfolio_cum_return', 0) or 0):+.2f} %",
        "generated_at": format_date_fr(as_of) or "",
        # Identité du portefeuille : la couverture d'un rapport de gestion
        # s'identifie par son numéro, pas seulement par le nom du client.
        # Le résumé de portefeuille expose `name` et `mandate` ; les noms
        # bruts du dataset restent acceptés pour un fait construit à la main.
        "portfolio_id": first.get("portfolio_id", "") or client.get("client_id", ""),
        "portfolio_name": first.get("name", "") or first.get("portfolio_name", ""),
        "mandate_type": first.get("mandate", "") or first.get("mandate_type", ""),
        "strategy": first.get("strategy", ""),
        "inception_date": format_date_fr(str(first.get("inception_date", "") or "")),
        "year": as_of[:4],
    }
    return {key: str(value) for key, value in variables.items()}


# --------------------------------------------------------------------- Rendu


class DeckBuilder:
    """Construit le PPTX final d'un reporting."""

    def __init__(self, template_path: str | None = None, *, brand: dict[str, Any] | None = None) -> None:
        self.template_path = template_path
        self.brand = brand or {}

    # ------------------------------------------------------------ Chargement

    def _open(self, palette: T.Palette) -> Presentation:
        if self.template_path:
            try:
                prs = Presentation(str(self.template_path))
            except Exception as exc:
                raise TemplateError(f"Template PPTX illisible : {exc}") from exc
            if T.has_layout_slides(prs):
                return prs
            # Template de marque sans zones nommées : on l'utilise tel quel.
            logger.info("Template without SWR_LAYOUT slides: using default geometry")
        return T.build_default_template(self.brand or palette.as_dict())

    # ------------------------------------------------------------- Rendu

    def render(
        self,
        definition: ReportingDefinition,
        facts: dict[str, Any],
        narratives: dict[str, str],
        *,
        as_of: str = "",
    ) -> bytes:
        palette = T.Palette(definition.brand.model_dump())
        prs = self._open(palette)
        blueprints = {
            name: prs.slides[index] for name, index in T.layout_names(prs).items()
        }
        variables = build_variables(definition, facts)

        # Les slides modèles servent de gabarit puis disparaissent du livrable : le
        # client ne doit pas recevoir une slide vide marquée « SWR_LAYOUT ». Les
        # objets restent référencés le temps du rendu pour être dupliqués.
        for _ in range(len(prs.slides)):
            _delete_slide(prs, 0)

        warnings: list[str] = []
        for slide in definition.slides:
            layout = str(slide.layout)
            source = blueprints.get(layout)
            if source is None:
                target = prs.slides.add_slide(T.blank_layout(prs))
                self._draw_fallback(target, layout, palette)
                warnings.append(f"Template : slide modèle « {layout} » absente, géométrie par défaut.")
            else:
                target = _duplicate_slide(prs, source)
            _remove_marker(target)
            try:
                self._fill(
                    target, slide, layout, palette, facts, narratives, variables,
                    as_of, definition,
                )
            except Exception:
                logger.exception("Slide %s: rendu incomplet", slide.id)
                warnings.append(f"Slide « {slide.id} » partiellement remplie.")

        buffer = io.BytesIO()
        prs.save(buffer)
        if warnings:
            logger.info("Deck built with warnings: %s", "; ".join(warnings))
        return buffer.getvalue()

    # ------------------------------------------------------------- Contenu

    def _fill(
        self,
        slide: Any,
        spec: SlideDefinition,
        layout: str,
        palette: T.Palette,
        facts: dict[str, Any],
        narratives: dict[str, str],
        variables: dict[str, Any],
        as_of: str,
        definition: ReportingDefinition,
    ) -> None:
        title = substitute(spec.title, variables) or _default_title(layout)
        if layout == "disclaimer":
            title = spec.title or "Mentions légales"

        if layout in {"cover", "section"}:
            # Fond blanc : titre en bleu nuit, jamais de texte blanc sur aplat.
            _set_zone(
                slide, T.ZONE_TITLE, title, size=36 if layout == "cover" else 28,
                color=palette.primary, bold=True, font=palette.font_title,
                rect=T.DEFAULT_ZONES["cover_title"] if layout == "cover"
                else (T.MARGIN_LEFT, 3.2, 10.6, 0.9),
            )
            _set_zone(
                slide, T.ZONE_SUBTITLE, substitute(spec.subtitle, variables),
                size=15 if layout == "cover" else 13, color=palette.ink,
                font=palette.font_body,
                rect=T.DEFAULT_ZONES["cover_subtitle"] if layout == "cover"
                else (T.MARGIN_LEFT, 4.15, 10.6, 0.6),
            )
            if layout == "cover":
                _set_zone(
                    slide, T.ZONE_META, cover_meta(variables), size=10.5,
                    color=palette.neutral, font=palette.font_body,
                    rect=T.DEFAULT_ZONES["cover_meta"],
                )
                if palette.legal_entity:
                    _set_zone(slide, "SWR_LEGAL", palette.legal_entity, size=8.5,
                              color=palette.neutral, font=palette.font_body,
                              rect=(T.MARGIN_LEFT, 6.5, 8.4, 0.3))
                if palette.confidentiality:
                    _set_zone(slide, "SWR_CONFIDENTIAL", palette.confidentiality,
                              size=8.5, color=palette.neutral, bold=True,
                              font=palette.font_body, align=PP_ALIGN.RIGHT,
                              rect=(9.2, 6.5, 3.51, 0.3))
            else:
                _set_zone(
                    slide, T.ZONE_META, substitute(spec.text, variables), size=11,
                    color=palette.neutral, font=palette.font_body,
                    rect=(T.MARGIN_LEFT, 4.9, 10.6, 0.9),
                )
            return

        _set_zone(slide, T.ZONE_TITLE, title, size=20, color=palette.primary, bold=True,
                  font=palette.font_title, rect=T.title_zone(palette))

        if layout == "disclaimer":
            # Les mentions légales sont la seule narration du deck qui ne vient
            # pas de l'IA : elles sont rédigées dans la définition.
            body = substitute(
                spec.text or definition.disclaimer, variables
            ).replace("{as_of}", format_date_fr(as_of) or variables.get("as_of", ""))
            _set_zone(slide, T.ZONE_TEXT, body, size=9, color=palette.ink,
                      font=palette.font_body, line_spacing=1.18,
                      rect=(T.MARGIN_LEFT, 1.75, T.CONTENT_WIDTH, 4.5))
            _set_zone(slide, T.ZONE_FOOTER, footer_band(palette, variables, facts), size=7.5,
                      color=palette.neutral, font=palette.font_body,
                      rect=T.DEFAULT_ZONES["footer"])
            _set_zone(slide, T.ZONE_PAGE, "", size=7.5, color=palette.neutral,
                      font=palette.font_body, align=PP_ALIGN.RIGHT,
                      rect=T.DEFAULT_ZONES["page"])
            return

        # Des indicateurs posés sur une slide qui n'est pas une slide « kpis »
        # occupent un bandeau haut : graphique, tableau et narration sont alors
        # replacés selon une disposition déterministe, pas selon les ancres du
        # template, pour ne pas se chevaucher.
        stacked = bool(spec.kpis) and layout != "kpis"
        zones = _stacked_zones(layout) if stacked else _kpi_layout_zones(layout, len(spec.kpis))
        if stacked:
            # Les ancres du template sont retirées : elles décrivent une
            # composition sans indicateurs, donc sans le bandeau qui les pousse.
            for zone in (T.ZONE_CHART, T.ZONE_TABLE, T.ZONE_TEXT):
                _drop_zone(slide, zone)

        if spec.kpis and layout in {"kpis", "chart", "table", "narrative", "text"}:
            self._render_kpis(slide, spec, palette, facts, variables, stacked)

        note = (narratives.get(spec.id) or spec.text or "").strip()

        if spec.chart and layout in {"chart", "kpis", "table", "narrative", "text"}:
            self._render_chart(slide, spec.chart, palette, facts, variables, layout, zones)

        if spec.panels and layout == "chart":
            # Les petits multiples remplacent la composition du template : son
            # cadre d'ancrage et sa zone texte décrivent un graphique unique.
            _drop_zone(slide, T.ZONE_CHART)
            _drop_zone(slide, T.ZONE_TEXT)
            note_rect = _panel_note_rect(bool(note))
            placed = self._render_panels(
                slide, spec.panels, palette, facts, variables, note_rect=bool(note)
            )
            if note and placed:
                _set_zone(
                    slide, T.ZONE_TEXT, substitute(note, variables), size=10,
                    color=palette.ink, font=palette.font_body, line_spacing=1.3,
                    rect=note_rect,
                )

        if spec.table and layout in {"table", "chart", "kpis", "narrative", "text"}:
            self._render_table(slide, spec.table, palette, facts, variables, layout, zones)

        narrative = "" if spec.panels else (narratives.get(spec.id) or "").strip()
        if narrative:
            _set_zone(slide, T.ZONE_TEXT, narrative, size=_narrative_size(layout),
                      color=palette.ink, font=palette.font_body,
                      line_spacing=1.25 if layout == "kpis" else 1.35,
                      rect=zones.get("text"))
        elif spec.text:
            _set_zone(slide, T.ZONE_TEXT, substitute(spec.text, variables),
                      size=_narrative_size(layout), color=palette.ink,
                      font=palette.font_body, line_spacing=1.3, rect=zones.get("text"))

        source = substitute(
            spec.footer or "Source : données de gestion au {{as_of_fr}}", variables
        )
        _set_zone(slide, T.ZONE_SOURCE, source, size=8, color=palette.neutral,
                  font=palette.font_body, rect=zones.get("source"))
        _set_zone(slide, T.ZONE_FOOTER, footer_band(palette, variables, facts), size=7.5,
                  color=palette.neutral, font=palette.font_body, rect=T.DEFAULT_ZONES["footer"])
        _set_zone(slide, T.ZONE_PAGE, "", size=7.5, color=palette.neutral,
                  font=palette.font_body, align=PP_ALIGN.RIGHT, rect=T.DEFAULT_ZONES["page"])

    # ---------------------------------------------------------------- KPI

    def _render_kpis(
        self,
        slide: Any,
        spec: SlideDefinition,
        palette: T.Palette,
        facts: dict[str, Any],
        variables: dict[str, Any],
        stacked: bool,
    ) -> None:
        currency = str((facts.get("period") or {}).get("base_currency", "EUR"))
        # En mode empilé, une seule rangée de cartes tient au-dessus du graphique ;
        # les indicateurs suivants sont ignorés plutôt que de chevaucher le visuel.
        declared = spec.kpis[:4] if stacked else spec.kpis[:8]
        for index, kpi in enumerate(declared, 1):
            value = resolve_metric(facts, kpi.key)
            label = substitute(kpi.label or kpi.key, variables)
            formatted = format_value(
                value, kpi.format, decimals=kpi.decimals, suffix=kpi.suffix, currency=currency
            )
            accent = (
                palette.value_color(_as_float(value))
                if _is_signed_metric(kpi.key)
                else palette.primary
            )
            shape = T.find_zone(slide, f"{T.KPI_ZONE_PREFIX}{index}")
            if shape is None:
                # Au-delà des cartes du template, on continue sur une seconde ligne.
                rect = T.kpi_rect(index) if index <= 4 else T.kpi_rect_secondary(index)
                shape = T.add_kpi_card(
                    slide, rect, f"{T.KPI_ZONE_PREFIX}{index}", palette
                )
            T.set_kpi_card(shape, formatted, label, palette, accent=accent)

    # ------------------------------------------------------------ Graphique

    def _render_chart(
        self,
        slide: Any,
        spec: ChartSpec,
        palette: T.Palette,
        facts: dict[str, Any],
        variables: dict[str, Any],
        layout: str,
        zones: dict[str, tuple[float, float, float, float]] | None = None,
        rect: tuple[float, float, float, float] | None = None,
    ) -> None:
        data = _chart_data(spec, facts)
        if data is None or not data["series"]:
            return
        zones = zones or {}
        fallback = zones.get("chart") or T.DEFAULT_ZONES["chart"]
        if rect is not None:
            left, top, width, height = rect
        # En mode empilé la position du template est ignorée : la disposition est
        # imposée par `_stacked_zones`, sinon le graphique passerait sous les cartes.
        elif zones.get("chart"):
            left, top, width, height = fallback
        else:
            left, top, width, height = T.zone_anchor(slide, T.ZONE_CHART, fallback)
            if width < 1.5 or height < 1.5:
                left, top, width, height = fallback

        frame = CategoryChartData()
        frame.categories = [str(category) for category in data["categories"]]
        for name, values in data["series"]:
            frame.add_series(name, tuple(values), number_format=data.get("number_format") or "General")

        chart_type = CHART_TYPES.get(str(spec.kind), XL_CHART_TYPE.COLUMN_CLUSTERED)
        graphic_frame = slide.shapes.add_chart(
            chart_type, Inches(left), Inches(top), Inches(width), Inches(height), frame
        )
        graphic_frame.name = "SWR_RENDERED_CHART"
        chart = graphic_frame.chart
        chart.font.size = Pt(9)
        chart.font.name = palette.font_body

        if rect is None:
            anchor = T.find_zone(slide, T.ZONE_CHART)
            if anchor is not None and anchor.has_text_frame:
                anchor.text_frame.clear()

        title = substitute(spec.title, variables)
        chart.has_title = bool(title)
        if title:
            chart.chart_title.text_frame.text = title
            chart.chart_title.text_frame.paragraphs[0].runs[0].font.size = Pt(11)
            chart.chart_title.text_frame.paragraphs[0].runs[0].font.bold = True
            chart.chart_title.text_frame.paragraphs[0].runs[0].font.color.rgb = palette.primary

        colors = palette.series_colors(max(len(data["categories"]), len(data["series"])))
        for index, series in enumerate(chart.series):
            try:
                if str(spec.kind) in _OUTLINE_KINDS:
                    # Courbes et aires : contour seul, jamais de dégradé.
                    series.format.line.color.rgb = colors[index % len(colors)]
                    series.format.line.width = Pt(1.5)
                    if hasattr(series, "smooth"):
                        series.smooth = False
                else:
                    series.format.fill.solid()
                    series.format.fill.fore_color.rgb = colors[index % len(colors)]
                    series.format.line.fill.background()
            except (AttributeError, IndexError, ValueError):
                pass

        if str(spec.kind) in {"doughnut", "pie"}:
            plot = chart.plots[0]
            plot.vary_by_categories = True
            for index, point in enumerate(chart.series[0].points):
                point.format.fill.solid()
                point.format.fill.fore_color.rgb = colors[index % len(colors)]
            if spec.show_values:
                plot.has_data_labels = True
                labels = plot.data_labels
                labels.show_percentage = True
                labels.show_value = False
                labels.show_category_name = False
                labels.number_format = "0.0%"
                labels.number_format_is_linked = False
                labels.font.size = Pt(9)
                labels.font.color.rgb = palette.neutral

        chart.has_legend = (
            (spec.show_legend and len(data["series"]) > 1)
            or str(spec.kind) in {"line", "area"}
        )
        if chart.has_legend:
            chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            chart.legend.include_in_layout = False
            chart.legend.font.size = Pt(9)

        try:
            category_axis = chart.category_axis
            category_axis.tick_labels.font.size = Pt(9)
            category_axis.tick_label_position = XL_TICK_LABEL_POSITION.LOW
            category_axis.has_major_gridlines = False
            if str(spec.kind) not in {"doughnut", "pie"}:
                category_axis.format.line.color.rgb = palette.rule
            if str(spec.kind) == "barh":
                # PowerPoint empile les barres de bas en haut : sans inversion,
                # le plus grand encours se retrouverait en bas du graphique.
                _reverse_categories(category_axis)
        except (ValueError, AttributeError):
            pass
        try:
            value_axis = chart.value_axis
            value_axis.tick_labels.font.size = Pt(8)
            value_axis.has_major_gridlines = True
            value_axis.major_gridlines.format.line.color.rgb = palette.rule
            value_axis.format.line.fill.background()
        except (ValueError, AttributeError):
            pass

    # -------------------------------------------------------------- Tableau

    def _render_table(
        self,
        slide: Any,
        spec: TableSpec,
        palette: T.Palette,
        facts: dict[str, Any],
        variables: dict[str, Any],
        layout: str,
        zones: dict[str, tuple[float, float, float, float]] | None = None,
    ) -> None:
        rows = _table_rows(spec, facts)
        if not rows:
            return
        columns = [column.key for column in spec.columns] or list(rows[0].keys())
        labels = [
            substitute(column.label or column.key.replace("_", " ").capitalize(), variables)
            for column in spec.columns
        ]
        if len(labels) < len(columns):
            labels = labels + [
                str(key).replace("_", " ").capitalize() for key in columns[len(labels):]
            ]
        formats = [column.format for column in spec.columns] + ["text"] * len(columns)
        decimals = [column.decimals for column in spec.columns] + [None] * len(columns)
        currency = str((facts.get("period") or {}).get("base_currency", "EUR"))

        zones = zones or {}
        fallback = zones.get("table") or T.DEFAULT_ZONES["table"]
        if zones.get("table"):
            left, top, width, height = fallback
        else:
            left, top, width, height = T.zone_anchor(slide, T.ZONE_TABLE, fallback)
        body_rows = len(rows) + 1
        table_height = min(height, 0.34 * body_rows)
        graphic_frame = slide.shapes.add_table(
            body_rows, len(columns), Inches(left), Inches(top), Inches(width), Inches(table_height)
        )
        graphic_frame.name = "SWR_RENDERED_TABLE"
        anchor = T.find_zone(slide, T.ZONE_TABLE)
        if anchor is not None and anchor.has_text_frame:
            anchor.text_frame.clear()

        table = graphic_frame.table
        table.first_row = True
        # Pas de bandes alternées : la charte veut des lignes fines et un fond
        # blanc, la hiérarchie se fait au poids et aux filets.
        table.horz_banding = False
        first_width = width * 0.34
        others = (width - first_width) / max(1, len(columns) - 1)
        for index in range(len(columns)):
            table.columns[index].width = Inches(first_width if index == 0 else others)

        for index, label in enumerate(labels):
            cell = table.cell(0, index)
            _fill_cell(cell, str(label), size=8.5, bold=True, color=palette.primary,
                       fill=palette.surface, rule=palette.rule)
        for row_index, row in enumerate(rows, 1):
            # Une ligne de total se reconnaît à son libellé : elle est mise en
            # gras et fermée par un filet plus marqué.
            is_total = _is_total_row(row)
            for column_index, key in enumerate(columns):
                fmt = formats[column_index] if column_index < len(formats) else "text"
                dec = decimals[column_index] if column_index < len(decimals) else None
                value = _format_cell(row.get(key), fmt, dec, currency)
                color = palette.ink
                if fmt == "percent" and key in {"pnl_pct", "return"}:
                    color = palette.value_color(_as_float(row.get(key)))
                _fill_cell(
                    table.cell(row_index, column_index), value, size=8.5,
                    color=palette.primary if is_total else color, fill=palette.background,
                    bold=is_total, rule=palette.rule,
                    align=PP_ALIGN.LEFT if column_index == 0 else PP_ALIGN.RIGHT,
                )

    # --------------------------------------------------------------- Repli

    def _render_panels(
        self,
        slide: Any,
        specs: list[ChartSpec],
        palette: T.Palette,
        facts: dict[str, Any],
        variables: dict[str, Any],
        *,
        note_rect: bool = False,
    ) -> int:
        """Dispose jusqu'à quatre graphiques en grille 2x2 sur une même slide.

        C'est la présentation en petits multiples du rapport de gestion : quatre
        répartitions lues d'un coup d'œil, chacune avec son propre titre. Une
        répartition sans donnée est simplement sautée, la grille se referme.
        """
        area = _panel_area(reserved=note_rect)
        placed: list[tuple[ChartSpec, tuple[float, float, float, float]]] = []
        for spec in specs[:4]:
            if _chart_data(spec, facts) is None:
                continue
            placed.append((spec, _panel_rect(area, len(placed))))
        for spec, rect in placed:
            self._render_chart(
                slide, spec, palette, facts, variables, "chart", None, rect=rect
            )
        return len(placed)

    def _draw_fallback(self, slide: Any, layout: str, palette: T.Palette) -> None:
        """Gabarit dessiné à la main quand le template n'a pas de slide modèle."""
        if layout == "cover":
            _set_zone(slide, T.ZONE_TITLE, "", size=36, color=palette.primary, bold=True,
                      font=palette.font_title, rect=T.DEFAULT_ZONES["cover_title"])
            _set_zone(slide, T.ZONE_SUBTITLE, "", size=15, color=palette.ink,
                      font=palette.font_body, rect=T.DEFAULT_ZONES["cover_subtitle"])
            _set_zone(slide, T.ZONE_META, "", size=10.5, color=palette.neutral,
                      font=palette.font_body, line_spacing=1.35,
                      rect=T.DEFAULT_ZONES["cover_meta"])
            return
        T.header_block(slide, palette)
        _set_zone(slide, T.ZONE_TITLE, "", size=20, color=palette.primary, bold=True,
                  font=palette.font_title, rect=T.title_zone(palette))
        _set_zone(slide, T.ZONE_TEXT, "", size=11.5, color=palette.ink, font=palette.font_body,
                  line_spacing=1.35,
                  rect=T.DEFAULT_ZONES["text_wide"] if layout in {"narrative", "text"} else T.DEFAULT_ZONES["text"])
        T.footer_line(slide, palette)


# ------------------------------------------------------------------ Utilitaires


_WHITE = RGBColor(0xFF, 0xFF, 0xFF)


def cover_meta(variables: dict[str, Any]) -> str:
    """Bloc d'identité de la couverture : société, portefeuille, orientation, date.

    Le rapport de gestion s'identifie par le portefeuille et son mandat, pas
    seulement par le nom du client : c'est ce que le lecteur recherche en
    première ligne.
    """
    parts: list[str] = []
    client = str(variables.get("client_name", "") or "")
    if client:
        parts.append(f"Société : {client}")
    portfolio = str(variables.get("portfolio_id", "") or "")
    if portfolio:
        parts.append(f"Portefeuille n° {portfolio}")
    mandate = str(variables.get("mandate_type", "") or "")
    if mandate:
        parts.append(f"Orientation de gestion : {mandate}")
    parts.append(f"Arrêté au {variables.get('as_of_fr', '')}")
    return "\n".join(part for part in parts if not part.rstrip().endswith(":"))


def footer_band(palette: T.Palette, variables: dict[str, Any], facts: dict[str, Any]) -> str:
    """Bandeau de pied de page du rapport de gestion.

    Format de référence : « CA Indosuez Gestion | Rapport de gestion | Personnel
    et confidentiel | 2026 ». Sans identité de marque déclarée, on retombe sur
    la mention client / conseiller, qui reste informative.
    """
    if not (palette.legal_entity or palette.report_label or palette.confidentiality):
        return definition_footer(facts)
    year = str(variables.get("year") or str(variables.get("as_of", ""))[:4])
    parts = [
        palette.legal_entity,
        palette.report_label or str(variables.get("report_name", "")),
        palette.confidentiality,
        year,
    ]
    return " | ".join(part for part in parts if part)


def _kpi_layout_zones(
    layout: str, count: int
) -> dict[str, tuple[float, float, float, float]]:
    """Zone texte d'une slide « kpis » à repositionner.

    Le template fournit déjà une zone sous le bandeau de cartes, ce qui suffit
    pour une rangée d'indicateurs. Au-delà de quatre, une seconde rangée
    s'ajoute : l'ancre du template, prévue pour une seule rangée, se retrouve
    alors sous les cartes et la narration y serait illisible.
    """
    if layout != "kpis" or count <= T.KPI_COLUMNS:
        return {}
    return {"text": T.DEFAULT_ZONES["text_below_kpi_second_row"]}


def _stacked_zones(layout: str) -> dict[str, tuple[float, float, float, float]]:
    """Zones décalées sous un bandeau d'indicateurs posé sur une autre slide.

    En mode empilé, la géométrie du template est ignorée : la présence
    d'indicateurs change la composition de la slide, il faut donc une
    disposition déterministe plutôt que les ancres du template.
    """
    top = 3.42
    if layout == "chart":
        return {
            "chart": (T.MARGIN_LEFT, top, 7.7, 3.2),
            "text": (8.55, top, 4.15, 3.2),
            "source": T.DEFAULT_ZONES["source"],
        }
    if layout == "table":
        return {
            "table": (T.MARGIN_LEFT, top, T.CONTENT_WIDTH, 2.5),
            "text": (T.MARGIN_LEFT, 6.05, T.CONTENT_WIDTH, 0.62),
            "source": T.DEFAULT_ZONES["source"],
        }
    return {
        "text": (T.MARGIN_LEFT, top, T.CONTENT_WIDTH, 3.2),
        "source": T.DEFAULT_ZONES["source"],
    }


def _default_title(layout: str) -> str:
    return {
        "chart": "Analyse",
        "table": "Détail",
        "kpis": "Indicateurs clés",
        "narrative": "Commentaire",
        "text": "",
        "section": "",
        "cover": "",
        "disclaimer": "Mentions légales",
    }.get(layout, "")


def _narrative_size(layout: str) -> float:
    return {"kpis": 11.5, "chart": 11.0, "table": 10.0}.get(layout, 13.0)


def definition_footer(facts: dict[str, Any]) -> str:
    client = facts.get("client") or {}
    name = str(client.get("client_name", "") or "Client")
    manager = str(client.get("relationship_manager", "") or "")
    parts = [part for part in (name, f"Conseiller : {manager}" if manager else "") if part]
    return " — ".join(parts)


def _as_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


#: Blocs de faits consultables par une clé d'indicateur, après `kpis`.
METRIC_BLOCKS = (
    "esg", "pnl", "concentration", "flows", "activity", "period", "client", "bonds",
)


def resolve_metric(facts: dict[str, Any], key: str) -> Any:
    """Valeur d'un indicateur, quelle que soit la façon dont la clé est écrite.

    Les KPI vivent dans `facts["kpis"]`, mais une slide peut vouloir afficher un
    fait d'un autre bloc — le score ESG, le drawdown, la part des cinq premiers
    poids. Deux écritures sont acceptées : le nom plat (`top5_pct`, recherche dans
    tous les blocs) et le chemin explicite (`esg.score`, non ambigu). Le chemin
    explicite gagne quand les deux existent.
    """
    name = str(key or "").strip()
    if not name:
        return None
    kpis = facts.get("kpis") or {}
    if name in kpis:
        return kpis[name]
    if "." in name:
        head, _, tail = name.partition(".")
        block = facts.get(head)
        if isinstance(block, dict):
            return block.get(tail)
        return None
    for block in METRIC_BLOCKS:
        values = facts.get(block)
        if isinstance(values, dict) and name in values:
            return values[name]
    logger.warning("Unknown KPI key: %s", name)
    return None


def _is_signed_metric(key: str) -> bool:
    """Un indicateur signé (performance, P&L, écart) prend la couleur de sa valeur."""
    name = str(key).rsplit(".", 1)[-1]
    return name.startswith(
        ("performance", "alpha", "return", "pnl", "unrealised", "realised", "net_pnl")
    ) or name.endswith(("_pct", "_return", "_delta")) and name.startswith(("alpha", "beta"))


def _set_zone(
    slide: Any,
    name: str,
    text: str,
    *,
    size: float,
    color: RGBColor,
    bold: bool = False,
    font: str = "Calibri",
    align: PP_ALIGN = PP_ALIGN.LEFT,
    line_spacing: float | None = None,
    rect: tuple[float, float, float, float] | None = None,
    anchor: MSO_ANCHOR = MSO_ANCHOR.TOP,
) -> None:
    """Écrit une zone nommée ; la dessine si le template ne l'a pas prévue.

    Un `rect` explicite l'emporte sur l'ancre du template : il sert à
    repousser une zone dont la position par défaut est devenue incorrecte
    (bandeau d'indicateurs, seconde rangée de cartes).
    """
    shape = T.find_zone(slide, name)
    if shape is None:
        shape = T.add_textbox(slide, rect or T.zone_default(name), name)
    elif rect is not None:
        T.move_shape(shape, rect)
    T.set_text(
        shape, text, size=size, color=color, bold=bold, font=font, align=align,
        line_spacing=line_spacing, anchor=anchor,
    )


def _remove_marker(slide: Any) -> None:
    marker = T.find_zone(slide, T.LAYOUT_MARKER)
    if marker is not None:
        marker._element.getparent().remove(marker._element)


def _drop_zone(slide: Any, name: str) -> None:
    """Retire une zone du template dont la position n'a plus lieu d'être."""
    shape = T.find_zone(slide, name)
    if shape is not None:
        shape._element.getparent().remove(shape._element)


def _clear_cell_borders(cell: Any) -> None:
    """Neutralise les bordures héritées du style de table."""
    properties = cell._tc.get_or_add_tcPr()
    for tag in ("a:lnL", "a:lnR", "a:lnT", "a:lnB"):
        for element in properties.findall(qn(tag)):
            properties.remove(element)


def _set_cell_rule(cell: Any, color: RGBColor, width_pt: float = 0.75) -> None:
    """Trace un filet fin sous la cellule.

    python-pptx n'expose pas les bordures de cellule : la ligne se construit en
    XML (`a:lnB`). La charte demande des filets fins, pas un cadre épais — on
    supprime donc les autres bords et on ne garde que la séparation horizontale.
    """
    from pptx.oxml import parse_xml
    from pptx.oxml.ns import nsdecls

    _clear_cell_borders(cell)
    properties = cell._tc.get_or_add_tcPr()
    line = parse_xml(
        f'<a:lnB {nsdecls("a")} w="{int(width_pt * 12700)}" cap="flat">'
        f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
        '<a:prstDash val="solid"/>'
        "</a:lnB>"
    )
    # L'ordre des enfants de tcPr est imposé par le schéma : les lignes de
    # bordure précèdent le remplissage, qui lui-même précède les marges.
    fill = properties.find(qn("a:solidFill"))
    if fill is not None:
        fill.addprevious(line)
    else:
        properties.insert(0, line)


def _fill_cell(cell: Any, text: str, *, size: float, color: RGBColor, fill: RGBColor,
               bold: bool = False, align: PP_ALIGN = PP_ALIGN.LEFT,
               rule: RGBColor | None = None) -> None:
    cell.fill.solid()
    cell.fill.fore_color.rgb = fill
    cell.margin_left = Pt(6)
    cell.margin_right = Pt(6)
    cell.margin_top = Pt(2)
    cell.margin_bottom = Pt(2)
    cell.vertical_anchor = MSO_ANCHOR.MIDDLE
    frame = cell.text_frame
    frame.clear()
    frame.word_wrap = True
    paragraph = frame.paragraphs[0]
    paragraph.alignment = align
    run = paragraph.add_run()
    run.text = str(text)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    if rule is not None:
        _set_cell_rule(cell, rule)
    else:
        _clear_cell_borders(cell)


#: Préfixes de libellé qui désignent une ligne de clôture d'un tableau.
TOTAL_PREFIXES = ("total", "total général")


def _is_total_row(row: dict[str, Any]) -> bool:
    """Vrai pour une ligne de total, signalée par le fait ou par son libellé."""
    if row.get("total") is True:
        return True
    label = str(row.get("label") or row.get("typology") or "").strip().lower()
    return label.startswith(TOTAL_PREFIXES)


def _format_cell(value: Any, fmt: str, decimals: int | None, currency: str) -> str:
    if fmt == "text":
        return "—" if value is None or value == "" else str(value)
    return format_value(value, fmt, decimals=decimals, currency=currency)


def _delete_slide(prs: Presentation, index: int) -> None:
    slide_ids = prs.slides._sldIdLst  # noqa: SLF001 - API interne, stable depuis 0.6.19
    entries = list(slide_ids)
    if index >= len(entries):
        return
    entry = entries[index]
    rel_id = entry.get(qn("r:id"))
    if rel_id:
        prs.part.drop_rel(rel_id)
    slide_ids.remove(entry)


def _duplicate_slide(prs: Presentation, source: Any) -> Any:
    """Duplique une slide modèle en copiant son XML.

    Les images ne sont pas recopiées par relation (rId) mais réinsérées depuis
    leur contenu binaire : le résultat ne dépend pas de la numérotation des
    relations du template.
    """
    target = prs.slides.add_slide(T.blank_layout(prs))
    for shape in list(target.shapes):
        shape._element.getparent().remove(shape._element)
    _copy_background(source, target)

    for shape in source.shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            try:
                picture = target.shapes.add_picture(
                    io.BytesIO(shape.image.blob), shape.left, shape.top,
                    shape.width, shape.height,
                )
                picture.name = shape.name
            except Exception:  # pragma: no cover - image illisible : on l'ignore
                logger.warning("Unable to copy picture %s", shape.name)
            continue
        target.shapes._spTree.append(copy.deepcopy(shape._element))  # noqa: SLF001
    return target


def _copy_background(source: Any, target: Any) -> None:
    """Reprend le fond (couleur ou image) de la slide modèle."""
    source_bg = source._element.find(qn("p:cSld")).find(qn("p:bg"))
    if source_bg is None:
        return
    target_c_sld = target._element.find(qn("p:cSld"))
    existing = target_c_sld.find(qn("p:bg"))
    if existing is not None:
        target_c_sld.remove(existing)
    target_c_sld.insert(0, copy.deepcopy(source_bg))


# ------------------------------------------------------- Sources des données


#: Zone utile d'une grille de petits multiples, en pouces.
PANEL_TOP = 1.62
PANEL_HEIGHT = 4.45
PANEL_GAP = 0.22
#: Hauteur réservée à la note de lecture sous la grille.
PANEL_NOTE_GAP = 0.16
PANEL_NOTE_HEIGHT = 1.15


def _panel_area(*, reserved: bool) -> tuple[float, float, float, float]:
    """Zone de la grille, raccourcie si une note de lecture doit passer dessous."""
    height = PANEL_HEIGHT - (PANEL_NOTE_GAP + PANEL_NOTE_HEIGHT) if reserved else PANEL_HEIGHT
    return (T.MARGIN_LEFT, PANEL_TOP, T.CONTENT_WIDTH, height)


def _panel_note_rect(has_note: bool) -> tuple[float, float, float, float] | None:
    """Position de la note de lecture sous la grille des petits multiples."""
    if not has_note:
        return None
    top = PANEL_TOP + PANEL_HEIGHT - PANEL_NOTE_HEIGHT
    return (T.MARGIN_LEFT, top, T.CONTENT_WIDTH, PANEL_NOTE_HEIGHT)


def _panel_rect(area: tuple[float, float, float, float], placed: int) -> tuple[float, float, float, float]:
    """Case du `placed`-ième petit multiple dans la grille 2x2.

    Le rang détermine à lui seul la case : une répartition sans donnée décale
    les suivantes sans laisser de trou dans la grille.
    """
    left, top, width, height = area
    cell_width = (width - PANEL_GAP) / 2
    cell_height = (height - PANEL_GAP) / 2
    column = placed % 2
    row = placed // 2
    return (
        left + column * (cell_width + PANEL_GAP),
        top + row * (cell_height + PANEL_GAP),
        cell_width,
        cell_height,
    )


def _reverse_categories(axis: Any) -> None:
    """Axe des catégories de haut en bas (barres horizontales décroissantes).

    L'orientation d'un axe n'est pas exposée par python-pptx : elle se règle
    dans le XML, à `c:scaling/c:orientation`.
    """
    scaling = axis._element.find(qn("c:scaling"))
    if scaling is None:
        return
    orientation = scaling.find(qn("c:orientation"))
    if orientation is not None:
        orientation.set("val", "maxMin")


def _chart_data(spec: ChartSpec, facts: dict[str, Any]) -> dict[str, Any] | None:
    """Traduit une spécification de graphique en catégories et séries chiffrées."""
    source = str(spec.source)
    if source == "allocation":
        slices = (facts.get("allocations") or {}).get(str(spec.dimension)) or []
        slices = slices[: spec.limit]
        return {
            "categories": [str(slice_["label"]) for slice_ in slices],
            "series": [("% de l'actif", [float(slice_["pct"]) for slice_ in slices])],
            "number_format": "0.0",
        }
    if source == "performance":
        performance = facts.get("performance") or {}
        labels = performance.get("labels") or []
        requested = list(spec.series) or ["portfolio"]
        series: list[tuple[str, list[float]]] = []
        for name in requested:
            values = performance.get(str(name)) or []
            if values:
                series.append((str(name).capitalize(), [float(value) for value in values]))
        if not series or not labels:
            return None
        return {
            "categories": [str(label) for label in labels],
            "series": series,
            "number_format": "0.0",
        }
    if source in {"top_holdings", "pnl"}:
        holdings = (facts.get("top_holdings") or [])[: spec.limit]
        if not holdings:
            return None
        measure = "pnl_pct" if source == "pnl" or spec.measure == "pnl_pct" else spec.measure
        label = "P&L (%)" if measure == "pnl_pct" else "Poids (%)"
        return {
            "categories": [str(holding["instrument"]) for holding in holdings],
            "series": [(label, [float(holding.get(measure, 0) or 0) for holding in holdings])],
            "number_format": "0.0",
        }
    if source.startswith("bond_"):
        return _bond_chart_data(source, facts, spec.limit)
    return None


#: Source de graphique obligataire → clé de la liste à tracer.
_BOND_CHART_SERIES = {
    "bond_maturities": "maturities",
    "bond_ratings": "ratings",
    "bond_issuers": "issuers",
    "bond_categories": "categories",
    "bond_sectors": "sectors",
    "bond_countries": "countries",
}


def _bond_chart_data(source: str, facts: dict[str, Any], limit: int) -> dict[str, Any] | None:
    """Répartition obligataire, en % de l'encours obligataire."""
    slices = (facts.get("bonds") or {}).get(_BOND_CHART_SERIES.get(source, "")) or []
    slices = [slice_ for slice_ in slices if float(slice_.get("value", 0) or 0) > 0][:limit]
    if not slices:
        return None
    return {
        "categories": [str(slice_["label"]) for slice_ in slices],
        "series": [("% de l'obligataire", [float(slice_["pct"]) for slice_ in slices])],
        "number_format": "0.0",
    }


def _table_rows(spec: TableSpec, facts: dict[str, Any]) -> list[dict[str, Any]]:
    source = str(spec.source)
    rows: list[dict[str, Any]]
    if source == "top_holdings":
        rows = list(facts.get("top_holdings") or [])
    elif source == "portfolios":
        rows = list(facts.get("portfolios") or [])
    elif source == "risks":
        rows = [
            {
                "level": {"high": "Élevé", "medium": "Moyen", "low": "Faible"}.get(
                    str(risk.get("level")), ""
                ),
                "label": risk.get("label", ""),
                "detail": risk.get("detail", ""),
            }
            for risk in facts.get("risks") or []
        ]
    elif source == "allocations":
        rows = list((facts.get("allocations") or {}).get(str(spec.dimension)) or [])
    elif source in {"flows", "esg", "activity", "pnl"}:
        block = facts.get(source) or {}
        rows = [
            {
                "label": FACT_LABELS.get(str(label), str(label).replace("_", " ").capitalize()),
                "value": value,
            }
            for label, value in block.items()
            if isinstance(value, (int, float))
        ]
    elif source == "rating_scale":
        rows = [dict(row) for row in (facts.get("bonds") or {}).get("rating_scale") or []]
    elif source == "coupons":
        rows = [dict(row) for row in (facts.get("bonds") or {}).get("coupons") or []]
    elif source == "bond_totals":
        rows = _bond_total_rows(facts)
    elif source == "bond_positions":
        rows = [dict(row) for row in (facts.get("bonds") or {}).get("positions") or []]
    elif source.startswith("bond_"):
        key = _BOND_CHART_SERIES.get(source, "")
        rows = [dict(row) for row in (facts.get("bonds") or {}).get(key) or []]
    else:
        return []
    return rows[: spec.limit]


def _bond_total_rows(facts: dict[str, Any]) -> list[dict[str, Any]]:
    """Lignes de clôture du portefeuille : typologies, obligataire, monétaire, général.

    Chaque pourcentage est rapporté à l'actif net, ce qui permet aux lignes de
    total de se lire les unes après les autres. Le total général vient de l'actif
    net lui-même : le solder obligataire et monétaire n'y suffit pas, la classe
    d'actif du mandat peut en être une troisième.
    """
    bonds = facts.get("bonds") or {}
    asset = float((facts.get("kpis") or {}).get("aum_total", 0) or 0)
    rows = [dict(row) for row in bonds.get("totals") or []]
    if not asset:
        return rows

    def line(label: str, value: float) -> dict[str, Any]:
        return {
            "label": label,
            "value": round(value, 2),
            "pct": round(value / asset * 100, 2),
            "total": True,
        }

    bond_total = float(bonds.get("bond_total", 0) or 0)
    if bond_total:
        rows.append(line("Total obligataire", bond_total))
    cash_total = float(bonds.get("cash_total", 0) or 0)
    if cash_total:
        rows.append(line("Total monétaire", cash_total))
    rows.append(line("Total général", asset))
    return rows
