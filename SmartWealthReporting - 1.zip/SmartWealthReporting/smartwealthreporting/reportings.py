"""Bibliothèque des reportings : un dossier autonome par reporting.

```
reportings/
└── monthly_client_review/
    ├── definition.json   # structure des slides, KPI, graphiques, charte
    ├── prompt.md         # consignes IA (ton, audience, règles, prudence)
    └── template.pptx     # charte graphique : slides modèles aux formes nommées
```

Ajouter un reporting = créer un dossier. Aucun code à modifier : l'API et
l'interface découvrent les dossiers au démarrage de chaque requête.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from .errors import APIError
from .schemas import ReportingDefinition, ReportingDetail, ReportingRef

ID_PATTERN = re.compile(r"^[a-z0-9_\-]+$")


class ReportingLibrary:
    """Découverte, lecture et écriture des dossiers de reporting."""

    def __init__(self, base_dir: Path) -> None:
        self.base_dir = Path(base_dir).resolve()
        self.root = self.base_dir / "reportings"

    # ------------------------------------------------------------ Parcours

    def ids(self) -> list[str]:
        if not self.root.is_dir():
            return []
        return sorted(
            entry.name
            for entry in self.root.iterdir()
            if entry.is_dir() and (entry / "definition.json").is_file()
        )

    def folder(self, reporting_id: str) -> Path:
        identifier = str(reporting_id or "").strip()
        if not ID_PATTERN.match(identifier):
            raise APIError(400, "Identifiant de reporting invalide (a-z, 0-9, - et _).")
        folder = (self.root / identifier).resolve()
        try:
            folder.relative_to(self.root.resolve())
        except ValueError as exc:  # pragma: no cover - garde-fou traversée de chemin
            raise APIError(400, "Identifiant de reporting invalide.") from exc
        if not folder.is_dir():
            raise APIError(404, f"Reporting inconnu : {identifier}")
        return folder

    def exists(self, reporting_id: str) -> bool:
        try:
            self.folder(reporting_id)
        except APIError:
            return False
        return True

    # ------------------------------------------------------------ Lecture

    def definition_path(self, reporting_id: str) -> Path:
        return self.folder(reporting_id) / "definition.json"

    def load(self, reporting_id: str) -> ReportingDefinition:
        path = self.definition_path(reporting_id)
        try:
            with path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
        except json.JSONDecodeError as exc:
            raise APIError(
                422, f"definition.json invalide pour « {reporting_id} » : {exc.msg} (ligne {exc.lineno})"
            ) from exc
        except OSError as exc:
            raise APIError(500, f"definition.json illisible pour « {reporting_id} » : {exc}") from exc
        if not isinstance(raw, dict):
            raise APIError(422, f"definition.json doit contenir un objet JSON ({reporting_id}).")
        # Le nom du dossier fait foi : c'est lui qui porte les routes, les
        # téléchargements et le dossier de sortie. Un `id` divergent dans le
        # fichier serait une source d'incohérence silencieuse.
        raw["id"] = reporting_id
        try:
            definition = ReportingDefinition(**raw)
        except ValidationError as exc:
            details = "; ".join(
                f"{'.'.join(str(part) for part in error['loc'])}: {error['msg']}"
                for error in exc.errors()
            )
            raise APIError(422, f"definition.json invalide pour « {reporting_id} » : {details}") from exc

        identifiers = [slide.id for slide in definition.slides]
        duplicates = {name for name in identifiers if identifiers.count(name) > 1}
        if duplicates:
            raise APIError(
                422,
                f"definition.json : identifiant de slide dupliqué ({', '.join(sorted(duplicates))}).",
            )
        if not definition.slides:
            raise APIError(422, f"definition.json : le reporting « {reporting_id} » n'a aucune slide.")
        return definition

    def prompt_path(self, reporting_id: str) -> Path:
        return self.folder(reporting_id) / "prompt.md"

    def load_prompt(self, reporting_id: str) -> str:
        path = self.prompt_path(reporting_id)
        try:
            return path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return ""
        except OSError as exc:
            raise APIError(500, f"prompt.md illisible pour « {reporting_id} » : {exc}") from exc

    def template_path(self, reporting_id: str) -> Path:
        return self.folder(reporting_id) / "template.pptx"

    def has_template(self, reporting_id: str) -> bool:
        return self.template_path(reporting_id).is_file()

    # ------------------------------------------------------------ Écriture

    def save_prompt(self, reporting_id: str, prompt: str) -> str:
        path = self.prompt_path(reporting_id)
        _atomic_write(path, str(prompt or "").strip() + "\n")
        return self.load_prompt(reporting_id)

    def save_definition(self, reporting_id: str, payload: dict[str, Any]) -> ReportingDefinition:
        payload = dict(payload or {})
        payload["id"] = reporting_id
        # On relit par le modèle : une définition invalide n'est jamais persistée.
        try:
            ReportingDefinition(**payload)
        except ValidationError as exc:
            details = "; ".join(
                f"{'.'.join(str(part) for part in error['loc'])}: {error['msg']}"
                for error in exc.errors()
            )
            raise APIError(422, f"Définition invalide : {details}") from exc
        _atomic_write(
            self.definition_path(reporting_id),
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        )
        return self.load(reporting_id)

    def create(
        self,
        reporting_id: str,
        name: str = "",
        *,
        copy_template_from: str | None = None,
    ) -> ReportingDefinition:
        identifier = str(reporting_id or "").strip()
        if not ID_PATTERN.match(identifier):
            raise APIError(400, "Identifiant de reporting invalide (a-z, 0-9, - et _).")
        folder = self.root / identifier
        if folder.exists():
            raise APIError(409, f"Le reporting « {identifier} » existe déjà.")
        folder.mkdir(parents=True, exist_ok=True)

        definition = ReportingDefinition(
            id=identifier,
            name=name.strip() or identifier.replace("_", " ").title(),
            description="Nouveau reporting privé wealth management.",
            slides=[
                {
                    "id": "cover",
                    "layout": "cover",
                    "title": "{{client_name}}",
                    "subtitle": "{{period_label}}",
                },
                {"id": "commentary", "layout": "narrative", "title": "Commentaire", "narrative": True,
                 "focus": "2 à 3 phrases de synthèse pour le client."},
            ],
        )
        self.save_definition(identifier, definition.model_dump())
        self.save_prompt(
            identifier,
            "Tu es un gestionnaire de patrimoine privé. Rédige en français, "
            "de façon claire et factuelle, pour un client non spécialiste.\n",
        )
        if copy_template_from and self.has_template(copy_template_from):
            shutil.copyfile(self.template_path(copy_template_from), self.template_path(identifier))
        return self.load(identifier)

    def delete(self, reporting_id: str) -> None:
        folder = self.folder(reporting_id)
        shutil.rmtree(folder)

    # --------------------------------------------------------------- Vue

    def list(self) -> list[ReportingRef]:
        references: list[ReportingRef] = []
        for identifier in self.ids():
            references.append(self.reference(identifier))
        return references

    def reference(self, reporting_id: str) -> ReportingRef:
        definition = self.load(reporting_id)
        prompt_chars = len(self.load_prompt(reporting_id))
        return ReportingRef(
            id=definition.id,
            name=definition.name,
            description=definition.description,
            version=definition.version,
            audience=definition.audience,
            slides=len(definition.slides),
            narrative_slides=len(definition.narrative_slides()),
            has_template=self.has_template(reporting_id),
            prompt_chars=prompt_chars,
            modified_at=_modified_at(self.folder(reporting_id)),
        )

    def detail(self, reporting_id: str) -> ReportingDetail:
        definition = self.load(reporting_id)
        return ReportingDetail(
            definition=definition,
            prompt=self.load_prompt(reporting_id),
            template_path=str(self.template_path(reporting_id)),
            warnings=self.warnings(definition),
        )

    def warnings(self, definition: ReportingDefinition) -> list[str]:
        """Points d'attention affichés dans l'interface avant génération."""
        warnings: list[str] = []
        if not self.has_template(definition.id):
            warnings.append(
                "Template PPTX absent : un template par défaut sera utilisé "
                "(généré à la volée, sans charte)."
            )
        if not self.load_prompt(definition.id).strip():
            warnings.append("prompt.md vide : la narration utilisera des consignes par défaut.")
        if not definition.narrative_slides():
            warnings.append("Aucune slide à narration : le modèle ne sera pas appelé.")
        if not definition.default_client_id and not any(
            kpi.key for slide in definition.slides for kpi in slide.kpis
        ):
            warnings.append("Aucun client par défaut : précisez le client à la génération.")
        return warnings


def _atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temp_path.open("w", encoding="utf-8") as handle:
            handle.write(content)
        os.replace(temp_path, path)
    finally:
        temp_path.unlink(missing_ok=True)


def _modified_at(folder: Path) -> str:
    try:
        return datetime.fromtimestamp(folder.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
    except OSError:
        return ""
