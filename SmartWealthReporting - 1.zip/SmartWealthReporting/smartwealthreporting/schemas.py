from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

#: `percent` porte un signe devant les valeurs positives : il est réservé aux
#: variations (performance, écart, plus-value). Un poids ou un taux se dit en
#: `share`, qui rend le même pourcentage sans ce signe.
NumberFormat = Literal["currency", "percent", "share", "number", "text"]
ChartKind = Literal[
    "doughnut", "pie", "bar", "column", "barh", "stacked_bar", "stacked_area",
    "line", "area",
]
SlideLayout = Literal["cover", "section", "kpis", "chart", "table", "narrative", "text", "disclaimer"]

#: Sources de données acceptées par un graphique ou un tableau.
ChartSource = Literal[
    "allocation", "performance", "top_holdings", "pnl",
    "bond_maturities", "bond_ratings", "bond_issuers", "bond_categories",
    "bond_sectors", "bond_countries",
]
TableSource = Literal[
    "top_holdings", "portfolios", "risks", "allocations", "flows", "esg", "activity", "pnl",
    "bond_positions", "bond_totals", "bond_maturities", "bond_ratings", "bond_issuers",
    "coupons", "rating_scale",
]


# ------------------------------------------------------------------ Auth


class LoginRequest(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    username: str
    role: str
    client_id: str = ""


class UserCreateRequest(BaseModel):
    username: str
    password: str
    role: Literal["admin", "user"] = "user"
    client_id: str = ""


class UserUpdateRequest(BaseModel):
    password: str | None = None
    role: Literal["admin", "user"] | None = None
    client_id: str | None = None


# ------------------------------------------------------------- Reporting


class KpiSpec(BaseModel):
    """Une case d'indicateur : la donnée vient du serveur, jamais du modèle."""

    model_config = ConfigDict(extra="allow")

    key: str
    label: str = ""
    format: NumberFormat = "number"
    decimals: int | None = None
    suffix: str = ""
    delta: str = ""


class ChartSpec(BaseModel):
    model_config = ConfigDict(extra="allow")

    kind: ChartKind = "bar"
    title: str = ""
    source: ChartSource = "allocation"
    dimension: Literal["asset_class", "sector", "country", "currency", "category"] = "asset_class"
    measure: Literal["market_value", "weight", "pnl_pct"] = "weight"
    series: list[str] = Field(default_factory=lambda: ["portfolio"])
    limit: int = Field(default=8, ge=1, le=30)
    show_values: bool = True
    show_legend: bool = True


class ColumnSpec(BaseModel):
    model_config = ConfigDict(extra="allow")

    key: str
    label: str = ""
    format: NumberFormat = "text"
    decimals: int | None = None


class TableSpec(BaseModel):
    model_config = ConfigDict(extra="allow")

    source: TableSource = "top_holdings"
    columns: list[ColumnSpec] = Field(default_factory=list)
    limit: int = Field(default=10, ge=1, le=40)
    #: Pour `allocations` : clé de la dimension à tabuler.
    dimension: str = "asset_class"


class SlideDefinition(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str = Field(min_length=1, max_length=64)
    layout: SlideLayout = "narrative"
    title: str = ""
    subtitle: str = ""
    #: Une slide à `true` attend une narration du modèle ; `focus` lui dit quoi dire.
    narrative: bool = False
    focus: str = ""
    min_words: int = Field(default=25, ge=0, le=400)
    max_words: int = Field(default=120, ge=5, le=600)
    kpis: list[KpiSpec] = Field(default_factory=list)
    chart: ChartSpec | None = None
    #: Petits multiples : deux à quatre graphiques sur une même slide, posés en
    #: grille. Utilisé par les slides de répartitions analytiques.
    panels: list[ChartSpec] = Field(default_factory=list)
    table: TableSpec | None = None
    text: str = ""
    footer: str = ""


class BrandSpec(BaseModel):
    """Charte du reporting : couleurs, typographie, identité émettrice.

    Les valeurs par défaut suivent une charte de banque privée — bleu nuit,
    fonds blancs, gris pour les comparables, sans-serif. Les champs
    d'identité (`house`, `legal_entity`, `tagline`, `confidentiality`) sont
    affichés tels quels sur la couverture et dans le bandeau de pied de page.
    """

    model_config = ConfigDict(extra="allow")

    primary: str = "16324F"
    accent: str = "2E5C8A"
    ink: str = "2B2B2B"
    positive: str = "4E8F75"
    negative: str = "B85C5C"
    neutral: str = "6B7280"
    rule: str = "D9DEE7"
    surface: str = "F7F9FC"
    background: str = "FFFFFF"
    font_title: str = "Arial"
    font_body: str = "Arial"
    #: Maison de gestion affichée en marque discrète : « SDG GESTION ».
    house: str = ""
    #: Entité juridique émettrice, citée en pied de page.
    legal_entity: str = ""
    #: Signature courte sous la marque : « Architects of Wealth ».
    tagline: str = ""
    #: Mention de confidentialité affichée en couverture.
    confidentiality: str = ""
    #: Libellé du document repris dans le bandeau : « Rapport de gestion ».
    report_label: str = ""


class PeriodSpec(BaseModel):
    model_config = ConfigDict(extra="allow")

    type: Literal["month", "quarter", "year", "ytd"] = "ytd"
    label: str = ""


class ContextSpec(BaseModel):
    model_config = ConfigDict(extra="allow")

    #: Sections de faits envoyées au modèle ; vide = toutes.
    sections: list[str] = Field(default_factory=list)
    detail: Literal["rapide", "standard", "complet"] = "standard"


class AISpec(BaseModel):
    model_config = ConfigDict(extra="allow")

    #: `true` : la génération échoue si le modèle local est indisponible.
    required: bool = False
    temperature: float | None = None
    max_tokens: int | None = None


class ReportingDefinition(BaseModel):
    """`definition.json` d'un reporting — le contrat du dossier `reportings/<id>/`."""

    model_config = ConfigDict(extra="allow")

    id: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9_\-]+$")
    name: str = "Reporting"
    description: str = ""
    version: str = "1.0"
    language: Literal["fr", "en"] = "fr"
    audience: str = "client"
    template: str = "template.pptx"
    prompt: str = "prompt.md"
    period: PeriodSpec = Field(default_factory=PeriodSpec)
    brand: BrandSpec = Field(default_factory=BrandSpec)
    context: ContextSpec = Field(default_factory=ContextSpec)
    ai: AISpec = Field(default_factory=AISpec)
    disclaimer: str = (
        "Document d'information établi à la demande du client, sur la base des données "
        "de gestion au {as_of}. Les performances passées ne préjugent pas des "
        "performances futures. Ce document ne constitue pas une offre, un conseil en "
        "investissement ou une recommandation personnalisée."
    )
    default_client_id: str = ""
    slides: list[SlideDefinition] = Field(default_factory=list)

    def slide(self, slide_id: str) -> SlideDefinition | None:
        return next((slide for slide in self.slides if slide.id == slide_id), None)

    def narrative_slides(self) -> list[SlideDefinition]:
        return [slide for slide in self.slides if slide.narrative]


# ------------------------------------------------------------- API payloads


class ReportingRef(BaseModel):
    id: str
    name: str
    description: str = ""
    version: str = "1.0"
    audience: str = ""
    slides: int = 0
    narrative_slides: int = 0
    has_template: bool = False
    prompt_chars: int = 0
    modified_at: str = ""


class ReportingDetail(BaseModel):
    definition: ReportingDefinition
    prompt: str
    template_path: str
    warnings: list[str] = Field(default_factory=list)


class PromptUpdateRequest(BaseModel):
    prompt: str = Field(max_length=40000)


class DefinitionUpdateRequest(BaseModel):
    definition: dict[str, Any]


class GenerateRequest(BaseModel):
    client_id: str = ""
    portfolio_ids: list[str] = Field(default_factory=list)
    as_of: str = ""
    period: Literal["month", "quarter", "year", "ytd"] | None = None
    period_label: str = ""
    title: str = ""
    subtitle: str = ""
    #: `false` génère le deck sans narration (utile sans modèle local installé).
    use_ai: bool = True
    #: Écrase la valeur de `ai.required` pour cette génération.
    allow_fallback: bool = True
    output_name: str = ""


class SlideVerification(BaseModel):
    ok: bool = True
    numbers_checked: int = 0
    unverified_numbers: list[dict[str, Any]] = Field(default_factory=list)
    warning: str = ""


class SlideResult(BaseModel):
    id: str
    layout: str
    title: str
    narrative: str = ""
    narrative_source: Literal["ia", "vide", "desactivee", "erreur"] = "vide"
    verification: SlideVerification | None = None
    error: str = ""


class GenerationResponse(BaseModel):
    id: str
    reporting_id: str
    filename: str
    download_url: str
    created_at: str
    elapsed_seconds: float = 0.0
    client_id: str = ""
    period_label: str = ""
    as_of: str = ""
    slides: list[SlideResult] = Field(default_factory=list)
    facts: dict[str, Any] = Field(default_factory=dict)
    context_chars: int = 0
    engine: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    ok: bool = True


class ContextResponse(BaseModel):
    reporting_id: str
    client_id: str = ""
    period_label: str = ""
    as_of: str = ""
    facts: dict[str, Any] = Field(default_factory=dict)
    context_text: str = ""
    chars: int = 0
    truncated: bool = False
    prompt: str = ""
    system_prompt: str = ""
    slides: list[dict[str, Any]] = Field(default_factory=list)


class AIConfigRequest(BaseModel):
    """Réglages de génération. Une clé absente n'est pas touchée."""

    n_ctx: int | None = None
    n_threads: int | None = None
    n_batch: int | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    top_p: float | None = None
    repeat_penalty: float | None = None
    max_context_chars: int | None = None
    narrative_min_chars: int | None = None
    narrative_max_chars: int | None = None
    max_slides_per_call: int | None = None
    retries: int | None = None


class DatasourceConfigRequest(BaseModel):
    """Chemins des datasets et du moteur IA. Un champ absent n'est pas touché."""

    datasets: dict[str, str] | None = None
    gguf_path: str | None = None
    llm_backend: Literal["gguf", "llamafile"] | None = None
    llamafile_path: str | None = None
    llamafile_port: int | str | None = None
    llamafile_url: str | None = None


class DatasetPreviewRequest(BaseModel):
    name: str
    limit: int = Field(default=25, ge=1, le=500)


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    """Question libre sur un reporting, pour ajuster un libellé avant génération."""

    reporting_id: str = ""
    client_id: str = ""
    question: str = Field(min_length=1, max_length=1000)
    history: list[ChatMessage] = Field(default_factory=list)


class ChatResponse(BaseModel):
    answer: str
    slides: dict[str, str] = Field(default_factory=dict)
    verification: SlideVerification | None = None
