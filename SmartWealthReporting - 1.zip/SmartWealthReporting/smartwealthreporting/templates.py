"""Contrat entre le template PPTX et le moteur de rendu.

Un template est un `.pptx` ordinaire. Chaque slide servant de **modèle** porte une
forme nommée `SWR_LAYOUT` dont le texte indique le type de slide
(`cover`, `section`, `kpis`, `chart`, `table`, `narrative`, `text`, `disclaimer`).
Les autres formes nommées sont des **zones** remplies par le moteur :

| Zone                | Type     | Contenu                                    |
| ------------------- | -------- | ------------------------------------------ |
| `SWR_TITLE`         | texte    | titre de la slide                          |
| `SWR_SUBTITLE`      | texte    | sous-titre (cover, section)                |
| `SWR_META`          | texte    | ligne d'identité client / date (cover)     |
| `SWR_TEXT`          | texte    | narration IA ou texte statique             |
| `SWR_KPI_1..N`      | texte    | carte indicateur : valeur puis libellé     |
| `SWR_CHART`         | cadre    | rectangle d'ancrage du graphique natif     |
| `SWR_TABLE`         | cadre    | rectangle d'ancrage du tableau             |
| `SWR_SOURCE`        | texte    | ligne de source des données                |
| `SWR_FOOTER`        | texte    | pied de page                               |
| `SWR_PAGE`          | texte    | numéro de slide                            |

Une zone absente n'est pas une erreur : le moteur dessine alors la zone à sa
position par défaut. Un template sans slide `SWR_LAYOUT` (un template de marque
externe, par exemple) reste utilisable : le moteur construit les slides sur le
layout « vierge » en s'appuyant sur la charte de la définition.
"""

from __future__ import annotations

from typing import Any

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

LAYOUT_MARKER = "SWR_LAYOUT"
ZONE_TITLE = "SWR_TITLE"
ZONE_SUBTITLE = "SWR_SUBTITLE"
ZONE_META = "SWR_META"
ZONE_TEXT = "SWR_TEXT"
ZONE_CHART = "SWR_CHART"
ZONE_TABLE = "SWR_TABLE"
ZONE_SOURCE = "SWR_SOURCE"
ZONE_FOOTER = "SWR_FOOTER"
ZONE_PAGE = "SWR_PAGE"
KPI_ZONE_PREFIX = "SWR_KPI_"

#: Largeurs de slide supportées par le rendu : tout est positionné en pouces.
SLIDE_WIDTH_IN = 13.333
SLIDE_HEIGHT_IN = 7.5

MARGIN_LEFT = 0.62
MARGIN_RIGHT = 0.62
CONTENT_WIDTH = SLIDE_WIDTH_IN - MARGIN_LEFT - MARGIN_RIGHT

#: Géométrie de repli, en pouces, quand le template ne fournit pas la zone.
DEFAULT_ZONES: dict[str, tuple[float, float, float, float]] = {
    "title": (MARGIN_LEFT, 0.42, CONTENT_WIDTH, 0.62),
    #: Variante à gauche quand la marque de la maison occupe la droite.
    "title_with_brand": (MARGIN_LEFT, 0.42, 9.05, 0.62),
    "subtitle": (MARGIN_LEFT, 1.02, CONTENT_WIDTH, 0.45),
    "text": (MARGIN_LEFT, 1.75, CONTENT_WIDTH, 4.6),
    "text_narrow": (MARGIN_LEFT, 1.75, 8.1, 4.6),
    "text_wide": (MARGIN_LEFT, 1.75, CONTENT_WIDTH, 4.9),
    #: Zone texte d'une slide « kpis » : sous le bandeau de cartes, jamais dessus.
    "text_below_kpis": (MARGIN_LEFT, 3.45, CONTENT_WIDTH, 3.05),
    #: Variante à deux rangées de cartes (au-delà de quatre indicateurs).
    "text_below_kpi_second_row": (MARGIN_LEFT, 5.2, CONTENT_WIDTH, 1.32),
    "chart": (MARGIN_LEFT, 1.72, 7.7, 4.75),
    "table": (MARGIN_LEFT, 1.72, CONTENT_WIDTH, 4.35),
    #: Zone texte d'une slide « table » : au-dessus de la mention de source.
    "text_below_table": (MARGIN_LEFT, 6.14, CONTENT_WIDTH, 0.44),
    "source": (MARGIN_LEFT, 6.62, 9.0, 0.3),
    "footer": (MARGIN_LEFT, 6.95, 9.0, 0.3),
    "page": (11.9, 6.95, 0.8, 0.3),
    "meta": (MARGIN_LEFT, 5.55, CONTENT_WIDTH, 0.45),
    #: Titre de couverture : placé au tiers inférieur, la marque reste au-dessus.
    "cover_title": (MARGIN_LEFT, 2.28, 10.6, 1.0),
    "cover_subtitle": (MARGIN_LEFT, 3.42, 10.6, 0.55),
    "cover_meta": (MARGIN_LEFT, 4.25, 10.6, 1.5),
    "kpi_row": (MARGIN_LEFT, 1.72, CONTENT_WIDTH, 1.55),
    "kpi_secondary_row": (MARGIN_LEFT, 3.45, CONTENT_WIDTH, 1.55),
}

DEFAULT_LAYOUTS = ("cover", "section", "kpis", "chart", "table", "narrative", "text", "disclaimer")

#: Colonnes de la grille d'indicateurs : au-delà, les cartes passent à la ligne.
KPI_COLUMNS = 4


#: Charte par défaut : bleu nuit institutionnel, fonds blancs, gris pour les
#: comparables. Aucune couleur saturée — le rapport de gestion est un document
#: de conformité, pas une pièce commerciale.
DEFAULT_BRAND: dict[str, str] = {
    "primary": "16324F",     # bleu nuit principal
    "accent": "2E5C8A",      # bleu institutionnel secondaire
    "ink": "2B2B2B",         # gris très foncé, corps de texte
    "neutral": "6B7280",     # gris moyen, mentions
    "rule": "D9DEE7",        # gris clair, filets et bordures
    "surface": "F7F9FC",     # fond secondaire très léger
    "background": "FFFFFF",
    "positive": "4E8F75",    # vert discret, jamais vif
    "negative": "B85C5C",    # rouge discret, jamais vif
    "font_title": "Arial",
    "font_body": "Arial",
}

#: Teintes de graphique : un bleu pour la série clé, des gris pour les
#: comparables. Une échelle monochrome évite l'arc-en-ciel des graphiques
#: de distribution standards.
SERIES_BLUE = "2E5C8A"
SERIES_GREYS = ("9BA6B4", "B7C0CC", "6B7280", "CDD5DE", "8794A4")
SERIES_LIGHT_BLUE = "7FA3C4"


class Palette:
    """Couleurs de la charte, résolues depuis la définition du reporting."""

    def __init__(self, brand: dict[str, Any] | None = None) -> None:
        brand = {**DEFAULT_BRAND, **(brand or {})}
        self.primary = _rgb(brand.get("primary"), DEFAULT_BRAND["primary"])
        self.accent = _rgb(brand.get("accent"), DEFAULT_BRAND["accent"])
        self.ink = _rgb(brand.get("ink"), DEFAULT_BRAND["ink"])
        self.positive = _rgb(brand.get("positive"), DEFAULT_BRAND["positive"])
        self.negative = _rgb(brand.get("negative"), DEFAULT_BRAND["negative"])
        self.neutral = _rgb(brand.get("neutral"), DEFAULT_BRAND["neutral"])
        self.rule = _rgb(brand.get("rule"), DEFAULT_BRAND["rule"])
        self.background = _rgb(brand.get("background"), DEFAULT_BRAND["background"])
        self.surface = _rgb(brand.get("surface"), DEFAULT_BRAND["surface"])
        self.font_title = str(brand.get("font_title") or "Arial")
        self.font_body = str(brand.get("font_body") or "Arial")
        #: Identité affichée sur la couverture et dans le bandeau de pied de page.
        self.house = str(brand.get("house") or "")
        self.legal_entity = str(brand.get("legal_entity") or "")
        self.tagline = str(brand.get("tagline") or "")
        self.confidentiality = str(brand.get("confidentiality") or "")
        self.report_label = str(brand.get("report_label") or "")

    def series_colors(self, count: int) -> list[RGBColor]:
        """Palette de graphique : un bleu principal, puis des gris cohérents.

        L'ordre place le bleu en tête pour que la série clé dominate visuellement
        le graphe, et n'utilise jamais de teinte saturée.
        """
        wanted = max(count, 1)
        palette = [_rgb(SERIES_BLUE, SERIES_BLUE), _rgb(SERIES_LIGHT_BLUE, SERIES_LIGHT_BLUE)]
        palette += [_rgb(grey, grey) for grey in SERIES_GREYS]
        while len(palette) < wanted:
            palette.append(_lighten(self.primary, 0.18 + 0.22 * (len(palette) - len(SERIES_GREYS) - 2)))
        return palette[:wanted]

    def value_color(self, value: float) -> RGBColor:
        if value > 0:
            return self.positive
        if value < 0:
            return self.negative
        return self.neutral

    def as_dict(self) -> dict[str, str]:
        return {
            "primary": str(self.primary),
            "accent": str(self.accent),
            "ink": str(self.ink),
            "positive": str(self.positive),
            "negative": str(self.negative),
            "neutral": str(self.neutral),
            "rule": str(self.rule),
            "background": str(self.background),
            "surface": str(self.surface),
        }


def _rgb(value: Any, fallback: str) -> RGBColor:
    text = str(value or "").strip().lstrip("#")
    if len(text) == 6:
        try:
            return RGBColor.from_string(text.upper())
        except (ValueError, AttributeError):
            pass
    try:
        return RGBColor.from_string(str(fallback).upper())
    except (ValueError, AttributeError):
        return RGBColor(0x0F, 0x2A, 0x43)


def _lighten(color: RGBColor, ratio: float) -> RGBColor:
    return RGBColor(
        min(255, int(color[0] + (255 - color[0]) * ratio)),
        min(255, int(color[1] + (255 - color[1]) * ratio)),
        min(255, int(color[2] + (255 - color[2]) * ratio)),
    )


def blank_layout(prs: Presentation) -> Any:
    """Layout « vierge » du template, quel que soit son nom localisé."""
    for layout in prs.slide_layouts:
        if str(layout.name).strip().lower() in {"blank", "vierge", "vide"}:
            return layout
    return prs.slide_layouts[min(6, len(prs.slide_layouts) - 1)]


def has_layout_slides(prs: Presentation) -> bool:
    return bool(layout_names(prs))


def layout_names(prs: Presentation) -> dict[str, int]:
    """Type de layout → index de la slide modèle dans le template."""
    found: dict[str, int] = {}
    for index, slide in enumerate(prs.slides):
        marker = _find_shape(slide, LAYOUT_MARKER)
        if marker is None or not marker.has_text_frame:
            continue
        name = marker.text_frame.text.strip().lower()
        if name and name not in found:
            found[name] = index
    return found


def _find_shape(slide: Any, name: str) -> Any | None:
    for shape in slide.shapes:
        if shape.name == name:
            return shape
    return None


def find_zone(slide: Any, name: str) -> Any | None:
    return _find_shape(slide, name)


def zone_rect(slide: Any, name: str, fallback: tuple[float, float, float, float]) -> tuple[int, int, int, int]:
    """Position d'une zone en EMU, avec repli sur la géométrie par défaut."""
    shape = _find_shape(slide, name)
    if shape is None:
        left, top, width, height = fallback
        return Emu(Inches(left)), Emu(Inches(top)), Emu(Inches(width)), Emu(Inches(height))
    return shape.left, shape.top, shape.width, shape.height


def zone_anchor(slide: Any, name: str, fallback: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    """Position d'une zone en pouces (utilisée pour les graphiques natifs)."""
    shape = _find_shape(slide, name)
    if shape is None:
        return fallback
    return (
        shape.left / 914400,
        shape.top / 914400,
        shape.width / 914400,
        shape.height / 914400,
    )


def move_shape(shape: Any, rect: tuple[float, float, float, float]) -> None:
    """Repositionne une forme déjà posée sur la slide, en pouces."""
    left, top, width, height = rect
    shape.left = Inches(left)
    shape.top = Inches(top)
    shape.width = Inches(width)
    shape.height = Inches(height)


def set_text(
    shape: Any,
    text: str,
    *,
    size: float,
    color: RGBColor,
    bold: bool = False,
    font: str = "Calibri",
    align: PP_ALIGN = PP_ALIGN.LEFT,
    anchor: MSO_ANCHOR = MSO_ANCHOR.TOP,
    italic: bool = False,
    line_spacing: float | None = None,
    space_after: float = 0,
) -> None:
    """Écrit un texte simple dans une forme, en remplaçant tout le contenu."""
    frame = shape.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.vertical_anchor = anchor
    frame.margin_left = Pt(2)
    frame.margin_right = Pt(2)
    frame.margin_top = Pt(1)
    frame.margin_bottom = Pt(1)
    paragraph = frame.paragraphs[0]
    paragraph.alignment = align
    if line_spacing:
        paragraph.line_spacing = line_spacing
    if space_after:
        paragraph.space_after = Pt(space_after)
    run = paragraph.add_run()
    run.text = str(text or "")
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.name = font
    run.font.color.rgb = color


def set_kpi_card(shape: Any, value: str, label: str, palette: Palette, *, accent: RGBColor | None = None) -> None:
    """Carte d'indicateur : valeur en grand, libellé en dessous."""
    frame = shape.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    frame.margin_left = Pt(12)
    frame.margin_right = Pt(8)
    frame.margin_top = Pt(6)
    frame.margin_bottom = Pt(6)

    value_paragraph = frame.paragraphs[0]
    value_paragraph.alignment = PP_ALIGN.LEFT
    run = value_paragraph.add_run()
    run.text = str(value or "—")
    run.font.size = Pt(19)
    run.font.bold = True
    run.font.name = palette.font_title
    run.font.color.rgb = accent or palette.primary

    label_paragraph = frame.add_paragraph()
    label_paragraph.alignment = PP_ALIGN.LEFT
    label_paragraph.line_spacing = 1.1
    label_run = label_paragraph.add_run()
    label_run.text = str(label or "")
    label_run.font.size = Pt(8.5)
    label_run.font.name = palette.font_body
    label_run.font.color.rgb = palette.neutral


def add_kpi_card(slide: Any, rect: tuple[float, float, float, float], name: str, palette: Palette) -> Any:
    """Carte d'indicateur : cadre blanc à filet gris, filet d'accent à gauche.

    La charte ne veut ni carte colorée ni coins arrondis : un cadre très fin et
    un court trait bleu suffisent à séparer l'indicateur du blanc de la slide.
    """
    card = add_rect(slide, rect, name=name, fill=palette.background, line=palette.rule)
    left, top, _width, height = rect
    add_rect(slide, (left, top, 0.035, height), fill=palette.accent)
    set_kpi_card(card, "", "", palette)
    return card


def add_textbox(slide: Any, rect: tuple[float, float, float, float], name: str) -> Any:
    left, top, width, height = rect
    shape = slide.shapes.add_textbox(
        Inches(left), Inches(top), Inches(width), Inches(height)
    )
    shape.name = name
    return shape


def add_rect(
    slide: Any,
    rect: tuple[float, float, float, float],
    *,
    name: str = "",
    fill: RGBColor | None = None,
    line: RGBColor | None = None,
    rounded: bool = False,
) -> Any:
    left, top, width, height = rect
    kind = MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE
    shape = slide.shapes.add_shape(kind, Inches(left), Inches(top), Inches(width), Inches(height))
    if name:
        shape.name = name
    if fill is None:
        shape.fill.background()
    else:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill
    if line is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = line
        shape.line.width = Pt(0.75)
    shape.shadow.inherit = False
    if rounded:
        try:
            shape.adjustments[0] = 0.06
        except (IndexError, ValueError):
            pass
    shape.text_frame.text = ""
    return shape


def footer_line(slide: Any, palette: Palette) -> None:
    """Filet de séparation au-dessus du bandeau de pied de page.

    Un filet gris de 0,75 pt, pas un aplat : le pied de page doit rester une
    mention administrative, pas un bandeau de couleur.
    """
    add_rect(
        slide,
        (MARGIN_LEFT, SLIDE_HEIGHT_IN - 0.62, CONTENT_WIDTH, 0.01),
        fill=palette.rule,
    )


def header_block(slide: Any, palette: Palette) -> None:
    """Filet d'accent sous le titre des slides de contenu.

    La charte bannit les aplatsdark en haut de page : l'ancrage du titre se fait
    par un filet court, comme dans un rapport de gestion classique.
    """
    add_rect(slide, (MARGIN_LEFT, 1.12, 1.15, 0.02), fill=palette.accent)
    add_rect(
        slide, (MARGIN_LEFT + 1.25, 1.12, CONTENT_WIDTH - 1.25, 0.01), fill=palette.rule
    )


def brand_mark(
    slide: Any, palette: Palette, rect: tuple[float, float, float, float], *, align: str = "left"
) -> None:
    """Signature de marque discrète : maison de gestion, puis signature.

    Occupe deux lignes minuscules en gris moyen. La marque ne domine jamais la
    slide : elle identifie l'émetteur sans apparaître comme un élément de design.
    """
    align_enum = PP_ALIGN.RIGHT if align == "right" else PP_ALIGN.LEFT
    width = rect[2]
    mark = add_textbox(slide, (rect[0], rect[1], width, 0.24), "SWR_BRAND")
    set_text(
        mark, palette.house, size=9, color=palette.primary, bold=True,
        font=palette.font_body, align=align_enum,
    )
    if not palette.tagline:
        return
    tagline = add_textbox(slide, (rect[0], rect[1] + 0.24, width, 0.22), "SWR_TAGLINE")
    set_text(
        tagline, palette.tagline, size=7.5, color=palette.neutral, italic=True,
        font=palette.font_body, align=align_enum,
    )


def build_default_template(brand: dict[str, Any] | None = None) -> Presentation:
    """Template PWM 16:9 par défaut, avec une slide modèle par type.

    Il sert de point de départ reproductible : on peut le remplacer par la charte
    de la maison sans toucher au code, les zones nommées font le contrat.
    """
    palette = Palette(brand)
    prs = Presentation()
    prs.slide_width = Inches(SLIDE_WIDTH_IN)
    prs.slide_height = Inches(SLIDE_HEIGHT_IN)
    layout = blank_layout(prs)

    for name in DEFAULT_LAYOUTS:
        slide = prs.slides.add_slide(layout)
        _clear_placeholders(slide)
        marker = add_textbox(slide, (0, 0, 2.0, 0.25), LAYOUT_MARKER)
        set_text(marker, name, size=8, color=palette.neutral, font=palette.font_body)
        _decorate(slide, name, palette)

    return prs


def _clear_placeholders(slide: Any) -> None:
    for shape in list(slide.shapes):
        shape._element.getparent().remove(shape._element)


def _decorate(slide: Any, name: str, palette: Palette) -> None:
    title_font = palette.font_title
    body_font = palette.font_body

    # Les layouts pleine page sont dessinés puis quittés : leur décor ne doit
    # pas hériter du bandeau d'en-tête des slides de contenu.
    if name == "cover":
        # Fond blanc assumé : la couverture d'un rapport de gestion n'a rien
        # d'un écran d'accueil. La marque tient en haut à droite, en petit.
        if palette.house:
            brand_mark(slide, palette, (9.6, 0.55, 3.11), align="right")
        add_rect(slide, (MARGIN_LEFT, 2.05, 1.6, 0.03), fill=palette.accent)
        title = add_textbox(slide, DEFAULT_ZONES["cover_title"], ZONE_TITLE)
        set_text(title, "", size=36, color=palette.primary, bold=True, font=title_font)
        subtitle = add_textbox(slide, DEFAULT_ZONES["cover_subtitle"], ZONE_SUBTITLE)
        set_text(subtitle, "", size=15, color=palette.ink, font=body_font)
        meta = add_textbox(slide, DEFAULT_ZONES["cover_meta"], ZONE_META)
        set_text(meta, "", size=10, color=palette.neutral, font=body_font, line_spacing=1.35)
        if palette.legal_entity or palette.confidentiality:
            # Mention d'émetteur et de confidentialité, en bas de couverture.
            add_rect(slide, (MARGIN_LEFT, 6.35, CONTENT_WIDTH, 0.01), fill=palette.rule)
            legal = add_textbox(slide, (MARGIN_LEFT, 6.5, 8.4, 0.3), "SWR_LEGAL")
            set_text(legal, palette.legal_entity or "", size=8.5, color=palette.neutral, font=body_font)
            if palette.confidentiality:
                notice = add_textbox(slide, (9.2, 6.5, 3.51, 0.3), "SWR_CONFIDENTIAL")
                set_text(
                    notice, palette.confidentiality, size=8.5, color=palette.neutral,
                    font=body_font, bold=True, align=PP_ALIGN.RIGHT,
                )
        return

    if name == "section":
        if palette.house:
            brand_mark(slide, palette, (9.6, 0.55, 3.11), align="right")
        add_rect(slide, (MARGIN_LEFT, 2.95, 1.6, 0.03), fill=palette.accent)
        title = add_textbox(slide, (MARGIN_LEFT, 3.2, 10.6, 0.9), ZONE_TITLE)
        set_text(title, "", size=28, color=palette.primary, bold=True, font=title_font)
        subtitle = add_textbox(slide, (MARGIN_LEFT, 4.15, 10.6, 0.6), ZONE_SUBTITLE)
        set_text(subtitle, "", size=13, color=palette.ink, font=body_font)
        return

    if name == "disclaimer":
        # Fond blanc et texte dense : la charte veut un avertissement compact,
        # pas un encadré coloré qui attire l'œil.
        header_block(slide, palette)
        title = add_textbox(slide, title_zone(palette), ZONE_TITLE)
        set_text(title, "", size=17, color=palette.primary, bold=True, font=title_font)
        text = add_textbox(slide, (MARGIN_LEFT, 1.75, CONTENT_WIDTH, 4.5), ZONE_TEXT)
        set_text(text, "", size=9, color=palette.ink, font=body_font, line_spacing=1.18)
        footer_line(slide, palette)
        _footer_zones(slide, palette, body_font)
        return

    header_block(slide, palette)
    title = add_textbox(slide, title_zone(palette), ZONE_TITLE)
    set_text(title, "", size=20, color=palette.primary, bold=True, font=title_font)
    if palette.house:
        # Rappel de marque, très léger, à droite du titre.
        brand_mark(slide, palette, (9.9, 0.5, 2.81), align="right")

    if name == "kpis":
        for index in range(4):
            add_kpi_card(slide, _kpi_rect(index, 0), f"{KPI_ZONE_PREFIX}{index + 1}", palette)
        text = add_textbox(slide, DEFAULT_ZONES["text_below_kpis"], ZONE_TEXT)
        set_text(text, "", size=11.5, color=palette.ink, font=body_font, line_spacing=1.3)
        add_textbox(slide, DEFAULT_ZONES["source"], ZONE_SOURCE)
    elif name == "chart":
        add_rect(
            slide, DEFAULT_ZONES["chart"], name=ZONE_CHART, fill=palette.background,
            line=palette.rule,
        )
        text = add_textbox(slide, (8.55, 1.72, 4.15, 4.75), ZONE_TEXT)
        set_text(text, "", size=10.5, color=palette.ink, font=body_font, line_spacing=1.3)
        add_textbox(slide, DEFAULT_ZONES["source"], ZONE_SOURCE)
    elif name == "table":
        add_rect(
            slide, DEFAULT_ZONES["table"], name=ZONE_TABLE, fill=palette.background,
            line=palette.rule,
        )
        text = add_textbox(slide, DEFAULT_ZONES["text_below_table"], ZONE_TEXT)
        set_text(text, "", size=9.5, color=palette.ink, font=body_font, line_spacing=1.2)
        add_textbox(slide, DEFAULT_ZONES["source"], ZONE_SOURCE)
    elif name == "narrative":
        text = add_textbox(slide, (MARGIN_LEFT, 1.72, 9.3, 4.75), ZONE_TEXT)
        set_text(text, "", size=12.5, color=palette.ink, font=body_font, line_spacing=1.4)
        add_textbox(slide, DEFAULT_ZONES["source"], ZONE_SOURCE)
    elif name == "text":
        text = add_textbox(slide, DEFAULT_ZONES["text_wide"], ZONE_TEXT)
        set_text(text, "", size=11.5, color=palette.ink, font=body_font, line_spacing=1.35)
        add_textbox(slide, DEFAULT_ZONES["source"], ZONE_SOURCE)
    else:  # pragma: no cover - garde-fou
        pass

    footer_line(slide, palette)
    _footer_zones(slide, palette, body_font)


def _footer_zones(slide: Any, palette: Palette, body_font: str) -> None:
    """Bandeau de pied de page : mention à gauche, pagination à droite."""
    footer = add_textbox(slide, DEFAULT_ZONES["footer"], ZONE_FOOTER)
    set_text(footer, "", size=7.5, color=palette.neutral, font=body_font)
    page = add_textbox(slide, DEFAULT_ZONES["page"], ZONE_PAGE)
    set_text(page, "", size=7.5, color=palette.neutral, font=body_font, align=PP_ALIGN.RIGHT)


def _kpi_rect(index: int, row: int) -> tuple[float, float, float, float]:
    """Position d'une carte d'indicateur : 4 colonnes, lignes successives."""
    columns = 4
    gap = 0.22
    width = (CONTENT_WIDTH - gap * (columns - 1)) / columns
    left = MARGIN_LEFT + (index % columns) * (width + gap)
    top = DEFAULT_ZONES["kpi_row"][1] if row == 0 else DEFAULT_ZONES["kpi_secondary_row"][1]
    return (left, top, width, DEFAULT_ZONES["kpi_row"][3])


def kpi_rect(index: int) -> tuple[float, float, float, float]:
    """Position de la carte d'indicateur numéro `index` (1-based), ligne 1."""
    return _kpi_rect(max(0, index - 1), 0)


def kpi_rect_secondary(index: int) -> tuple[float, float, float, float]:
    """Position d'une carte supplémentaire au-delà de la quatrième (2e ligne)."""
    return _kpi_rect(max(0, index - 4), 1)


def title_zone(palette: Palette) -> tuple[float, float, float, float]:
    """Zone du titre des slides de contenu.

    La charte pose un rappel de marque à droite du titre ; la zone doit alors
    s'arrêter avant lui, sinon les deux textes se chevauchent.
    """
    return DEFAULT_ZONES["title_with_brand"] if palette.house else DEFAULT_ZONES["title"]


def zone_default(name: str) -> tuple[float, float, float, float]:
    """Géométrie de repli d'une zone nommée, quand le template ne la fournit pas."""
    return {
        ZONE_TITLE: DEFAULT_ZONES["title"],
        ZONE_SUBTITLE: DEFAULT_ZONES["subtitle"],
        ZONE_META: DEFAULT_ZONES["meta"],
        ZONE_TEXT: DEFAULT_ZONES["text_wide"],
        ZONE_CHART: DEFAULT_ZONES["chart"],
        ZONE_TABLE: DEFAULT_ZONES["table"],
        ZONE_SOURCE: DEFAULT_ZONES["source"],
        ZONE_FOOTER: DEFAULT_ZONES["footer"],
        ZONE_PAGE: DEFAULT_ZONES["page"],
    }.get(name, DEFAULT_ZONES["text_wide"])
