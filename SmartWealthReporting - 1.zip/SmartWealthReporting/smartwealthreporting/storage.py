from __future__ import annotations

import json
import logging
import math
import os
import threading
import uuid
from datetime import date, datetime, time
from decimal import Decimal
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import SUPPORTED_SUFFIXES, DataSourceConfig

logger = logging.getLogger(__name__)


def dataframe_to_records(frame: pd.DataFrame | None) -> list[dict[str, Any]]:
    """Convertit un DataFrame en enregistrements JSON sans NaN/NumPy."""
    if frame is None or frame.empty:
        return []
    return [
        {key: _json_safe(value) for key, value in row.items()}
        for row in frame.to_dict("records")
    ]


def _json_safe(value: Any) -> Any:
    if value is None or value is pd.NaT:
        return None
    if isinstance(value, np.generic):
        return _json_safe(value.item())
    if isinstance(value, (pd.Timestamp, datetime, date, time)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, float) and not math.isfinite(value):
        return None
    try:
        missing = pd.isna(value)
        if isinstance(missing, bool) and missing:
            return None
    except (TypeError, ValueError):
        pass
    return value


def read_frame(path: Path, sheet: str | int | None = None) -> pd.DataFrame:
    """Lit un fichier tabular selon son extension.

    Le format est déduit de l'extension : un même dataset peut être livré en
    Parquet par un système amont et en CSV par un export manuel.
    """
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path)
    if suffix == ".csv":
        return _read_csv(path)
    if suffix in {".xlsx", ".xlsm"}:
        return pd.read_excel(path, sheet_name=0 if sheet is None else sheet, engine="openpyxl")
    if suffix == ".json":
        return _read_json(path)
    raise ValueError(
        f"Format non supporté : {suffix or path.name}. "
        f"Formats acceptés : {', '.join(SUPPORTED_SUFFIXES)}"
    )


def _read_csv(path: Path) -> pd.DataFrame:
    """Lecture CSV tolérante : séparateur détecté, encodage UTF-8 avec repli latin-1."""
    last_error: Exception | None = None
    for encoding in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            return pd.read_csv(path, encoding=encoding, sep=None, engine="python")
        except UnicodeDecodeError as exc:
            last_error = exc
        except Exception as exc:  # séparateur exotique : on tente le suivant
            last_error = exc
    logger.warning("Unable to read CSV %s: %s", path, last_error)
    return pd.DataFrame()


def _read_json(path: Path) -> pd.DataFrame:
    with path.open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    if isinstance(raw, list):
        return pd.DataFrame(raw)
    if isinstance(raw, dict):
        for key in ("records", "data", "rows"):
            if isinstance(raw.get(key), list):
                return pd.DataFrame(raw[key])
        # Format colonnes → lignes.
        if raw and all(isinstance(value, list) for value in raw.values()):
            return pd.DataFrame(raw)
    return pd.DataFrame()


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    """Écrit un DataFrame selon l'extension, de façon atomique."""
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    temp_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp{suffix}")
    try:
        if suffix == ".parquet":
            frame.to_parquet(temp_path, index=False)
        elif suffix == ".csv":
            frame.to_csv(temp_path, index=False, encoding="utf-8")
        elif suffix in {".xlsx", ".xlsm"}:
            frame.to_excel(temp_path, index=False, engine="openpyxl")
        elif suffix == ".json":
            with temp_path.open("w", encoding="utf-8") as handle:
                json.dump(dataframe_to_records(frame), handle, ensure_ascii=False, indent=2)
                handle.write("\n")
        else:
            raise ValueError(f"Format non supporté : {suffix or path.name}")
        os.replace(temp_path, path)
    finally:
        temp_path.unlink(missing_ok=True)


class DatasetRepository:
    """Dépôt de données multi-format avec verrou de processus et cache par fichier.

    Le cache est indexé sur (chemin, taille, mtime) : un fichier remplacé par un
    export est relu automatiquement, sans invalider le cache à la main.
    """

    def __init__(self, config: DataSourceConfig) -> None:
        self.config = config
        self._lock = threading.RLock()
        self._cache: dict[str, tuple[tuple[Any, ...], pd.DataFrame]] = {}

    # --------------------------------------------------------------- Lecture

    def path(self, name: str) -> Path:
        return self.config.dataset_path(name)

    def frame(self, name: str) -> pd.DataFrame:
        path = self.path(name)
        try:
            stat = path.stat()
            stamp = (str(path), stat.st_size, stat.st_mtime)
        except OSError:
            with self._lock:
                self._cache.pop(name, None)
            return pd.DataFrame()
        with self._lock:
            cached = self._cache.get(name)
            if cached is not None and cached[0] == stamp:
                return cached[1]
        try:
            frame = read_frame(path)
        except Exception:
            logger.exception("Unable to read datasource %s (%s)", name, path)
            return pd.DataFrame()
        with self._lock:
            self._cache[name] = (stamp, frame)
        return frame

    def records(self, name: str) -> list[dict[str, Any]]:
        return dataframe_to_records(self.frame(name))

    def columns(self, name: str) -> list[str]:
        return [str(column) for column in self.frame(name).columns]

    def preview(self, name: str, limit: int = 25) -> list[dict[str, Any]]:
        return dataframe_to_records(self.frame(name).head(max(1, int(limit))))

    def status(self) -> list[dict[str, Any]]:
        """État de chaque dataset, dans le format attendu par l'onglet Données."""
        entries: list[dict[str, Any]] = []
        for name, configured in self.config.dataset_paths().items():
            path = self.config.resolve(configured)
            exists = path.is_file()
            rows = 0
            size_kb = 0.0
            columns: list[str] = []
            error = ""
            if exists:
                try:
                    size_kb = round(path.stat().st_size / 1024, 1)
                except OSError:
                    size_kb = 0.0
                frame = self.frame(name)
                rows = int(len(frame))
                columns = [str(column) for column in frame.columns]
            else:
                error = "Fichier introuvable."
            entries.append(
                {
                    "name": name,
                    "configured": configured,
                    "path": str(path),
                    "format": path.suffix.lstrip(".").lower(),
                    "supported": path.suffix.lower() in SUPPORTED_SUFFIXES,
                    "exists": exists,
                    "rows": rows,
                    "columns": columns,
                    "size_kb": size_kb,
                    "error": error,
                }
            )
        return entries

    def invalidate(self, name: str | None = None) -> None:
        with self._lock:
            if name is None:
                self._cache.clear()
            else:
                self._cache.pop(name, None)

    # --------------------------------------------------------------- Écriture

    def save_records(self, name: str, records: list[dict[str, Any]]) -> None:
        self.save_frame(name, pd.DataFrame(records))

    def save_frame(self, name: str, frame: pd.DataFrame) -> None:
        path = self.path(name)
        with self._lock:
            write_frame(frame, path)
            self.invalidate(name)
