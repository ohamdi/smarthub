"""Fixtures partagées : application isolée sur des données de test.

Les tests ne touchent jamais les données de `data/` : chaque fixture construit un
répertoire temporaire avec ses propres Parquet et son propre jeu de reportings.
Un test qui casse ne peut donc pas corrompre la démonstration.
"""

from __future__ import annotations

import sys
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Iterator

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from smartwealthreporting.auth import Principal  # noqa: E402
from smartwealthreporting.config import DataSourceConfig, Settings  # noqa: E402
from smartwealthreporting.metrics import MetricsEngine, ReportScope  # noqa: E402
from smartwealthreporting.reportings import ReportingLibrary  # noqa: E402
from smartwealthreporting.services import ApplicationService  # noqa: E402
from smartwealthreporting.storage import DatasetRepository, write_frame  # noqa: E402

AS_OF = date(2026, 9, 30)


# ------------------------------------------------------------------ Données

#: Deux lignes obligataires de référence, choisies pour que chaque moyenne pondérée
#: se vérifie à la main : 600 000 en AA- / 4 ans / 3,00 % et 200 000 en BB+ /
#: 6 ans / 4,50 %, pour un encours obligataire de 800 000.
BOND_ROWS: tuple[dict[str, object], ...] = (
    {
        "as_of": "2026-09-30", "client_id": "T001", "portfolio_id": "PF-T001-GLO",
        "isin": "OB000000001", "instrument_name": "OAT 3,00 % 2031",
        "asset_class": "Obligations", "category": "Obligations Souveraines",
        "sector": "Souverain", "country": "France", "currency": "EUR",
        "issuer": "Souverain FR", "rating": "AA-", "maturity": "2031-05-15",
        "coupon": 3.0, "yield": 2.8, "mod_duration": 4.0, "quantity": 6_000.0,
        "price": 100.0, "market_value": 600_000.0, "cost_basis": 590_000.0,
        "pnl_unrealised": 10_000.0, "cash_value": 0.0, "esg_score": 0,
        "esg_e": 0, "esg_s": 0, "esg_g": 0,
    },
    {
        "as_of": "2026-09-30", "client_id": "T001", "portfolio_id": "PF-T001-GLO",
        "isin": "OB000000002", "instrument_name": "Banque SAS 4,50 % 2027",
        "asset_class": "Obligations", "category": "Obligations Entreprises",
        "sector": "Finance", "country": "France", "currency": "EUR",
        "issuer": "Banque SAS", "rating": "BB+", "maturity": "2027-03-01",
        "coupon": 4.5, "yield": 4.2, "mod_duration": 6.0, "quantity": 2_000.0,
        "price": 100.0, "market_value": 200_000.0, "cost_basis": 205_000.0,
        "pnl_unrealised": -5_000.0, "cash_value": 0.0, "esg_score": 0,
        "esg_e": 0, "esg_s": 0, "esg_g": 0,
    },
)


def with_bonds(metrics: MetricsEngine, *rows: dict[str, object]) -> dict[str, Any]:
    """Injecte des lignes obligataires dans le jeu de test et recalcule les faits."""
    metrics.repository.save_frame(
        "holdings",
        pd.concat(
            [metrics.repository.frame("holdings"), pd.DataFrame(list(rows))],
            ignore_index=True,
        ),
    )
    return metrics.build(ReportScope(client_id="T001", period="ytd", as_of="2026-09-30"))


def _performance_rows(portfolio_id: str, drift: float = 0.4) -> list[dict[str, Any]]:
    """Douze points mensuels, du T-11 au T0."""
    rows: list[dict[str, Any]] = []
    value = 0.0
    for index in range(12):
        day = AS_OF - timedelta(days=30 * (11 - index))
        value = round(value + drift, 2)
        rows.append(
            {
                "portfolio_id": portfolio_id,
                "date": day.isoformat(),
                "portfolio_cum": value,
                "benchmark_cum": round(value - 1.5, 2),
                "aum": 2_000_000.0,
                "volatility": 6.4,
                "sharpe": 0.72,
                "max_drawdown": -4.2,
            }
        )
    return rows


HOLDINGS = [
    # (isin, nom, classe, secteur, pays, devise, note, mv, cout, esg)
    ("FR0000120078", "Air Liquide", "Actions", "Industrie", "France", "EUR", "BBB+", 800_000, 720_000, 78),
    ("FR0000121014", "LVMH", "Actions", "Luxe", "France", "EUR", "BBB+", 600_000, 540_000, 64),
    ("FR0000120271", "TotalEnergies", "Actions", "Energie", "France", "EUR", "A+", 400_000, 380_000, 62),
    ("FR0000199679", "OAT 3.00% Oct 2031", "Obligations", "Souverain", "France", "EUR", "AA", 500_000, 495_000, 0),
    ("FR0010337793", "Schneider Electric 2.50% 2031", "Obligations", "Industrie", "France", "EUR", "A+", 300_000, 298_000, 80),
    ("FR0000989626", "Amundi ETF MSCI World", "Fonds", "Diversifie", "Monde", "EUR", "Non note", 250_000, 230_000, 69),
    ("FR0010791160", "SCPI Europe Retail", "Immobilier", "Immobilier", "Europe", "EUR", "Non note", 200_000, 195_000, 66),
    ("FR0000996564", "Amundi Money Market", "Monetaire", "Cash", "France", "EUR", "AAA", 150_000, 150_000, 0),
]

TRANSACTIONS = [
    {
        "client_id": "T001", "portfolio_id": "PF-T001-GLO", "trade_date": "2026-02-10",
        "transaction_type": "BUY", "instrument_name": "Air Liquide", "isin": "FR0000120078",
        "quantity": 100.0, "price": 8000.0, "amount": 800_000.0, "fees": 280.0,
        "realised_pnl": 0.0, "income": 0.0,
    },
    {
        "client_id": "T001", "portfolio_id": "PF-T001-GLO", "trade_date": "2026-05-12",
        "transaction_type": "DIVIDEND", "instrument_name": "TotalEnergies", "isin": "FR0000120271",
        "quantity": 0.0, "price": 0.0, "amount": 4_800.0, "fees": 0.0,
        "realised_pnl": 0.0, "income": 4_800.0,
    },
    {
        "client_id": "T001", "portfolio_id": "PF-T001-GLO", "trade_date": "2026-07-03",
        "transaction_type": "SELL", "instrument_name": "LVMH", "isin": "FR0000121014",
        "quantity": 50.0, "price": 12_000.0, "amount": 600_000.0, "fees": 210.0,
        "realised_pnl": 12_000.0, "income": 0.0,
    },
    {
        "client_id": "T001", "portfolio_id": "PF-T001-GLO", "trade_date": "2026-09-01",
        "transaction_type": "FEE", "instrument_name": "Frais de gestion", "isin": "—",
        "quantity": 0.0, "price": 0.0, "amount": -6_400.0, "fees": 6_400.0,
        "realised_pnl": 0.0, "income": 0.0,
    },
]


@pytest.fixture
def data_dir(tmp_path: Path) -> Path:
    """Répertoire `data/` de test : Parquet pour la gestion, JSON pour les comptes."""
    folder = tmp_path / "data"
    folder.mkdir(parents=True, exist_ok=True)

    write_frame(
        pd.DataFrame(
            [
                {
                    "client_id": "T001", "client_name": "Test Client", "segment": "Privé",
                    "domicile": "Paris", "relationship_manager": "Conseiller Test",
                    "base_ccy": "EUR", "risk_profile": "Modéré",
                },
                {
                    "client_id": "T002", "client_name": "Autre Client", "segment": "Family Office",
                    "domicile": "Lyon", "relationship_manager": "Conseiller Test",
                    "base_ccy": "EUR", "risk_profile": "Prudent",
                },
            ]
        ),
        folder / "clients.parquet",
    )
    write_frame(
        pd.DataFrame(
            [
                {
                    "portfolio_id": "PF-T001-GLO", "client_id": "T001",
                    "portfolio_name": "Global", "mandate_type": "Actions",
                    "strategy": "Growth", "base_ccy": "EUR", "aum": 3_200_000.0,
                    "inception_date": "2020-01-01",
                },
                {
                    "portfolio_id": "PF-T002-DEF", "client_id": "T002",
                    "portfolio_name": "Defensif", "mandate_type": "Obligataire",
                    "strategy": "Prudent", "base_ccy": "EUR", "aum": 1_500_000.0,
                    "inception_date": "2019-01-01",
                },
            ]
        ),
        folder / "portfolios.parquet",
    )
    write_frame(
        pd.DataFrame(
            [
                {
                    "as_of": AS_OF.isoformat(), "client_id": "T001", "portfolio_id": "PF-T001-GLO",
                    "isin": isin, "instrument_name": name, "asset_class": asset_class,
                    "category": asset_class, "sector": sector, "country": country,
                    "currency": currency, "rating": rating, "quantity": 100.0,
                    "price": market_value / 100.0, "market_value": float(market_value),
                    "cost_basis": float(cost), "pnl_unrealised": float(market_value - cost),
                    "coupon": 2.5, "yield": 2.5,
                    "cash_value": float(market_value) if asset_class == "Monetaire" else 0.0,
                    "esg_score": esg, "esg_e": esg, "esg_s": esg, "esg_g": esg,
                }
                for isin, name, asset_class, sector, country, currency, rating,
                market_value, cost, esg in HOLDINGS
            ]
            # Le second client reçoit un extrait réduit, pour tester l'isolation.
            + [
                {
                    "as_of": AS_OF.isoformat(), "client_id": "T002", "portfolio_id": "PF-T002-DEF",
                    "isin": "FR0000199679", "instrument_name": "OAT 3.00% Oct 2031",
                    "asset_class": "Obligations", "category": "Obligations", "sector": "Souverain",
                    "country": "France", "currency": "EUR", "rating": "AA", "quantity": 1000.0,
                    "price": 1500.0, "market_value": 1_500_000.0, "cost_basis": 1_490_000.0,
                    "pnl_unrealised": 10_000.0, "coupon": 3.0, "yield": 3.0, "cash_value": 0.0,
                    "esg_score": 0, "esg_e": 0, "esg_s": 0, "esg_g": 0,
                }
            ]
        ),
        folder / "holdings.parquet",
    )
    write_frame(
        pd.DataFrame(_performance_rows("PF-T001-GLO") + _performance_rows("PF-T002-DEF", drift=0.2)),
        folder / "performance.parquet",
    )
    write_frame(pd.DataFrame(TRANSACTIONS), folder / "transactions.parquet")
    (folder / "users.json").write_text(
        '[{"username": "admin", "password": "admin123", "role": "admin", "client_id": ""}]',
        encoding="utf-8",
    )
    return folder


@pytest.fixture
def config(data_dir: Path) -> DataSourceConfig:
    settings = DataSourceConfig(data_dir.parent)
    settings.save({})
    return settings


@pytest.fixture
def repository(config: DataSourceConfig) -> DatasetRepository:
    return DatasetRepository(config)


@pytest.fixture
def metrics(repository: DatasetRepository) -> MetricsEngine:
    return MetricsEngine(repository=repository)


@pytest.fixture
def scope() -> ReportScope:
    return ReportScope(client_id="T001", period="ytd", as_of=AS_OF.isoformat())


# -------------------------------------------------------------- Reportings


@pytest.fixture
def library(tmp_path: Path, data_dir: Path) -> ReportingLibrary:
    """Bibliothèque avec deux reportings : un simple, un empilé (KPI + graphique)."""
    root = tmp_path / "reportings"
    (root / "test_review").mkdir(parents=True)
    (root / "stacked_review").mkdir(parents=True)

    (root / "test_review" / "definition.json").write_text(
        """{
  "id": "test_review",
  "name": "Revue de test",
  "language": "fr",
  "audience": "client",
  "period": {"type": "ytd"},
  "default_client_id": "T001",
  "disclaimer": "Document de test au {as_of}.",
  "slides": [
    {"id": "cover", "layout": "cover", "title": "{{client_name}}", "subtitle": "{{period_label}}"},
    {"id": "kpi", "layout": "kpis", "title": "Synthese",
     "kpis": [{"key": "aum_total", "label": "Actif", "format": "currency", "decimals": 0},
              {"key": "portfolio_cum_return", "label": "Perf", "format": "percent"}]},
    {"id": "perf", "layout": "chart", "title": "Performance", "narrative": true,
     "focus": "Commenter l'ecart au benchmark.",
     "chart": {"kind": "line", "source": "performance", "series": ["portfolio", "benchmark"]}},
    {"id": "alloc", "layout": "chart", "title": "Allocation",
     "chart": {"kind": "doughnut", "source": "allocation", "dimension": "asset_class"}},
    {"id": "pos", "layout": "table", "title": "Positions", "narrative": true,
     "table": {"source": "top_holdings", "limit": 5,
               "columns": [{"key": "instrument", "label": "Instrument"},
                           {"key": "weight", "label": "Poids", "format": "percent"}]}},
    {"id": "disclaimer", "layout": "disclaimer", "title": "Mentions"}
  ]
}""",
        encoding="utf-8",
    )
    (root / "test_review" / "prompt.md").write_text(
        "Tu es gestionnaire de patrimoine. Redige en francais, sans anglicisme.\n", encoding="utf-8"
    )

    (root / "stacked_review" / "definition.json").write_text(
        """{
  "id": "stacked_review",
  "name": "Revue empilee",
  "period": {"type": "ytd"},
  "slides": [
    {"id": "cover", "layout": "cover", "title": "{{client_name}}"},
    {"id": "mix", "layout": "chart", "title": "KPI + graphique", "narrative": true,
     "kpis": [{"key": "aum_total", "label": "Actif", "format": "currency"},
              {"key": "cash_pct", "label": "Tresorerie", "format": "percent"}],
     "chart": {"kind": "doughnut", "source": "allocation", "dimension": "asset_class"}}
  ]
}""",
        encoding="utf-8",
    )
    (root / "stacked_review" / "prompt.md").write_text("Ton sobre.\n", encoding="utf-8")
    return ReportingLibrary(tmp_path)


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(
        base_dir=tmp_path,
        config_path=tmp_path / "datasource_config.json",
        session_secret="test-secret",
        auto_start_llamafile=False,
    )


@pytest.fixture
def service(settings: Settings, library: ReportingLibrary) -> Iterator[ApplicationService]:
    config = DataSourceConfig(settings.base_dir, settings.config_path)
    config.save({})
    repository = DatasetRepository(config)
    engine = MetricsEngine(repository=repository)
    instance = ApplicationService(settings, config, repository, library, engine)
    instance.llm = None
    yield instance
    for child in (settings.outputs_dir,):
        for item in sorted(child.rglob("*"), reverse=True) if child.exists() else []:
            item.unlink() if item.is_file() else item.rmdir()


@pytest.fixture
def admin() -> Principal:
    return Principal(username="admin", role="admin")


@pytest.fixture
def restricted() -> Principal:
    return Principal(username="conseiller", role="user", client_id="T001")


class StubLLM:
    """Modèle local simulé : renvoie une réponse JSON, ou lève sur ordre."""

    def __init__(self, replies: list[str] | str = "", *, error: Exception | None = None) -> None:
        self.replies = [replies] if isinstance(replies, str) else list(replies)
        self.calls: list[list[dict[str, str]]] = []
        self.error = error
        self.unloaded = False

    def chat(self, messages: list[dict[str, str]], **_: Any) -> str:
        self.calls.append(messages)
        if self.error is not None:
            raise self.error
        if not self.replies:
            return '{"slides":{}}'
        index = min(len(self.calls) - 1, len(self.replies) - 1)
        return self.replies[index]

    def unload(self) -> None:
        self.unloaded = True

    def warmup(self) -> None:
        return None

    def model_status(self) -> dict[str, Any]:
        return {"backend": "stub", "loaded": True, "available": True, "model_name": "stub"}

    def start_llamafile(self) -> None:
        return None

    def stop_llamafile(self) -> None:
        return None

    def config_changed(self) -> None:
        return None


@pytest.fixture
def stub_llm() -> type[StubLLM]:
    return StubLLM
