"""Bibliothèque des reportings : un dossier, trois fichiers, aucune migration SQL.

Le contrat est volontairement simple — `definition.json`, `prompt.md`,
`template.pptx` — pour qu'un redacteur puisse dupliquer un dossier du jour au
lendemain. Ces tests gardent ce contrat strict : pas de définition invalide
écrite, pas de sortie du dossier de sortie.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from smartwealthreporting.errors import APIError
from smartwealthreporting.reportings import ReportingLibrary

DEFINITION = {
    "id": "test_review",
    "name": "Revue de test",
    "slides": [
        {"id": "cover", "layout": "cover", "title": "{{client_name}}"},
        {"id": "commentary", "layout": "narrative", "narrative": True},
    ],
}


# ------------------------------------------------------------------ Découverte


def test_ids_lists_only_complete_folders(library: ReportingLibrary, tmp_path: Path) -> None:
    (tmp_path / "reportings" / "vide").mkdir()

    assert library.ids() == ["stacked_review", "test_review"]


def test_ids_without_root(library: ReportingLibrary) -> None:
    empty = ReportingLibrary(library.base_dir / "ailleurs")

    assert empty.ids() == []


def test_folder_is_resolved_inside_the_root(library: ReportingLibrary) -> None:
    assert library.folder("test_review").parent == library.root


@pytest.mark.parametrize(
    "identifier", ["../donnees", "a/b", "", "Espace Interdit", "with.dot"]
)
def test_invalid_identifier_is_refused(library: ReportingLibrary, identifier: str) -> None:
    with pytest.raises(APIError) as excinfo:
        library.folder(identifier)
    assert excinfo.value.status_code == 400


def test_unknown_reporting_is_a_404(library: ReportingLibrary) -> None:
    with pytest.raises(APIError) as excinfo:
        library.folder("inexistant")
    assert excinfo.value.status_code == 404
    assert library.exists("inexistant") is False


# ------------------------------------------------------------------- Lecture


def test_load_definition(library: ReportingLibrary) -> None:
    definition = library.load("test_review")

    assert definition.id == "test_review"
    assert definition.name == "Revue de test"
    assert definition.language == "fr"
    assert [slide.id for slide in definition.slides] == ["cover", "kpi", "perf", "alloc", "pos", "disclaimer"]


def test_narrative_slides(library: ReportingLibrary) -> None:
    definition = library.load("test_review")

    assert [slide.id for slide in definition.narrative_slides()] == ["perf", "pos"]
    assert definition.slide("alloc") is not None
    assert definition.slide("fantome") is None


def test_load_prompt(library: ReportingLibrary) -> None:
    assert "gestionnaire de patrimoine" in library.load_prompt("test_review")


def test_missing_prompt_reads_as_empty(library: ReportingLibrary) -> None:
    (library.prompt_path("test_review")).unlink()

    assert library.load_prompt("test_review") == ""


def test_broken_json_is_a_422_with_a_line(library: ReportingLibrary) -> None:
    library.definition_path("test_review").write_text("{ pas du json", encoding="utf-8")

    with pytest.raises(APIError) as excinfo:
        library.load("test_review")
    assert excinfo.value.status_code == 422
    assert "ligne" in excinfo.value.message


def test_definition_must_be_an_object(library: ReportingLibrary) -> None:
    library.definition_path("test_review").write_text("[]", encoding="utf-8")

    with pytest.raises(APIError) as excinfo:
        library.load("test_review")
    assert excinfo.value.status_code == 422


def test_invalid_definition_is_rejected(library: ReportingLibrary) -> None:
    library.definition_path("test_review").write_text(
        json.dumps({"id": "test_review", "slides": [{"id": "a", "layout": "paradoxe"}]}),
        encoding="utf-8",
    )

    with pytest.raises(APIError) as excinfo:
        library.load("test_review")
    assert excinfo.value.status_code == 422


def test_empty_reporting_is_refused(library: ReportingLibrary) -> None:
    library.definition_path("test_review").write_text(
        json.dumps({"id": "test_review", "slides": []}), encoding="utf-8"
    )

    with pytest.raises(APIError) as excinfo:
        library.load("test_review")
    assert excinfo.value.status_code == 422
    assert "aucune slide" in excinfo.value.message


def test_duplicate_slide_ids_are_refused(library: ReportingLibrary) -> None:
    library.definition_path("test_review").write_text(
        json.dumps(
            {
                "id": "test_review",
                "slides": [
                    {"id": "dup", "layout": "cover"},
                    {"id": "dup", "layout": "chart"},
                ],
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(APIError) as excinfo:
        library.load("test_review")
    assert excinfo.value.status_code == 422
    assert "dupliqué" in excinfo.value.message


def test_id_is_always_forced_to_the_folder(library: ReportingLibrary) -> None:
    raw = json.loads(library.definition_path("test_review").read_text(encoding="utf-8"))
    raw["id"] = "autre"
    library.definition_path("test_review").write_text(json.dumps(raw), encoding="utf-8")

    assert library.load("test_review").id == "test_review"


# ------------------------------------------------------------------- Écriture


def test_save_prompt_round_trip(library: ReportingLibrary) -> None:
    saved = library.save_prompt("test_review", "  Ton sobre et factuel.  ")

    assert saved == "Ton sobre et factuel.\n"
    assert library.load_prompt("test_review") == saved


def test_save_prompt_leaves_no_temp_file(library: ReportingLibrary) -> None:
    library.save_prompt("test_review", "Ton sobre")

    assert sorted(path.name for path in library.folder("test_review").iterdir()) == [
        "definition.json",
        "prompt.md",
    ]


def test_save_definition_round_trip(library: ReportingLibrary) -> None:
    definition = library.save_definition("test_review", DEFINITION)

    assert definition.id == "test_review"
    assert json.loads(library.definition_path("test_review").read_text())["id"] == "test_review"


def test_save_definition_validates_before_writing(library: ReportingLibrary) -> None:
    before = library.definition_path("test_review").read_text(encoding="utf-8")

    with pytest.raises(APIError) as excinfo:
        library.save_definition("test_review", {"slides": [{"id": "a", "layout": "paradoxe"}]})
    assert excinfo.value.status_code == 422
    assert library.definition_path("test_review").read_text(encoding="utf-8") == before


# ------------------------------------------------------------------ Création


def test_create_produces_a_usable_reporting(library: ReportingLibrary) -> None:
    definition = library.create("nouveau_reporting", "Nouveau reporting")

    assert definition.id == "nouveau_reporting"
    assert library.exists("nouveau_reporting")
    assert library.load_prompt("nouveau_reporting").strip()
    assert library.has_template("nouveau_reporting") is False  # installé à la demande


def test_create_derives_a_name(library: ReportingLibrary) -> None:
    assert library.create("revue_trim").name == "Revue Trim"


def test_create_refuses_an_existing_id(library: ReportingLibrary) -> None:
    with pytest.raises(APIError) as excinfo:
        library.create("test_review")
    assert excinfo.value.status_code == 409


def test_create_copies_a_template_when_asked(library: ReportingLibrary, tmp_path: Path) -> None:
    from smartwealthreporting.templates import build_default_template

    source = library.template_path("test_review")
    build_default_template().save(str(source))

    library.create("copie", copy_template_from="test_review")

    assert library.has_template("copie")
    assert source.stat().st_size > 0


def test_delete_removes_the_folder(library: ReportingLibrary) -> None:
    library.delete("stacked_review")

    assert not library.exists("stacked_review")
    assert "stacked_review" not in library.ids()


def test_delete_unknown_reporting_is_a_404(library: ReportingLibrary) -> None:
    with pytest.raises(APIError) as excinfo:
        library.delete("inexistant")
    assert excinfo.value.status_code == 404


# ----------------------------------------------------------------------- Vue


def test_reference_summarizes(library: ReportingLibrary) -> None:
    reference = library.reference("test_review")

    assert reference.slides == 6
    assert reference.narrative_slides == 2
    assert reference.has_template is False
    assert reference.prompt_chars > 0
    assert reference.modified_at


def test_list_covers_every_folder(library: ReportingLibrary) -> None:
    assert [reference.id for reference in library.list()] == ["stacked_review", "test_review"]


def test_detail_gathers_definition_prompt_and_warnings(library: ReportingLibrary) -> None:
    detail = library.detail("test_review")

    assert detail.definition.id == "test_review"
    assert detail.prompt.strip()
    assert detail.template_path.endswith("template.pptx")
    assert any("Template" in warning for warning in detail.warnings)


def test_warnings_mention_a_missing_template_and_prompt(library: ReportingLibrary) -> None:
    warnings = library.warnings(library.load("test_review"))

    assert any("Template" in warning for warning in warnings)
    assert not any("prompt.md vide" in warning for warning in warnings)


def test_warnings_for_a_reporting_without_narration(library: ReportingLibrary, tmp_path: Path) -> None:
    folder = library.root / "statique"
    folder.mkdir(parents=True)
    (folder / "definition.json").write_text(
        json.dumps(
            {
                "id": "statique",
                "name": "Reporting statique",
                "slides": [{"id": "cover", "layout": "cover", "title": "{{client_name}}"}],
            }
        ),
        encoding="utf-8",
    )
    library.save_prompt("statique", "Ton sobre.")

    warnings = library.warnings(library.load("statique"))

    assert any("narration" in warning for warning in warnings)
    assert any("client par défaut" in warning for warning in warnings)


def test_warnings_disappear_once_the_reporting_is_complete(library: ReportingLibrary) -> None:
    from smartwealthreporting.templates import build_default_template

    build_default_template().save(str(library.template_path("test_review")))
    library.save_prompt("test_review", "Ton sobre.")

    assert library.warnings(library.load("test_review")) == []