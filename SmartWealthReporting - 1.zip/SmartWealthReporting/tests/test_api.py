"""API HTTP : ce que voit réellement le navigateur.

Les tests passent par `TestClient` avec le même service injecté que la
production : seule la narration est remplacée par `StubLLM`. Chaque réponse est
relue comme le ferait l'interface (JSON, codes HTTP, en-têtes de téléchargement).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterator

import pytest
from fastapi.testclient import TestClient

from smartwealthreporting.config import Settings
from smartwealthreporting.main import create_app
from smartwealthreporting.reportings import ReportingLibrary
from smartwealthreporting.services import ApplicationService


# ------------------------------------------------------------------ Fixtures


@pytest.fixture
def static_dir(settings: Settings) -> Path:
    folder = settings.static_dir
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "index.html").write_text(
        "<!doctype html><title>SmartWealthReporting</title>", encoding="utf-8"
    )
    return folder


@pytest.fixture
def app(settings: Settings, library: ReportingLibrary, data_dir: Path) -> Any:
    return create_app(settings)


@pytest.fixture
def model(app: Any, stub_llm: type) -> Any:
    instance = stub_llm()
    app.state.service.llm = instance
    return instance


@pytest.fixture
def client(app: Any, model: Any, static_dir: Path) -> Iterator[TestClient]:
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def auth(client: TestClient) -> TestClient:
    response = client.post("/api/login", json={"username": "admin", "password": "admin123"})
    assert response.status_code == 200
    return client


def body(response: Any) -> dict[str, Any]:
    return response.json()


# ------------------------------------------------------------------- Système


def test_health_is_public(client: TestClient) -> None:
    response = client.get("/health")

    assert response.status_code == 200
    assert body(response)["status"] == "ok"
    assert body(response)["reportings"] == 2


def test_unknown_api_route_is_a_404(client: TestClient) -> None:
    response = client.get("/api/inexistant")

    assert response.status_code == 404


def test_the_spa_serves_the_index_for_any_route(client: TestClient) -> None:
    response = client.get("/reportings/test_review")

    assert response.status_code == 200
    assert "SmartWealthReporting" in response.text


def test_openapi_schema_is_served(client: TestClient) -> None:
    schema = body(client.get("/openapi.json"))

    assert "/api/reportings/{reporting_id}/generate" in schema["paths"]


# ------------------------------------------------------------------- Session


def test_every_api_call_asks_for_a_session(client: TestClient) -> None:
    for path in ("/api/me", "/api/clients", "/api/datasets", "/api/reportings"):
        response = client.get(path)
        assert response.status_code == 401, path
        assert body(response)["login_required"] is True


def test_login_and_me(auth: TestClient) -> None:
    response = auth.get("/api/me")

    assert body(response) == {"username": "admin", "role": "admin", "client_id": ""}


def test_login_with_wrong_credentials(client: TestClient) -> None:
    response = client.post("/api/login", json={"username": "admin", "password": "faux"})

    assert response.status_code == 401
    assert body(response)["error"] == "Identifiants invalides"


def test_logout_closes_the_session(auth: TestClient) -> None:
    assert auth.post("/api/logout").status_code == 200
    assert auth.get("/api/me").status_code == 401


def test_a_restricted_user_only_sees_his_client(
    client: TestClient, app: Any, stub_llm: type
) -> None:
    users = app.state.service.repository
    users.save_records(
        "users",
        [{"username": "rm.lille", "password": "lille2026", "role": "user", "client_id": "T001"}],
    )
    client.post("/api/login", json={"username": "rm.lille", "password": "lille2026"})

    response = client.get("/api/clients")

    assert response.status_code == 200
    assert [row["client_id"] for row in body(response)] == ["T001"]


def test_a_restricted_user_cannot_generate_for_another_client(
    client: TestClient, app: Any
) -> None:
    app.state.service.repository.save_records(
        "users",
        [{"username": "rm.lille", "password": "lille2026", "role": "user", "client_id": "T001"}],
    )
    client.post("/api/login", json={"username": "rm.lille", "password": "lille2026"})

    response = client.post(
        "/api/reportings/test_review/generate", json={"client_id": "T002", "use_ai": False}
    )

    assert response.status_code == 403


# -------------------------------------------------------------------- Données


def test_datasets_are_listed(auth: TestClient) -> None:
    rows = body(auth.get("/api/datasets"))

    assert {row["name"] for row in rows} >= {"clients", "holdings", "performance"}
    assert next(row for row in rows if row["name"] == "clients")["rows"] == 2


def test_dataset_preview(auth: TestClient) -> None:
    response = auth.post("/api/datasets/preview", json={"name": "holdings", "limit": 2})

    assert response.status_code == 200
    assert len(body(response)["rows"]) == 2


def test_dataset_preview_of_an_unknown_table(auth: TestClient) -> None:
    response = auth.post("/api/datasets/preview", json={"name": "inexistant"})

    assert response.status_code == 404


def test_dataset_preview_validates_the_limit(auth: TestClient) -> None:
    response = auth.post("/api/datasets/preview", json={"name": "clients", "limit": 0})

    assert response.status_code == 422
    assert "limit" in body(response)["error"]


def test_clients_carry_their_aum(auth: TestClient) -> None:
    rows = body(auth.get("/api/clients"))

    assert next(row for row in rows if row["client_id"] == "T001")["aum"] == 3_200_000.0


# ----------------------------------------------------------------- Reportings


def test_reportings_are_listed(auth: TestClient) -> None:
    rows = {row["id"]: row for row in body(auth.get("/api/reportings"))}

    assert set(rows) == {"test_review", "stacked_review"}
    assert rows["test_review"]["slides"] == 6


def test_reporting_detail(auth: TestClient) -> None:
    detail = body(auth.get("/api/reportings/test_review"))

    assert detail["definition"]["id"] == "test_review"
    assert "gestionnaire de patrimoine" in detail["prompt"]


def test_reporting_detail_of_an_unknown_reporting(auth: TestClient) -> None:
    assert auth.get("/api/reportings/inexistant").status_code == 404


def test_reporting_id_is_validated(auth: TestClient) -> None:
    response = auth.get("/api/reportings/../datasource_config")

    assert response.status_code in {400, 404}


def test_saving_the_prompt(auth: TestClient) -> None:
    response = auth.put("/api/reportings/test_review/prompt", json={"prompt": "Ton sobre, en francais."})

    assert response.status_code == 200
    assert "Ton sobre" in body(response)["prompt"]


def test_an_overlong_prompt_is_refused(auth: TestClient) -> None:
    response = auth.put("/api/reportings/test_review/prompt", json={"prompt": "x" * 40_001})

    assert response.status_code == 422


def test_saving_the_definition(auth: TestClient) -> None:
    definition = body(auth.get("/api/reportings/test_review"))["definition"]
    definition["name"] = "Revue renommee"

    response = auth.put("/api/reportings/test_review", json={"definition": definition})

    assert response.status_code == 200
    assert body(response)["name"] == "Revue renommee"


def test_an_invalid_definition_is_explained(auth: TestClient) -> None:
    response = auth.put(
        "/api/reportings/test_review", json={"definition": {"name": "sans slide"}}
    )

    assert response.status_code == 422
    assert "n'a aucune slide" in body(response)["error"]


def test_a_malformed_definition_field_is_reported_field_by_field(auth: TestClient) -> None:
    response = auth.put(
        "/api/reportings/test_review",
        json={"definition": {"name": "x", "slides": [{"id": "s", "layout": "inconnu"}]}},
    )

    assert response.status_code == 422
    assert "Définition invalide" in body(response)["error"]


def test_creating_a_reporting(auth: TestClient, app: Any) -> None:
    response = auth.post(
        "/api/reportings", json={"id": "trimestriel", "name": "Revue trimestrielle"}
    )

    assert response.status_code == 201
    assert body(response)["id"] == "trimestriel"
    assert app.state.service.library.template_path("trimestriel").is_file()


def test_creating_a_reporting_needs_an_id(auth: TestClient) -> None:
    assert auth.post("/api/reportings", json={"name": "Sans id"}).status_code == 400


def test_deleting_a_reporting(auth: TestClient) -> None:
    auth.post("/api/reportings", json={"id": "epingle", "name": "Épinglé"})

    response = auth.delete("/api/reportings/epingle")

    assert response.status_code == 200
    assert auth.get("/api/reportings/epingle").status_code == 404


def test_template_download(auth: TestClient) -> None:
    response = auth.get("/api/reportings/test_review/template.pptx")

    assert response.status_code == 200
    assert response.content[:2] == b"PK"
    assert "attachment" in response.headers["content-disposition"]
    assert response.headers["content-type"].endswith("presentationml.presentation")


def test_template_install(auth: TestClient, app: Any) -> None:
    response = auth.post("/api/reportings/test_review/template/install")

    assert response.status_code == 200
    assert Path(body(response)["path"]).is_file()
    assert app.state.service.library.has_template("test_review") is True


# ------------------------------------------------------------------- Contexte


def test_context_of_a_reporting(auth: TestClient) -> None:
    response = auth.get("/api/reportings/test_review/context")

    assert response.status_code == 200
    assert body(response)["client_id"] == "T001"
    assert body(response)["chars"] == len(body(response)["context_text"])


def test_context_accepts_query_parameters(auth: TestClient) -> None:
    response = auth.get("/api/reportings/test_review/context?client_id=T002&period=month")

    assert response.status_code == 200
    assert body(response)["client_id"] == "T002"


def test_context_refuses_a_foreign_client_for_a_restricted_user(
    client: TestClient, app: Any
) -> None:
    app.state.service.repository.save_records(
        "users",
        [{"username": "rm.lille", "password": "lille2026", "role": "user", "client_id": "T001"}],
    )
    client.post("/api/login", json={"username": "rm.lille", "password": "lille2026"})

    response = client.get("/api/reportings/test_review/context?client_id=T002")

    assert response.status_code == 403


# ---------------------------------------------------------------- Génération


def test_generate_returns_the_deck_metadata(auth: TestClient, model: Any) -> None:
    model.replies = [
        json.dumps(
            {
                "slides": {
                    "perf": "Le portefeuille de 3 200 000 EUR progresse de 4,80 % sur la periode.",
                    "pos": "Les cinq premieres lignes pchent 81,2 % de l'actif, par choix.",
                }
            }
        )
    ]

    response = auth.post("/api/reportings/test_review/generate", json={"use_ai": True})

    assert response.status_code == 200
    payload = body(response)
    assert payload["reporting_id"] == "test_review"
    assert payload["ok"] is True
    assert len(payload["slides"]) == 6
    assert payload["slides"][2]["narrative_source"] == "ia"
    assert payload["engine"]["backend"] == "stub"


def test_generate_without_ai(auth: TestClient, model: Any) -> None:
    response = auth.post("/api/reportings/test_review/generate", json={"use_ai": False})

    assert response.status_code == 200
    assert model.calls == []
    assert body(response)["slides"][2]["narrative_source"] == "desactivee"


def test_generate_with_a_custom_output_name(auth: TestClient) -> None:
    response = auth.post(
        "/api/reportings/test_review/generate", json={"use_ai": False, "output_name": "revue-client"}
    )

    assert body(response)["filename"] == "revue-client.pptx"
    assert body(response)["download_url"] == "/api/runs/test_review/revue-client.pptx"


def test_downloading_a_generated_deck(auth: TestClient) -> None:
    run = body(
        auth.post("/api/reportings/test_review/generate", json={"use_ai": False})
    )

    response = auth.get(run["download_url"])

    assert response.status_code == 200
    assert response.content[:2] == b"PK"
    assert response.headers["content-length"] == str(len(response.content))
    assert "attachment" in response.headers["content-disposition"]


def test_downloading_an_unknown_deck(auth: TestClient) -> None:
    assert auth.get("/api/runs/test_review/absent.pptx").status_code == 404


def test_download_cannot_escape_the_output_folder(auth: TestClient) -> None:
    """Un nom de fichier traversal n'est jamais servi : ni le deck, ni un autre fichier."""
    response = auth.get("/api/runs/test_review/..%2F..%2Fdatasource_config.json")

    assert response.status_code in {400, 404}


def test_generation_history(auth: TestClient) -> None:
    auth.post("/api/reportings/test_review/generate", json={"use_ai": False})

    rows = body(auth.get("/api/runs"))

    assert len(rows) == 1
    assert rows[0]["reporting_id"] == "test_review"
    assert set(rows[0]["facts"]) == {"period", "client", "kpis", "allocations"}


def test_generation_history_of_one_reporting(auth: TestClient) -> None:
    auth.post("/api/reportings/test_review/generate", json={"use_ai": False})
    auth.post("/api/reportings/stacked_review/generate", json={"use_ai": False})

    assert len(body(auth.get("/api/runs", params={"reporting_id": "stacked_review"}))) == 1


# ------------------------------------------------------------------ Moteur IA


def test_ai_status(auth: TestClient, model: Any) -> None:
    status = body(auth.get("/api/ai/status"))

    assert status["backend"] == "stub"
    assert status["available"] is True
    assert isinstance(status["models"], list)


def test_ai_status_without_a_model(client: TestClient, app: Any) -> None:
    client.post("/api/login", json={"username": "admin", "password": "admin123"})
    app.state.service.llm = None

    status = body(client.get("/api/ai/status"))

    assert status["available"] is False
    assert status["error"] == "Service IA non initialisé."


def test_ai_config_is_readable_and_writable(auth: TestClient) -> None:
    assert body(auth.get("/api/ai/config"))["max_slides_per_call"] == 3

    response = auth.post("/api/ai/config", json={"max_slides_per_call": 2, "temperature": 0.2})

    assert response.status_code == 200
    assert body(response)["max_slides_per_call"] == 2
    assert body(response)["temperature"] == 0.2


def test_an_out_of_range_setting_is_ignored(auth: TestClient) -> None:
    response = auth.post("/api/ai/config", json={"max_slides_per_call": 99})

    assert body(response)["max_slides_per_call"] == 3


def test_warmup(auth: TestClient) -> None:
    response = auth.post("/api/ai/warmup")

    assert response.status_code == 200
    assert body(response)["ok"] is True


def test_warmup_without_a_model(client: TestClient, app: Any) -> None:
    client.post("/api/login", json={"username": "admin", "password": "admin123"})
    app.state.service.llm = None

    assert client.post("/api/ai/warmup").status_code == 503


def test_ai_chat_rewrites_only_text(auth: TestClient, model: Any) -> None:
    model.replies = [json.dumps({"slides": {"commentaire": "Le portefeuille de 3 200 000 EUR progresse."}})]

    response = auth.post(
        "/api/ai/chat",
        json={"reporting_id": "test_review", "question": "Rends le commentaire plus sobre."},
    )

    assert response.status_code == 200
    assert "3 200 000" in body(response)["answer"].replace(" ", " ")
    assert body(response)["verification"]["ok"] is True


def test_ai_chat_flags_an_invented_number(auth: TestClient, model: Any) -> None:
    model.replies = [json.dumps({"slides": {"commentaire": "Le rendement atteint 27,40 % cette annee."}})]

    response = auth.post(
        "/api/ai/chat",
        json={"reporting_id": "test_review", "question": "Commentaire ?" },
    )

    assert body(response)["verification"]["ok"] is False


def test_ai_chat_needs_a_model(client: TestClient, app: Any) -> None:
    client.post("/api/login", json={"username": "admin", "password": "admin123"})
    app.state.service.llm = None

    response = client.post(
        "/api/ai/chat", json={"reporting_id": "test_review", "question": "Hello ?"}
    )

    assert response.status_code == 503


def test_ai_chat_requires_a_question(auth: TestClient) -> None:
    response = auth.post("/api/ai/chat", json={"reporting_id": "test_review", "question": ""})

    assert response.status_code == 422


# ---------------------------------------------------------------- Utilisateurs


def test_users_are_listed(auth: TestClient) -> None:
    rows = body(auth.get("/api/users"))

    assert rows == [{"username": "admin", "role": "admin", "client_id": ""}]
    assert all("password" not in row for row in rows)


def test_user_lifecycle(auth: TestClient) -> None:
    created = auth.post(
        "/api/users",
        json={"username": "conseiller", "password": "conseiller123", "role": "user", "client_id": "T001"},
    )
    assert created.status_code == 201

    assert auth.put(
        "/api/users/conseiller", json={"client_id": "T002"}
    ).status_code == 200
    assert next(
        row for row in body(auth.get("/api/users")) if row["username"] == "conseiller"
    )["client_id"] == "T002"

    assert auth.delete("/api/users/conseiller").status_code == 200
    assert body(auth.get("/api/users")) == [
        {"username": "admin", "role": "admin", "client_id": ""}
    ]


def test_creating_a_duplicate_user(auth: TestClient) -> None:
    response = auth.post(
        "/api/users", json={"username": "admin", "password": "autre", "role": "admin"}
    )

    assert response.status_code == 409


def test_updating_an_unknown_user(auth: TestClient) -> None:
    response = auth.put("/api/users/inconnu", json={"role": "user"})

    assert response.status_code == 404


def test_a_new_user_can_log_in(auth: TestClient, client: TestClient) -> None:
    auth.post(
        "/api/users", json={"username": "rm", "password": "rm2026", "role": "user", "client_id": "T002"}
    )

    response = client.post("/api/login", json={"username": "RM", "password": "rm2026"})

    assert response.status_code == 200
    assert body(response)["client_id"] == "T002"


# --------------------------------------------------------------- Configuration


def test_datasource_config_is_readable(auth: TestClient) -> None:
    payload = body(auth.get("/api/config/datasource"))

    assert payload["datasets"]["clients"].endswith("clients.parquet")
    assert payload["llm"]["llm_backend"] == "gguf"


def test_datasource_config_is_writable(auth: TestClient, data_dir: Path) -> None:
    response = auth.post(
        "/api/config/datasource",
        json={"datasets": {"performance": str(data_dir / "performance.csv")}},
    )

    assert response.status_code == 200
    assert body(response)["datasets"]["performance"].endswith("performance.csv")


def test_a_dataset_can_be_reset(auth: TestClient) -> None:
    response = auth.post("/api/config/datasets/clients/reset")

    assert body(response)["datasets"]["clients"] == "data/clients.parquet"


def test_resetting_an_unknown_dataset(auth: TestClient) -> None:
    assert auth.post("/api/config/datasets/inconnu/reset").status_code == 404


# --------------------------------------------------------------- Erreurs API


def test_an_applicative_error_carries_its_message(auth: TestClient) -> None:
    response = auth.post("/api/reportings/test_review/generate", json={"period": "inconnu"})

    assert response.status_code == 422
    assert "period" in body(response)["error"]


def test_a_reporting_error_does_not_break_the_session(auth: TestClient) -> None:
    auth.get("/api/reportings/inexistant")

    assert auth.get("/api/me").status_code == 200