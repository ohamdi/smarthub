"""Dépôt multi-format : Parquet, CSV, Excel, JSON lus et écrits par le même code.

C'est la promesse du module : un dataset livré en CSV par un export manuel et le
même dataset livré en Parquet par le système amont se lisent de façon identique,
sans que l'appelant ait à savoir quel format il a sous les yeux.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from smartwealthreporting.config import SUPPORTED_SUFFIXES
from smartwealthreporting.storage import (
    DatasetRepository,
    dataframe_to_records,
    read_frame,
    write_frame,
)

ROWS = [
    {"client_id": "T001", "client_name": "Client Un", "aum": 1_000_000.0, "esg": 72.5},
    {"client_id": "T002", "client_name": "Client Deux", "aum": 250_000.0, "esg": 61.0},
]


# --------------------------------------------------------------- Aller-retour


@pytest.mark.parametrize("suffix", [".parquet", ".csv", ".xlsx", ".json"])
def test_round_trip_every_format(tmp_path: Path, suffix: str) -> None:
    path = tmp_path / f"clients{suffix}"
    write_frame(pd.DataFrame(ROWS), path)

    assert path.is_file()
    frame = read_frame(path)
    assert list(frame["client_id"]) == ["T001", "T002"]
    assert float(frame["aum"].iloc[0]) == 1_000_000.0
    assert float(frame["esg"].iloc[1]) == 61.0


def test_supported_suffixes_cover_the_four_formats() -> None:
    assert {".parquet", ".csv", ".xlsx", ".json"} <= set(SUPPORTED_SUFFIXES)


def test_write_is_atomic_and_leaves_no_temp_file(tmp_path: Path) -> None:
    path = tmp_path / "clients.parquet"
    write_frame(pd.DataFrame(ROWS), path)

    leftovers = [item.name for item in tmp_path.iterdir() if ".tmp" in item.name]
    assert leftovers == []


def test_unknown_suffix_is_refused(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="Format non supporté"):
        write_frame(pd.DataFrame(ROWS), tmp_path / "clients.txt")
    with pytest.raises(ValueError, match="Format non supporté"):
        read_frame(tmp_path / "clients.txt")


# ------------------------------------------------------------------ Lectures


def test_csv_with_semicolon_and_latin1(tmp_path: Path) -> None:
    path = tmp_path / "holdings.csv"
    path.write_text("isin;instrument\nFR1;Amundi ETF\n", encoding="latin-1")

    frame = read_frame(path)
    assert list(frame.columns) == ["isin", "instrument"]
    assert frame["instrument"].iloc[0] == "Amundi ETF"


def test_json_list_of_objects(tmp_path: Path) -> None:
    path = tmp_path / "users.json"
    path.write_text(json.dumps(ROWS), encoding="utf-8")

    assert len(read_frame(path)) == 2


@pytest.mark.parametrize(
    "payload",
    [
        {"records": ROWS},
        {"data": ROWS},
        {"rows": ROWS},
    ],
)
def test_json_wrapped_objects(tmp_path: Path, payload: dict) -> None:
    path = tmp_path / "clients.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    assert list(read_frame(path)["client_id"]) == ["T001", "T002"]


def test_json_columns_layout(tmp_path: Path) -> None:
    path = tmp_path / "clients.json"
    path.write_text(
        json.dumps({"client_id": ["T001", "T002"], "client_name": ["Un", "Deux"]}),
        encoding="utf-8",
    )

    frame = read_frame(path)
    assert list(frame["client_name"]) == ["Un", "Deux"]


def test_json_scalar_payload_yields_empty_frame(tmp_path: Path) -> None:
    path = tmp_path / "clients.json"
    path.write_text(json.dumps({"a": 1, "b": 2}), encoding="utf-8")

    assert read_frame(path).empty


def test_records_are_json_safe(tmp_path: Path) -> None:
    frame = pd.DataFrame(
        {
            "label": ["a", None],
            "value": [float("nan"), float("inf")],
            "stamp": [pd.Timestamp("2026-09-30"), pd.NaT],
            "flag": [True, False],
        }
    )
    records = dataframe_to_records(frame)

    assert records[0]["stamp"] == "2026-09-30T00:00:00"
    assert records[0]["label"] == "a"
    assert records[0]["value"] is None  # NaN et inf ne sont pas du JSON
    assert records[1]["label"] is None
    assert records[1]["stamp"] is None
    assert records[0]["flag"] is True


def test_empty_frame_has_no_records() -> None:
    assert dataframe_to_records(None) == []
    assert dataframe_to_records(pd.DataFrame()) == []


# ------------------------------------------------------------------ Dépôt


def test_repository_reads_configured_dataset(repository: DatasetRepository) -> None:
    records = repository.records("clients")

    assert [record["client_id"] for record in records] == ["T001", "T002"]
    assert "client_name" in repository.columns("clients")


def test_configured_but_absent_dataset_reads_as_empty(repository: DatasetRepository) -> None:
    repository.config.save({"esg_ratings": "data/esg_ratings.parquet"})

    assert repository.frame("esg_ratings").empty
    assert repository.records("esg_ratings") == []


def test_unknown_dataset_raises(repository: DatasetRepository) -> None:
    with pytest.raises(KeyError):
        repository.frame("table_inexistante")


def test_cache_follows_file_replacement(repository: DatasetRepository, data_dir: Path) -> None:
    assert repository.frame("clients").shape[0] == 2

    write_frame(pd.DataFrame(ROWS + [ROWS[0] | {"client_id": "T003"}]), data_dir / "clients.parquet")

    assert repository.frame("clients").shape[0] == 3


def test_explicit_invalidate(repository: DatasetRepository, data_dir: Path) -> None:
    write_frame(pd.DataFrame(ROWS * 2), data_dir / "clients.parquet")
    repository.invalidate("clients")

    assert repository.frame("clients").shape[0] == 4


def test_save_records_replaces_and_invalidates(repository: DatasetRepository) -> None:
    assert repository.frame("clients").shape[0] == 2

    repository.save_records("clients", [ROWS[0]])

    frame = repository.frame("clients")
    assert frame.shape[0] == 1
    assert repository.frame("clients").shape[0] == 1  # relu, pas servi par le cache


def test_status_reports_every_configured_dataset(repository: DatasetRepository) -> None:
    entries = {entry["name"]: entry for entry in repository.status()}

    assert {"clients", "portfolios", "holdings", "users"} <= set(entries)
    assert entries["clients"]["exists"] is True
    assert entries["clients"]["rows"] == 2
    assert entries["clients"]["format"] == "parquet"
    assert entries["clients"]["size_kb"] > 0
    assert "client_name" in entries["clients"]["columns"]
    # Un dataset additionnel absent est signalé, pas ignoré en silence.
    assert entries["holdings"]["error"] == ""


def test_status_flags_missing_file(repository: DatasetRepository) -> None:
    entries = {entry["name"]: entry for entry in repository.status()}
    assert entries["transactions"]["exists"] is True

    (repository.path("transactions")).unlink()
    entries = {entry["name"]: entry for entry in repository.status()}
    assert entries["transactions"]["exists"] is False
    assert entries["transactions"]["error"] == "Fichier introuvable."


def test_preview_limits_rows(repository: DatasetRepository) -> None:
    assert len(repository.preview("clients", limit=1)) == 1
    assert len(repository.preview("clients", limit=0)) == 1  # jamais moins d'une ligne
    assert len(repository.preview("clients", limit=99)) == 2


def test_csv_dataset_is_read_through_the_repository(
    repository: DatasetRepository, data_dir: Path
) -> None:
    """Le même code sert un dataset Parquet et sa version CSV."""
    path = data_dir / "esg_ratings.csv"
    write_frame(pd.DataFrame([{"isin": "FR1", "score": 71.0}]), path)
    repository.config.save({"esg_ratings": "data/esg_ratings.csv"})
    repository.invalidate()

    assert repository.frame("esg_ratings")["score"].tolist() == [71.0]