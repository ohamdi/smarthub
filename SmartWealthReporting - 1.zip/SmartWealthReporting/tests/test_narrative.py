"""Lecture de la réponse du modèle : un modèle 3B ne respecte pas toujours le contrat.

Ces tests couvrent ce que fait vraiment un modèle local : chatter autour du JSON,
l'encapsuler dans un bloc Markdown, l'injecter dans une phrase, le tronquer, ou
répondre carrément autre chose. Le deck ne doit jamais afficher de JSON brut.
"""

from __future__ import annotations

from smartwealthreporting.narrative import (
    parse_json_object,
    parse_reply,
    sanitise,
)


# ------------------------------------------------------------ Extraction JSON


def test_plain_json() -> None:
    assert parse_json_object('{"slides": {"cover": "Bonjour"}}') == {"slides": {"cover": "Bonjour"}}


def test_json_in_a_markdown_fence() -> None:
    raw = '```json\n{"slides": {"cover": "Bonjour"}}\n```'

    assert parse_json_object(raw) == {"slides": {"cover": "Bonjour"}}


def test_json_embedded_in_prose() -> None:
    raw = 'Voici le commentaire : {"slides": {"cover": "Bonjour"}} — bonne lecture.'

    assert parse_json_object(raw)["slides"]["cover"] == "Bonjour"


def test_json_before_another_object() -> None:
    raw = '```\n{"meta": 1}\n{"slides": {"cover": "Bonjour"}}\n```'

    assert parse_json_object(raw) == {"meta": 1}


def test_braces_inside_strings_do_not_confuse_the_parser() -> None:
    raw = '{"slides": {"cover": "Le taux {taux} reste stable {et} monitored."}}'

    assert parse_json_object(raw)["slides"]["cover"].startswith("Le taux")


def test_truncated_json_is_repaired() -> None:
    assert parse_json_object('{"slides": {"cover": "Bonjour"') == {"slides": {"cover": "Bonjour"}}
    assert parse_json_object('{"slides": {"cover": "Bonjour"},') is not None


def test_trailing_comma_inside_a_value_is_dropped() -> None:
    assert parse_json_object('{"slides": {"cover": "Bonjour",}}') is not None


def test_garbage_yields_nothing() -> None:
    assert parse_json_object("Le modèle refuse de répondre.") is None
    assert parse_json_object("") is None
    assert parse_json_object(None) is None
    assert parse_json_object("[1, 2, 3]") is None  # un tableau n'est pas un objet


def test_broken_object_is_skipped_for_the_next_one() -> None:
    raw = '{pas du json} {"slides": {"cover": "Bonjour"}}'

    assert parse_json_object(raw)["slides"]["cover"] == "Bonjour"


# ------------------------------------------------------------------ Nettoyage


def test_sanitise_removes_markdown() -> None:
    assert sanitise("**Gras** et _italique_", max_chars=100, min_chars=0) == "Gras et italique"


def test_sanitise_removes_bullets() -> None:
    assert sanitise("- premier\n- second", max_chars=100, min_chars=0) == "premier second"
    assert sanitise("1. un\n2) deux", max_chars=100, min_chars=0) == "un deux"


def test_sanitise_removes_html_and_code_fences() -> None:
    assert sanitise("<b>Gras</b> et ```code```", max_chars=100, min_chars=0) == "Gras et code"


def test_sanitise_collapses_whitespace_and_unescapes() -> None:
    assert sanitise('  il   dit\\n "oui"  ', max_chars=100, min_chars=0) == 'il dit "oui"'


def test_sanitise_truncates_on_a_word_boundary() -> None:
    text = sanitise("un deux trois quatre cinq six sept", max_chars=14, min_chars=0)

    assert text.endswith("…")
    assert " " not in text[-2:]  # la coupure ne mange pas la fin d'un mot


def test_sanitise_rejects_text_below_the_floor() -> None:
    """Une réponse tronquée ne part pas au client : elle est jetée, pas affichée."""
    assert sanitise("ok", max_chars=400, min_chars=60) == ""
    assert sanitise("", max_chars=400, min_chars=60) == ""


def test_sanitise_refuses_non_strings() -> None:
    assert sanitise({"cover": "x"}, max_chars=400, min_chars=0) == ""
    assert sanitise(42, max_chars=400, min_chars=0) == ""


# ------------------------------------------------------------------ Réponses


def test_expected_shape() -> None:
    parsed = parse_reply('{"slides": {"perf": "Bon trimestre."}}', ["perf", "alloc"])

    assert parsed["slides"] == {"perf": "Bon trimestre."}
    assert parsed["missing"] == ["alloc"]
    assert "alloc" in parsed["error"]
    assert parsed["error"] != ""  # informatif : le lot a produit quelque chose


def test_complete_answer_has_no_error() -> None:
    parsed = parse_reply('{"slides": {"perf": "Bon trimestre."}}', ["perf"])

    assert parsed["missing"] == []
    assert parsed["error"] == ""


def test_unknown_slide_ids_are_dropped() -> None:
    parsed = parse_reply('{"slides": {"inconnue": "texte", "perf": "Bon trimestre."}}', ["perf"])

    assert set(parsed["slides"]) == {"perf"}


def test_list_form_is_accepted() -> None:
    raw = '{"slides": [{"id": "perf", "text": "Bon trimestre."}]}'

    assert parse_reply(raw, ["perf"])["slides"] == {"perf": "Bon trimestre."}


def test_flat_object_form_is_accepted() -> None:
    parsed = parse_reply('{"perf": "Bon trimestre."}', ["perf", "alloc"])

    assert parsed["slides"] == {"perf": "Bon trimestre."}


def test_empty_slide_is_not_returned() -> None:
    parsed = parse_reply('{"slides": {"perf": "   "}}', ["perf"])

    assert parsed["slides"] == {}
    assert parsed["missing"] == ["perf"]


def test_response_without_json_is_an_explicit_failure() -> None:
    parsed = parse_reply("Je suis désolé, je ne peux pas.", ["perf"])

    assert parsed["slides"] == {}
    assert parsed["missing"] == ["perf"]
    assert "JSON" in parsed["error"]
    assert parsed["raw"].startswith("Je suis désolé")


def test_text_is_cleaned_on_the_way_out() -> None:
    raw = '{"slides": {"perf": "- **Point** : voir <i>annexe</i>"}}'

    assert parse_reply(raw, ["perf"])["slides"]["perf"] == "Point : voir annexe"


def test_raw_answer_is_kept_for_diagnosis() -> None:
    parsed = parse_reply('{"slides": {"perf": "' + "x" * 900 + '"}}', ["perf"])

    assert len(parsed["raw"]) == 400