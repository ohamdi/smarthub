"""Service d'orchestration : périmètre, narration IA, persistance, historique.

Les chiffres viennent toujours de `metrics`, la narration du seul stub `StubLLM`,
et chaque test vérifie le contrat visible par l'utilisateur : sources des textes
(`ia`/`vide`/`desactivee`/`erreur`), avertissements, fichiers écrits, historique.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from smartwealthreporting import ai_config
from smartwealthreporting.auth import Principal
from smartwealthreporting.errors import APIError, TemplateError
from smartwealthreporting.reportings import ReportingLibrary
from smartwealthreporting.schemas import GenerateRequest, ReportingDefinition, SlideDefinition
from smartwealthreporting.services import ApplicationService, _aum_of, _slug


# ------------------------------------------------------------------- Helpers


def request_for(**kwargs: Any) -> GenerateRequest:
    return GenerateRequest(**kwargs)


def slide_by_id(response: Any, slide_id: str) -> Any:
    return next(slide for slide in response.slides if slide.id == slide_id)


def reply(*pairs: tuple[str, str]) -> str:
    """Réponse JSON conforme au contrat : une entrée par slide commentée."""
    return json.dumps({"slides": {slide_id: text for slide_id, text in pairs}})


GOOD_PERF = (
    "Le portefeuille de 3 200 000 EUR progresse de 4,80 % sur la periode, soit "
    "150 pb de mieux que le benchmark. L'ecart provient des valeurs actionnieres."
)
GOOD_POS = (
    "Le poids des cinq premieres lignes represente 81,2 % de l'actif, une "
    "concentration assumee au regard du profil de risque modere du client."
)


# ------------------------------------------------------------------- Clients


def test_admin_sees_every_client(service: ApplicationService, admin: Principal) -> None:
    clients = service.clients(admin)

    assert [row["client_id"] for row in clients] == ["T002", "T001"]  # tri par nom
    assert clients[-1]["client_name"] == "Test Client"
    assert clients[-1]["aum"] == 3_200_000.0


def test_restricted_user_sees_only_his_clients(
    service: ApplicationService, restricted: Principal
) -> None:
    assert [row["client_id"] for row in service.clients(restricted)] == ["T001"]


def test_allowed_client_ids(service: ApplicationService, admin: Principal) -> None:
    assert service.allowed_client_ids(admin) is None
    assert service.allowed_client_ids(
        Principal(username="rm", role="user", client_id="C006")
    ) == {"C006"}
    assert service.allowed_client_ids(Principal(username="rm", role="user", client_id="*")) is None


# ------------------------------------------------------------------- Données


def test_datasets_list_the_loaded_tables(service: ApplicationService) -> None:
    names = {row["name"] for row in service.datasets()}

    assert {"clients", "holdings", "performance", "transactions"} <= names
    assert all(row["rows"] > 0 for row in service.datasets() if row["name"] != "users")


def test_dataset_preview(service: ApplicationService) -> None:
    preview = service.dataset_preview("holdings", limit=3)

    assert preview["name"] == "holdings"
    assert len(preview["rows"]) == 3
    assert "market_value" in preview["columns"]
    assert preview["total"] == 9


def test_dataset_preview_of_an_unknown_table(service: ApplicationService) -> None:
    with pytest.raises(APIError) as error:
        service.dataset_preview("inexistant")

    assert error.value.status_code == 404


def test_update_datasets_notifies_the_model(
    service: ApplicationService, stub_llm: type, data_dir: Path
) -> None:
    model = stub_llm()
    service.llm = model

    saved = service.update_datasets({"clients": str(data_dir / "clients.parquet")})

    assert saved["clients"].endswith("clients.parquet")
    assert service.config.dataset_paths()["clients"].endswith("clients.parquet")


def test_update_datasets_with_an_empty_payload_keeps_the_config(
    service: ApplicationService,
) -> None:
    before = service.config.load()

    assert service.update_datasets({"clients": None}) == before
    assert service.config.load() == before


# ----------------------------------------------------------------- Périmètre


def test_scope_defaults_to_the_reporting_client(
    service: ApplicationService, admin: Principal
) -> None:
    definition = service.library.load("test_review")

    scope = service.scope(definition, admin, request_for())

    assert scope.client_id == "T001"
    assert scope.period == "ytd"


def test_scope_is_locked_on_the_principal_client(
    service: ApplicationService, restricted: Principal
) -> None:
    definition = service.library.load("test_review")

    scope = service.scope(definition, restricted, request_for(client_id=""))

    assert scope.client_id == "T001"


def test_scope_refuses_a_client_outside_the_portfolio(
    service: ApplicationService, restricted: Principal
) -> None:
    definition = service.library.load("test_review")

    with pytest.raises(APIError) as error:
        service.scope(definition, restricted, request_for(client_id="T002"))

    assert error.value.status_code == 403


def test_facts_of_an_unknown_client_are_empty(
    service: ApplicationService, admin: Principal
) -> None:
    definition = service.library.load("test_review")

    facts = service.facts(service.scope(definition, admin, request_for(client_id="T999")))

    assert _aum_of(facts) == 0.0


# ------------------------------------------------------------------ Contexte


def test_context_payload_shows_what_would_be_sent(
    service: ApplicationService, admin: Principal
) -> None:
    payload = service.context_payload("test_review", admin, request_for())

    assert payload.reporting_id == "test_review"
    assert payload.client_id == "T001"
    assert payload.as_of == "2026-09-30"
    assert payload.chars == len(payload.context_text)
    assert "Actif" in payload.context_text
    assert payload.facts["kpis"]["aum_total"] == 3_200_000.0
    # Le prompt système contient les faits, le périmètre est donc verifiable.
    assert payload.context_text[:200] in payload.system_prompt


def test_context_payload_lists_only_narrative_slides(
    service: ApplicationService, admin: Principal
) -> None:
    payload = service.context_payload("test_review", admin, request_for())

    assert {brief["id"] for brief in payload.slides} == {"perf", "pos"}


# ---------------------------------------------------------------- Narration


def test_narration_batches_the_slides(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    model = stub_llm([reply(("perf", GOOD_PERF), ("pos", GOOD_POS))])
    service.llm = model

    run = service.generate("test_review", admin, request_for())

    assert len(model.calls) == 1  # deux slides, un lot
    assert slide_by_id(run, "perf").narrative_source == "ia"
    assert slide_by_id(run, "perf").narrative == GOOD_PERF
    assert slide_by_id(run, "pos").verification.ok is True
    assert run.ok is True


def test_narration_splits_the_slots_when_the_batch_is_full(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    service.update_ai_settings({"max_slides_per_call": 1})
    model = stub_llm([reply(("perf", GOOD_PERF)), reply(("pos", GOOD_POS))])
    service.llm = model

    run = service.generate("test_review", admin, request_for())

    assert len(model.calls) == 2
    assert {slide.narrative_source for slide in run.slides if slide.narrative} == {"ia"}


def test_partial_batch_is_reused_then_completed(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    """Un lot incomplet garde ce qui est arrivé et redemande seulement le reste."""
    model = stub_llm(
        [
            reply(("perf", GOOD_PERF)),  # `pos` manquant
            reply(("pos", GOOD_POS)),  # seconde tentative : uniquement le manquant
        ]
    )
    service.llm = model

    run = service.generate("test_review", admin, request_for())

    assert len(model.calls) == 2
    assert "Il manque le commentaire pour : pos" in model.calls[1][-1]["content"]
    assert slide_by_id(run, "perf").narrative == GOOD_PERF
    assert slide_by_id(run, "pos").narrative == GOOD_POS
    assert run.ok is True


def test_an_unusable_answer_is_retried_then_given_up(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    model = stub_llm(["voici du texte sans JSON", "toujours pas de JSON"])
    service.llm = model

    run = service.generate("test_review", admin, request_for())

    assert len(model.calls) == 2  # une tentative par `retries`
    assert slide_by_id(run, "perf").narrative_source == "erreur"
    assert run.ok is False
    assert run.warnings  # le deck part quand même, avec un avertissement


def test_a_model_that_raises_leaves_the_deck_untouched(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    service.llm = stub_llm(error=RuntimeError("GGUF indisponible"))

    run = service.generate("test_review", admin, request_for())

    assert "GGUF indisponible" in slide_by_id(run, "perf").error
    assert run.ok is False
    assert service.output_path("test_review", run.filename).is_file()


def test_without_model_the_narration_is_reported_as_unavailable(
    service: ApplicationService, admin: Principal
) -> None:
    service.llm = None

    run = service.generate("test_review", admin, request_for())

    assert slide_by_id(run, "perf").narrative_source == "erreur"
    assert slide_by_id(run, "perf").error == "Service IA non initialisé."
    assert slide_by_id(run, "cover").narrative_source == "vide"


def test_a_number_outside_the_facts_is_flagged(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    hallucination = (
        "Le rendement du fonds atteint 27,40 % cette annee, un niveau jamais observe "
        "sur le segment depuis 2008."
    )
    service.llm = stub_llm([reply(("perf", hallucination), ("pos", GOOD_POS))])

    run = service.generate("test_review", admin, request_for())

    report = slide_by_id(run, "perf").verification
    assert report.ok is False
    assert report.numbers_checked >= 1
    assert any("ne figurent pas dans les faits calculés" in text for text in run.warnings)


def test_a_number_in_the_facts_passes_verification(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    service.llm = stub_llm([reply(("perf", GOOD_PERF), ("pos", GOOD_POS))])

    run = service.generate("test_review", admin, request_for())

    assert slide_by_id(run, "perf").verification.numbers_checked >= 1
    assert not [text for text in run.warnings if "ne figurent pas" in text]


def test_narration_disabled_produces_a_silent_deck(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    model = stub_llm()
    service.llm = model

    run = service.generate("test_review", admin, request_for(use_ai=False))

    assert model.calls == []
    assert slide_by_id(run, "perf").narrative_source == "desactivee"
    assert "Narration non demandée" in " ".join(run.warnings)


def test_a_reporting_without_narrative_slide_skips_the_model(
    service: ApplicationService, admin: Principal, stub_llm: type
) -> None:
    folder = service.library.root / "chiffres_seuls"
    folder.mkdir(parents=True)
    (folder / "definition.json").write_text(
        json.dumps(
            {
                "id": "chiffres_seuls",
                "name": "Chiffres seuls",
                "period": {"type": "ytd"},
                "slides": [
                    {"id": "cover", "layout": "cover", "title": "{{client_name}}"},
                    {"id": "kpi", "layout": "kpis", "title": "Actif",
                     "kpis": [{"key": "aum_total", "label": "Actif", "format": "currency"}]},
                ],
            }
        ),
        encoding="utf-8",
    )
    model = stub_llm()
    service.llm = model

    run = service.generate("chiffres_seuls", admin, request_for())

    assert model.calls == []
    assert run.reporting_id == "chiffres_seuls"
    assert not [text for text in run.warnings if "Narration" in text]


def test_narrate_returns_nothing_without_a_context(
    service: ApplicationService, library: ReportingLibrary
) -> None:
    result = service.narrate(library.load("test_review"), "prompt", "", service.ai_settings())

    assert result == {
        "slides": {}, "verification": {}, "warnings": [], "error": "", "errors": [], "failed": []
    }


def test_narrate_skips_a_definition_without_narrative_slide(
    service: ApplicationService,
) -> None:
    definition = ReportingDefinition(
        id="chiffres_seuls",
        slides=[SlideDefinition(id="cover", layout="cover", title="Couverture")],
    )

    result = service.narrate(
        definition, "Ton sobre.", "Actif : 3 200 000 EUR", service.ai_settings()
    )

    assert result["failed"] == []
    assert result["error"] == ""


# ----------------------------------------------------------------- Livraison


def test_generate_writes_the_deck_and_its_sidecar(
    service: ApplicationService, admin: Principal
) -> None:
    service.llm = None

    run = service.generate("test_review", admin, request_for(use_ai=False))

    target = service.settings.outputs_dir / "test_review" / run.filename
    assert target.is_file()
    assert target.read_bytes()[:2] == b"PK"
    assert run.download_url == f"/api/runs/test_review/{run.filename}"
    assert run.facts["kpis"]["nb_positions"] == 8

    sidecar = json.loads(target.with_suffix(".json").read_text(encoding="utf-8"))
    assert sidecar["id"] == run.id
    assert len(sidecar["slides"]) == len(run.slides)


def test_generate_uses_the_reporting_template(
    service: ApplicationService, admin: Principal
) -> None:
    service.install_template("test_review")
    service.llm = None

    run = service.generate("test_review", admin, request_for(use_ai=False))

    assert service.library.template_path("test_review").is_file()
    assert service.output_path("test_review", run.filename).is_file()


def test_output_name_is_forced_inside_the_output_folder(
    service: ApplicationService, admin: Principal
) -> None:
    service.llm = None

    run = service.generate(
        "test_review", admin, request_for(use_ai=False, output_name="../../evasion.pptx")
    )

    assert run.filename == "evasion.pptx"
    assert (service.settings.outputs_dir / "test_review" / "evasion.pptx").is_file()
    assert not (service.settings.outputs_dir / "evasion.pptx").exists()


def test_output_name_without_extension_is_completed(
    service: ApplicationService, admin: Principal
) -> None:
    service.llm = None

    run = service.generate("test_review", admin, request_for(use_ai=False, output_name="revue"))

    assert run.filename == "revue.pptx"


def test_an_empty_scope_warns_before_delivery(
    service: ApplicationService, admin: Principal
) -> None:
    service.llm = None

    run = service.generate("test_review", admin, request_for(use_ai=False, client_id="T999"))

    assert "Aucune position trouvée" in " ".join(run.warnings)
    assert service.output_path("test_review", run.filename).is_file()


def test_a_broken_template_is_a_clear_error(
    service: ApplicationService, admin: Principal
) -> None:
    target = service.library.template_path("test_review")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(b"pas un pptx")
    service.llm = None

    with pytest.raises(TemplateError) as error:
        service.generate("test_review", admin, request_for(use_ai=False))

    assert error.value.status_code == 422
    assert "illisible" in error.value.message


# ---------------------------------------------------------------- Historique


def test_runs_lists_the_generations_of_a_reporting(
    service: ApplicationService, admin: Principal
) -> None:
    service.llm = None
    service.generate("test_review", admin, request_for(use_ai=False))

    runs = service.runs("test_review")

    assert len(runs) == 1
    assert runs[0]["reporting_id"] == "test_review"


def test_runs_filters_by_reporting(service: ApplicationService, admin: Principal) -> None:
    service.llm = None
    service.generate("test_review", admin, request_for(use_ai=False))
    service.generate("stacked_review", admin, request_for(use_ai=False))

    assert len(service.runs("stacked_review")) == 1
    assert len(service.runs()) == 2


def test_history_is_rebuilt_from_disk_on_a_new_service(
    service: ApplicationService, admin: Principal, settings: Any, config: Any
) -> None:
    service.llm = None
    first = service.generate("test_review", admin, request_for(use_ai=False))

    from smartwealthreporting.metrics import MetricsEngine
    from smartwealthreporting.storage import DatasetRepository

    restarted = ApplicationService(
        settings, config, DatasetRepository(config), service.library, MetricsEngine(repository=service.repository)
    )
    runs = restarted.runs("test_review")

    assert [record["filename"] for record in runs] == [first.filename]
    # L'historique n'expose que le résumé : les faits complets pèsent trop lourd.
    assert set(runs[0]["facts"]) == {"period", "client", "kpis", "allocations"}


def test_run_of_an_unknown_file_is_a_404(service: ApplicationService) -> None:
    with pytest.raises(APIError) as error:
        service.run("test_review", "jamais.pptx")

    assert error.value.status_code == 404


def test_run_ignores_a_traversal_filename(service: ApplicationService) -> None:
    with pytest.raises(APIError) as error:
        service.run("test_review", "../../datasource_config.json")

    assert error.value.status_code == 404


def test_output_path_points_inside_the_outputs(service: ApplicationService, admin: Principal) -> None:
    service.llm = None
    run = service.generate("test_review", admin, request_for(use_ai=False))

    target = service.output_path("test_review", run.filename)

    assert target.is_file()
    assert target.suffix == ".pptx"


def test_output_path_rejects_a_foreign_extension(service: ApplicationService) -> None:
    with pytest.raises(APIError) as error:
        service.output_path("test_review", "datasource_config.json")

    assert error.value.status_code == 400


def test_output_path_of_a_missing_file(service: ApplicationService) -> None:
    with pytest.raises(APIError) as error:
        service.output_path("test_review", "absent.pptx")

    assert error.value.status_code == 404


def test_run_history_is_bounded(service: ApplicationService, admin: Principal, monkeypatch) -> None:
    from smartwealthreporting import services as services_module

    monkeypatch.setattr(services_module, "RUN_HISTORY_LIMIT", 2)
    service.llm = None
    for index in range(3):
        service.generate("test_review", admin, request_for(use_ai=False, output_name=f"deck{index}.pptx"))

    assert len(service._runs) == 2


# --------------------------------------------------------------- Reportings


def test_reportings_are_listed_with_their_size(service: ApplicationService) -> None:
    rows = {row["id"]: row for row in service.reportings()}

    assert set(rows) == {"test_review", "stacked_review"}
    assert rows["test_review"]["slides"] == 6
    assert rows["test_review"]["narrative_slides"] == 2
    assert rows["test_review"]["has_template"] is False


def test_reporting_detail_exposes_definition_prompt_and_warnings(
    service: ApplicationService,
) -> None:
    detail = service.reporting_detail("test_review")

    assert detail["definition"]["name"] == "Revue de test"
    assert "gestionnaire de patrimoine" in detail["prompt"]
    assert detail["warnings"] == [] or all(isinstance(text, str) for text in detail["warnings"])


def test_saving_the_prompt_persists_it(service: ApplicationService) -> None:
    saved = service.save_prompt("test_review", "Ton très sobre, en français.\n")

    assert saved["chars"] == len(saved["prompt"])
    assert "Ton très sobre" in service.library.load_prompt("test_review")


def test_saving_a_definition_updates_the_library(service: ApplicationService) -> None:
    payload = service.reporting_detail("test_review")["definition"]
    payload["name"] = "Revue renommee"

    saved = service.save_definition("test_review", payload)

    assert saved["name"] == "Revue renommee"
    assert service.library.load("test_review").name == "Revue renommee"


def test_creating_a_reporting_installs_a_template(
    service: ApplicationService, library: ReportingLibrary
) -> None:
    created = service.create_reporting("mensuel", "Revue mensuelle", copy_template="test_review")

    assert created["id"] == "mensuel"
    assert service.library.template_path("mensuel").is_file()
    assert service.library.template_path("mensuel").read_bytes()[:2] == b"PK"
    assert (library.root / "mensuel" / "definition.json").is_file()


def test_deleting_a_reporting_removes_its_folder(service: ApplicationService) -> None:
    service.create_reporting("epingle", "Épinglé")

    service.delete_reporting("epingle")

    assert "epingle" not in {row["id"] for row in service.reportings()}


def test_template_bytes_installs_a_default_template(service: ApplicationService) -> None:
    payload = service.template_bytes("test_review")

    assert payload[:2] == b"PK"
    assert service.library.template_path("test_review").is_file()


def test_template_bytes_survive_an_unreadable_file(service: ApplicationService) -> None:
    # Un dossier à la place du template : la lecture échoue, l'API le dit.
    service.library.template_path("test_review").mkdir(parents=True, exist_ok=True)

    with pytest.raises(APIError) as error:
        service.template_bytes("test_review")

    assert error.value.status_code == 500


# ---------------------------------------------------------------- Moteur IA


def test_ai_settings_defaults_are_bounded(service: ApplicationService) -> None:
    settings = service.ai_settings()

    assert settings["max_slides_per_call"] == ai_config.DEFAULTS["max_slides_per_call"]
    assert settings["narrative_min_chars"] < settings["narrative_max_chars"]


def test_updating_ai_settings_unloads_the_model(
    service: ApplicationService, stub_llm: type
) -> None:
    model = stub_llm()
    service.llm = model

    saved = service.update_ai_settings({"n_ctx": 4096, "temperature": 0.15})

    assert saved["n_ctx"] == 4096
    assert saved["temperature"] == 0.15
    assert model.unloaded is True


def test_ai_settings_refuse_an_out_of_range_value(service: ApplicationService) -> None:
    saved = service.update_ai_settings({"n_ctx": 12})

    assert saved["n_ctx"] == ai_config.DEFAULTS["n_ctx"]


def test_ai_status_without_a_model(service: ApplicationService) -> None:
    status = service.ai_status()

    assert status["available"] is False
    assert status["error"] == "Service IA non initialisé."
    assert isinstance(status["models"], list)


def test_ai_status_with_a_model(service: ApplicationService, stub_llm: type) -> None:
    service.llm = stub_llm()

    assert service.ai_status()["backend"] == "stub"


def test_warmup_needs_a_model(service: ApplicationService) -> None:
    with pytest.raises(APIError) as error:
        service.warmup()

    assert error.value.status_code == 503


def test_warmup_with_a_model(service: ApplicationService, stub_llm: type) -> None:
    service.llm = stub_llm()

    result = service.warmup()

    assert result["ok"] is True
    assert result["engine"]["backend"] == "stub"


# ------------------------------------------------------------------- Divers


def test_slug_keeps_a_readable_filename() -> None:
    assert _slug("Test Client/revue 2026") == "Test-Client-revue-2026"
    assert _slug("///") == "reporting"