"""Calcul des faits : les chiffres du deck viennent tous d'ici.

Les valeurs attendues sont recopiées à la main depuis le jeu de test de
`conftest.py` : si une formule change, ces tests le disent.
"""

from __future__ import annotations

import pandas as pd
from conftest import BOND_ROWS, with_bonds, _performance_rows

from smartwealthreporting.metrics import (
    INVESTMENT_GRADE_MAX_RANK,
    RATING_CORRESPONDENCE,
    RATING_SCALE,
    MetricsEngine,
    ReportScope,
    _curve_max_drawdown,
    _curve_sharpe,
    _curve_volatility,
)

#: actif du client T001 : 800 000 + 600 000 + 400 000 + 500 000 + 300 000 + 250 000 + 200 000 + 150 000
AUM_T001 = 3_200_000.0
COST_T001 = 720_000 + 540_000 + 380_000 + 495_000 + 298_000 + 230_000 + 195_000 + 150_000


# ------------------------------------------------------------------ Structure


def test_facts_expose_every_block(metrics: MetricsEngine, scope: ReportScope) -> None:
    facts = metrics.build(scope)

    assert {
        "client", "period", "kpis", "allocations", "performance", "top_holdings",
        "pnl", "esg", "flows", "activity", "concentration", "portfolios", "risks",
        "bonds",
    } <= set(facts)


def test_build_is_deterministic(metrics: MetricsEngine, scope: ReportScope) -> None:
    assert metrics.build(scope) == metrics.build(scope)


def test_client_facts(metrics: MetricsEngine, scope: ReportScope) -> None:
    client = metrics.client(scope)

    assert client["client_name"] == "Test Client"
    assert client["relationship_manager"] == "Conseiller Test"
    assert client["base_ccy"] == "EUR"


def test_unknown_client_yields_empty_client(metrics: MetricsEngine) -> None:
    assert metrics.client(ReportScope(client_id="INCONNU")) == {}


# ---------------------------------------------------------------------- KPI


def test_aum_and_positions(metrics: MetricsEngine, scope: ReportScope) -> None:
    kpis = metrics.build(scope)["kpis"]

    assert kpis["aum_total"] == AUM_T001
    assert kpis["cost_basis"] == COST_T001
    assert kpis["nb_positions"] == 8
    assert kpis["nb_portfolios"] == 1


def test_cash_and_unrealised(metrics: MetricsEngine, scope: ReportScope) -> None:
    kpis = metrics.build(scope)["kpis"]

    # Trésorerie = la seule ligne Monetaire, soit 150 000 sur 3 200 000.
    assert kpis["cash_pct"] == 4.69
    assert kpis["unrealised_pct"] == round((AUM_T001 - COST_T001) / COST_T001 * 100, 2)


def test_performance_kpis(metrics: MetricsEngine, scope: ReportScope) -> None:
    kpis = metrics.build(scope)["kpis"]

    # La courbe de test progresse de 0,40 point par mois sur 12 points ; le
    # benchmark est décalé de -1,50 point en permanence.
    assert kpis["portfolio_cum_return"] == 4.80
    assert kpis["benchmark_cum_return"] == 3.30
    assert kpis["alpha"] == 1.50
    assert kpis["sharpe"] == 0.72
    assert kpis["volatility"] == 6.4
    assert kpis["max_drawdown"] == -4.2


def test_kpis_are_json_friendly(metrics: MetricsEngine, scope: ReportScope) -> None:
    import json

    payload = json.dumps(metrics.build(scope), ensure_ascii=False)

    assert "NaN" not in payload
    assert "Infinity" not in payload


# ------------------------------------------------------------------ Isolation


def test_scope_isolates_the_other_client(metrics: MetricsEngine) -> None:
    facts = metrics.build(ReportScope(client_id="T002", period="ytd", as_of="2026-09-30"))

    assert facts["kpis"]["aum_total"] == 1_500_000.0
    assert facts["kpis"]["nb_positions"] == 1
    assert [row["portfolio_id"] for row in facts["portfolios"]] == ["PF-T002-DEF"]


def test_portfolio_scope_narrows_holdings(metrics: MetricsEngine, scope: ReportScope) -> None:
    facts = metrics.build(
        ReportScope(client_id="T001", portfolio_ids=("PF-T001-GLO",), period="ytd",
                    as_of="2026-09-30")
    )

    assert facts["kpis"]["nb_positions"] == 8
    assert facts["performance"]["labels"]


def test_performance_resolves_portfolios_from_the_client(
    metrics: MetricsEngine, scope: ReportScope
) -> None:
    """La table performance n'a pas de `client_id` : le périmètre passe par les portefeuilles."""
    frame = metrics.repository.frame("performance")

    assert "client_id" not in frame.columns
    assert metrics._portfolio_ids(scope) == {"PF-T001-GLO"}
    assert not metrics.performance(scope).empty


def test_client_scope_without_client_column_is_empty(
    metrics: MetricsEngine, data_dir
) -> None:
    frame = pd.DataFrame([{"portfolio_id": "PF-T001-GLO", "market_value": 100.0}])
    metrics.repository.save_frame("holdings", frame)

    assert metrics.holdings(ReportScope(client_id="T001")).empty


def test_latest_positions_only(metrics: MetricsEngine, data_dir) -> None:
    """Deux dates d'arrêté ne doivent pas doubler l'actif."""
    frame = metrics.repository.frame("holdings")
    stale = frame.iloc[[0]].copy()
    stale["as_of"] = "2026-06-30"
    stale["market_value"] = 999_999.0
    metrics.repository.save_frame("holdings", pd.concat([stale, frame], ignore_index=True))

    facts = metrics.build(ReportScope(client_id="T001", period="ytd", as_of="2026-09-30"))

    assert facts["kpis"]["aum_total"] == AUM_T001
    assert facts["kpis"]["nb_positions"] == 8


# -------------------------------------------------------------- Performance


def test_performance_series_align_with_labels(metrics: MetricsEngine, scope: ReportScope) -> None:
    performance = metrics.build(scope)["performance"]

    assert len(performance["labels"]) == 12
    assert len(performance["portfolio"]) == len(performance["labels"])
    assert len(performance["benchmark"]) == len(performance["labels"])
    assert performance["labels"][0] == "nov. 25"  # la courbe commence avant l'exercice
    assert performance["labels"][-1] == "sept. 26"


def test_performance_is_weighted_by_aum(metrics: MetricsEngine) -> None:
    """Deux portefeuilles du même client : la courbe est pondérée, pas moyennée."""
    performance = metrics.repository.frame("performance")
    extra = performance[performance["portfolio_id"] == "PF-T002-DEF"].copy()
    extra["portfolio_cum"] = extra["portfolio_cum"] * 2
    extra["benchmark_cum"] = extra["benchmark_cum"] * 2
    metrics.repository.save_frame(
        "performance", pd.concat([performance, extra], ignore_index=True)
    )
    portfolios = metrics.repository.frame("portfolios").copy()
    portfolios.loc[portfolios["portfolio_id"] == "PF-T002-DEF", "aum"] = 9_000_000.0
    metrics.repository.save_frame("portfolios", portfolios)

    result = metrics._performance(
        metrics.performance(ReportScope(client_id="T001")), metrics.portfolios(
            ReportScope(client_id="T001")
        )
    )

    assert result["weighted"] is True
    # La courbe du gros portefeuille (×2) domine la moyenne pondérée.
    assert result["portfolio_total"] > 4.40


def test_performance_without_frame_is_empty(metrics: MetricsEngine, data_dir) -> None:
    metrics.repository.save_frame("performance", pd.DataFrame())

    performance = metrics.build(ReportScope(client_id="T001"))["performance"]

    assert performance["labels"] == []
    assert performance["portfolio_total"] == 0.0


# ------------------------------------------------------------- Allocations


def test_allocations_sum_to_a_hundred_percent(metrics: MetricsEngine, scope: ReportScope) -> None:
    allocations = metrics.build(scope)["allocations"]

    for dimension in ("asset_class", "sector", "country", "currency", "category"):
        slices = allocations[dimension]
        assert slices, dimension
        assert round(sum(item["pct"] for item in slices), 2) == 100.0, dimension
        # Tri décroissant : le camembert se lit sans avoir à réordonner.
        values = [item["value"] for item in slices]
        assert values == sorted(values, reverse=True)


def test_allocation_merges_long_tails(metrics: MetricsEngine, scope: ReportScope) -> None:
    facts = metrics.build(scope)
    sectors = facts["allocations"]["sector"]
    facts["allocations"]["sector"] = sectors
    metrics.repository.save_frame(
        "holdings",
        pd.concat(
            [
                metrics.repository.frame("holdings"),
                pd.DataFrame(
                    [
                        {
                            "as_of": "2026-09-30", "client_id": "T001",
                            "portfolio_id": "PF-T001-GLO", "isin": f"S{index}",
                            "instrument_name": f"Secteur {index}", "asset_class": "Actions",
                            "category": "Actions", "sector": f"S{index}", "country": "France",
                            "currency": "EUR", "rating": "A", "quantity": 1.0, "price": 1.0,
                            "market_value": 1.0, "cost_basis": 1.0, "pnl_unrealised": 0.0,
                            "coupon": 0.0, "yield": 0.0, "cash_value": 0.0, "esg_score": 0,
                            "esg_e": 0, "esg_s": 0, "esg_g": 0,
                        }
                        for index in range(20)
                    ]
                ),
            ],
            ignore_index=True,
        ),
    )

    slices = metrics.build(ReportScope(client_id="T001"))["allocations"]["sector"]

    assert len(slices) == 13  # 12 tranches + « Autres »
    assert slices[-1]["label"] == "Autres"


# ------------------------------------------------------------------ Positions


def test_top_holdings_are_ranked_with_weights(metrics: MetricsEngine, scope: ReportScope) -> None:
    holdings = metrics.build(scope)["top_holdings"]

    assert holdings[0]["instrument"] == "Air Liquide"
    assert holdings[0]["market_value"] == 800_000.0
    assert holdings[0]["weight"] == 25.0
    assert holdings[0]["pnl_pct"] == round(80_000 / 720_000 * 100, 2)
    assert sum(item["weight"] for item in holdings) == 100.0


# -------------------------------------------------------------- P&L / ESG


def test_pnl_block(metrics: MetricsEngine, scope: ReportScope) -> None:
    pnl = metrics.build(scope)["pnl"]

    assert pnl["unrealised_pnl"] == AUM_T001 - COST_T001
    assert pnl["realised_pnl"] == 12_000.0
    assert pnl["income"] == 4_800.0
    assert pnl["fees"] == 6_890.0  # frais de gestion + frais d'achat et de vente
    assert pnl["best"]["instrument"] == "Air Liquide"  # +11,11 % latent
    assert pnl["best"]["pnl_pct"] == 11.11
    assert pnl["worst"]["instrument"] == "Amundi Money Market"  # fonds à valeur constante


def test_esg_ignores_unrated_positions(metrics: MetricsEngine, scope: ReportScope) -> None:
    esg = metrics.build(scope)["esg"]

    # OAT et money market n'ont pas de note : 2 550 000 sur 3 200 000 sont notés.
    assert esg["coverage_pct"] == 79.7
    assert esg["score"] > 0
    assert esg["e"] == esg["s"] == esg["g"]


def test_esg_without_holdings_is_zero(metrics: MetricsEngine) -> None:
    esg = metrics._esg(pd.DataFrame())

    assert esg == {"score": 0.0, "e": 0.0, "s": 0.0, "g": 0.0, "coverage_pct": 0.0}


# ---------------------------------------------------------- Flux / activité


def test_flows_and_activity(metrics: MetricsEngine, scope: ReportScope) -> None:
    facts = metrics.build(scope)

    assert facts["flows"]["dividends"] == 4_800.0
    assert facts["flows"]["fees"] == 6_400.0
    assert facts["flows"]["deposits"] == 0.0
    assert facts["activity"]["trades"] == 2
    assert facts["activity"]["buy_count"] == 1
    assert facts["activity"]["sell_count"] == 1
    assert facts["activity"]["last_trade"] == "2026-09-01"


def test_transactions_are_limited_to_the_period(metrics: MetricsEngine) -> None:
    ytd = metrics.transactions(ReportScope(client_id="T001", period="ytd", as_of="2026-09-30"))
    month = metrics.transactions(ReportScope(client_id="T001", period="month", as_of="2026-09-30"))

    assert len(ytd) == 4
    assert len(month) == 1  # le frais de gestion du 1er septembre


# ------------------------------------------------------------- Concentration


def test_concentration(metrics: MetricsEngine, scope: ReportScope) -> None:
    concentration = metrics.build(scope)["concentration"]

    assert concentration["largest_position"] == "Air Liquide"
    assert concentration["largest_weight_pct"] == 25.0
    assert concentration["top5_pct"] == 81.25
    assert concentration["nb_positions"] == 8


# -------------------------------------------------------------------- Risques


def test_risks_are_server_side_observations(metrics: MetricsEngine, scope: ReportScope) -> None:
    risks = metrics.build(scope)["risks"]
    codes = {risk["code"] for risk in risks}

    assert codes == {"concentration", "cash", "performance", "esg"}
    by_code = {risk["code"]: risk for risk in risks}
    assert by_code["concentration"]["level"] == "high"  # 81,25 % sur les 5 premiers
    assert by_code["cash"]["level"] == "low"
    assert by_code["performance"]["level"] == "low"


def test_risk_details_use_french_decimals(metrics: MetricsEngine, scope: ReportScope) -> None:
    risks = {risk["code"]: risk for risk in metrics.build(scope)["risks"]}

    # Un `81.25 %` au milieu d'un deck français se voit immédiatement.
    assert "81,2 %" in risks["concentration"]["detail"]
    assert "+4,80 %" in risks["performance"]["detail"]


def test_risk_levels_follow_the_thresholds(metrics: MetricsEngine) -> None:
    risks = {
        risk["code"]: risk
        for risk in metrics.build(
            ReportScope(client_id="T002", period="ytd", as_of="2026-09-30")
        )["risks"]
    }

    assert risks["concentration"]["level"] == "high"  # une position = tout l'actif
    assert risks["performance"]["level"] == "low"  # +1,50 point de surperformance
    assert risks["esg"]["level"] == "medium"  # aucune position notée


# ------------------------------------------------------------------- Période


def test_period_block(metrics: MetricsEngine, scope: ReportScope) -> None:
    period = metrics.build(scope)["period"]

    assert period["as_of"] == "2026-09-30"
    assert period["label"] == "Année 2026 (YTD)"
    assert period["period"] == "ytd"
    assert period["base_currency"] == "EUR"


def test_explicit_label_wins(metrics: MetricsEngine, scope: ReportScope) -> None:
    facts = metrics.build(
        ReportScope(client_id="T001", period="quarter", period_label="Revue T3", as_of="2026-09-30")
    )

    assert facts["period"]["label"] == "Revue T3"


def test_as_of_defaults_to_the_latest_holding_date(
    metrics: MetricsEngine, data_dir
) -> None:
    frame = metrics.repository.frame("holdings")
    frame["as_of"] = "2026-08-31"
    metrics.repository.save_frame("holdings", frame)

    facts = metrics.build(ReportScope(client_id="T001", period="ytd"))

    assert facts["period"]["as_of"] == "2026-08-31"


# ------------------------------------------------------------------ Portefeuilles


def test_portfolio_summary(metrics: MetricsEngine, scope: ReportScope) -> None:
    portfolios = metrics.build(scope)["portfolios"]

    assert portfolios[0]["portfolio_id"] == "PF-T001-GLO"
    assert portfolios[0]["name"] == "Global"
    assert portfolios[0]["mandate"] == "Actions"
    assert portfolios[0]["strategy"] == "Growth"
    assert portfolios[0]["aum"] == 3_200_000.0


# ------------------------------------------------------------------ Cas vides


def test_scope_without_client_covers_every_client(metrics: MetricsEngine) -> None:
    """Un reporting sans `client_id` n'est pas un reporting vide : c'est un reporting global."""
    facts = metrics.build(ReportScope(period="ytd", as_of="2026-09-30"))

    assert facts["kpis"]["aum_total"] == AUM_T001 + 1_500_000.0
    assert facts["kpis"]["nb_positions"] == 9
    assert len(facts["portfolios"]) == 2


def test_unknown_client_produces_empty_but_safe_facts(metrics: MetricsEngine) -> None:
    facts = metrics.build(ReportScope(client_id="INCONNU", period="ytd", as_of="2026-09-30"))

    assert facts["kpis"]["aum_total"] == 0.0
    assert facts["kpis"]["nb_positions"] == 0
    assert facts["client"] == {}
    assert facts["top_holdings"] == []
    assert facts["portfolios"] == []
    assert facts["performance"]["labels"] == []
    assert isinstance(facts["risks"], list) and facts["risks"]

# ----------------------------------------------------------------- Obligataire


def test_bond_facts_read_the_whole_bond_book(metrics: MetricsEngine) -> None:
    bonds = with_bonds(metrics, *BOND_ROWS)["bonds"]

    assert bonds["bond_total"] == 800_000.0
    assert bonds["bond_pct"] == 20.0  # 800 000 sur 4 000 000
    assert bonds["nb_bonds"] == 2
    assert bonds["nb_issuers"] == 2
    # TRA pondéré : (2,80×600 000 + 4,20×200 000) / 800 000
    assert bonds["tra_pct"] == 3.15
    # Durée modifiée pondérée : (4,0×600 000 + 6,0×200 000) / 800 000
    assert bonds["duration_years"] == 4.5


def test_life_average_is_weighted_years_to_maturity(metrics: MetricsEngine) -> None:
    """« Vie moyenne » : années restant à l'échéance, pondérées par encours."""
    bonds = with_bonds(metrics, *BOND_ROWS)["bonds"]

    # 4,62 ans à 75 % et 0,42 an à 25 %, arrondi à deux décimales.
    assert bonds["life_years"] == 3.57
    # La sensibilité est la durée modifiée : les deux notions se confondent
    # souvent par abus de langage, elles restent distinctes ici.
    assert bonds["sensitivity"] == bonds["duration_years"] == 4.5


def test_rating_average_is_a_weighted_rank_mapped_back_to_a_grade(
    metrics: MetricsEngine,
) -> None:
    bonds = with_bonds(metrics, *BOND_ROWS)["bonds"]

    # (4×600 000 + 11×200 000) / 800 000 = 5,75 → rang 6, soit « A ».
    assert bonds["rating_average"] == "A"
    assert bonds["rating_average_rank"] == 5.75
    assert bonds["investment_grade_pct"] == 75.0  # BB+ est sous BBB-
    assert bonds["high_yield_pct"] == 25.0
    assert bonds["unrated_pct"] == 0.0


def test_unrated_lines_count_as_a_third_bucket(metrics: MetricsEngine) -> None:
    unrated = {**BOND_ROWS[1], "isin": "OB000000003", "rating": "Non noté"}

    bonds = with_bonds(metrics, BOND_ROWS[0], unrated)["bonds"]

    assert bonds["unrated_pct"] == 25.0
    assert bonds["investment_grade_pct"] == 75.0
    assert bonds["high_yield_pct"] == 0.0
    # Seule la ligne AA- est notée : sa pondération est sans effet, la notation
    # moyenne reste donc AA- et non une moyenne de deux grades.
    assert bonds["rating_average"] == "AA-"


def test_rating_average_of_a_fully_unrated_book_has_no_grade(metrics: MetricsEngine) -> None:
    row = {**BOND_ROWS[0], "isin": "OB000000004", "rating": "Non noté"}

    bonds = with_bonds(metrics, row)["bonds"]

    assert bonds["rating_average"] == "—"
    assert bonds["unrated_pct"] == 100.0
    assert bonds["investment_grade_pct"] == 0.0


def test_maturity_buckets_sum_to_a_hundred_percent(metrics: MetricsEngine) -> None:
    bonds = with_bonds(metrics, *BOND_ROWS)["bonds"]
    buckets = {row["label"]: row["pct"] for row in bonds["maturities"]}

    assert round(sum(buckets.values()), 2) == 100.0
    assert buckets["3 à 5 ans"] == 75.0  # OAT 2031
    assert buckets["Moins de 1 an"] == 25.0  # Banque SAS 2027
    assert buckets["Plus de 10 ans"] == 0.0


def test_matured_lines_leave_the_risk_profile(metrics: MetricsEngine) -> None:
    """Un titre échu ne pèse plus : le retirer évite des maturités négatives."""
    matured = {**BOND_ROWS[1], "isin": "OB000000005", "maturity": "2024-01-31"}

    bonds = with_bonds(metrics, BOND_ROWS[0], matured)["bonds"]

    assert bonds["maturities"][0]["pct"] == 0.0  # « Moins de 1 an » à zéro
    assert bonds["life_years"] == 4.62  # seule la ligne OAT 2031 reste
    assert bonds["nb_bonds"] == 2  # mais la ligne reste au nombre de titres


def test_issuer_ranking_is_descending(metrics: MetricsEngine) -> None:
    bonds = with_bonds(metrics, *BOND_ROWS)["bonds"]
    issuers = bonds["issuers"]

    assert [row["label"] for row in issuers] == ["Souverain FR", "Banque SAS"]
    assert issuers[0]["pct"] == 75.0
    assert issuers[0]["value"] == 600_000.0


def test_bond_positions_carry_the_line_detail(metrics: MetricsEngine) -> None:
    positions = with_bonds(metrics, *BOND_ROWS)["bonds"]["positions"]

    assert len(positions) == 2
    assert positions[0]["issuer"] == "Souverain FR"
    assert positions[0]["typology"] == "Obligations Souveraines"
    assert positions[0]["maturity"] == "2031-05-15"
    assert positions[0]["coupon"] == 3.0
    assert positions[0]["price"] == 100.0
    assert positions[0]["duration"] == 4.0
    assert positions[0]["pnl_unrealised"] == 10_000.0
    # Deux bases de poids : l'actif net et l'obligataire seul.
    assert positions[0]["weight"] == 15.0  # 600 000 / 4 000 000
    assert positions[0]["bond_weight"] == 75.0  # 600 000 / 800 000


def test_bond_totals_close_on_the_asset(metrics: MetricsEngine) -> None:
    totals = with_bonds(metrics, *BOND_ROWS)["bonds"]["totals"]

    assert [row["label"] for row in totals] == [
        "Obligations Souveraines", "Obligations Entreprises",
    ]
    assert round(sum(row["pct"] for row in totals), 2) == 20.0


def test_coupon_lines_separate_collected_from_expected(metrics: MetricsEngine) -> None:
    bonds = with_bonds(metrics, *BOND_ROWS)["bonds"]

    # 3,00 % × 600 000 + 4,50 % × 200 000
    assert bonds["coupons_expected"] == 27_000.0
    lines = bonds["coupons"]
    assert [row["label"] for row in lines] == [
        "Coupons encaissés sur la période",
        "Coupons attendus sur douze mois",
        "Solde à recevoir",
    ]
    assert lines[1]["value"] == 27_000.0
    # Le solde est la différence, pas une répétition du même montant.
    assert lines[2]["value"] == lines[1]["value"] - lines[0]["value"]


def test_non_bond_lines_carry_no_bond_facts(metrics: MetricsEngine) -> None:
    """Le jeu de test n'a aucune ligne obligataire : le bloc reste neutre."""
    bonds = metrics.build(ReportScope(client_id="T001", period="ytd", as_of="2026-09-30"))["bonds"]

    assert bonds["bond_total"] == 0.0
    assert bonds["nb_bonds"] == 0
    assert bonds["positions"] == []
    assert bonds["maturities"] == []
    assert bonds["coupons"] == [] or bonds["coupons"][1]["value"] == 0.0


def test_bond_kpis_are_exposed_flat_for_the_slides(metrics: MetricsEngine) -> None:
    kpis = with_bonds(metrics, *BOND_ROWS)["kpis"]

    assert kpis["bond_total"] == 800_000.0
    assert kpis["life_years"] == 3.57
    assert kpis["rating_average"] == "A"
    assert kpis["nb_issuers"] == 2
    assert kpis["sensitivity"] == 4.5
    assert kpis["coupons_expected"] == 27_000.0


def test_rating_scale_matches_the_three_agencies() -> None:
    scale = {row["sp"]: row for row in RATING_CORRESPONDENCE}

    assert len(RATING_CORRESPONDENCE) == len(RATING_SCALE) == 22
    assert scale["AAA"]["moodys"] == "Aaa"
    assert scale["AA-"]["moodys"] == "Aa3"
    assert scale["BBB-"]["moodys"] == "Baa3"
    assert scale["BB+"]["moodys"] == "Ba1"
    assert scale["D"]["moodys"] == "D"
    assert scale["AAA"]["fitch"] == "AAA"
    # BBB- est le plancher de l'investment grade, BB+ son premier échelon au-delà.
    assert dict(RATING_SCALE)["BBB-"] == INVESTMENT_GRADE_MAX_RANK
    assert scale["BBB-"]["bucket"] == "Investment grade"
    assert scale["BB+"]["bucket"] == "Haut rendement"


def test_missing_bond_labels_never_render_as_nan(metrics: MetricsEngine) -> None:
    """Un champ vide se lit « — », pas « nan » : le tableau est lu par un client."""
    incomplete = {**BOND_ROWS[0], "isin": "OB000000006", "rating": None, "maturity": None}

    positions = with_bonds(metrics, incomplete)["bonds"]["positions"]

    assert positions[0]["rating"] == "—"
    assert positions[0]["maturity"] == "—"


# ------------------------------------------------------- Mesures de risque


def test_single_portfolio_keeps_the_risk_columns_of_the_dataset(
    metrics: MetricsEngine, scope: ReportScope
) -> None:
    """Un portefeuille unique : les colonnes de la source font foi, telles quelles."""
    performance = metrics.build(scope)["performance"]

    # Les colonnes du jeu de test (voir conftest) : aucune recalcul nécessaire.
    assert performance["volatility"] == 6.4
    assert performance["sharpe"] == 0.72
    assert performance["max_drawdown"] == -4.2


def test_risk_measures_are_recomputed_across_several_portfolios(
    metrics: MetricsEngine, scope: ReportScope
) -> None:
    """Plusieurs portefeuilles : le risque se lit sur la courbe consolidée.

    Les colonnes de la source décrivent un portefeuille chacune ; les cumuler
    donnerait le risque d'un portefeuille arbitrairement choisi, pas celui du
    client.
    """
    # Le second portefeuille doit exister dans `portfolios` : c'est ce tableau
    # qui rattache une courbe de performance à un client.
    portfolios = metrics.repository.frame("portfolios")
    metrics.repository.save_frame(
        "portfolios",
        pd.concat(
            [
                portfolios,
                pd.DataFrame([{
                    "portfolio_id": "PF-T001-FON", "client_id": "T001",
                    "portfolio_name": "Fonds", "mandate_type": "Monetaire",
                    "strategy": "Prudent", "base_ccy": "EUR", "aum": 800_000.0,
                    "inception_date": "2021-01-01",
                }]),
            ],
            ignore_index=True,
        ),
    )
    frame = metrics.repository.frame("performance")
    second = pd.DataFrame(_performance_rows("PF-T001-FON", drift=0.9))
    # Le second portefeuille publie un risque sans rapport avec sa courbe.
    second["volatility"] = 0.2
    second["sharpe"] = 0.01
    second["max_drawdown"] = -0.04
    metrics.repository.save_frame(
        "performance", pd.concat([frame, second], ignore_index=True)
    )

    performance = metrics.build(scope)["performance"]
    curve = performance["portfolio"]
    volatility = _curve_volatility(curve)

    assert performance["volatility"] == volatility
    assert performance["sharpe"] == _curve_sharpe(curve[-1], volatility)
    assert performance["max_drawdown"] == _curve_max_drawdown(curve)
    # Les colonnes du second portefeuille ne fuient plus : elles ne décrivent
    # qu'une branche du périmètre.
    assert performance["volatility"] != 0.2
    assert performance["max_drawdown"] != -0.04


def test_curve_risk_measures_are_computed_on_growth_factors() -> None:
    """Un cumul négatif ne peut pas produire une baisse supérieure à -100 %."""
    assert _curve_max_drawdown([0.0, -50.0, -40.0, -60.0]) == -60.0
    # De +10 % à +5 %, la baisse vaut 4,55 % du niveau atteint et non 50 % :
    # le drawdown se mesure depuis le sommet, pas depuis le point de départ.
    assert _curve_max_drawdown([0.0, 10.0, 5.0, 12.0]) == -4.55
    assert _curve_max_drawdown([0.0, 1.0, 2.0]) == 0.0
    assert _curve_max_drawdown([]) == 0.0
    # Moins de quatre points : aucune volatilité annualisable à estimer.
    assert _curve_volatility([0.0, 1.0, 2.0]) == 0.0


def test_curve_volatility_is_annualised_from_monthly_moves() -> None:
    """Alternance +1 / -1 : un écart-type mensuel de 1 % donne 3,54 % par an."""
    curve = [float(index % 2) for index in range(25)]

    assert _curve_volatility(curve) == 3.54
    assert _curve_sharpe(10.0, 0.0) == 0.0  # volatilité nulle : ratio indéfini, pas infini


def test_consolidated_volatility_stays_between_its_constituents(
    metrics: MetricsEngine, scope: ReportScope
) -> None:
    """Le risque publié suit la courbe, et la pondération l'atténue.

    Le jeu de test dessine des courbes parfaitement droites — un portefeuille
    sans bruit a une volatilité nulle. Une seconde branche oscille donc de
    ±4 % par mois : son risque propre est élevé, mais une branche plate la
    tempère, et le risque consolidé doit s'établir entre les deux.
    """
    portfolios = metrics.repository.frame("portfolios")
    metrics.repository.save_frame(
        "portfolios",
        pd.concat(
            [
                portfolios,
                pd.DataFrame([{
                    "portfolio_id": "PF-T001-FON", "client_id": "T001",
                    "portfolio_name": "Fonds", "mandate_type": "Monetaire",
                    "strategy": "Prudent", "base_ccy": "EUR", "aum": 800_000.0,
                    "inception_date": "2021-01-01",
                }]),
            ],
            ignore_index=True,
        ),
    )
    oscillating = [4.0 if index % 2 else 0.0 for index in range(12)]
    second = pd.DataFrame(_performance_rows("PF-T001-FON"))
    second["portfolio_cum"] = oscillating
    # La source publie un risque sans rapport avec cette courbe.
    second["volatility"] = 0.2
    metrics.repository.save_frame(
        "performance",
        pd.concat([metrics.repository.frame("performance"), second], ignore_index=True),
    )

    performance = metrics.build(scope)["performance"]
    branch = _curve_volatility(oscillating)

    # La branche plate (risque nul) tempère la branche mobile : le risque
    # consolidé est réel mais inférieur à celui de la branche la plus risquée.
    assert 0.0 < performance["volatility"] < branch
    # Il suit la courbe consolidée, pas la colonne de la source.
    assert performance["volatility"] == _curve_volatility(performance["portfolio"])
    assert performance["volatility"] != 0.2
