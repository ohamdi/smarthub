"""Contexte envoyé au modèle : texte déterministe, en français, sans accents.

Le contexte est ce que le modèle voit, et il est affichable tel quel dans
l'interface : s'il est ambigu, c'est la narration qui sera ambiguë. Ces tests
figent donc son contenu, pas seulement sa forme.
"""

from __future__ import annotations

from conftest import BOND_ROWS, with_bonds

from smartwealthreporting import context as context_module
from smartwealthreporting.context import (
    SECTION_TITLES,
    THIN_SPACE,
    flow_count,
    format_number,
    format_signed,
    render,
)
from smartwealthreporting.metrics import MetricsEngine, ReportScope

SPACE = f"1{THIN_SPACE}234{THIN_SPACE}567"
MILLIONS = f"3{THIN_SPACE}200{THIN_SPACE}000"


# --------------------------------------------------------------- Formatage


def test_format_number_is_french() -> None:
    assert format_number(3_200_000) == MILLIONS
    assert format_number(3_200_000.456, decimals=2) == f"{MILLIONS},46"
    assert format_number(-1_250.5, decimals=1) == f"-1{THIN_SPACE}250,5"
    assert format_number(0) == "0"
    assert format_number(None) == "—"
    assert format_number("abc") == "—"


def test_format_number_suffix() -> None:
    assert format_number(72.4, decimals=1, suffix=" %") == "72,4 %"


def test_thousands_separator_is_never_broken() -> None:
    """Fine espace insécable : un montant ne doit jamais se couper sur deux lignes."""
    assert THIN_SPACE == " "
    assert " " not in format_number(1_234_567)


def test_format_signed_marks_positive_values() -> None:
    assert format_signed(4.8) == "+4,80"
    assert format_signed(-1.5) == "-1,50"
    assert format_signed(0) == "0,00"


def test_flow_count_tolerates_garbage() -> None:
    assert flow_count({"subscriptions": 3}, "subscriptions") == 3
    assert flow_count({}, "subscriptions") == 0
    assert flow_count({"subscriptions": None}, "subscriptions") == 0


# ------------------------------------------------------------------ Rendu


def test_render_contains_every_section(metrics: MetricsEngine, scope: ReportScope) -> None:
    """Toutes les sections sauf l'obligataire, qui n'a pas de donnée à ce client."""
    result = render(with_bonds(metrics, *BOND_ROWS))
    present = {key for key, title in SECTION_TITLES if title in result["text"]}

    assert present == {key for key, _title in SECTION_TITLES}
    assert result["chars"] == len(result["text"])
    assert result["truncated"] is False


def test_render_omits_the_bond_section_without_bonds(
    metrics: MetricsEngine, scope: ReportScope
) -> None:
    """Un client sans ligne obligataire n'a pas de section obligataire à annoncer."""
    assert "PORTEFEUILLE OBLIGATAIRE" not in render(metrics.build(scope))["text"]


def test_render_reads_the_bond_profile_as_french(metrics: MetricsEngine) -> None:
    text = render(with_bonds(metrics, *BOND_ROWS), sections=("bonds",))["text"]

    assert "PORTEFEUILLE OBLIGATAIRE" in text
    assert f"800{THIN_SPACE}000 EUR" in text
    assert "20,00 % de l'actif net" in text
    assert "2 titres emis par 2 emetteurs" in text
    # Notation moyenne, qualité et profil de maturité, en poids d'encours.
    assert "Notation moyenne A" in text
    assert "investment grade 75,00 %" in text
    assert "haut rendement 25,00 %" in text
    assert "tranche de maturite" in text


def test_render_reads_as_french(metrics: MetricsEngine, scope: ReportScope) -> None:
    """Libellés du contexte sans accents, valeurs avec la typographie française."""
    text = render(metrics.build(scope))["text"]

    assert "PERIODE ET CLIENT" in text
    assert "Test Client" in text
    assert "arretes" not in text  # le libellé est écrit sans accent
    assert "Arretes" not in text


def test_render_uses_french_numbers(metrics: MetricsEngine, scope: ReportScope) -> None:
    text = render(metrics.build(scope))["text"]

    assert f"{MILLIONS} EUR" in text
    assert "+4,80 %" in text
    assert "1,50" in text  # l'écart au benchmark


def test_render_keeps_only_requested_sections(metrics: MetricsEngine, scope: ReportScope) -> None:
    result = render(metrics.build(scope), sections=("kpis", "performance"))

    assert "INDICATEURS CLES" in result["text"]
    assert "PERFORMANCE" in result["text"]
    assert "PRINCIPALES POSITIONS" not in result["text"]
    assert result["sections"] == ["kpis", "performance"]


def test_render_truncates_between_lines(metrics: MetricsEngine, scope: ReportScope) -> None:
    result = render(metrics.build(scope), max_chars=400)

    assert result["truncated"] is True
    assert result["chars"] <= 400
    assert "[contexte tronque]" in result["text"]
    # Un nombre coupé au milieu ferait échouer la vérification pour une bonne
    # raison : la dernière ligne doit rester complète.
    assert not result["text"].splitlines()[-2].endswith((",", "."))


def test_render_of_empty_facts_is_still_valid() -> None:
    result = render({})

    assert "PERIODE ET CLIENT" in result["text"]
    assert result["truncated"] is False


def test_kpi_lines_use_their_label(metrics: MetricsEngine, scope: ReportScope) -> None:
    text = render(metrics.build(scope), sections=("kpis",))["text"]

    assert f"- Actif total : {MILLIONS} EUR" in text
    assert "- Ratio de Sharpe : 0,72" in text
    assert "- Nombre de positions : 8" in text


def test_performance_samples_do_not_exceed_twelve(metrics: MetricsEngine, scope: ReportScope) -> None:
    text = render(metrics.build(scope), sections=("performance",))["text"]

    assert text.count("(benchmark") <= 13


def test_risk_levels_are_translated(metrics: MetricsEngine, scope: ReportScope) -> None:
    text = render(metrics.build(scope), sections=("risks",))["text"]

    assert "eleve : Concentration" in text
    assert "faible : Trésorerie" in text


def test_section_titles_cover_the_fact_blocks() -> None:
    assert {key for key, _title in SECTION_TITLES} == {
        "kpis", "allocations", "performance", "pnl", "top_holdings", "esg",
        "flows", "concentration", "risks", "portfolios", "bonds",
    }


def test_render_is_stable(metrics: MetricsEngine, scope: ReportScope) -> None:
    facts = metrics.build(scope)

    assert render(facts)["text"] == render(facts)["text"]


def test_unknown_section_renders_nothing() -> None:
    result = context_module.render({"kpis": {"aum_total": 10.0}}, sections=("inconnu",))

    assert result["text"] == ""
    assert result["chars"] == 0