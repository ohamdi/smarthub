"""Garde-fou numérique : ce que la narration cite, ce que les faits contiennent.

Le contrôle ne dit pas si une narration est juste : il dit si les montants
qu'elle cite existent dans le contexte réellement envoyé au modèle. C'est ce qui
rend visible, avant diffusion au client, un « 1,8 % de rendement » inventé.
"""

from __future__ import annotations

import pytest

from smartwealthreporting.verify import (
    SIGNIFICANT_THRESHOLD,
    build_registry,
    check,
    extract_numbers,
    warning,
)

CONTEXT = (
    "PERIODE ET CLIENT : Année 2026 (YTD).\n"
    "INDICATEURS CLES\n"
    "- Actif total : 3 200 000 EUR\n"
    "- Performance cumulee du portefeuille : +4,80 %\n"
    "- Ratio de Sharpe : 0,72\n"
    "- Nombre de positions : 8\n"
    "- Drawdown maximal : -4,20 %\n"
    "PERFORMANCE\n"
    "- Performance cumulee : portefeuille +4,80 %, benchmark +3,30 %, ecart +1,50 points.\n"
    "RESULTAT\n"
    "- Mois d'aout : -192 000 EUR (rattrapage du rallye de juillet).\n"
    "PRINCIPALES POSITIONS\n"
    "- 1. Air Liquide : 800 000 EUR, 25,00 % de l'actif, P&L +11,11 %.\n"
    "- 2. LVMH : 600 000 EUR, 18,75 % de l'actif, P&L +11,11 %.\n"
    "CONCENTRATION\n"
    "- Les 5 premieres positions representent 81,2 % de l'actif.\n"
)


@pytest.fixture
def registry():
    return build_registry(CONTEXT)


# ------------------------------------------------------------------ Registre


def test_registry_knows_context_numbers(registry) -> None:
    assert check("L'actif atteint 3 200 000 EUR.", registry)["ok"] is True
    assert check("Air Liquide pèse 800 000 EUR.", registry)["ok"] is True
    assert check("La performance ressort à +4,80 %.", registry)["ok"] is True
    assert check("Le drawdown atteint -4,20 points.", registry)["ok"] is True
    assert check("Aout a été à -192 000 EUR.", registry)["ok"] is True


def test_registry_ignores_separator_style(registry) -> None:
    """`3 200 000` et `3,200,000` sont le même montant."""
    assert check("L'actif atteint 3,200,000 EUR.", registry)["ok"] is True
    assert check("L'actif atteint 3200000 EUR.", registry)["ok"] is True


def test_registry_accepts_rounded_amounts(registry) -> None:
    """Un montant écrit en abrégé reste recevable si l'arrondi est proche."""
    assert check("Le portefeuille pèse 12 M EUR.", build_registry("Valeur : 12 456 789 EUR."))["ok"]
    assert check("Le portefeuille pèse 4 M EUR.", build_registry("Valeur : 3 995 000 EUR."))["ok"]
    assert check("Le portefeuille pèse 6 M EUR.", build_registry("Valeur : 3 995 000 EUR."))["ok"] is False


def test_registry_tolerates_rounding_at_three_significant_digits(registry) -> None:
    """`18,80 %` contre un poids réel de 18,75 % est un arrondi, pas une invention."""
    assert check("LVMH pèse 18,80 % de l'actif.", registry)["ok"] is True


def test_registry_catches_invented_amounts(registry) -> None:
    report = check("Le portefeuille a progressé de 1 800 000 EUR.", registry)

    assert report["ok"] is False
    assert report["unverified_numbers"] == [{"value": "1 800 000", "canonical": "1800000"}]


def test_small_integers_are_not_checked(registry) -> None:
    """« 3 positions » ou « 8 lignes » ne sont pas des indices d'hallucination."""
    report = check("Le portefeuille compte 3 mandates et 42 lignes.", registry)

    assert report["ok"] is True
    assert report["numbers_checked"] == 0


def test_threshold_is_a_few_thousand(registry) -> None:
    assert check("L'actif vaut 999 EUR.", registry)["ok"] is True
    assert check("L'actif vaut 1 000 500 EUR.", registry)["ok"] is False
    assert SIGNIFICANT_THRESHOLD == 1000


def test_percentages_are_checked_too(registry) -> None:
    assert check("Le portefeuille a perdu 1,80 % ce mois-ci.", registry)["ok"] is True
    assert check("Le portefeuille a gagné 42,30 % ce mois-ci.", registry)["ok"] is False


def test_numbers_are_reported_once(registry) -> None:
    report = check("3 200 000 EUR, soit 3 200 000 EUR, et 1 800 000 EUR.", registry)

    assert report["numbers_checked"] == 2  # 1 800 000 cité deux fois, compté une fois
    assert len(report["unverified_numbers"]) == 1


def test_unverified_list_is_capped(registry) -> None:
    invented = " ".join(f"{index * 1_000_000 + 7} EUR" for index in range(1, 30))
    report = check(invented, registry)

    assert len(report["unverified_numbers"]) == 8
    assert report["ok"] is False


def test_allowed_values_bypass_the_check(registry) -> None:
    report = check("Horodatage 20260930.", registry, allowed=["20260930"])

    assert report["ok"] is True


# ------------------------------------------------------------------- Avertissement


def test_warning_is_empty_on_success(registry) -> None:
    assert warning(check("3 200 000 EUR.", registry)) == ""


def test_warning_names_the_values(registry) -> None:
    message = warning(check("Le gain atteint 1 800 000 EUR.", registry))

    assert "1 800 000" in message
    assert "relire" in message


# -------------------------------------------------------------------- Extraction


def test_extract_numbers_reads_the_raw_tokens() -> None:
    assert extract_numbers("+4,80 % sur 3 200 000 EUR") == ["+4,80 %", "3 200 000"]


def test_extract_numbers_on_empty_text() -> None:
    assert extract_numbers("") == []
    assert extract_numbers(None) == []


# ------------------------------------------------------------------- Robustesse


def test_check_survives_nonsense_input(registry) -> None:
    assert check("", registry)["ok"] is True
    assert check("Aucun chiffre dans cette phrase.", registry)["numbers_checked"] == 0


def test_negative_amounts_are_matched(registry) -> None:
    assert check("Le P&L latent est de -192 000 EUR.", registry)["ok"] is True
    assert check("Le P&L latent est de -1 992 000 EUR.", registry)["ok"] is False


def test_empty_context_flags_every_amount() -> None:
    report = check("Le portefeuille vaut 3 200 000 EUR.", build_registry(""))

    assert report["ok"] is False