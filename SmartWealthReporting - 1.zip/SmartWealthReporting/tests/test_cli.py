"""CLI : diagnostic, initialisation des templates et génération hors interface.

Les sous-commandes sont lancées sur une base temporaire (`--base-dir`) bâtie avec
les fixtures de test : mêmes données, mêmes reportings que l'API, aucun effet de
bord sur `data/` et `reportings/` du projet.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

import pytest

from smartwealthreporting import cli
from smartwealthreporting.reportings import ReportingLibrary


@pytest.fixture
def base(
    tmp_path: Path, data_dir: Path, library: ReportingLibrary
) -> Path:
    """Racine de projet jetable : `data/`, `reportings/` et les deux configurations."""
    (tmp_path / "datasource_config.json").write_text(
        json.dumps({"gguf_path": "", "llm_backend": "gguf"}), encoding="utf-8"
    )
    (tmp_path / "ai_config.json").write_text(
        json.dumps({"max_slides_per_call": 3}), encoding="utf-8"
    )
    return tmp_path


@pytest.fixture
def run(base: Path, monkeypatch: pytest.MonkeyPatch) -> Callable[..., int]:
    """Lance la CLI sur la base temporaire et renvoie son code de sortie."""

    def invoke(*argv: str) -> int:
        monkeypatch.setenv("SWR_BASE_DIR", str(base))
        monkeypatch.setenv("SWR_SECRET_KEY", "test-secret")
        monkeypatch.delenv("SWR_CONFIG_PATH", raising=False)
        return cli.main(["--base-dir", str(base), *argv])

    return invoke


# ------------------------------------------------------------------ Paramètres


def test_defaults_listen_on_port_5050() -> None:
    args = cli.build_parser().parse_args([])

    assert (args.host, args.port) == ("0.0.0.0", 5050)
    assert args.generate == ""


def test_environment_overrides_the_port(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SWR_PORT", "5123")

    assert cli.build_parser().parse_args([]).port == 5123


# ------------------------------------------------------------------ Diagnostic


def test_list_reportings(run: Callable[..., int], capsys: pytest.CaptureFixture[str]) -> None:
    code = run("--list-reportings")

    output = capsys.readouterr().out
    assert code == 0
    assert "test_review" in output
    assert "Revue de test" in output
    assert "template NON" in output


def test_list_reportings_as_json(run: Callable[..., int], capsys: pytest.CaptureFixture[str]) -> None:
    run("--list-reportings", "--json")

    rows = json.loads(capsys.readouterr().out)
    assert {row["id"] for row in rows} == {"stacked_review", "test_review"}
    assert next(row for row in rows if row["id"] == "test_review")["slides"] == 6


def test_list_reportings_without_any(
    tmp_path: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SWR_BASE_DIR", str(tmp_path))

    code = cli.main(["--base-dir", str(tmp_path), "--list-reportings"])

    assert code == 0
    assert "Aucun reporting" in capsys.readouterr().out


def test_check_lists_the_tables_and_the_model(
    run: Callable[..., int], capsys: pytest.CaptureFixture[str]
) -> None:
    code = run("--check")

    output = capsys.readouterr().out
    assert code == 1  # aucun modèle GGUF configuré : un point d'attention
    assert "clients" in output
    assert "MANQUANT" not in output
    assert "modèle" in output
    assert "point(s) d'attention" in output


def test_check_as_json(run: Callable[..., int], capsys: pytest.CaptureFixture[str]) -> None:
    run("--check", "--json")

    payload = json.loads(capsys.readouterr().out)
    assert payload["problems"] >= 1
    assert {row["name"] for row in payload["datasets"]} >= {"clients", "holdings"}
    assert payload["engine"]["backend"] == "gguf"


# ----------------------------------------------------------------- Templates


def test_init_templates_writes_a_missing_template(
    run: Callable[..., int], capsys: pytest.CaptureFixture[str], base: Path
) -> None:
    code = run("--init-templates")

    assert code == 0
    assert "template écrit" in capsys.readouterr().out
    assert (base / "reportings" / "test_review" / "template.pptx").is_file()


def test_init_templates_keeps_an_existing_one(
    run: Callable[..., int], capsys: pytest.CaptureFixture[str], base: Path
) -> None:
    run("--init-templates")
    capsys.readouterr()
    target = base / "reportings" / "test_review" / "template.pptx"
    stamp = target.stat().st_mtime_ns

    code = run("--init-templates")

    assert code == 0
    assert "conservé" in capsys.readouterr().out
    assert target.stat().st_mtime_ns == stamp


def test_init_templates_without_any_reporting(
    tmp_path: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SWR_BASE_DIR", str(tmp_path))

    code = cli.main(["--base-dir", str(tmp_path), "--init-templates"])

    assert code == 0
    assert "rien à initialiser" in capsys.readouterr().out


# ---------------------------------------------------------------- Génération


def test_generate_without_ai(
    run: Callable[..., int], capsys: pytest.CaptureFixture[str], base: Path
) -> None:
    code = run("--generate", "test_review", "--client", "T001", "--no-ai")

    output = capsys.readouterr().out
    assert code == 0
    assert "Reporting   : test_review" in output
    assert "(des" in output  # slides sans narration
    assert list((base / "outputs" / "test_review").glob("*.pptx"))


def test_generate_as_json(
    run: Callable[..., int], capsys: pytest.CaptureFixture[str], base: Path
) -> None:
    code = run(
        "--generate", "test_review", "--client", "T001", "--no-ai",
        "--output-name", "revue", "--json",
    )

    payload = json.loads(capsys.readouterr().out)
    assert code == 0
    assert payload["filename"] == "revue.pptx"
    assert payload["ok"] is True
    assert (base / "outputs" / "test_review" / "revue.pptx").is_file()


def test_generate_with_a_period(
    run: Callable[..., int], capsys: pytest.CaptureFixture[str]
) -> None:
    run("--generate", "test_review", "--client", "T001", "--no-ai", "--period", "month", "--json")

    payload = json.loads(capsys.readouterr().out)
    assert "2026" in payload["period_label"]
    assert payload["period_label"] != "Année 2026 (YTD)"


def test_generate_of_an_unknown_reporting(run: Callable[..., int], capsys: pytest.CaptureFixture[str]) -> None:
    code = run("--generate", "inexistant", "--no-ai")

    assert code == 2
    assert "Erreur" in capsys.readouterr().err


def test_generate_of_a_client_without_position(
    run: Callable[..., int], capsys: pytest.CaptureFixture[str]
) -> None:
    code = run("--generate", "test_review", "--client", "T999", "--no-ai")

    output = capsys.readouterr().out
    assert code == 0  # le deck est produit, vide, avec un avertissement
    assert "Aucune position" in output


def test_generate_uses_the_installed_template(
    run: Callable[..., int], capsys: pytest.CaptureFixture[str], base: Path
) -> None:
    run("--init-templates")
    capsys.readouterr()

    run("--generate", "test_review", "--client", "T001", "--no-ai", "--json")

    payload = json.loads(capsys.readouterr().out)
    assert not [text for text in payload["warnings"] if "Template PPTX absent" in text]
    assert (base / "outputs" / "test_review" / payload["filename"]).is_file()