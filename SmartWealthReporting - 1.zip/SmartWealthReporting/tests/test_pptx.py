"""Rendu PPTX : les faits entrent, la charte du template sort intacte.

Le deck produit est relu avec python-pptx : on vérifie le nombre de slides, la
présence du titre, des indicateurs, du graphique et du tableau, et l'absence des
slides modèles `SWR_LAYOUT` dans le livrable client.
"""

from __future__ import annotations

from typing import get_args

import io
from pathlib import Path
from typing import Any

import pytest
from conftest import BOND_ROWS, with_bonds
from pptx import Presentation

from smartwealthreporting import templates as T
from smartwealthreporting.errors import TemplateError
from smartwealthreporting.metrics import MetricsEngine, ReportScope
from smartwealthreporting.pptx_builder import (
    CHART_TYPES,
    DeckBuilder,
    _chart_data,
    _is_total_row,
    _table_rows,
    build_variables,
    cover_meta,
    definition_footer,
    footer_band,
    format_date_fr,
    format_value,
    resolve_metric,
    substitute,
)
from smartwealthreporting.reportings import ReportingLibrary
from smartwealthreporting.schemas import (
    ChartKind,
    ChartSpec,
    ColumnSpec,
    KpiSpec,
    ReportingDefinition,
    SlideDefinition,
    TableSpec,
)


# -------------------------------------------------------------------- Outils


NARROW = "\u202f"  # espace fine insécable utilisée par le moteur de formatage


def plain(text: str) -> str:
    """Neutralise les espaces typographiques pour comparer à des chaînes simples."""
    return str(text).replace(NARROW, " ").replace("\u00a0", " ").replace(" ", " ")


def open_deck(payload: bytes) -> Presentation:
    return Presentation(io.BytesIO(payload))


def slide_texts(presentation: Presentation) -> list[str]:
    texts: list[str] = []
    for slide in presentation.slides:
        chunks: list[str] = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                chunks.append(shape.text_frame.text)
            elif getattr(shape, "has_table", False):
                chunks.extend(
                    cell.text for row in shape.table.rows for cell in row.cells
                )
        texts.append("\n".join(chunks))
    return texts


def shape_names(container: Presentation | Any) -> list[str]:
    """Noms des formes d'une présentation entière ou d'une seule slide."""
    slides = getattr(container, "slides", None)
    if slides is None:
        slides = [container]
    return [shape.name for slide in slides for shape in slide.shapes]


@pytest.fixture
def facts(metrics: MetricsEngine, scope: ReportScope) -> dict[str, Any]:
    return metrics.build(scope)


@pytest.fixture
def definition(library: ReportingLibrary) -> ReportingDefinition:
    return library.load("test_review")


@pytest.fixture
def template_path(library: ReportingLibrary, tmp_path: Path) -> Path:
    path = tmp_path / "template.pptx"
    T.build_default_template().save(str(path))
    return path


# ------------------------------------------------------------------ Formatage


def test_format_value_currency() -> None:
    assert plain(format_value(3_200_000, "currency")) == "3 200 000 EUR"
    assert plain(format_value(-1_250.5, "currency", decimals=1)) == "-1 250,5 EUR"


def test_format_value_percent() -> None:
    assert format_value(4.8, "percent") == "+4,80 %"
    assert format_value(-1.5, "percent", decimals=1) == "-1,5 %"
    assert format_value(4.8, "percent", suffix=" pts") == "+4,80 pts"


def test_format_value_number_and_text() -> None:
    assert plain(format_value(1_234.56, "number", decimals=0)) == "1 235"
    assert plain(format_value(1_234.56, "number", decimals=2)) == "1 234,56"
    assert format_value(8, "number") == "8"  # entier : pas de décimale inutile
    assert plain(format_value(1_234.56, "number", suffix=" lignes")) == "1 234,56 lignes"
    assert format_value("Air Liquide", "text") == "Air Liquide"
    assert format_value(None, "number") == "—"
    assert format_value("", "text") == "—"


def test_format_date_fr() -> None:
    assert format_date_fr("2026-09-30") == "30 septembre 2026"
    assert format_date_fr("2026-01-05") == "5 janvier 2026"
    assert format_date_fr("") == ""
    assert format_date_fr("pas une date") == "pas une date"


def test_substitute_leaves_unknown_placeholders() -> None:
    text = "{{client_name}} — {{inconnu}} au {{as_of}}"

    assert substitute(text, {"client_name": "Test Client", "as_of": "2026-09-30"}) == (
        "Test Client — {{inconnu}} au 2026-09-30"
    )


def test_substitute_on_empty_text() -> None:
    assert substitute("", {}) == ""


def test_build_variables(definition: ReportingDefinition, facts: dict[str, Any]) -> None:
    variables = build_variables(definition, facts)

    assert variables["client_name"] == "Test Client"
    assert variables["client_id"] == "T001"
    assert variables["segment"] == "Privé"
    assert variables["period_label"] == "Année 2026 (YTD)"
    assert variables["as_of"] == "2026-09-30"
    assert variables["as_of_fr"] == "30 septembre 2026"
    assert variables["currency"] == "EUR"
    assert variables["report_name"] == "Revue de test"
    assert variables["performance"].startswith("+")
    assert variables["aum"].replace(NARROW, "") == "3200000"


def test_variables_of_an_empty_report(facts: dict[str, Any]) -> None:
    variables = build_variables(ReportingDefinition(id="vide", slides=[]), {"kpis": {}})

    assert variables["client_name"] == "Client"
    assert variables["aum"] == "—"


def test_cover_meta_lists_the_client(definition: ReportingDefinition, facts: dict[str, Any]) -> None:
    meta = cover_meta(build_variables(definition, facts))

    # La couverture d'un rapport de gestion s'identifie par le portefeuille et
    # son mandat : la société remplace le client, le segment n'y figure plus.
    assert "Société : Test Client" in meta
    assert "Portefeuille n° PF-T001-GLO" in meta
    assert "Orientation de gestion : Actions" in meta
    assert "Arrêté au 30 septembre 2026" in meta
    assert "Segment" not in meta


def test_footer_band_follows_the_brand_charter(
    definition: ReportingDefinition, facts: dict[str, Any]
) -> None:
    palette = T.Palette(
        {
            "legal_entity": "CA Indosuez Gestion",
            "report_label": "Rapport de gestion",
            "confidentiality": "Personnel et confidentiel",
        }
    )
    variables = build_variables(definition, facts)

    assert footer_band(palette, variables, facts) == (
        "CA Indosuez Gestion | Rapport de gestion | Personnel et confidentiel | 2026"
    )


def test_footer_band_falls_back_to_the_client_mention(
    definition: ReportingDefinition, facts: dict[str, Any]
) -> None:
    # Sans identité de marque déclarée, le bandeau reste informatif plutôt que vide.
    palette = T.Palette({})
    variables = build_variables(definition, facts)

    assert footer_band(palette, variables, facts) == definition_footer(facts)


def test_definition_footer(facts: dict[str, Any]) -> None:
    assert definition_footer(facts) == "Test Client — Conseiller : Conseiller Test"
    assert definition_footer({}) == "Client"


# ----------------------------------------------------------- Clés d'indicateur


def test_resolve_metric_flat_key(facts: dict[str, Any]) -> None:
    assert resolve_metric(facts, "aum_total") == 3_200_000.0
    assert resolve_metric(facts, "score") == facts["esg"]["score"]


def test_resolve_metric_dotted_path(facts: dict[str, Any]) -> None:
    assert resolve_metric(facts, "esg.score") == facts["esg"]["score"]
    assert resolve_metric(facts, "concentration.top5_pct") == 81.25
    assert resolve_metric(facts, "period.as_of") == "2026-09-30"


def test_resolve_metric_dotted_path_wins(facts: dict[str, Any]) -> None:
    assert resolve_metric(facts, "esg.coverage_pct") == facts["esg"]["coverage_pct"]


def test_resolve_metric_unknown(facts: dict[str, Any]) -> None:
    assert resolve_metric(facts, "") is None
    assert resolve_metric(facts, "inexistant") is None
    assert resolve_metric(facts, "esg.inexistant") is None
    assert resolve_metric(facts, "bloc_inconnu.clef") is None


# ------------------------------------------------------------------ Données


def test_chart_data_from_allocation(facts: dict[str, Any]) -> None:
    from smartwealthreporting.pptx_builder import _chart_data

    data = _chart_data(ChartSpec(kind="doughnut", source="allocation"), facts)

    assert data["categories"] == ["Actions", "Obligations", "Fonds", "Immobilier", "Monetaire"]
    assert data["series"] == [("% de l'actif", [56.25, 25.0, 7.81, 6.25, 4.69])]


def test_chart_data_from_performance(facts: dict[str, Any]) -> None:
    from smartwealthreporting.pptx_builder import _chart_data

    data = _chart_data(
        ChartSpec(kind="line", source="performance", series=["portfolio", "benchmark"]), facts
    )

    assert len(data["categories"]) == 12
    assert [name for name, _values in data["series"]] == ["Portfolio", "Benchmark"]


def test_chart_data_from_top_holdings_and_pnl(facts: dict[str, Any]) -> None:
    from smartwealthreporting.pptx_builder import _chart_data

    weights = _chart_data(ChartSpec(source="top_holdings"), facts)
    pnl = _chart_data(ChartSpec(source="pnl"), facts)

    assert weights["categories"][0] == "Air Liquide"
    assert pnl["series"][0][0] == "P&L (%)"


def test_chart_data_returns_none_without_facts() -> None:
    from smartwealthreporting.pptx_builder import _chart_data

    assert _chart_data(ChartSpec(source="performance"), {}) is None
    assert _chart_data(ChartSpec(source="top_holdings"), {}) is None


def test_table_rows_from_every_source(facts: dict[str, Any]) -> None:
    from smartwealthreporting.pptx_builder import _table_rows

    assert _table_rows(TableSpec(source="top_holdings", limit=3), facts)[0]["instrument"] == "Air Liquide"
    assert _table_rows(TableSpec(source="portfolios"), facts)[0]["portfolio_id"] == "PF-T001-GLO"
    assert _table_rows(TableSpec(source="risks"), facts)[0]["level"] == "Élevé"
    assert _table_rows(TableSpec(source="allocations"), facts)[0]["label"] == "Actions"
    assert {"label": "Dividendes", "value": 4_800.0} in _table_rows(TableSpec(source="flows"), facts)
    assert _table_rows(TableSpec(source="esg"), facts)
    assert _table_rows(TableSpec(source="activity"), facts)


def test_table_rows_respect_the_limit(facts: dict[str, Any]) -> None:
    from smartwealthreporting.pptx_builder import _table_rows

    assert len(_table_rows(TableSpec(source="top_holdings", limit=2), facts)) == 2


# -------------------------------------------------------------------- Rendu


def test_render_without_template(
    definition: ReportingDefinition, facts: dict[str, Any]
) -> None:
    payload = DeckBuilder().render(
        definition, facts, {"perf": "Le portefeuille progresse."}, as_of="2026-09-30"
    )

    assert payload[:2] == b"PK"
    presentation = open_deck(payload)
    assert len(presentation.slides) == len(definition.slides)
    texts = slide_texts(presentation)
    assert "Test Client" in texts[0]  # couverture
    assert "Année 2026 (YTD)" in texts[0]
    assert "Le portefeuille progresse." in "\n".join(texts)


def test_render_with_template(
    definition: ReportingDefinition, facts: dict[str, Any], template_path: Path
) -> None:
    payload = DeckBuilder(str(template_path)).render(definition, facts, {}, as_of="2026-09-30")
    presentation = open_deck(payload)

    assert len(presentation.slides) == len(definition.slides)
    # Les slides modèles ne doivent jamais être livrées au client.
    assert T.LAYOUT_MARKER not in shape_names(presentation)


def test_render_keeps_the_template_geometry(
    definition: ReportingDefinition, facts: dict[str, Any], template_path: Path
) -> None:
    payload = DeckBuilder(str(template_path)).render(definition, facts, {}, as_of="2026-09-30")
    presentation = open_deck(payload)

    zones = {shape.name for shape in presentation.slides[2].shapes}
    assert T.ZONE_TITLE in zones
    assert "SWR_RENDERED_CHART" in zones  # le graphique natif est bien posé


def test_kpis_are_rendered(
    definition: ReportingDefinition, facts: dict[str, Any], template_path: Path
) -> None:
    payload = DeckBuilder(str(template_path)).render(definition, facts, {}, as_of="2026-09-30")
    presentation = open_deck(payload)
    names = shape_names(presentation.slides[1])

    assert "SWR_KPI_1" in names and "SWR_KPI_2" in names
    texts = slide_texts(presentation)
    assert "Actif" in texts[1]
    assert "3 200 000" in plain(texts[1])


def test_table_is_rendered(
    definition: ReportingDefinition, facts: dict[str, Any], template_path: Path
) -> None:
    payload = DeckBuilder(str(template_path)).render(definition, facts, {}, as_of="2026-09-30")
    presentation = open_deck(payload)

    assert "SWR_RENDERED_TABLE" in shape_names(presentation.slides[4])
    assert "Air Liquide" in "\n".join(slide_texts(presentation))


def test_stacked_layout_keeps_kpis_above_the_chart(
    library: ReportingLibrary, facts: dict[str, Any], template_path: Path
) -> None:
    """Indicateurs posés sur une slide graphique : aucun chevauchement."""
    definition = library.load("stacked_review")
    payload = DeckBuilder(str(template_path)).render(definition, facts, {}, as_of="2026-09-30")
    slide = open_deck(payload).slides[1]

    cards = [shape for shape in slide.shapes if shape.name.startswith(T.KPI_ZONE_PREFIX)]
    chart = next(shape for shape in slide.shapes if shape.name == "SWR_RENDERED_CHART")

    assert len(cards) == 2
    assert min(card.top for card in cards) + max(card.height for card in cards) <= chart.top


def _rect(shape: Any) -> tuple[float, float, float, float]:
    """Rectangle d'une forme, en pouces : (gauche, haut, largeur, hauteur)."""
    return (
        shape.left / 914400,
        shape.top / 914400,
        (shape.width or 0) / 914400,
        (shape.height or 0) / 914400,
    )


def _content_shapes(slide: Any) -> list[Any]:
    """Formes porteuses de texte ou de tableau, hors fonds et bandeaux."""
    decorative = ("header", "band", "accent", "rule", "bg", "footer_line")
    shapes = []
    for shape in slide.shapes:
        if getattr(shape, "has_table", False) or (
            shape.has_text_frame and shape.text_frame.text.strip()
        ):
            if not any(hint in shape.name.lower() for hint in decorative):
                shapes.append(shape)
    return shapes


def test_no_shape_overlaps_another_on_any_slide(
    definition: ReportingDefinition, facts: dict[str, Any], template_path: Path
) -> None:
    """Aucune slide ne doit superposer deux zones de contenu.

    Régression : le bandeau d'indicateurs et la narration se recouvraient sur
    les slides « kpis », et le texte d'une slide « table » mordait sur la
    mention de source.
    """
    narratives = {
        slide.id: "Commentaire de l'IA. " * 6 for slide in definition.slides
    }
    payload = DeckBuilder(str(template_path)).render(
        definition, facts, narratives, as_of="2026-09-30"
    )

    overlaps: list[str] = []
    for index, slide in enumerate(open_deck(payload).slides, 1):
        shapes = _content_shapes(slide)
        for i in range(len(shapes)):
            for j in range(i + 1, len(shapes)):
                ax, ay, aw, ah = _rect(shapes[i])
                bx, by, bw, bh = _rect(shapes[j])
                inter_w = min(ax + aw, bx + bw) - max(ax, bx)
                inter_h = min(ay + ah, by + bh) - max(ay, by)
                if inter_w > 0.04 and inter_h > 0.04:
                    overlaps.append(
                        f"slide {index}: {shapes[i].name} x {shapes[j].name}"
                    )

    assert not overlaps, overlaps


def test_a_second_row_of_kpis_pushes_the_narrative_down(
    facts: dict[str, Any], template_path: Path
) -> None:
    """Au-delà de quatre indicateurs, le texte doit passer sous la 2e rangée."""
    keys = [
        "aum_total",
        "portfolio_cum_return",
        "benchmark_cum_return",
        "alpha",
        "cash_pct",
        "nb_positions",
    ]
    definition = ReportingDefinition(
        id="kpi_multi",
        name="Six indicateurs",
        description="Deux rangées de cartes.",
        slides=[
            SlideDefinition(
                id="synthese",
                layout="kpis",
                title="Indicateurs",
                kpis=[KpiSpec(key=key, label=key) for key in keys],
                narrative=True,
            )
        ],
    )
    payload = DeckBuilder(str(template_path)).render(
        definition, facts, {"synthese": "Synthèse." * 20}, as_of="2026-09-30"
    )
    slide = open_deck(payload).slides[0]

    cards = [shape for shape in slide.shapes if shape.name.startswith(T.KPI_ZONE_PREFIX)]
    text = next(shape for shape in slide.shapes if shape.name == "SWR_TEXT")

    assert len(cards) == 6
    # Deux rangées sont bien présentes : la seconde commence sous la première.
    assert max(card.top for card in cards) > min(card.top for card in cards)
    assert min(card.top for card in cards) + max(card.height for card in cards) <= text.top


def test_narrative_replaces_the_static_text(
    definition: ReportingDefinition, facts: dict[str, Any]
) -> None:
    payload = DeckBuilder().render(
        definition, facts, {"perf": "Commentaire de l'IA."}, as_of="2026-09-30"
    )

    assert "Commentaire de l'IA." in "\n".join(slide_texts(open_deck(payload)))


def test_disclaimer_is_not_written_by_the_model(
    definition: ReportingDefinition, facts: dict[str, Any]
) -> None:
    payload = DeckBuilder().render(
        definition, facts, {"disclaimer": "Texte injecté"}, as_of="2026-09-30"
    )
    texts = slide_texts(open_deck(payload))

    assert "Document de test au 30 septembre 2026." in texts[-1]
    assert "Texte injecté" not in texts[-1]


def test_source_and_footer_are_written(
    definition: ReportingDefinition, facts: dict[str, Any], template_path: Path
) -> None:
    payload = DeckBuilder(str(template_path)).render(definition, facts, {}, as_of="2026-09-30")
    texts = "\n".join(slide_texts(open_deck(payload)))

    assert "données de gestion au 30 septembre 2026" in texts
    assert "Conseiller : Conseiller Test" in texts


def test_unknown_layout_falls_back(
    library: ReportingLibrary, facts: dict[str, Any], tmp_path: Path
) -> None:
    """Un template sans zone `SWR_LAYOUT` reste utilisable, en géométrie par défaut."""
    bare = tmp_path / "marque.pptx"
    Presentation().save(str(bare))
    definition = library.load("test_review")

    payload = DeckBuilder(str(bare)).render(definition, facts, {}, as_of="2026-09-30")

    assert len(open_deck(payload).slides) == len(definition.slides)


def test_unreadable_template_is_reported(
    definition: ReportingDefinition, facts: dict[str, Any], tmp_path: Path
) -> None:
    broken = tmp_path / "casse.pptx"
    broken.write_bytes(b"pas un pptx")

    with pytest.raises(TemplateError):
        DeckBuilder(str(broken)).render(definition, facts, {}, as_of="2026-09-30")


def test_render_is_deterministic(definition: ReportingDefinition, facts: dict[str, Any]) -> None:
    builder = DeckBuilder()

    first = open_deck(builder.render(definition, facts, {}, as_of="2026-09-30"))
    second = open_deck(builder.render(definition, facts, {}, as_of="2026-09-30"))

    assert slide_texts(first) == slide_texts(second)


def test_render_of_an_empty_reporting_still_produces_a_file() -> None:
    """Sans slides déclarées le rendu reste un fichier PPTX lisible, mais vide."""
    payload = DeckBuilder().render(ReportingDefinition(id="vide"), {}, {})

    assert payload[:2] == b"PK"
    assert len(open_deck(payload).slides) == 0


# ------------------------------------------------------------------ Templates


def test_default_template_declares_one_slide_per_layout() -> None:
    presentation = T.build_default_template()

    assert set(T.layout_names(presentation)) == set(T.DEFAULT_LAYOUTS)
    assert T.has_layout_slides(presentation)


def test_default_template_carries_the_named_zones() -> None:
    presentation = T.build_default_template()
    chart_slide = presentation.slides[T.layout_names(presentation)["chart"]]

    assert T.find_zone(chart_slide, T.ZONE_TITLE) is not None
    assert T.find_zone(chart_slide, T.ZONE_CHART) is not None
    assert T.find_zone(chart_slide, T.ZONE_SOURCE) is not None


def test_kpi_slide_declares_four_cards() -> None:
    presentation = T.build_default_template()
    kpi_slide = presentation.slides[T.layout_names(presentation)["kpis"]]

    assert all(T.find_zone(kpi_slide, f"{T.KPI_ZONE_PREFIX}{index}") for index in range(1, 5))


def test_zone_rect_falls_back_on_geometry() -> None:
    presentation = T.build_default_template()
    slide = presentation.slides[0]
    left, top, width, height = T.zone_rect(slide, "SWR_ABSENTE", (1.0, 2.0, 3.0, 0.5))

    assert round(left / 914400, 2) == 1.0
    assert round(top / 914400, 2) == 2.0
    assert round(width / 914400, 2) == 3.0
    assert round(height / 914400, 2) == 0.5


def test_zone_anchor_uses_the_template_position() -> None:
    presentation = T.build_default_template()
    chart_slide = presentation.slides[T.layout_names(presentation)["chart"]]

    left, top, _width, _height = T.zone_anchor(chart_slide, T.ZONE_CHART, (0, 0, 1, 1))

    assert top > 1.0  # le graphique ne commence pas sous le titre
    assert T.zone_anchor(chart_slide, "SWR_ABSENTE", (9, 9, 1, 1)) == (9, 9, 1, 1)


def test_palette_applies_the_brand() -> None:
    palette = T.Palette({"primary": "#123456", "accent": "#ABCDEF"})

    assert str(palette.primary) == "123456"
    assert str(palette.accent) == "ABCDEF"
    assert palette.value_color(12.3) != palette.value_color(-3.0)


def test_palette_tolerates_an_invalid_colour() -> None:
    palette = T.Palette({"primary": "pas une couleur"})

    assert str(palette.primary) == str(T.Palette().primary)


def test_series_colors_cycles() -> None:
    colors = T.Palette().series_colors(10)

    assert len(colors) == 10
    assert len({str(color) for color in colors}) == 10

# ------------------------------------------------------------- Obligataire


@pytest.fixture
def bond_facts(metrics: MetricsEngine) -> dict[str, Any]:
    """Faits d'un portefeuille comportant deux lignes obligataires."""
    return with_bonds(metrics, *BOND_ROWS)


def test_bond_chart_sources_are_readable(bond_facts: dict[str, Any]) -> None:
    for source in (
        "bond_maturities", "bond_ratings", "bond_issuers",
        "bond_categories", "bond_sectors", "bond_countries",
    ):
        data = _chart_data(ChartSpec(kind="barh", source=source), bond_facts)

        assert data is not None, source
        assert data["categories"], source
        assert data["series"] == [("% de l'obligataire", data["series"][0][1])]
        # Toutes les répartitions se lisent en part de l'obligataire.
        assert all(value >= 0 for value in data["series"][0][1]), source


def test_bond_chart_source_without_bonds_draws_nothing(facts: dict[str, Any]) -> None:
    assert _chart_data(ChartSpec(kind="barh", source="bond_issuers"), facts) is None


def test_bond_table_sources_are_readable(bond_facts: dict[str, Any]) -> None:
    positions = _table_rows(TableSpec(source="bond_positions"), bond_facts)
    totals = _table_rows(TableSpec(source="bond_totals"), bond_facts)
    coupons = _table_rows(TableSpec(source="coupons"), bond_facts)
    scale = _table_rows(TableSpec(source="rating_scale"), bond_facts)

    assert [row["issuer"] for row in positions] == ["Souverain FR", "Banque SAS"]
    assert positions[0]["weight"] == 15.0
    # Les totaux se terminent par les lignes de clôture : elles sont Recognues
    # comme telles et donc mises en gras par le rendu.
    assert totals[-1]["label"] == "Total général"
    assert totals[-1]["pct"] == 100.0
    assert [row["label"] for row in coupons][0].startswith("Coupons encaissés")
    assert scale[0] == {
        "sp": "AAA", "moodys": "Aaa", "fitch": "AAA", "bucket": "Investment grade",
    }


def test_table_total_rows_close_on_the_asset(bond_facts: dict[str, Any]) -> None:
    """Le total général vaut l'actif net, pas l'obligataire ni le monétaire."""
    rows = _table_rows(TableSpec(source="bond_totals"), bond_facts)
    labels = [row["label"] for row in rows]

    assert labels[-3:] == ["Total obligataire", "Total monétaire", "Total général"]
    assert rows[-1]["value"] == bond_facts["kpis"]["aum_total"]
    assert rows[-3]["value"] + rows[-2]["value"] < rows[-1]["value"]


def test_total_rows_are_the_ones_set_in_bold() -> None:
    assert _is_total_row({"label": "Total monétaire"})
    assert _is_total_row({"label": "total général", "total": False})
    assert _is_total_row({"typology": "Total obligataire"})
    assert _is_total_row({"label": "Banque", "total": True})
    # Une ligne de position ne devient pas un total parce qu'elle est en gras.
    assert not _is_total_row({"label": "OAT 3,00 % 2031"})


def test_table_header_is_light_and_totals_are_emphasised(
    bond_facts: dict[str, Any], template_path: Path
) -> None:
    definition = ReportingDefinition(
        id="obligataire",
        name="Totaux",
        description="Tableau de clôture obligataire.",
        slides=[
            SlideDefinition(
                id="totaux",
                layout="table",
                title="Totaux",
                table=TableSpec(
                    source="bond_totals",
                    columns=[
                        ColumnSpec(key="label", label="Typologie"),
                        ColumnSpec(key="value", label="Encours", format="currency"),
                        ColumnSpec(key="pct", label="% actif net", format="share"),
                    ],
                ),
            )
        ],
    )
    payload = DeckBuilder(str(template_path)).render(
        definition, bond_facts, {}, as_of="2026-09-30"
    )
    table = next(
        shape.table for shape in open_deck(payload).slides[0].shapes if shape.has_table
    )
    palette = T.Palette()

    # En-tête : fond clair, texte foncé — pas de bandeau plein de couleur.
    assert table.cell(0, 0).fill.fore_color.rgb == palette.surface
    assert table.cell(0, 0).text_frame.paragraphs[0].runs[0].font.color.rgb != palette.surface
    # Ligne de total : en gras et dans la couleur de marque.
    total = table.cell(len(table.rows) - 1, 0)
    assert total.text_frame.paragraphs[0].runs[0].font.bold is True
    assert total.text_frame.paragraphs[0].runs[0].font.color.rgb == palette.primary
    # Un poids ne porte pas de signe : « +34,18 % de l'actif » se lirait mal.
    assert table.cell(1, 2).text == "15,00 %"
    assert table.cell(1, 0).text_frame.paragraphs[0].runs[0].font.bold is False


def test_share_format_omits_the_sign_that_percent_adds() -> None:
    assert format_value(34.18, "share") == "34,18 %"
    assert format_value(34.18, "percent") == "+34,18 %"
    assert format_value(-3.5, "share") == "-3,50 %"
    # Le format « percent » reste réservé aux variations.
    assert format_value(1.5, "percent", suffix=" pts") == "+1,50 pts"
    assert format_value(34180, "share", decimals=0) == f"34{NARROW}180 %"


# ------------------------------------------------------ Petits multiples


def test_panels_lay_out_four_charts_in_a_grid(
    bond_facts: dict[str, Any], template_path: Path
) -> None:
    definition = ReportingDefinition(
        id="analytiques",
        name="Répartitions analytiques",
        description="Quatre vues en petits multiples.",
        slides=[
            SlideDefinition(
                id="repartitions",
                layout="chart",
                title="Répartitions analytiques",
                panels=[
                    ChartSpec(kind="column", title="Maturité", source="bond_maturities"),
                    ChartSpec(kind="barh", title="Notation", source="bond_ratings"),
                    ChartSpec(kind="barh", title="Secteur", source="bond_sectors"),
                    ChartSpec(kind="barh", title="Pays", source="bond_countries"),
                ],
            )
        ],
    )
    payload = DeckBuilder(str(template_path)).render(
        definition, bond_facts, {}, as_of="2026-09-30"
    )
    slide = open_deck(payload).slides[0]
    charts = [shape for shape in slide.shapes if shape.has_chart]

    assert len(charts) == 4
    # Deux rangées, deux colonnes : les quatre cadres se chevauchent deux à deux
    # dans les deux axes sans jamais se recouvrir.
    tops = sorted({round(shape.top, 2) for shape in charts})
    lefts = sorted({round(shape.left, 2) for shape in charts})
    assert len(tops) == 2 and len(lefts) == 2
    assert len({(round(s.left, 2), round(s.top, 2)) for s in charts}) == 4
    # Chaque graphique garde son propre titre.
    titles = {chart.chart.chart_title.text_frame.text for chart in charts}
    assert titles == {"Maturité", "Notation", "Secteur", "Pays"}


def test_panels_skip_a_view_without_data(
    bond_facts: dict[str, Any], template_path: Path
) -> None:
    """Une répartition vide ne laisse pas de trou : la grille se referme."""
    # Le secteur n'a pas de donnée servie : la vue saute, l'autre reste.
    facts = {**bond_facts, "bonds": {**bond_facts["bonds"], "sectors": []}}
    definition = ReportingDefinition(
        id="analytiques_partiels",
        name="Répartitions partielles",
        description="Une seule vue servie en données.",
        slides=[
            SlideDefinition(
                id="repartitions",
                layout="chart",
                title="Répartitions analytiques",
                panels=[
                    ChartSpec(kind="barh", title="Notation", source="bond_ratings"),
                    ChartSpec(kind="barh", title="Secteur", source="bond_sectors"),
                ],
            )
        ],
    )
    payload = DeckBuilder(str(template_path)).render(
        definition, facts, {}, as_of="2026-09-30"
    )
    slide = open_deck(payload).slides[0]
    charts = [shape for shape in slide.shapes if shape.has_chart]

    assert len(charts) == 1
    # La vue restante occupe la première case de la grille, pas la seconde.
    assert charts[0].left == pytest.approx(T.MARGIN_LEFT * 914400, abs=1000)


def test_panel_note_sits_below_the_grid(
    bond_facts: dict[str, Any], template_path: Path
) -> None:
    definition = ReportingDefinition(
        id="analytiques_note",
        name="Répartitions commentées",
        description="Grille et note de lecture.",
        slides=[
            SlideDefinition(
                id="repartitions",
                layout="chart",
                title="Répartitions analytiques",
                panels=[
                    ChartSpec(kind="barh", title="Notation", source="bond_ratings"),
                    ChartSpec(kind="barh", title="Secteur", source="bond_sectors"),
                ],
                text="La lecture croisée des quatre vues.",
            )
        ],
    )
    payload = DeckBuilder(str(template_path)).render(
        definition, bond_facts, {}, as_of="2026-09-30"
    )
    slide = open_deck(payload).slides[0]
    charts = [shape for shape in slide.shapes if shape.has_chart]
    note = next(shape for shape in slide.shapes if shape.name == T.ZONE_TEXT)

    assert "La lecture croisée" in note.text_frame.text
    # La note est sous la grille, et la grille s'est rétractée pour la laisser passer.
    assert max(chart.top + chart.height for chart in charts) <= note.top


def test_panels_do_not_leave_the_template_anchor_behind(
    bond_facts: dict[str, Any], template_path: Path
) -> None:
    definition = ReportingDefinition(
        id="analytiques_propre",
        name="Répartitions propres",
        description="Aucun cadre résiduel du template.",
        slides=[
            SlideDefinition(
                id="repartitions",
                layout="chart",
                title="Répartitions analytiques",
                panels=[
                    ChartSpec(kind="barh", title="Notation", source="bond_ratings"),
                    ChartSpec(kind="barh", title="Secteur", source="bond_sectors"),
                ],
            )
        ],
    )
    payload = DeckBuilder(str(template_path)).render(
        definition, bond_facts, {}, as_of="2026-09-30"
    )
    names = shape_names(open_deck(payload).slides[0])

    assert names.count(T.ZONE_CHART) == 0
    assert T.ZONE_TEXT not in names


def test_every_declared_chart_kind_is_mapped(bond_facts: dict[str, Any]) -> None:
    """Le vocabulaire des graphiques ne doit pas contenir de valeur morte.

    Un `kind` déclaré sans correspondance dans `CHART_TYPES` ne lèverait aucune
    erreur : le rendu retomberait silencieusement sur un histogramme. Chaque
    type déclaré doit donc produire le graphique qu'il annonce.
    """
    kinds = get_args(ChartKind)

    assert set(kinds) == set(CHART_TYPES)
    for kind in kinds:
        spec = ChartSpec(kind=kind, source="bond_issuers")
        definition = ReportingDefinition(
            id=f"type_{kind}",
            name="Type",
            description=f"Graphique {kind}.",
            slides=[
                SlideDefinition(
                    id="graphe", layout="chart", title=kind, chart=spec
                )
            ],
        )
        payload = DeckBuilder().render(
            definition, bond_facts, {}, as_of="2026-09-30"
        )
        charts = [
            shape.chart
            for shape in open_deck(payload).slides[0].shapes
            if shape.has_chart
        ]

        assert len(charts) == 1, kind
        assert charts[0].chart_type == CHART_TYPES[kind], kind
