"""Tests du pilotage du module IA : configuration, contexte, vérification, API.

Ces tests n'appellent jamais le modèle : `llama_cpp` est absent de la plupart
des environnements de test et une génération prendrait des dizaines de
secondes. Le moteur est remplacé par un stub qui enregistre les messages reçus,
ce qui permet aussi de vérifier ce qui est réellement envoyé au modèle.
"""

from __future__ import annotations

import json
import shutil
import sys
import types
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

from smartpms import ai_config, ai_verify
from smartpms.ai_config import load as load_ai_config
from smartpms.main import create_app
from smartpms.services import ApplicationService

PROJECT_DIR = Path(__file__).resolve().parent.parent


class StubLLM:
    """Remplace `LLMService` : journalise les messages, ne génère rien."""

    def __init__(self, answer: str = "") -> None:
        self.answer = answer
        self.messages: list[dict[str, str]] = []
        self.unloaded = 0
        self.warmed = 0

    def chat(self, messages: list[dict[str, str]], **_: Any) -> dict[str, Any]:
        self.messages = messages
        return {"choices": [{"message": {"content": self.answer or '{"answer":"ok"}'}}]}

    def warmup(self) -> None:
        self.warmed += 1

    def unload(self) -> None:
        self.unloaded += 1

    def config_changed(self) -> None:
        pass

    def ai_config(self) -> dict[str, Any]:
        # Aliasé : la méthode porte le même nom que le module.
        return load_ai_config(self.base_dir)

    def model_status(self) -> dict[str, Any]:
        return {
            "backend": "gguf",
            "path": "",
            "loaded": False,
            "available": False,
            "model_name": "",
            "model_path": "",
            "error": None,
            "config": self.ai_config(),
        }

    base_dir: Path = PROJECT_DIR


@pytest.fixture()
def sandbox(tmp_path: Path) -> Path:
    """Copie des données dans un répertoire temporaire.

    Les tests écrivent (`/ai/config`), il ne faut donc jamais qu'ils touchent le
    `ai_config.json` de la machine.
    """
    for name in (
        "portfolios.parquet",
        "holdings.parquet",
        "esg.parquet",
        "operations.parquet",
        "inventories.parquet",
        "cash.parquet",
        "constraints.parquet",
        "exclusions.parquet",
    ):
        source = PROJECT_DIR / name
        if source.is_file():
            shutil.copy(source, tmp_path / name)
    return tmp_path


def _settings(base_dir: Path):
    from smartpms.config import Settings

    return Settings(
        base_dir=base_dir,
        config_path=base_dir / "datasource_config.json",
        session_secret="test-secret",
        # Le serveur de test ne doit surtout pas démarrer un processus llamafile.
        auto_start_llamafile=False,
    )


@pytest.fixture()
def client(sandbox: Path) -> TestClient:
    from smartpms.config import DataSourceConfig

    settings = _settings(sandbox)
    config = DataSourceConfig(settings.base_dir, settings.config_path)
    config.save({**config.load(), "gguf_path": "", "llm_backend": "gguf"})
    app = create_app(settings)
    with TestClient(app) as test_client:
        # `get_service` lit `app.state.service` : le remplacement passe par là.
        stub = StubLLM()
        stub.base_dir = sandbox
        app.state.service.llm = stub
        test_client.stub = stub  # type: ignore[attr-defined]
        response = test_client.post(
            "/api/login", json={"username": "admin", "password": "admin123"}
        )
        assert response.status_code == 200, response.text
        yield test_client


# --- ai_config : chargement, bornes, détection ------------------------------


def test_defaults_when_no_file(sandbox: Path) -> None:
    assert not ai_config.config_path(sandbox).exists()
    assert ai_config.load(sandbox) == ai_config.DEFAULTS


def test_load_ignores_broken_file(sandbox: Path) -> None:
    ai_config.config_path(sandbox).write_text("{pas du json", encoding="utf-8")
    assert ai_config.load(sandbox) == ai_config.DEFAULTS


def test_load_ignores_non_dict_file(sandbox: Path) -> None:
    ai_config.config_path(sandbox).write_text("[1, 2]", encoding="utf-8")
    assert ai_config.load(sandbox) == ai_config.DEFAULTS


def test_load_reads_partial_file(sandbox: Path) -> None:
    ai_config.config_path(sandbox).write_text(
        json.dumps({"temperature": 0.7}), encoding="utf-8"
    )
    config = ai_config.load(sandbox)
    assert config["temperature"] == 0.7
    # Les clés absentes gardent leur défaut.
    assert config["max_tokens"] == ai_config.DEFAULTS["max_tokens"]


def test_load_coerces_types(sandbox: Path) -> None:
    ai_config.config_path(sandbox).write_text(
        json.dumps({"n_ctx": "4096", "temperature": "0.9"}), encoding="utf-8"
    )
    config = ai_config.load(sandbox)
    assert config["n_ctx"] == 4096
    assert config["temperature"] == 0.9


@pytest.mark.parametrize("key", ["n_ctx", "n_threads", "n_batch", "max_tokens"])
def test_load_rejects_out_of_bounds(sandbox: Path, key: str) -> None:
    ai_config.config_path(sandbox).write_text(json.dumps({key: 99_999_999}), encoding="utf-8")
    assert ai_config.load(sandbox)[key] == ai_config.DEFAULTS[key]


def test_load_rejects_unknown_detail(sandbox: Path) -> None:
    ai_config.config_path(sandbox).write_text(
        json.dumps({"default_detail": "absurd"}), encoding="utf-8"
    )
    assert ai_config.load(sandbox)["default_detail"] == ai_config.DEFAULT_DETAIL


def test_save_persists(sandbox: Path) -> None:
    saved = ai_config.save(sandbox, {"n_ctx": 16384, "default_detail": "complet"})
    assert saved["n_ctx"] == 16384
    assert json.loads(ai_config.config_path(sandbox).read_text(encoding="utf-8"))["n_ctx"] == 16384
    # Relu du disque : la valeur survit au redémarrage.
    assert ai_config.load(sandbox)["n_ctx"] == 16384


def test_save_ignores_none_and_keeps_current(sandbox: Path) -> None:
    ai_config.save(sandbox, {"n_ctx": 16384})
    again = ai_config.save(sandbox, {"n_ctx": None, "temperature": 0.8})
    assert again["n_ctx"] == 16384
    assert again["temperature"] == 0.8


def test_save_refuses_out_of_bounds(sandbox: Path) -> None:
    ai_config.save(sandbox, {"n_ctx": 16384})
    after = ai_config.save(sandbox, {"n_ctx": 10})
    assert after["n_ctx"] == 16384, "une valeur hors bornes ne doit pas être écrite"


def test_save_rejects_unknown_detail(sandbox: Path) -> None:
    assert ai_config.save(sandbox, {"default_detail": "nope"})["default_detail"] == (
        ai_config.DEFAULT_DETAIL
    )


def test_expand_handles_home_and_relative(sandbox: Path, monkeypatch) -> None:
    monkeypatch.setenv("HOME", str(sandbox))
    assert ai_config.expand("~/model.gguf", sandbox) == sandbox / "model.gguf"
    assert ai_config.expand("model.gguf", sandbox) == sandbox / "model.gguf"
    assert ai_config.expand("", sandbox) == sandbox


@pytest.fixture()
def no_model_dirs(monkeypatch: pytest.MonkeyPatch) -> None:
    """Neutralise `~/Models` etc. : le test ne doit pas voir les modèles de la machine."""
    monkeypatch.setattr(ai_config, "MODEL_DIRS", [])


def test_list_models_finds_files(sandbox: Path, no_model_dirs: None) -> None:
    (sandbox / "un-modele.gguf").write_bytes(b"x" * (3 * 1024 * 1024))
    models = ai_config.list_models(sandbox, str(sandbox / "un-modele.gguf"))
    assert [m["name"] for m in models] == ["un-modele.gguf"]
    assert models[0]["size_mb"] == pytest.approx(3.0, abs=0.01)
    assert models[0]["path"] == str(sandbox / "un-modele.gguf")


def test_list_models_ignores_missing_dirs(sandbox: Path, no_model_dirs: None) -> None:
    assert ai_config.list_models(sandbox, "") == []


def test_list_models_deduplicates(sandbox: Path, no_model_dirs: None) -> None:
    """Le dossier du modèle actif passe en tête : pas de doublon."""
    (sandbox / "m.gguf").write_bytes(b"x")
    models = ai_config.list_models(sandbox, str(sandbox / "m.gguf"))
    assert len([m for m in models if m["name"] == "m.gguf"]) == 1


def test_describe_model_missing(sandbox: Path) -> None:
    described = ai_config.describe_model(sandbox, "/absent/model.gguf")
    assert described["exists"] is False
    assert described["size_mb"] == 0.0


def test_describe_model_present(sandbox: Path) -> None:
    path = sandbox / "m.gguf"
    path.write_bytes(b"y" * 1024)
    assert ai_config.describe_model(sandbox, str(path))["exists"] is True


# --- ai_verify : montants et sigles ----------------------------------------


def test_verify_reads_french_and_english_numbers() -> None:
    assert ai_verify._numbers("2 450 000 EUR") == [2450000.0]
    assert ai_verify._numbers("1 234 567,89") == [1234567.89]
    assert ai_verify._numbers("1,234,567.89") == [1234567.89]


def test_verify_ignores_small_numbers() -> None:
    result = ai_verify.check("Le score ESG est de 62,5 sur 100.", "score 62,5")
    assert result["numbers_checked"] == 0
    assert result["ok"] is True


def test_verify_flags_absent_amount() -> None:
    result = ai_verify.check("La trésorerie atteint 2 450 000 EUR.", "trésorerie 398 000")
    assert result["ok"] is False
    assert [n["value"] for n in result["unverified_numbers"]] == ["2 450 000"]
    assert "2 450 000" in ai_verify.warning(result)


def test_verify_accepts_present_amount() -> None:
    result = ai_verify.check("La trésorerie atteint 398 000 EUR.", "trésorerie 398 000")
    assert result["ok"] is True
    assert result["numbers_checked"] == 1
    assert ai_verify.warning(result) == ""


def test_verify_accepts_rounded_amounts() -> None:
    context = "valeur totale 3 250 000"
    assert ai_verify.check("Environ 3 250 000 EUR.", context)["ok"] is True
    assert ai_verify.check("Environ 3,25 M EUR.", context)["ok"] is True
    assert ai_verify.check("Environ 3250 k EUR.", context)["ok"] is True


def test_verify_uses_relative_tolerance() -> None:
    """0,25 % d'écart est accepté, la tolérance relative vaut 0,5 %."""
    assert ai_verify.check("Environ 399 000 EUR.", "valeur 398 000")["ok"] is True
    assert ai_verify.check("Environ 410 000 EUR.", "valeur 398 000")["ok"] is False


def test_verify_flags_unknown_ticker() -> None:
    result = ai_verify.check("Le titre ZZZZ domine.", "MSFT pèse", tickers=["MSFT"])
    assert result["unknown_tickers"] == ["ZZZZ"]
    assert "ZZZZ" in ai_verify.warning(result)


def test_verify_accepts_known_tickers() -> None:
    assert ai_verify.check("MSFT domine.", "MSFT pèse", tickers=["MSFT"])["ok"] is True
    assert ai_verify.check("AI.PA domine.", "AI.PA pèse", tickers=["AI.PA"])["ok"] is True


def test_verify_accepts_ticker_root() -> None:
    """`ASML` est accepté si le contexte contient `ASML.AS`."""
    assert ai_verify.check("ASML domine.", "ASML.AS pèse", tickers=["ASML.AS"])["ok"] is True


def test_verify_ignores_acronyms_and_sections() -> None:
    answer = "Le P&L est positif et l'ESG moyen est de 62,5. SYNTHESE : okay."
    assert ai_verify.check(answer, "P&L et ESG", tickers=["MSFT"])["ok"] is True


def test_verify_ignores_markdown() -> None:
    assert ai_verify.check("**MSFT** domine", "MSFT", tickers=["MSFT"])["ok"] is True


def test_verify_accepts_token_from_context() -> None:
    assert ai_verify.check("Le secteur SANE est exposé.", "secteur SANE", tickers=["MSFT"])["ok"] is True


def test_verify_without_tickers_skips_ticker_check() -> None:
    assert ai_verify.check("Le titre ZZZZ domine.", "contexte")["unknown_tickers"] == []


def test_verify_extra_values_authorise_metrics() -> None:
    result = ai_verify.check("Le total est de 1 000 000.", "rien", extra_values=[1000000.0])
    assert result["ok"] is True


def test_verify_deduplicates_repeated_amounts() -> None:
    answer = "398 000 ici, puis 398 000 là."
    assert ai_verify.check(answer, "398 000")["numbers_checked"] == 1


def test_verify_empty_answer() -> None:
    assert ai_verify.check("", "398 000")["ok"] is True


def test_verify_caps_reported_problems() -> None:
    answer = " ".join(f"{n} EUR" for n in range(10_000, 10_020))
    result = ai_verify.check(answer, "contexte vide")
    assert len(result["unverified_numbers"]) == 8


# --- Contexte : niveaux de détail ------------------------------------------


@pytest.fixture()
def service(sandbox: Path) -> ApplicationService:
    from smartpms.config import DataSourceConfig
    from smartpms.storage import ParquetRepository

    settings = _settings(sandbox)
    config = DataSourceConfig(settings.base_dir, settings.config_path)
    svc = ApplicationService(settings, config, ParquetRepository(config))
    stub = StubLLM()
    stub.base_dir = sandbox
    svc.llm = stub
    return svc


def test_context_default_is_standard(service: ApplicationService) -> None:
    from smartpms.auth import Principal

    admin = Principal(username="admin", role="admin")
    assert service.ai_context(admin) == service.ai_context(admin, "standard")


def test_context_uses_configured_default(service: ApplicationService, sandbox: Path) -> None:
    from smartpms.auth import Principal

    ai_config.save(sandbox, {"default_detail": "rapide"})
    admin = Principal(username="admin", role="admin")
    assert service.ai_context(admin) == service.ai_context(admin, "rapide")


def test_context_falls_back_on_unknown_detail(service: ApplicationService) -> None:
    from smartpms.auth import Principal

    admin = Principal(username="admin", role="admin")
    assert service.ai_context(admin, "n'importe quoi") == service.ai_context(
        admin, ai_config.DEFAULT_DETAIL
    )


def test_context_levels_grow(service: ApplicationService) -> None:
    from smartpms.auth import Principal

    admin = Principal(username="admin", role="admin")
    sizes = [len(service.ai_context(admin, level)) for level in ("rapide", "standard", "complet")]
    assert sizes[0] < sizes[1] < sizes[2]


def test_context_rapide_has_no_position_lines(service: ApplicationService) -> None:
    from smartpms.auth import Principal

    admin = Principal(username="admin", role="admin")
    text = service.ai_context(admin, "rapide")
    assert "POSITIONS" not in text
    assert "INDICATEURS GLOBAUX" in text


def test_context_complet_adds_cash_operations_exclusions(service: ApplicationService) -> None:
    from smartpms.auth import Principal

    admin = Principal(username="admin", role="admin")
    text = service.ai_context(admin, "complet")
    assert "TRESORERIE" in text
    assert "OPERATIONS RECENTES" in text
    assert "TITRES EXCLUS" in text


def test_context_payload_carries_scope_and_size(service: ApplicationService) -> None:
    from smartpms.auth import Principal

    admin = Principal(username="admin", role="admin")
    payload = service.ai_context_payload(admin, "complet")
    assert payload["detail"] == "complet"
    assert payload["scope"] == "Tous les portefeuilles"
    assert payload["chars"] == len(payload["text"])


def test_context_respects_principal_scope(service: ApplicationService) -> None:
    from smartpms.auth import Principal

    user = Principal(username="hamdi", role="user", client_id="client_hamdi")
    scope = service.ai_scope(user)
    assert scope != "Tous les portefeuilles"
    assert service.ai_context(user, "complet")


def test_context_excludes_unauthorised_positions(service: ApplicationService) -> None:
    """Un utilisateur ne doit voir que les tickers de ses portefeuilles."""
    from smartpms.auth import Principal

    user = Principal(username="hamdi", role="user", client_id="client_hamdi")
    text = service.ai_context(user, "complet")
    admin_text = service.ai_context(Principal(username="admin", role="admin"), "complet")
    if len(admin_text) > len(text):
        assert text != admin_text


def test_ai_tickers_are_authorised_only(service: ApplicationService) -> None:
    from smartpms.auth import Principal

    user = Principal(username="hamdi", role="user", client_id="client_hamdi")
    assert set(service.ai_tickers(user)) <= set(service.ai_tickers(Principal("admin", "admin")))


# --- API ---------------------------------------------------------------------


def test_status_requires_auth(client: TestClient) -> None:
    client.cookies.clear()
    assert client.get("/api/ai/status").status_code == 401


def test_status_reports_engine_and_levels(client: TestClient) -> None:
    body = client.get("/api/ai/status").json()
    assert body["engine"]["backend"] == "gguf"
    assert body["detail_levels"] == ai_config.DETAIL_LEVELS
    assert body["default_detail"] == ai_config.DEFAULT_DETAIL
    assert body["scope"] == "Tous les portefeuilles"
    assert "n_ctx" in body["bounds"]


def test_config_roundtrip(client: TestClient) -> None:
    assert client.post("/api/ai/config", json={"n_ctx": 16384}).json()["config"]["n_ctx"] == 16384
    assert client.get("/api/ai/config").json()["n_ctx"] == 16384


def test_config_post_reloads_engine(client: TestClient) -> None:
    body = client.post("/api/ai/config", json={"n_threads": 2}).json()
    assert body["ok"] is True
    assert body["engine_loaded"] is False
    # n_threads fait partie de la signature : le modèle doit être rechargé.
    assert client.stub.unloaded == 1


def test_config_ignores_unknown_keys(client: TestClient) -> None:
    before = client.get("/api/ai/config").json()
    client.post("/api/ai/config", json={"temperature": 0.55})
    after = client.get("/api/ai/config").json()
    assert after["temperature"] == 0.55
    assert after["n_ctx"] == before["n_ctx"]


def test_config_rejects_bad_detail(client: TestClient) -> None:
    assert client.post("/api/ai/config", json={"default_detail": "nope"}).status_code == 422


def test_context_view(client: TestClient) -> None:
    body = client.get("/api/ai/context", params={"detail": "rapide"}).json()
    assert body["detail"] == "rapide"
    assert body["text"].startswith("PORTEFEUILLES")
    assert body["truncated"] is False
    assert body["chars"] == len(body["text"])


def test_context_view_reports_truncation(client: TestClient) -> None:
    client.post("/api/ai/config", json={"max_context_chars": 2000})
    body = client.get("/api/ai/context", params={"detail": "complet"}).json()
    assert body["truncated"] is True
    assert len(body["text"]) <= 2000


def test_estimate(client: TestClient) -> None:
    body = client.post(
        "/api/ai/estimate", json={"question": "répartition sectorielle ?", "detail": "rapide"}
    ).json()
    assert body["detail"] == "rapide"
    assert body["prompt_chars"] > 0
    assert body["estimate_seconds"] > 0
    assert body["model_loaded"] is False
    assert body["extra_seconds_if_loading"] == 8


def test_estimate_follows_level(client: TestClient) -> None:
    def size(level: str) -> int:
        return client.post(
            "/api/ai/estimate", json={"question": "x", "detail": level}
        ).json()["prompt_chars"]

    assert size("rapide") < size("complet")


def test_warmup(client: TestClient) -> None:
    body = client.post("/api/ai/warmup").json()
    assert body["ok"] is True
    assert client.stub.warmed == 1


def test_chat_requires_question(client: TestClient) -> None:
    assert client.post("/api/ai/chat", json={"question": "   "}).status_code == 400


def test_chat_sends_level_and_verifies(client: TestClient) -> None:
    # Le montant doit exister dans le niveau `rapide`, celui réellement envoyé.
    context = client.get("/api/ai/context", params={"detail": "rapide"}).json()["text"]
    amount = max(ai_verify._numbers(context))
    client.stub.answer = '{"answer":"La valorisation atteint %s EUR."}' % f"{amount:,.0f}".replace(",", " ")
    body = client.post("/api/ai/chat", json={"question": "valorisation ?", "detail": "rapide"}).json()
    system = client.stub.messages[0]["content"]
    assert "CONTEXTE DU PORTEFEUILLE" in system
    # Niveau rapide : pas de section POSITIONS dans ce qui est envoyé.
    assert "POSITIONS (les plus importantes)" not in system
    assert body["verification"]["ok"] is True


def test_chat_flags_amount_absent_from_chosen_level(client: TestClient) -> None:
    """Un montant qui n'existe qu'au niveau `complet` est signalé en `rapide`.

    C'est le comportement attendu : le contrôle porte sur le contexte réellement
    envoyé, pas sur les données complètes du serveur.
    """
    rapide = client.get("/api/ai/context", params={"detail": "rapide"}).json()["text"]
    complet = client.get("/api/ai/context", params={"detail": "complet"}).json()["text"]
    cash = next(
        n
        for n in sorted(set(ai_verify._numbers(complet)) - set(ai_verify._numbers(rapide)), reverse=True)
        if n >= 1000
    )
    client.stub.answer = '{"answer":"La trésorerie atteint %s EUR."}' % f"{cash:,.0f}".replace(",", " ")
    body = client.post("/api/ai/chat", json={"question": "trésorerie ?", "detail": "rapide"}).json()
    assert body["verification"]["ok"] is False


def test_chat_flags_invented_amount(client: TestClient) -> None:
    client.stub.answer = '{"answer":"La trésorerie atteint 9 999 999 EUR."}'
    body = client.post("/api/ai/chat", json={"question": "trésorerie ?"}).json()
    assert body["verification"]["ok"] is False
    assert body["verification"]["warning"]


def test_chat_verification_absent_when_no_answer(client: TestClient) -> None:
    """Une réponse sans montant ne produit qu'un contrôle vide, pas une erreur."""
    client.stub.answer = '{"answer":"Le portefeuille est diversifié."}'
    body = client.post("/api/ai/chat", json={"question": "vue ?"}).json()
    assert body["verification"]["ok"] is True
    assert body["verification"]["numbers_checked"] == 0


def test_chat_rejects_empty_model_output(client: TestClient) -> None:
    client.stub.answer = "   "
    assert client.post("/api/ai/chat", json={"question": "?"}).status_code == 500


def test_chat_survives_engine_failure(client: TestClient) -> None:
    def boom(*_: Any, **__: Any) -> None:
        raise RuntimeError("model absent")

    client.stub.chat = boom  # type: ignore[assignment]
    assert client.post("/api/ai/chat", json={"question": "?"}).status_code == 503


def test_model_route_still_works(client: TestClient) -> None:
    body = client.get("/api/ai/model").json()
    assert body["backend"] == "gguf"
    assert "config" in body


def test_datasource_config_still_saves(client: TestClient, sandbox: Path) -> None:
    assert client.post("/api/config/datasource", json={"gguf_path": ""}).json()["ok"] is True
    stored = json.loads((sandbox / "datasource_config.json").read_text(encoding="utf-8"))
    assert "gguf_path" in stored


def test_tests_do_not_touch_project_config() -> None:
    """Garde-fou : le dépôt ne doit pas contenir d'ai_config.json écrit par un test."""
    assert not (PROJECT_DIR / "ai_config.json").exists(), (
        "un test a écrit dans le répertoire du projet au lieu du bac à sable"
    )


# --- Moteur : la configuration IA atteint bien llama-cpp --------------------


@pytest.fixture()
def gguf_sandbox(sandbox: Path) -> Path:
    (sandbox / "model.gguf").write_bytes(b"GGUF")
    (sandbox / "datasource_config.json").write_text(
        json.dumps({"gguf_path": str(sandbox / "model.gguf"), "llm_backend": "gguf"}),
        encoding="utf-8",
    )
    return sandbox


@pytest.fixture()
def fake_llama(monkeypatch: pytest.MonkeyPatch):
    """Remplace `llama_cpp` pour ne pas charger de poids."""
    calls: dict[str, Any] = {}

    class FakeLlama:
        def __init__(self, **kwargs: Any) -> None:
            calls["load"] = kwargs

        def create_chat_completion(self, _messages: Any, **kwargs: Any) -> dict[str, Any]:
            calls["generate"] = kwargs
            return {"choices": [{"message": {"content": "ok"}}]}

    module = types.ModuleType("llama_cpp")
    module.Llama = FakeLlama  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "llama_cpp", module)
    return calls


def _engine(base_dir: Path):
    from smartpms.config import DataSourceConfig
    from smartpms.llm import LLMService

    config = DataSourceConfig(base_dir, base_dir / "datasource_config.json")
    return LLMService(config)


def test_engine_uses_config_load_params(gguf_sandbox: Path, fake_llama: dict) -> None:
    engine = _engine(gguf_sandbox)
    engine.warmup()
    load = fake_llama["load"]
    assert load["n_ctx"] == ai_config.DEFAULTS["n_ctx"]
    assert load["n_batch"] == ai_config.DEFAULTS["n_batch"]
    # n_threads = 0 signifie « tous les cœurs », pas « aucun ».
    assert load["n_threads"] > 0
    assert load["verbose"] is False


def test_engine_reloads_when_load_params_change(gguf_sandbox: Path, fake_llama: dict) -> None:
    engine = _engine(gguf_sandbox)
    engine.warmup()
    ai_config.save(gguf_sandbox, {"n_ctx": 16384, "n_threads": 3, "n_batch": 512})
    engine.chat([{"role": "user", "content": "x"}])
    assert fake_llama["load"]["n_ctx"] == 16384
    assert fake_llama["load"]["n_threads"] == 3


def test_engine_reuses_loaded_model(gguf_sandbox: Path, fake_llama: dict) -> None:
    engine = _engine(gguf_sandbox)
    engine.chat([{"role": "user", "content": "x"}])
    engine.chat([{"role": "user", "content": "y"}])
    assert "load" in fake_llama, "le modèle doit être mis en cache entre deux questions"
    assert fake_llama["generate"]  # la seconde passe par le modèle en cache


def test_engine_unload_forces_reload(gguf_sandbox: Path, fake_llama: dict) -> None:
    engine = _engine(gguf_sandbox)
    engine.warmup()
    engine.unload()
    engine.warmup()
    assert engine.model_status()["loaded"] is True


def test_engine_uses_generation_params(gguf_sandbox: Path, fake_llama: dict) -> None:
    engine = _engine(gguf_sandbox)
    ai_config.save(gguf_sandbox, {"max_tokens": 64, "temperature": 0.9})
    engine.chat([{"role": "user", "content": "x"}])
    assert fake_llama["generate"]["max_tokens"] == 64
    assert fake_llama["generate"]["temperature"] == 0.9


def test_engine_explicit_params_win(gguf_sandbox: Path, fake_llama: dict) -> None:
    engine = _engine(gguf_sandbox)
    engine.chat([{"role": "user", "content": "x"}], max_tokens=7, temperature=0.0)
    assert fake_llama["generate"]["max_tokens"] == 7


def test_engine_reports_missing_model(gguf_sandbox: Path) -> None:
    (gguf_sandbox / "model.gguf").unlink()
    status = _engine(gguf_sandbox).model_status()
    assert status["available"] is False
    assert status["error"]


def test_engine_warmup_keeps_error_for_status(gguf_sandbox: Path) -> None:
    (gguf_sandbox / "model.gguf").unlink()
    engine = _engine(gguf_sandbox)
    with pytest.raises(RuntimeError):
        engine.warmup()
    # L'échec doit être explicable dans l'interface, pas seulement dans un traceback.
    assert engine.model_status()["error"]


def test_engine_status_carries_model_name(gguf_sandbox: Path) -> None:
    status = _engine(gguf_sandbox).model_status()
    assert status["model_name"] == "model.gguf"
    assert status["config"]["n_ctx"] == ai_config.DEFAULTS["n_ctx"]


def test_engine_warmup_skipped_for_llamafile(sandbox: Path, monkeypatch) -> None:
    (sandbox / "datasource_config.json").write_text(
        json.dumps({"llm_backend": "llamafile", "llamafile_url": ""}), encoding="utf-8"
    )
    engine = _engine(sandbox)
    engine.warmup()  # aucun modèle local à charger : ne doit rien lever
    assert engine.model_status()["backend"] == "llamafile"