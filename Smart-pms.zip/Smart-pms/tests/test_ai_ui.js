/* Test du pilotage du module IA dans l'interface, exécuté hors navigateur :

     node tests/test_ai_ui.js      (depuis la racine du projet)

   Le script inline de static/index.html est exécuté dans un contexte Node avec
   un DOM minimal et un `fetch` simulé, puis les fonctions de l'onglet IA sont
   appelées pour vérifier ce qu'elles écrivent réellement dans la page. Complète
   pytest (côté serveur) pour ce qui ne peut pas être exécuté sans navigateur. */
const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('static/index.html', 'utf8');
const script = /<script>([\s\S]*?)<\/script>/.exec(html)[1];

/* --- DOM minimal ------------------------------------------------------- */
class El {
  constructor(id) {
    this.id = id;
    this.value = '';
    this.textContent = '';
    this.innerHTML = '';
    this.className = '';
    this.disabled = false;
    this.dataset = {};
    /* classList réel, synchronisé avec className : le code de la page écrit
       `el.className` en direct pour la pastille et utilise `classList.toggle`
       pour la barre de progression. Un shim inerte ferait passer n'importe
       quelle assertion, donc on implémente les quatre opérations. */
    const el = this;
    this.classList = {
      _tokens: () => el.className.split(/\s+/).filter(Boolean),
      add(...t) { const s = new Set(this._tokens()); t.forEach(x => s.add(x)); el.className = [...s].join(' '); },
      remove(...t) { const s = this._tokens().filter(x => !t.includes(x)); el.className = s.join(' '); },
      contains(t) { return this._tokens().includes(t); },
      toggle(t, force) {
        const has = this.contains(t);
        const want = force === undefined ? !has : !!force;
        if (want) this.add(t); else this.remove(t);
        return want;
      },
    };
    this.style = {};
    this.children = [];
    this.options = [];
    this.selected = false;
    this.listeners = {};
  }
  addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
  querySelector(sel) { return new El(this.id + sel); }
  querySelectorAll() { return []; }
  appendChild(child) { this.children.push(child); return child; }
  removeChild() {}
  scrollIntoView() {}
  getAttribute() { return null; }
  setAttribute() {}
  remove() {}
  closest() { return null; }
  focus() {}
}

const elements = new Map();
const getEl = id => {
  if (!elements.has(id)) elements.set(id, new El(id));
  return elements.get(id);
};

/* Valeurs initiales des champs de réglages, pour vérifier le remplissage. */
['aiDetail', 'aiModelSelect', 'aiCfgCtx', 'aiCfgThreads', 'aiCfgBatch', 'aiCfgMaxTokens',
 'aiCfgTemp', 'aiCfgTopP', 'aiCfgRepeat', 'aiCfgMaxChars', 'aiCfgDetail', 'aiChatInput'
].forEach(id => { elements.set(id, new El(id)); });
getEl('aiCfgDetail').value = 'standard';
/* Le DOM de test ne parse pas le HTML : on reporte l'état initial des classes
   que le markup pose, sinon la barre semblerait visible au repos. */
getEl('aiProgress').className = 'ai-progress d-none';
getEl('aiDot').className = 'ai-dot';

const document_ = {
  getElementById: getEl,
  querySelector: sel => getEl(sel),
  querySelectorAll: () => [],
  createElement: tag => new El(tag),
  addEventListener() {},
  body: new El('body'),
  cookie: '',
};

/* --- Réponses simulées -------------------------------------------------- */
const calls = [];
const responses = {
  '/api/ai/status': {
    engine: { backend: 'gguf', available: true, loaded: false, model_name: 'm.gguf', error: null,
              config: { n_ctx: 8192, temperature: 0.3, max_tokens: 900 } },
    detail_levels: { rapide: 'Agrégats seuls', standard: 'Positions principales', complet: 'Tout' },
    default_detail: 'standard',
    scope: 'Tous les portefeuilles',
    model: { configured: '/models/m.gguf', resolved: '/models/m.gguf', exists: true, size_mb: 1800 },
    models: [
      { name: 'm.gguf', path: '/models/m.gguf', size_mb: 1800, dir: '/models' },
      { name: 'g.gguf', path: '/models/g.gguf', size_mb: 900, dir: '/models' },
    ],
    bounds: { n_ctx: [2048, 131072] },
    defaults: { n_ctx: 8192 },
  },
  '/api/ai/config': { n_ctx: 8192, n_threads: 0, n_batch: 2048, max_tokens: 900,
                     temperature: 0.3, top_p: 0.9, repeat_penalty: 1.1,
                     max_context_chars: 20000, default_detail: 'standard' },
  '/api/ai/context': { text: 'PORTEFEUILLES:\n- Test Fund', detail: 'standard',
                       scope: 'Tous les portefeuilles', chars: 4722, truncated: false },
  '/api/ai/estimate': { detail: 'standard', context_chars: 4722, prompt_chars: 7722,
                        context_truncated: false, max_tokens: 900, estimate_seconds: 92.5,
                        model_loaded: false, extra_seconds_if_loading: 8 },
  '/api/ai/warmup': { ok: true, seconds: 4.2, engine: { loaded: true } },
  '/api/ai/model': { backend: 'gguf', path: '/models/m.gguf', available: true, loaded: true },
  '/api/config/datasource': { ok: true },
  '/api/ai/chat': { answer: 'ok', verification: { ok: true, warning: '' } },
};

/* Le script inline définit son propre `api()` : on simule donc `fetch`. */
const fetch = async (url, opts = {}) => {
  const method = opts.method || 'GET';
  const key = String(url).split('?')[0];
  const body = opts.body ? JSON.parse(opts.body) : undefined;
  calls.push({ method, url, body });
  if (method === 'POST' && key === '/api/ai/config') {
    responses['/api/ai/config'] = { ...responses['/api/ai/config'], ...body };
    return { ok: true, status: 200, json: async () => ({ ok: true, config: responses['/api/ai/config'], engine_loaded: false }) };
  }
  if (!(key in responses)) {
    return { ok: false, status: 404, json: async () => ({ error: 'route non simulée: ' + key }) };
  }
  return { ok: true, status: 200, json: async () => responses[key] };
};

const sandbox = {
  document: document_,
  window: {},
  console,
  fetch,
  setTimeout, clearTimeout, setInterval, clearInterval,
  Chart: function () { return { destroy() {} }; },
  bootstrap: { Toast: function () { this.show = () => {}; } },
  URL, Date, Math, JSON, Number, String, Object, Array, isNaN, parseFloat, parseInt,
  localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  MutationObserver: function () { this.observe = () => {}; this.disconnect = () => {}; },
  ResizeObserver: function () { this.observe = () => {}; this.disconnect = () => {}; },
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;

vm.createContext(sandbox);
vm.runInContext(script, sandbox, { filename: 'index.html#inline' });

/* --- Vérifications ----------------------------------------------------- */
let failures = 0;
function check(label, condition, detail) {
  if (condition) { console.log('  ok   ' + label); return; }
  failures += 1;
  console.log('  FAIL ' + label + (detail ? '  → ' + detail : ''));
}

(async () => {
  console.log('loadAIStatus');
  const status = await sandbox.loadAIStatus();
  check('niveaux reconstruits', getEl('aiDetail').innerHTML.includes('rapide'), getEl('aiDetail').innerHTML.slice(0, 90));
  check('défaut affiché', getEl('aiDetail').innerHTML.includes('Défaut (standard)'));
  check('modèles listés', getEl('aiModelSelect').innerHTML.includes('m.gguf') && getEl('aiModelSelect').innerHTML.includes('g.gguf'));
  check('modèle actif sélectionné', getEl('aiModelSelect').innerHTML.includes('selected'));
  check('périmètre affiché', getEl('aiScopeOut').textContent === 'Tous les portefeuilles', getEl('aiScopeOut').textContent);
  check('niveau par défaut synchronisé', getEl('aiCfgDetail').value === 'standard');

  console.log('pastille d\'état');
  check('modèle dispo non chargé → idle', getEl('aiDot').className === 'ai-dot idle', getEl('aiDot').className);
  check('libellé « non chargé »', getEl('aiState').textContent === 'Modèle non chargé', getEl('aiState').textContent);
  check('métadonnées affichées', getEl('aiModelMeta').textContent.includes('fenêtre 8192 tokens'), getEl('aiModelMeta').textContent);
  check('nom du modèle affiché', getEl('aiModelMeta').textContent.includes('m.gguf'));

  responses['/api/ai/status'].engine.loaded = true;
  await sandbox.loadAIStatus();
  check('modèle chargé → on', getEl('aiDot').className === 'ai-dot on', getEl('aiDot').className);
  check('libellé « chargé »', getEl('aiState').textContent === 'Modèle chargé');

  /* Un modèle chargé ne peut pas être « absent » : on remet donc `loaded` à
     faux, sinon la pastille affiche légitimement l'état précédent. */
  responses['/api/ai/status'].engine.available = false;
  responses['/api/ai/status'].engine.loaded = false;
  responses['/api/ai/status'].engine.error = 'Fichier .gguf introuvable.';
  await sandbox.loadAIStatus();
  check('modèle absent → off', getEl('aiDot').className === 'ai-dot off', getEl('aiDot').className);
  check('cause affichée', getEl('aiModelMeta').textContent.includes('introuvable'), getEl('aiModelMeta').textContent);
  responses['/api/ai/status'].engine.available = true;
  responses['/api/ai/status'].engine.loaded = false;
  responses['/api/ai/status'].engine.error = null;
  await sandbox.loadAIStatus();

  console.log('barre de progression');
  check('barre masquée au repos', getEl('aiProgress').classList.contains('d-none'));
  sandbox.aiChatLoading(true);
  check('barre visible pendant une opération', !getEl('aiProgress').classList.contains('d-none'));
  check('pastille en attente', getEl('aiDot').className === 'ai-dot wait', getEl('aiDot').className);
  sandbox.aiChatLoading(false);
  check('barre masquée ensuite', getEl('aiProgress').classList.contains('d-none'));
  check('pastille revenues à l\'état réel', getEl('aiDot').className === 'ai-dot idle', getEl('aiDot').className);

  console.log('loadAIConfigForm');
  await sandbox.loadAIConfigForm();
  check('n_ctx rempli', getEl('aiCfgCtx').value === 8192, getEl('aiCfgCtx').value);
  check('temperature remplie', getEl('aiCfgTemp').value === 0.3);
  check('plafond contexte rempli', getEl('aiCfgMaxChars').value === 20000);

  console.log('loadAIContext');
  await sandbox.loadAIContext();
  check('contexte affiché', getEl('aiContextText').textContent.includes('PORTEFEUILLES'));
  check('métadonnées affichées', getEl('aiContextMeta').textContent.includes('4722 caractères'), getEl('aiContextMeta').textContent);

  console.log('aiEstimate');
  await sandbox.aiEstimate();
  check('estimation affichée', getEl('aiEstimateOut').textContent.includes('92.5 s'), getEl('aiEstimateOut').textContent);
  check('chargement mentionné', getEl('aiEstimateOut').textContent.includes('+8 s'));

  console.log('aiWarmup');
  await sandbox.aiWarmup();
  check('temps de chargement affiché', getEl('aiEstimateOut').textContent.includes('4.2 s'));
  check('barre de progression masquée après', getEl('aiProgress').classList.contains('d-none'));
  check('bouton rétabli', getEl('aiWarmupBtn').innerHTML.includes('Préparer'), getEl('aiWarmupBtn').innerHTML);

  console.log('saveAIConfig');
  getEl('aiCfgCtx').value = '16384';
  getEl('aiCfgThreads').value = '4';
  await sandbox.saveAIConfig();
  const saved = calls.filter(c => c.url === '/api/ai/config' && c.method === 'POST').pop();
  check('n_ctx envoyé', saved.body.n_ctx === 16384, JSON.stringify(saved.body));
  check('n_threads envoyé', saved.body.n_threads === 4);
  check('aucune clé nulle envoyée', !Object.values(saved.body).includes(null));
  check('message de confirmation', getEl('aiCfgStatus').innerHTML.includes('Enregistré'));

  console.log('applyAIModelSelection');
  getEl('aiModelSelect').value = '/models/g.gguf';
  await sandbox.applyAIModelSelection();
  const ds = calls.filter(c => c.url === '/api/config/datasource').pop();
  check('gguf_path écrit', ds.body.gguf_path === '/models/g.gguf', JSON.stringify(ds.body));

  console.log('sendAIQuestion');
  getEl('aiChatInput').value = 'répartition sectorielle ?';
  getEl('aiDetail').value = 'complet';
  await sandbox.sendAIQuestion();
  const chat = calls.filter(c => c.url === '/api/ai/chat').pop();
  check('niveau transmis', chat.body.detail === 'complet', JSON.stringify(chat.body));
  check('question transmise', chat.body.question === 'répartition sectorielle ?');

  console.log('');
  console.log(failures === 0 ? 'TOUT PASSE' : failures + ' ECHEC(S)');
  process.exit(failures === 0 ? 0 : 1);
})();