import os, json, secrets, math, re
from datetime import datetime, timedelta
from flask import Flask, jsonify, request, session, send_from_directory
import pandas as pd

app = Flask(__name__, static_folder='static', static_url_path='')
app.secret_key = secrets.token_hex(32)
app.permanent_session_lifetime = timedelta(hours=8)

CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'datasource_config.json')

def load_config():
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except:
        return {}

def get_parquet_path(key, default):
    cfg = load_config()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    default_path = os.path.join(base_dir, default)
    p = cfg.get(key)
    if p:
        if not os.path.isabs(p):
            p = os.path.join(base_dir, p)
        if os.path.exists(p):
            return p
    return default_path

PARQUET_PATH = get_parquet_path('portfolios_path', 'portfolios.parquet')
HOLDINGS_PATH = get_parquet_path('holdings_path', 'holdings.parquet')
ESG_PATH = get_parquet_path('esg_path', 'esg.parquet')
OPERATIONS_PATH = get_parquet_path('operations_path', 'operations.parquet')
INVENTORIES_PATH = get_parquet_path('inventories_path', 'inventories.parquet')
CASH_PATH = get_parquet_path('cash_path', 'cash.parquet')
CONSTRAINTS_PATH = get_parquet_path('constraints_path', 'constraints.parquet')
EXCLUSIONS_PATH = get_parquet_path('exclusions_path', 'exclusions.parquet')

EXCLUSION_ISIN_COLUMNS = ('isin', 'ISIN', 'security_isin', 'asset_isin', 'fund_isin')
EXCLUSION_NAME_COLUMNS = ('security_name', 'name', 'security', 'asset_name', 'instrument_name', 'description')
EXCLUSION_TYPE_COLUMNS = ('exclusion', 'exclusion_type', 'type', 'excluded_type', 'motif')
EXCLUSION_REASON_COLUMNS = ('exclusion_reason', 'reason', 'comment', 'commentaire', 'exclusion_comment')

ESG_SI_COLUMNS = ('si', 'si_pct', 'si_percent', 'pct_si', 'sustainable_investment', 'sustainable_invest', 'sri_share', '%si')
ESG_TAXONOMIE_COLUMNS = ('taxonomie', 'taxonomy', 'taxonomy_alignment', 'taxo', 'taxonomie_alignment')
ESG_LABEL_COLUMNS = ('esg_label', 'label', 'esglabel', 'label_esg', 'sri_label', 'esg_label_name')

USERS = {
    'admin': {'password': 'admin123', 'role': 'admin', 'client_id': None},
    'hamdi': {'password': 'hamdi123', 'role': 'user', 'client_id': 'client_hamdi'},
}

CLIENTS = [
    {"id": "client_hamdi", "name": "Hamdi", "email": "hamdi@example.com", "phone": "+33 6 00 00 00 00", "risk_profile": "moderate", "notes": ""},
]

SECTORS = [
    "A\u00e9ro & D\u00e9fense", "Automobile", "Consommation", "Coop\u00e9ratif",
    "Cybers\u00e9curit\u00e9", "Finance", "Fonds", "Industrie",
    "Infrastructure", "Luxe", "Mati\u00e8res premi\u00e8res",
    "Semi-conducteurs", "Services publics", "Sant\u00e9",
    "Technologie", "T\u00e9l\u00e9com", "\u00c9nergie"
]

COUNTRIES = ["CH", "CN", "DE", "FR", "IE", "IT", "NL", "TW", "UK", "US"]

BENCHMARKS = [
    {"id": 1, "name": "Euro Stoxx 50", "components": [{"ticker": "^STOXX50E", "label": "Euro Stoxx 50", "weight": 50}, {"ticker": "^FCHI", "label": "CAC 40", "weight": 25}, {"ticker": "^GDAXI", "label": "DAX", "weight": 25}]}
]

def df_to_json(df):
    df = df.astype(object)
    for col in df.columns:
        mask = df[col].isna()
        if mask.any():
            df.loc[mask, col] = None
    return df.to_dict('records')

def load_portfolios():
    try:
        df = pd.read_parquet(PARQUET_PATH)
    except:
        return []
    df = df.copy()
    def _norm_group(aliases, target):
        col = next((c for c in aliases if c in df.columns), None)
        if col is not None:
            if col != target:
                df[target] = df[col]
        elif target not in df.columns:
            df[target] = None
    _norm_group(UG_COLUMNS, 'ug')
    _norm_group(OG_COLUMNS, 'og')
    return df_to_json(df)

def save_portfolios(portfolios):
    df = pd.DataFrame(portfolios)
    df.to_parquet(PARQUET_PATH, index=False)

def load_constraints():
    try:
        df = pd.read_parquet(CONSTRAINTS_PATH)
        return df_to_json(df)
    except:
        return []

def save_constraints(constraints):
    df = pd.DataFrame(constraints)
    df.to_parquet(CONSTRAINTS_PATH, index=False)

CONSTRAINT_LABELS = {
    'max_position_weight': 'Poids max par position (%)',
    'min_position_weight': 'Poids min par position (%)',
    'max_category_weight': 'Poids max par catégorie (%)',
    'min_category_weight': 'Poids min par catégorie (%)',
    'max_sector_weight': 'Poids max par secteur (%)',
    'min_sector_weight': 'Poids min par secteur (%)',
    'max_country_weight': 'Poids max par pays (%)',
    'min_country_weight': 'Poids min par pays (%)',
    'max_issuer_weight': 'Poids max par émetteur (%)',
    'min_issuer_weight': 'Poids min par émetteur (%)',
    'max_currency_weight': 'Poids max par devise (%)',
    'min_currency_weight': 'Poids min par devise (%)',
    'max_isin_weight': 'Poids max par ISIN (%)',
    'min_isin_weight': 'Poids min par ISIN (%)',
    'max_isin_list_weight': 'Poids max par liste d\'ISIN (%)',
    'min_isin_list_weight': 'Poids min par liste d\'ISIN (%)',
    'min_esg_score': 'Score ESG minimum',
    'min_cash_pct': 'Cash minimum (% AuM)',
    'max_cash_pct': 'Cash maximum (% AuM)',
}

# type -> (champ de groupement, émetteur dérivé ?)
GROUP_DIMENSIONS = {
    'max_category_weight': ('category', False),
    'min_category_weight': ('category', False),
    'max_sector_weight': ('sector', False),
    'min_sector_weight': ('sector', False),
    'max_country_weight': ('country', False),
    'min_country_weight': ('country', False),
    'max_issuer_weight': ('issuer', True),
    'min_issuer_weight': ('issuer', True),
    'max_currency_weight': ('currency', False),
    'min_currency_weight': ('currency', False),
}

ISIN_TYPES = ('max_isin_weight', 'min_isin_weight', 'max_isin_list_weight', 'min_isin_list_weight')

def _cmp(val, op, threshold):
    try:
        if op == '<=': return val <= threshold
        if op == '>=': return val >= threshold
        if op == '<': return val < threshold
        if op == '>': return val > threshold
        if op == '==': return val == threshold
    except:
        return False
    return True

CATEGORY_LIKE_COLUMNS = ('category', 'asset_class', 'asset_classification', 'assetclass', 'instrument_type', 'security_type', 'instrument', 'class', 'type')
BOND_FIELDS = ('maturity_date', 'maturity', 'rating', 'coupon', 'yield', 'bond_rating', 'bond_maturity')
MARKET_EXPOSURE_COLUMNS = ('market_exposure', 'marketExposure', 'MarketExposure', 'market_exp', 'Market_Exposure', 'mkt_exposure', 'exposure', 'exposure_pct')
ISSUER_LIKE_COLUMNS = ('issuer', 'Issuer', 'émetteur', 'emetteur', 'issue', 'company', 'Company', 'institution', 'entity')
UG_COLUMNS = ('ug', 'unitegestion', 'unite_gestion', 'unite_de_gestion', 'unite-gestion', 'UG')
OG_COLUMNS = ('og', 'orientationgestion', 'orientation_gestion', 'orientation_de_gestion', 'orientation-gestion', 'OG')

def _non_empty(v):
    if v is None:
        return False
    if isinstance(v, float) and (pd.isna(v) or math.isnan(v)):
        return False
    return str(v).strip() not in ('', 'nan', 'None')

def _has_bond_fields(row):
    return any(_non_empty(row.get(f)) for f in BOND_FIELDS)

def _name_is_bond(name):
    return bool(re.search(r'\s+\d+(?:\.\d+)?%?\s+(?:\d{4}|\d{2}/\d{2})\s*$', str(name or '').strip()))

def normalize_asset_type(value):
    v = str(value or '').strip().lower()
    if not v:
        return None
    if any(k in v for k in ('oblig', 'bond', 'fix', 'debt', 'credit')):
        return 'Obligation'
    if any(k in v for k in ('action', 'equit', 'stock', 'share')):
        return 'Action'
    return None

def infer_asset_type(row):
    if _has_bond_fields(row) or _name_is_bond(row.get('name')):
        return 'Obligation'
    return 'Action'

def enrich_holdings(df):
    """Garantit une colonne 'category' exploitable (Action/Obligation) sur chaque ligne."""
    if df is None or df.empty:
        return df
    df = df.copy()
    cat_col = next((c for c in CATEGORY_LIKE_COLUMNS if c in df.columns), None)
    if cat_col is not None and cat_col != 'category':
        df['category'] = df[cat_col]
    def _resolve(v):
        norm = normalize_asset_type(v)
        if norm:
            return norm
        return v if _non_empty(v) else None
    if 'category' in df.columns:
        df['category'] = df['category'].apply(_resolve)
        missing = df['category'].isna()
        if missing.any():
            df.loc[missing, 'category'] = df.loc[missing].apply(infer_asset_type, axis=1)
    else:
        df['category'] = df.apply(infer_asset_type, axis=1)
    me_col = next((c for c in MARKET_EXPOSURE_COLUMNS if c in df.columns), None)
    if me_col is not None:
        df['market_exposure'] = df[me_col]
    elif 'market_exposure' not in df.columns:
        df['market_exposure'] = None
    df['market_exposure'] = pd.to_numeric(df['market_exposure'], errors='coerce')
    iss_col = next((c for c in ISSUER_LIKE_COLUMNS if c in df.columns), None)
    if iss_col is not None:
        df['issuer'] = df[iss_col]
    elif 'issuer' not in df.columns:
        df['issuer'] = None
    df['issuer'] = df['issuer'].astype(str).str.strip().replace({'': None, 'nan': None, 'None': None})
    missing = df['issuer'].isna()
    df.loc[missing, 'issuer'] = df[missing].apply(derive_issuer, axis=1)
    df.loc[df['issuer'].astype(str).str.strip() == '', 'issuer'] = None
    return df

def derive_issuer(row):
    name = str(row.get('name') or '').strip()
    if str(row.get('category') or '').lower() == 'obligation' or _name_is_bond(name):
        issuer = re.sub(r'\s+\d+(?:\.\d+)?%?\s+(?:\d{4}|\d{2}/\d{2})\s*$', '', name).strip()
        if issuer:
            return issuer
    return name or row.get('ticker') or '--'

def check_constraints(holdings, cash_df, fund_id=''):
    holdings = enrich_holdings(holdings)
    constraints = [c for c in load_constraints() if c.get('enabled', True)]
    total_aum = float(holdings['market_value'].sum()) if not holdings.empty else 0.0
    if fund_id and not holdings.empty:
        holdings = holdings[holdings['fund_id'] == fund_id]
        total_aum = float(holdings['market_value'].sum()) if not holdings.empty else 0.0
    if not cash_df.empty and fund_id:
        cash_df = cash_df[cash_df['fund_id'] == fund_id]

    avail_cash = 0.0
    if not cash_df.empty:
        for r in cash_df.to_dict('records'):
            a = r.get('available')
            if a is None or pd.isna(a):
                a = (r.get('balance') or 0) - (r.get('blocked') or 0)
            avail_cash += float(a or 0)

    records = holdings.to_dict('records') if not holdings.empty else []
    results = []
    for c in constraints:
        ctype = c.get('type', '')
        op = c.get('operator') or '<='
        try:
            value = float(c.get('value') or 0)
        except:
            value = 0.0
        res = {
            "id": c.get('id'), "name": c.get('name') or ctype, "type": ctype,
            "operator": op, "value": value, "current": None, "status": "NO_DATA",
            "violations": [],
        }
        if ctype in ('min_cash_pct', 'max_cash_pct'):
            cur = round(avail_cash / total_aum * 100, 2) if total_aum else None
            res["current"] = cur
            if cur is None:
                res["status"] = "NO_DATA"
            elif _cmp(cur, op, value):
                res["status"] = "OK"
            else:
                res["status"] = "VIOLATION"
                res["violations"].append({"detail": "Cash disponible %s%% vs limite %s%%" % (cur, value)})
            results.append(res)
            continue
        if ctype in GROUP_DIMENSIONS:
            field, derived = GROUP_DIMENSIONS[ctype]
            groups = {}
            for r in records:
                key = (str(r.get('issuer') or '').strip() or derive_issuer(r)) if derived else (r.get(field) or '--')
                groups[key] = groups.get(key, 0.0) + float(r.get('weight') or 0)
            param = str(c.get('param') or '').strip()
            if param.lower() in ('*', 'all', 'tous', 'toutes'):
                param = ''
            if param and param != '--':
                groups = {k: v for k, v in groups.items() if k == param}
            if not groups:
                res["status"] = "NO_DATA"
            else:
                vals = list(groups.values())
                res["current"] = round((max if op.startswith('>') else min)(vals), 2)
                offenders = [(k, v) for k, v in groups.items() if not _cmp(v, op, value)]
                if offenders:
                    res["status"] = "VIOLATION"
                    res["violations"] = [{"detail": "%s: %s%%" % (k, round(v, 2))} for k, v in sorted(offenders, key=lambda x: -x[1])]
                else:
                    res["status"] = "OK"
            results.append(res)
            continue
        if ctype in ISIN_TYPES:
            isins = set(x.strip().upper() for x in re.split(r'[;,\s]+', str(c.get('param') or '')) if x.strip())
            if not isins:
                res["status"] = "NO_DATA"
                results.append(res)
                continue
            matched = [r for r in records if str(r.get('isin') or '').strip().upper() in isins]
            cur = round(sum(float(r.get('weight') or 0) for r in matched), 2)
            res["current"] = cur
            if not matched:
                res["status"] = "NO_DATA"
            elif _cmp(cur, op, value):
                res["status"] = "OK"
            else:
                res["status"] = "VIOLATION"
                res["violations"] = [{"ticker": r.get('ticker'), "name": r.get('name'), "detail": "poids=%s%%" % round(float(r.get('weight') or 0), 2)} for r in matched]
            results.append(res)
            continue
        field = {'min_esg_score': 'esg_score'}.get(ctype, 'weight')
        offenders = []
        for r in records:
            v = r.get(field)
            if v is None or pd.isna(v):
                continue
            v = float(v)
            if not _cmp(v, op, value):
                offenders.append({"ticker": r.get('ticker'), "name": r.get('name'), "detail": "%s=%s" % (field, round(v, 2))})
        values = [float(r.get(field)) for r in records if r.get(field) is not None and not pd.isna(r.get(field))]
        if not values:
            res["status"] = "NO_DATA"
        else:
            res["current"] = round((min if op.startswith('>') else max)(values), 2)
            if offenders:
                res["status"] = "VIOLATION"
                res["violations"] = offenders[:20]
            else:
                res["status"] = "OK"
        results.append(res)
    return {
        "checked_at": datetime.now().isoformat(),
        "total_aum": round(total_aum, 2),
        "cash_available": round(avail_cash, 2),
        "constraints_total": len(constraints),
        "violation_count": sum(1 for r in results if r["status"] == "VIOLATION"),
        "results": results,
    }

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session:
            return jsonify({"error": "Unauthorized", "login_required": True}), 401
        return f(*args, **kwargs)
    return decorated

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    username = data.get('username', '').strip().lower()
    password = data.get('password', '')
    user = USERS.get(username)
    if not user or user['password'] != password:
        return jsonify({"error": "Invalid credentials"}), 401
    session['user'] = username
    session['role'] = user['role']
    session['client_id'] = user['client_id']
    return jsonify({"username": username, "role": user['role'], "client_id": user['client_id']})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({"ok": True})

@app.route('/api/me')
@login_required
def api_me():
    return jsonify({"username": session['user'], "role": session['role'], "client_id": session.get('client_id')})

@app.route('/api/portfolio')
@login_required
def api_portfolio():
    portfolios = load_portfolios()
    return jsonify(portfolios)

@app.route('/api/portfolio', methods=['POST'])
@login_required
def api_create_portfolio():
    data = request.get_json()
    pid = (data.get('fund_code') or '').strip()
    if not pid:
        pid = f"fund_{secrets.token_hex(4)}"
    pf = {
        "id": pid,
        "fund_code": data.get('fund_code', ''),
        "fund_name": data.get('fund_name', ''),
        "fund_currency": data.get('fund_currency', 'EUR'),
        "fund_manager": data.get('fund_manager', ''),
        "custodian": data.get('custodian', ''),
        "entity": data.get('entity', ''),
        "classification": data.get('classification', ''),
        "ug": data.get('ug', ''),
        "og": data.get('og', ''),
        "portfolio_year": data.get('portfolio_year', None),
        "initial_aum": data.get('initial_aum', None),
        "created_at": datetime.now().isoformat()
    }
    portfolios = load_portfolios()
    portfolios.append(pf)
    save_portfolios(portfolios)
    return jsonify(pf), 201

@app.route('/api/portfolio/<portfolio_id>', methods=['DELETE'])
@login_required
def api_delete_portfolio(portfolio_id):
    portfolios = load_portfolios()
    portfolios = [p for p in portfolios if p['id'] != portfolio_id]
    save_portfolios(portfolios)
    return jsonify({"ok": True})

@app.route('/api/holdings')
@login_required
def api_holdings():
    fund_id = request.args.get('fund_id', '')
    try:
        df = pd.read_parquet(HOLDINGS_PATH)
        if fund_id:
            df = df[df['fund_id'] == fund_id]
        df = enrich_holdings(df)
        return jsonify(df_to_json(df))
    except:
        return jsonify([])

@app.route('/api/esg')
@login_required
def api_esg():
    try:
        df = pd.read_parquet(ESG_PATH)
    except:
        return jsonify([])
    if df is None or df.empty:
        return jsonify([])
    df = df.copy()
    def _pick(aliases):
        return next((c for c in aliases if c in df.columns), None)
    c = _pick(ESG_SI_COLUMNS)
    if c is not None:
        df['si'] = df[c]
    elif 'si' not in df.columns:
        df['si'] = None
    df['si'] = pd.to_numeric(df['si'], errors='coerce')
    c = _pick(ESG_TAXONOMIE_COLUMNS)
    if c is not None:
        df['taxonomie'] = df[c]
    elif 'taxonomie' not in df.columns:
        df['taxonomie'] = None
    c = _pick(ESG_LABEL_COLUMNS)
    if c is not None:
        df['esg_label'] = df[c]
    elif 'esg_label' not in df.columns:
        df['esg_label'] = None
    for col in ('taxonomie', 'esg_label'):
        df[col] = df[col].astype(str).str.strip().replace({'': None, 'nan': None, 'None': None})
    return jsonify(df_to_json(df))

@app.route('/api/operations')
@login_required
def api_operations():
    fund_id = request.args.get('fund_id', '')
    date_from = request.args.get('from', '')
    date_to = request.args.get('to', '')
    try:
        df = pd.read_parquet(OPERATIONS_PATH)
        if fund_id:
            df = df[df['fund_id'] == fund_id]
        if 'date' in df.columns:
            if date_from:
                df = df[df['date'].astype(str) >= date_from]
            if date_to:
                df = df[df['date'].astype(str) <= date_to]
        return jsonify(df_to_json(df))
    except:
        return jsonify([])

@app.route('/api/inventories')
@login_required
def api_inventories():
    try:
        df = pd.read_parquet(INVENTORIES_PATH)
        return jsonify(df_to_json(df))
    except:
        return jsonify([])

@app.route('/api/exclusions')
@login_required
def api_exclusions():
    try:
        df = pd.read_parquet(EXCLUSIONS_PATH)
    except:
        return jsonify([])
    if df is None or df.empty:
        return jsonify([])
    df = df.copy()
    def _pick(aliases):
        return next((c for c in aliases if c in df.columns), None)
    out = pd.DataFrame()
    c = _pick(EXCLUSION_ISIN_COLUMNS)
    if c is not None:
        out['isin'] = df[c].astype(str).str.strip().str.upper()
    c = _pick(EXCLUSION_NAME_COLUMNS)
    if c is not None:
        out['name'] = df[c]
    c = _pick(EXCLUSION_TYPE_COLUMNS)
    if c is not None:
        out['exclusion'] = df[c]
    c = _pick(EXCLUSION_REASON_COLUMNS)
    if c is not None:
        out['reason'] = df[c]
    for col in ('isin', 'name', 'exclusion', 'reason'):
        if col not in out.columns:
            out[col] = None
        out[col] = out[col].astype(str).str.strip().replace({'': None, 'nan': None, 'None': None})
    return jsonify(df_to_json(out))

@app.route('/api/cash')
@login_required
def api_cash():
    try:
        df = pd.read_parquet(CASH_PATH)
        return jsonify(df_to_json(df))
    except:
        return jsonify([])

@app.route('/api/portfolio/export')
@login_required
def api_portfolio_export():
    import csv, io
    si = io.StringIO()
    w = csv.writer(si)
    w.writerow(['Fund Code', 'Fund Name', 'Fund Currency', 'Fund Manager', 'Custodian', 'Entity', 'Classification', 'UG', 'OG', 'Portfolio Year', 'Initial AuM', 'Created'])
    portfolios = load_portfolios()
    for p in portfolios:
        w.writerow([p.get('fund_code',''), p.get('fund_name',''), p.get('fund_currency',''), p.get('fund_manager',''), p.get('custodian',''), p.get('entity',''), p.get('classification',''), p.get('ug',''), p.get('og',''), p.get('portfolio_year',''), p.get('initial_aum',''), p.get('created_at','')])
    return si.getvalue(), 200, {'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename=portfolios.csv'}

@app.route('/api/dashboard')
@login_required
def api_dashboard():
    portfolios = load_portfolios()
    try:
        holdings_df = pd.read_parquet(HOLDINGS_PATH)
    except:
        holdings_df = pd.DataFrame()
    try:
        esg_df = pd.read_parquet(ESG_PATH)
        esg_map = {r['ticker']: r for r in esg_df.to_dict('records')}
    except:
        esg_map = {}

    total_aum = holdings_df['market_value'].sum() if not holdings_df.empty else 0
    total_pnl = holdings_df['total_pnl'].sum() if not holdings_df.empty else 0
    total_positions = len(holdings_df)

    esg_scores = holdings_df['esg_score'].dropna() if not holdings_df.empty else []
    avg_esg = esg_scores.mean() if len(esg_scores) else None

    for p in portfolios:
        pid = p.get('id', '')
        ph = holdings_df[holdings_df['fund_id'] == pid] if not holdings_df.empty else pd.DataFrame()
        p['name'] = p.pop('fund_name', p.get('fund_code', ''))
        p['type'] = p.pop('classification', 'Custom')
        p['aum'] = round(float(ph['market_value'].sum()), 2) if not ph.empty else 0
        p['pnl'] = round(float(ph['total_pnl'].sum()), 2) if not ph.empty else 0
        p['position_count'] = len(ph)
        p_esg = ph['esg_score'].dropna()
        p['esg_score'] = round(float(p_esg.mean()), 1) if len(p_esg) else None
        portfolio_year = p.get('portfolio_year')
        initial_aum = p.get('initial_aum')
        if portfolio_year is not None and initial_aum is not None:
            try:
                init_val = float(initial_aum)
                if init_val != 0:
                    p['performance'] = round((p['aum'] - init_val) / init_val * 100, 2)
                else:
                    p['performance'] = None
            except (ValueError, TypeError):
                p['performance'] = None
        else:
            p['performance'] = None

    return jsonify({
        "portfolios": portfolios,
        "total_value": len(portfolios),
        "total_aum": round(float(total_aum), 2),
        "total_pnl": round(float(total_pnl), 2),
        "avg_esg": round(float(avg_esg), 1) if avg_esg is not None else None,
        "positions_count": total_positions,
        "clients": CLIENTS
    })

@app.route('/api/constraints')
@login_required
def api_constraints():
    return jsonify(load_constraints())

@app.route('/api/constraints', methods=['POST'])
@login_required
def api_create_constraint():
    data = request.get_json() or {}
    c = {
        "id": data.get('id') or "ct_" + secrets.token_hex(4),
        "name": data.get('name', ''),
        "type": data.get('type', 'max_position_weight'),
        "operator": data.get('operator', ''),
        "value": data.get('value', 0),
        "param": data.get('param', ''),
        "scope": data.get('scope', 'all'),
        "enabled": bool(data.get('enabled', True)),
    }
    constraints = load_constraints()
    constraints.append(c)
    save_constraints(constraints)
    return jsonify(c), 201

@app.route('/api/constraints/<cid>', methods=['PUT'])
@login_required
def api_update_constraint(cid):
    data = request.get_json() or {}
    constraints = load_constraints()
    for c in constraints:
        if c.get('id') == cid:
            for k, v in data.items():
                c[k] = v
            break
    save_constraints(constraints)
    return jsonify({"ok": True})

@app.route('/api/constraints/<cid>', methods=['DELETE'])
@login_required
def api_delete_constraint(cid):
    constraints = [c for c in load_constraints() if c.get('id') != cid]
    save_constraints(constraints)
    return jsonify({"ok": True})

@app.route('/api/constraints/check')
@login_required
def api_constraints_check():
    fund_id = request.args.get('fund_id', '')
    try:
        holdings = pd.read_parquet(HOLDINGS_PATH)
    except:
        holdings = pd.DataFrame()
    try:
        cash_df = pd.read_parquet(CASH_PATH)
    except:
        cash_df = pd.DataFrame()
    return jsonify(check_constraints(holdings, cash_df, fund_id))

@app.route('/api/sectors')
@login_required
def api_sectors():
    return jsonify(SECTORS)

@app.route('/api/countries')
@login_required
def api_countries():
    return jsonify(COUNTRIES)

@app.route('/api/clients')
@login_required
def api_clients():
    return jsonify(CLIENTS)

@app.route('/api/clients', methods=['POST'])
@login_required
def api_create_client():
    data = request.get_json()
    cid = f"client_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(3)}"
    client = {"id": cid, "name": data.get('name', ''), "email": data.get('email', ''), "phone": data.get('phone', ''), "risk_profile": data.get('risk_profile', 'moderate'), "notes": data.get('notes', '')}
    CLIENTS.append(client)
    return jsonify(client), 201

@app.route('/api/config/benchmarks', methods=['GET', 'POST'])
@login_required
def api_benchmarks():
    if request.method == 'POST':
        data = request.get_json()
        bm = {"id": len(BENCHMARKS) + 1, "name": data.get('name', 'New Benchmark'), "components": data.get('components', [])}
        BENCHMARKS.append(bm)
        return jsonify(bm), 201
    return jsonify(BENCHMARKS)

def _build_report_data():
    """Build the factsheet data dict shared by JSON and Excel endpoints."""
    portfolio_id = request.args.get('portfolio', '')
    portfolios = load_portfolios()
    pf = None
    if portfolio_id:
        pf = next((p for p in portfolios if p.get('id') == portfolio_id), None)

    try:
        holdings_df = pd.read_parquet(HOLDINGS_PATH)
    except:
        holdings_df = pd.DataFrame()

    if not holdings_df.empty and portfolio_id:
        holdings_df = holdings_df[holdings_df['fund_id'] == portfolio_id]

    holdings_df = enrich_holdings(holdings_df) if not holdings_df.empty else holdings_df
    holdings = df_to_json(holdings_df) if not holdings_df.empty else []

    total_aum = round(float(holdings_df['market_value'].sum()), 2) if not holdings_df.empty else 0
    total_pnl = round(float(holdings_df['total_pnl'].sum()), 2) if not holdings_df.empty else 0
    position_count = len(holdings)

    esg_vals = [h.get('esg_score') for h in holdings if h.get('esg_score') is not None]
    avg_esg = round(sum(esg_vals) / len(esg_vals), 1) if esg_vals else None

    top10 = sorted(holdings, key=lambda h: float(h.get('market_value') or 0), reverse=True)[:10]

    asset_alloc = {}
    geo_alloc = {}
    sector_alloc = {}
    equity_val = 0.0
    bond_val = 0.0
    for h in holdings:
        mv = float(h.get('market_value') or 0)
        cat = h.get('category') or 'Autre'
        geo = h.get('country') or 'Autre'
        sect = h.get('sector') or 'Autre'
        asset_alloc[cat] = asset_alloc.get(cat, 0) + mv
        geo_alloc[geo] = geo_alloc.get(geo, 0) + mv
        sector_alloc[sect] = sector_alloc.get(sect, 0) + mv
        if cat.lower() in ('action', 'equity'):
            equity_val += mv
        elif cat.lower() in ('obligation', 'bond'):
            bond_val += mv

    def _alloc_list(d):
        items = [{"name": k, "value": round(v, 2), "pct": round(v / total_aum * 100, 1) if total_aum else 0} for k, v in d.items()]
        return sorted(items, key=lambda x: -x['value'])

    performance = None
    if pf:
        py = pf.get('portfolio_year')
        ia = pf.get('initial_aum')
        if py is not None and ia is not None:
            try:
                init_val = float(ia)
                if init_val != 0:
                    performance = round((total_aum - init_val) / init_val * 100, 2)
            except (ValueError, TypeError):
                pass

    avg_pe = None
    pe_vals = [float(h.get('pe_ratio') or 0) for h in holdings if h.get('pe_ratio') is not None]
    if pe_vals:
        avg_pe = round(sum(pe_vals) / len(pe_vals), 2)

    div_yield = None
    dy_vals = [float(h.get('dividend_yield') or 0) for h in holdings if h.get('dividend_yield') is not None]
    if dy_vals:
        div_yield = round(sum(dy_vals) / len(dy_vals), 2)

    period = request.args.get('period', '1Y')
    period_label = {'1M': '1 Mois', '3M': '3 Mois', '6M': '6 Mois', '1Y': '1 An', 'YTD': 'YTD'}.get(period, period)

    return {
        "portfolio": pf,
        "portfolios": portfolios,
        "clients": CLIENTS,
        "holdings": holdings,
        "top10": top10,
        "total_aum": total_aum,
        "total_pnl": total_pnl,
        "position_count": position_count,
        "avg_esg": avg_esg,
        "performance": performance,
        "asset_allocation": _alloc_list(asset_alloc),
        "geo_allocation": _alloc_list(geo_alloc),
        "sector_allocation": _alloc_list(sector_alloc),
        "equity_pct": round(equity_val / total_aum * 100, 1) if total_aum else 0,
        "bond_pct": round(bond_val / total_aum * 100, 1) if total_aum else 0,
        "avg_pe": avg_pe,
        "dividend_yield": div_yield,
        "benchmark": BENCHMARKS[0] if BENCHMARKS else None,
        "generated_at": datetime.now().strftime('%d/%m/%Y'),
        "period_label": period_label,
    }


@app.route('/api/report')
@login_required
def api_report():
    return jsonify(_build_report_data())


@app.route('/api/report/excel')
@login_required
def api_report_excel():
    from flask import send_file
    from excel_export import generate_excel
    data = _build_report_data()
    xlsx_bytes = generate_excel(data)
    filename = f'factsheet_{data["portfolio"].get("fund_code", "report")}_{data["generated_at"].replace("/", "")}.xlsx' if data['portfolio'] else 'factsheet.xlsx'
    return send_file(
        __import__('io').BytesIO(xlsx_bytes),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=filename,
    )


@app.route('/api/config/datasource', methods=['GET', 'POST'])
def api_datasource_config():
    if request.method == 'POST':
        data = request.get_json()
        with open(CONFIG_PATH, 'w') as f:
            json.dump(data, f)
        return jsonify({"ok": True})
    cfg = load_config()
    return jsonify(cfg)

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    if path in ['documentation', 'data-model', 'simple']:
        return send_from_directory('static', 'index.html')
    try:
        return send_from_directory('static', path)
    except:
        return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
