"""Compatibility entrypoint for the SmartPMS FastAPI application.

Run with either::

    uvicorn smartpms.main:app --host 0.0.0.0 --port 5000
    python app.py

The previous Flask implementation is kept as ``legacy_flask_app.py`` for
rollback/debugging during the migration.
"""

from __future__ import annotations

import os

import uvicorn

from smartpms.main import app

__all__ = ["app"]


if __name__ == "__main__":
    uvicorn.run(
        app,
        host=os.getenv("SMARTPMS_HOST", "0.0.0.0"),
        port=int(os.getenv("SMARTPMS_PORT", "5000")),
    )
