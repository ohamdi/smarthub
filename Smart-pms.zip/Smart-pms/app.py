import os, json, secrets, math
from datetime import datetime, timedelta
from flask import Flask, jsonify, request, session, send_from_directory
import pandas as pd

app = Flask(__name__, static_folder='static', static_url_path='')
app.secret_key = secrets.token_hex(32)
app.permanent_session_lifetime = timedelta(hours=8)

CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'datasource_config.json')

def load_config():
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except:
        return {}

def get_parquet_path(key, default):
    cfg = load_config()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    default_path = os.path.join(base_dir, default)
    p = cfg.get(key)
    if p:
        if not os.path.isabs(p):
            p = os.path.join(base_dir, p)
        if os.path.exists(p):
            return p
    return default_path

PARQUET_PATH = get_parquet_path('portfolios_path', 'portfolios.parquet')
HOLDINGS_PATH = get_parquet_path('holdings_path', 'holdings.parquet')
ESG_PATH = get_parquet_path('esg_path', 'esg.parquet')
OPERATIONS_PATH = get_parquet_path('operations_path', 'operations.parquet')
INVENTORIES_PATH = get_parquet_path('inventories_path', 'inventories.parquet')

USERS = {
    'admin': {'password': 'admin123', 'role': 'admin', 'client_id': None},
    'hamdi': {'password': 'hamdi123', 'role': 'user', 'client_id': 'client_hamdi'},
}

with open(os.path.join(os.path.dirname(__file__), 'static', 'prices.json')) as f:
    PRICES = json.load(f)

CLIENTS = [
    {"id": "client_hamdi", "name": "Hamdi", "email": "hamdi@example.com", "phone": "+33 6 00 00 00 00", "risk_profile": "moderate", "notes": ""},
]

SECTORS = [
    "A\u00e9ro & D\u00e9fense", "Automobile", "Consommation", "Coop\u00e9ratif",
    "Cybers\u00e9curit\u00e9", "Finance", "Fonds", "Industrie",
    "Infrastructure", "Luxe", "Mati\u00e8res premi\u00e8res",
    "Semi-conducteurs", "Services publics", "Sant\u00e9",
    "Technologie", "T\u00e9l\u00e9com", "\u00c9nergie"
]

COUNTRIES = ["CH", "CN", "DE", "FR", "IE", "IT", "NL", "TW", "UK", "US"]

CURRENCY_RATES = {"EUR": 1.0, "USD": 0.92, "GBP": 1.19, "CHF": 1.04, "GBp": 0.0119, "HKD": 0.118}

BENCHMARKS = [
    {"id": 1, "name": "Euro Stoxx 50", "components": [{"ticker": "^STOXX50E", "label": "Euro Stoxx 50", "weight": 50}, {"ticker": "^FCHI", "label": "CAC 40", "weight": 25}, {"ticker": "^GDAXI", "label": "DAX", "weight": 25}]}
]

def df_to_json(df):
    df = df.astype(object)
    for col in df.columns:
        mask = df[col].isna()
        if mask.any():
            df.loc[mask, col] = None
    return df.to_dict('records')

def load_portfolios():
    try:
        df = pd.read_parquet(PARQUET_PATH)
        return df_to_json(df)
    except:
        return []

def save_portfolios(portfolios):
    df = pd.DataFrame(portfolios)
    df.to_parquet(PARQUET_PATH, index=False)

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session:
            return jsonify({"error": "Unauthorized", "login_required": True}), 401
        return f(*args, **kwargs)
    return decorated

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    username = data.get('username', '').strip().lower()
    password = data.get('password', '')
    user = USERS.get(username)
    if not user or user['password'] != password:
        return jsonify({"error": "Invalid credentials"}), 401
    session['user'] = username
    session['role'] = user['role']
    session['client_id'] = user['client_id']
    return jsonify({"username": username, "role": user['role'], "client_id": user['client_id']})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({"ok": True})

@app.route('/api/me')
@login_required
def api_me():
    return jsonify({"username": session['user'], "role": session['role'], "client_id": session.get('client_id')})

@app.route('/api/portfolio')
@login_required
def api_portfolio():
    portfolios = load_portfolios()
    return jsonify(portfolios)

@app.route('/api/portfolio', methods=['POST'])
@login_required
def api_create_portfolio():
    data = request.get_json()
    pid = (data.get('fund_code') or '').strip()
    if not pid:
        pid = f"fund_{secrets.token_hex(4)}"
    pf = {
        "id": pid,
        "fund_code": data.get('fund_code', ''),
        "fund_name": data.get('fund_name', ''),
        "fund_currency": data.get('fund_currency', 'EUR'),
        "fund_manager": data.get('fund_manager', ''),
        "custodian": data.get('custodian', ''),
        "entity": data.get('entity', ''),
        "classification": data.get('classification', ''),
        "created_at": datetime.now().isoformat()
    }
    portfolios = load_portfolios()
    portfolios.append(pf)
    save_portfolios(portfolios)
    return jsonify(pf), 201

@app.route('/api/portfolio/<portfolio_id>', methods=['DELETE'])
@login_required
def api_delete_portfolio(portfolio_id):
    portfolios = load_portfolios()
    portfolios = [p for p in portfolios if p['id'] != portfolio_id]
    save_portfolios(portfolios)
    return jsonify({"ok": True})

@app.route('/api/holdings')
@login_required
def api_holdings():
    fund_id = request.args.get('fund_id', '')
    try:
        df = pd.read_parquet(HOLDINGS_PATH)
        if fund_id:
            df = df[df['fund_id'] == fund_id]
        return jsonify(df_to_json(df))
    except:
        return jsonify([])

@app.route('/api/esg')
@login_required
def api_esg():
    try:
        df = pd.read_parquet(ESG_PATH)
        return jsonify(df_to_json(df))
    except:
        return jsonify([])

@app.route('/api/operations')
@login_required
def api_operations():
    fund_id = request.args.get('fund_id', '')
    date_from = request.args.get('from', '')
    date_to = request.args.get('to', '')
    try:
        df = pd.read_parquet(OPERATIONS_PATH)
        if fund_id:
            df = df[df['fund_id'] == fund_id]
        if 'date' in df.columns:
            if date_from:
                df = df[df['date'].astype(str) >= date_from]
            if date_to:
                df = df[df['date'].astype(str) <= date_to]
        return jsonify(df_to_json(df))
    except:
        return jsonify([])

@app.route('/api/inventories')
@login_required
def api_inventories():
    try:
        df = pd.read_parquet(INVENTORIES_PATH)
        return jsonify(df_to_json(df))
    except:
        return jsonify([])

@app.route('/api/portfolio/export')
@login_required
def api_portfolio_export():
    import csv, io
    si = io.StringIO()
    w = csv.writer(si)
    w.writerow(['Fund Code', 'Fund Name', 'Fund Currency', 'Fund Manager', 'Custodian', 'Entity', 'Classification', 'Created'])
    portfolios = load_portfolios()
    for p in portfolios:
        w.writerow([p.get('fund_code',''), p.get('fund_name',''), p.get('fund_currency',''), p.get('fund_manager',''), p.get('custodian',''), p.get('entity',''), p.get('classification',''), p.get('created_at','')])
    return si.getvalue(), 200, {'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename=portfolios.csv'}

@app.route('/api/dashboard')
@login_required
def api_dashboard():
    portfolios = load_portfolios()
    try:
        holdings_df = pd.read_parquet(HOLDINGS_PATH)
    except:
        holdings_df = pd.DataFrame()
    try:
        esg_df = pd.read_parquet(ESG_PATH)
        esg_map = {r['ticker']: r for r in esg_df.to_dict('records')}
    except:
        esg_map = {}

    total_aum = holdings_df['market_value'].sum() if not holdings_df.empty else 0
    total_pnl = holdings_df['total_pnl'].sum() if not holdings_df.empty else 0
    total_positions = len(holdings_df)

    esg_scores = holdings_df['esg_score'].dropna() if not holdings_df.empty else []
    avg_esg = esg_scores.mean() if len(esg_scores) else None

    for p in portfolios:
        pid = p.get('id', '')
        ph = holdings_df[holdings_df['fund_id'] == pid] if not holdings_df.empty else pd.DataFrame()
        p['name'] = p.pop('fund_name', p.get('fund_code', ''))
        p['type'] = p.pop('classification', 'Custom')
        p['aum'] = round(float(ph['market_value'].sum()), 2) if not ph.empty else 0
        p['pnl'] = round(float(ph['total_pnl'].sum()), 2) if not ph.empty else 0
        p['position_count'] = len(ph)
        p_esg = ph['esg_score'].dropna()
        p['esg_score'] = round(float(p_esg.mean()), 1) if len(p_esg) else None

    return jsonify({
        "portfolios": portfolios,
        "total_value": len(portfolios),
        "total_aum": round(float(total_aum), 2),
        "total_pnl": round(float(total_pnl), 2),
        "avg_esg": round(float(avg_esg), 1) if avg_esg is not None else None,
        "positions_count": total_positions,
        "clients": CLIENTS
    })

@app.route('/api/portfolio/prices')
@login_required
def api_prices():
    return jsonify({"positions": []})

@app.route('/api/sectors')
@login_required
def api_sectors():
    return jsonify(SECTORS)

@app.route('/api/countries')
@login_required
def api_countries():
    return jsonify(COUNTRIES)

@app.route('/api/clients')
@login_required
def api_clients():
    return jsonify(CLIENTS)

@app.route('/api/clients', methods=['POST'])
@login_required
def api_create_client():
    data = request.get_json()
    cid = f"client_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(3)}"
    client = {"id": cid, "name": data.get('name', ''), "email": data.get('email', ''), "phone": data.get('phone', ''), "risk_profile": data.get('risk_profile', 'moderate'), "notes": data.get('notes', '')}
    CLIENTS.append(client)
    return jsonify(client), 201

@app.route('/api/config/benchmarks', methods=['GET', 'POST'])
@login_required
def api_benchmarks():
    if request.method == 'POST':
        data = request.get_json()
        bm = {"id": len(BENCHMARKS) + 1, "name": data.get('name', 'New Benchmark'), "components": data.get('components', [])}
        BENCHMARKS.append(bm)
        return jsonify(bm), 201
    return jsonify(BENCHMARKS)

@app.route('/api/report')
@login_required
def api_report():
    portfolios = load_portfolios()
    return jsonify({"portfolios": portfolios, "clients": CLIENTS})

@app.route('/api/config/datasource', methods=['GET', 'POST'])
def api_datasource_config():
    if request.method == 'POST':
        data = request.get_json()
        with open(CONFIG_PATH, 'w') as f:
            json.dump(data, f)
        return jsonify({"ok": True})
    cfg = load_config()
    return jsonify(cfg)

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    if path in ['documentation', 'data-model', 'simple']:
        return send_from_directory('static', 'index.html')
    try:
        return send_from_directory('static', path)
    except:
        return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
