from __future__ import annotations

import json
import logging
import os
import signal
import subprocess
import threading
import time
from pathlib import Path
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen

from .config import DataSourceConfig

logger = logging.getLogger(__name__)


class LLMService:
    """Lazy GGUF model wrapper and optional Llamafile process manager."""

    def __init__(self, config: DataSourceConfig) -> None:
        self.config = config
        self._lock = threading.RLock()
        self._llm: Any = None
        self._signature: tuple[Any, ...] | None = None
        self._llamafile_process: subprocess.Popen[Any] | None = None

    def chat(
        self, messages: list[dict[str, str]], max_tokens: int = 900, temperature: float = 0.3
    ) -> dict[str, Any]:
        settings = self.config.llm_settings()
        if settings["llm_backend"] == "llamafile":
            return self._llamafile_chat(
                settings,
                messages,
                max_tokens=max_tokens,
                temperature=temperature,
            )
        model = self._get_gguf(settings)
        return model.create_chat_completion(
            messages, max_tokens=max_tokens, temperature=temperature
        )

    def _get_gguf(self, settings: dict[str, Any]) -> Any:
        signature = (
            settings.get("llm_backend"),
            settings.get("gguf_path"),
        )
        model_path = Path(settings.get("gguf_path") or "")
        if not model_path.is_file():
            raise RuntimeError(
                "GGUF model not found. Set 'gguf_path' in datasource_config.json"
            )
        with self._lock:
            if self._llm is None or self._signature != signature:
                try:
                    from llama_cpp import Llama
                except ImportError as exc:
                    raise RuntimeError(
                        "llama-cpp-python is not installed. Install the optional LLM dependencies."
                    ) from exc
                self._llm = Llama(
                    model_path=str(model_path),
                    n_ctx=4096,
                    n_threads=os.cpu_count() or 4,
                    verbose=False,
                )
                self._signature = signature
            return self._llm

    @staticmethod
    def _llamafile_chat(
        settings: dict[str, Any],
        messages: list[dict[str, str]],
        max_tokens: int,
        temperature: float,
    ) -> dict[str, Any]:
        payload = json.dumps(
            {
                "model": "llamafile",
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
            }
        ).encode("utf-8")
        request = Request(
            f"{settings['llamafile_url']}/v1/chat/completions",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urlopen(request, timeout=120) as response:
                return json.loads(response.read())
        except URLError as exc:
            raise RuntimeError(
                f"Llamafile server unreachable ({settings['llamafile_url']}): {exc}"
            ) from exc

    def config_changed(self) -> None:
        """Discard a cached GGUF model when the datasource configuration changes."""
        with self._lock:
            signature = self.config.fingerprint()
            if self._llm is not None and signature != self._signature:
                self._llm = None
                self._signature = None

    def model_status(self) -> dict[str, Any]:
        settings = self.config.llm_settings()
        if settings["llm_backend"] == "llamafile":
            available = bool(settings.get("llamafile_url"))
            loaded = False
            if available:
                try:
                    with urlopen(
                        f"{settings['llamafile_url']}/v1/models", timeout=3
                    ):
                        loaded = True
                except Exception:
                    loaded = False
            return {
                "backend": "llamafile",
                "url": settings["llamafile_url"],
                "loaded": loaded,
                "available": available,
            }
        model_path = settings.get("gguf_path", "")
        return {
            "backend": "gguf",
            "path": model_path,
            "loaded": self._llm is not None,
            "available": bool(model_path and Path(model_path).is_file()),
        }

    def start_llamafile(self) -> None:
        settings = self.config.llm_settings()
        if settings["llm_backend"] != "llamafile":
            return
        binary = Path(settings.get("llamafile_path") or "")
        if not binary.is_file():
            return
        with self._lock:
            if (
                self._llamafile_process is not None
                and self._llamafile_process.poll() is None
            ):
                return
        if self._probe(settings["llamafile_url"], timeout=2):
            logger.info("Llamafile already running on %s", settings["llamafile_url"])
            return
        try:
            kwargs: dict[str, Any] = {
                "stdout": subprocess.DEVNULL,
                "stderr": subprocess.DEVNULL,
            }
            if os.name == "nt":
                kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
            else:
                kwargs["preexec_fn"] = os.setsid
            process = subprocess.Popen(
                [
                    str(binary),
                    "--server",
                    "--model",
                    str(binary.parent / "Llama-3.2-3B-Instruct-Q4_K_M.gguf"),
                    "--port",
                    str(settings["llamafile_port"]),
                    "--host",
                    "0.0.0.0",
                ],
                **kwargs,
            )
        except OSError as exc:
            logger.warning("Could not auto-start Llamafile: %s", exc)
            return
        with self._lock:
            self._llamafile_process = process
        for _ in range(30):
            if self._probe(settings["llamafile_url"], timeout=2):
                logger.info("Llamafile ready on %s", settings["llamafile_url"])
                return
            time.sleep(1)
        logger.warning("Llamafile started but did not respond after 30 seconds")

    def stop_llamafile(self) -> None:
        with self._lock:
            process = self._llamafile_process
            self._llamafile_process = None
        if process is None or process.poll() is not None:
            return
        try:
            if os.name == "nt":
                process.terminate()
            else:
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
            process.wait(timeout=5)
        except Exception:
            try:
                if os.name == "nt":
                    process.kill()
                else:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            except Exception:
                logger.exception("Unable to stop Llamafile")

    @staticmethod
    def _probe(base_url: str, timeout: int) -> bool:
        try:
            with urlopen(f"{base_url}/v1/models", timeout=timeout):
                return True
        except Exception:
            return False
