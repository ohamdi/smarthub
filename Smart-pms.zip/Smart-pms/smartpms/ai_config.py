"""Configuration du module IA : paramètres de génération et détection des modèles.

Ces réglages vivent dans `ai_config.json`, distinct de `datasource_config.json`
qui ne porte que des chemins de fichiers. Le chemin du modèle reste dans
`datasource_config.json` (`gguf_path`) : c'est un chemin, comme les tables
Parquet, et il est déjà exposé par l'onglet DataSource — le déplacer
provoquerait une migration et laisserait une clé morte.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List

#: Niveaux de détail du contexte envoyé au modèle, du plus léger au plus complet.
DETAIL_LEVELS: Dict[str, str] = {
    "rapide": "Indicateurs globaux et totaux par portefeuille",
    "standard": "Indicateurs, totaux par portefeuille et principales positions",
    "complet": "Tout, y compris le détail de chaque position, la trésorerie et "
    "les opérations récentes",
}

DEFAULT_DETAIL = "standard"

#: Plafond dur du bloc de contexte, avant troncature côté route.
MAX_CONTEXT_CHARS = 20000

DEFAULTS: Dict[str, Any] = {
    "n_ctx": 8192,
    # 0 = tous les cœurs détectés par llama-cpp-python.
    "n_threads": 0,
    "n_batch": 2048,
    "temperature": 0.3,
    "max_tokens": 900,
    "top_p": 0.9,
    "repeat_penalty": 1.1,
    "default_detail": DEFAULT_DETAIL,
    "max_context_chars": MAX_CONTEXT_CHARS,
}

#: Bornes de validation : une valeur hors de ces bornes ferait échouer le
#: chargement du modèle ou viderait la réponse.
BOUNDS: Dict[str, tuple[int, int]] = {
    "n_ctx": (2048, 131072),
    "n_threads": (0, 256),
    "n_batch": (32, 8192),
    "max_tokens": (16, 8192),
    "max_context_chars": (2000, 200000),
}

FLOATS = {"temperature", "top_p", "repeat_penalty"}

#: Dossiers scannés pour proposer des modèles dans l'interface.
MODEL_DIRS = [
    Path.home() / "Models",
    Path.home() / "Documents",
    Path.home() / "Downloads",
]


def config_path(base_dir: Path) -> Path:
    return Path(base_dir) / "ai_config.json"


def expand(path: str, base_dir: Path) -> Path:
    """Résout un chemin éventuellement relatif ou commencement par `~`."""
    p = Path(os.path.expandvars(os.path.expanduser(str(path or ""))))
    return p if p.is_absolute() else Path(base_dir) / p


def _coerce(key: str, value: Any) -> Any:
    """Ramène une valeur JSON au type attendu, ou l'écarte si elle est fausse."""
    if key in FLOATS:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    low, high = BOUNDS.get(key, (None, None))
    if low is not None and not low <= number <= high:
        return None
    return number


def load(base_dir: Path) -> Dict[str, Any]:
    """Configuration effective = défauts bornés + `ai_config.json`."""
    path = config_path(base_dir)
    stored: Dict[str, Any] = {}
    try:
        with open(path, encoding="utf-8") as handle:
            raw = json.load(handle)
        if isinstance(raw, dict):
            stored = raw
    except (OSError, json.JSONDecodeError):
        # Fichier absent ou illisible : les défauts suffisent.
        pass

    config = dict(DEFAULTS)
    for key in DEFAULTS:
        if key not in stored:
            continue
        value = stored[key]
        if key in FLOATS:
            coerced = _coerce(key, value)
        elif key in BOUNDS:
            coerced = _coerce(key, value)
        else:
            coerced = str(value) if value is not None else None
        if coerced is not None:
            config[key] = coerced
    if config["default_detail"] not in DETAIL_LEVELS:
        config["default_detail"] = DEFAULT_DETAIL
    return config


def save(base_dir: Path, values: Dict[str, Any]) -> Dict[str, Any]:
    """Écrit les valeurs fournies (clés autorisées uniquement) et renvoie la config.

    Une valeur hors bornes n'est pas écrite : la configuration reste inchangée
    plutôt que de casser le chargement du modèle au prochain démarrage.
    """
    current = load(base_dir)
    for key in DEFAULTS:
        if key not in values or values[key] is None:
            continue
        coerced = _coerce(key, values[key]) if key in FLOATS or key in BOUNDS else str(values[key])
        if coerced is not None:
            current[key] = coerced
    if current["default_detail"] not in DETAIL_LEVELS:
        current["default_detail"] = DEFAULT_DETAIL

    path = config_path(base_dir)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(current, handle, indent=2, ensure_ascii=False)
    return current


def list_models(base_dir: Path, current_path: str = "") -> List[Dict[str, Any]]:
    """Liste les fichiers `.gguf` disponibles sur la machine."""
    directories = list(MODEL_DIRS)
    active = expand(current_path, base_dir) if current_path else None
    if active is not None and active.parent.is_dir():
        directories.insert(0, active.parent)

    seen: Dict[Path, Dict[str, Any]] = {}
    for directory in directories:
        if not directory.is_dir():
            continue
        for candidate in sorted(directory.glob("*.gguf")):
            if candidate in seen or not candidate.is_file():
                continue
            try:
                size = candidate.stat().st_size
            except OSError:
                size = 0
            seen[candidate] = {
                "name": candidate.name,
                "path": str(candidate),
                "size_mb": round(size / (1024 * 1024), 1),
                "dir": str(candidate.parent),
            }
    return sorted(seen.values(), key=lambda model: model["name"].lower())


def describe_model(base_dir: Path, model_path: str) -> Dict[str, Any]:
    """État du modèle selectionné, au même format que les tables du DataSource."""
    resolved = expand(model_path, base_dir)
    exists = resolved.is_file()
    size_mb = 0.0
    if exists:
        try:
            size_mb = round(resolved.stat().st_size / (1024 * 1024), 1)
        except OSError:
            exists = False
    return {
        "configured": str(model_path or ""),
        "resolved": str(resolved),
        "exists": exists,
        "size_mb": size_mb,
    }
