from __future__ import annotations

from typing import Any


class APIError(Exception):
    def __init__(
        self,
        status_code: int,
        message: str,
        *,
        login_required: bool = False,
        extra: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.login_required = login_required
        self.extra = extra or {}

    def payload(self) -> dict[str, Any]:
        data: dict[str, Any] = {"error": self.message, **self.extra}
        if self.login_required:
            data["login_required"] = True
        return data
