from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    username: str
    role: str
    client_id: Any = ""


class PortfolioCreateRequest(BaseModel):
    fund_code: str = ""
    fund_name: str = ""
    fund_currency: str = "EUR"
    fund_manager: str = ""
    custodian: str = ""
    entity: str = ""
    classification: str = ""
    ug: str = ""
    og: str = ""
    portfolio_year: int | None = None
    initial_aum: float | None = None


class ConstraintCreateRequest(BaseModel):
    id: str | None = None
    name: str = ""
    type: str = "max_position_weight"
    operator: str = "<="
    value: float = 0
    param: str = ""
    scope: str = "all"
    enabled: bool = True


class ConstraintUpdateRequest(BaseModel):
    id: str | None = None
    name: str | None = None
    type: str | None = None
    operator: str | None = None
    value: float | None = None
    param: str | None = None
    scope: str | None = None
    enabled: bool | None = None


class UserCreateRequest(BaseModel):
    username: str
    password: str
    role: Literal["admin", "user"] = "user"
    client_id: str = ""


class UserUpdateRequest(BaseModel):
    password: str | None = None
    role: Literal["admin", "user"] | None = None
    client_id: str | None = None


class UserPortfoliosRequest(BaseModel):
    username: str
    by_name: list[str] = Field(default_factory=list)
    by_ug: list[str] = Field(default_factory=list)
    by_manager: list[str] = Field(default_factory=list)


class ClientCreateRequest(BaseModel):
    name: str = ""
    email: str = ""
    phone: str = ""
    risk_profile: str = "moderate"
    notes: str = ""


class BenchmarkComponent(BaseModel):
    ticker: str = ""
    label: str = ""
    weight: float = 0


class BenchmarkCreateRequest(BaseModel):
    name: str = "New Benchmark"
    components: list[BenchmarkComponent] = Field(default_factory=list)


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class AIChatRequest(BaseModel):
    question: str
    history: list[ChatMessage] = Field(default_factory=list)
    # Vide = niveau par défaut de ai_config.json.
    detail: Literal["", "rapide", "standard", "complet"] = ""


class AIVerification(BaseModel):
    """Garde-barre : ce que la réponse cite et ce que les données contiennent.

    `ok` ne signifie pas que la réponse est juste — seulement que chaque
    montant significatif et chaque sigle cités se retrouve dans le contexte
    effectivement envoyé au modèle.
    """

    ok: bool
    numbers_checked: int = 0
    unverified_numbers: list[dict[str, Any]] = Field(default_factory=list, max_length=8)
    unknown_tickers: list[str] = Field(default_factory=list, max_length=8)
    warning: str = ""


class AIMetric(BaseModel):
    label: str
    value: float = Field(allow_inf_nan=False)
    format: Literal["currency", "percent", "number"] = "number"
    trend: Literal["positive", "negative", "neutral"] = "neutral"


class AIChartPoint(BaseModel):
    label: str
    value: float = Field(allow_inf_nan=False)


class AIChartResponse(BaseModel):
    id: str
    kind: Literal[
        "top_positions",
        "position_weights",
        "sector_allocation",
        "country_allocation",
        "currency_allocation",
        "asset_allocation",
        "portfolio_comparison",
        "pnl_by_position",
        "esg_scores",
        # Any "group by X / measure Y" request resolved by the server.
        "grouped",
    ]
    type: Literal["bar", "doughnut"]
    title: str
    data: list[AIChartPoint] = Field(min_length=1, max_length=20)
    value_format: Literal["currency", "percent", "number"]
    unit: str
    orientation: Literal["vertical", "horizontal"] = "vertical"
    signed: bool = False


class AITableColumn(BaseModel):
    key: str
    label: str
    format: Literal["currency", "percent", "number", "text"] = "text"
    signed: bool = False


class AITableResponse(BaseModel):
    title: str
    columns: list[AITableColumn] = Field(min_length=1, max_length=10)
    rows: list[dict[str, Any]] = Field(min_length=1, max_length=20)


class AIChatResponse(BaseModel):
    answer: str
    metrics: list[AIMetric] = Field(default_factory=list, max_length=10)
    visualizations: list[AIChartResponse] = Field(default_factory=list, max_length=2)
    table: AITableResponse | None = None
    verification: AIVerification | None = None


class AIConfigRequest(BaseModel):
    """Réglages de génération. Une clé absente n'est pas touchée."""

    n_ctx: int | None = None
    n_threads: int | None = None
    n_batch: int | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    top_p: float | None = None
    repeat_penalty: float | None = None
    default_detail: Literal["rapide", "standard", "complet"] | None = None
    max_context_chars: int | None = None


class AIContextResponse(BaseModel):
    text: str
    detail: str
    scope: str
    chars: int
    truncated: bool = False


class DatasourceConfigRequest(BaseModel):
    portfolios_path: str | None = None
    holdings_path: str | None = None
    esg_path: str | None = None
    operations_path: str | None = None
    inventories_path: str | None = None
    cash_path: str | None = None
    constraints_path: str | None = None
    exclusions_path: str | None = None
    users_portfolios_path: str | None = None
    users_path: str | None = None
    gguf_path: str | None = None
    llm_backend: Literal["gguf", "llamafile"] | None = None
    llamafile_path: str | None = None
    llamafile_port: int | str | None = None
    llamafile_url: str | None = None
