from __future__ import annotations

import json
import os
import secrets
import threading
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any


DEFAULT_RESOURCE_FILES = {
    "portfolios_path": "portfolios.parquet",
    "holdings_path": "holdings.parquet",
    "esg_path": "esg.parquet",
    "operations_path": "operations.parquet",
    "inventories_path": "inventories.parquet",
    "cash_path": "cash.parquet",
    "constraints_path": "constraints.parquet",
    "exclusions_path": "exclusions.parquet",
    "users_portfolios_path": "users_portfolios.parquet",
    "users_path": "users.parquet",
}

DEFAULT_LLM_SETTINGS = {
    "llm_backend": "gguf",
    "gguf_path": "",
    "llamafile_path": "",
    "llamafile_port": 8080,
    "llamafile_url": "http://localhost:8080",
}


class DataSourceConfig:
    """Read and atomically persist the JSON-backed datasource configuration."""

    def __init__(self, base_dir: Path, config_path: Path | None = None) -> None:
        self.base_dir = base_dir.resolve()
        self.path = (config_path or self.base_dir / "datasource_config.json").resolve()
        self._lock = threading.RLock()

    def load(self) -> dict[str, Any]:
        with self._lock:
            try:
                with self.path.open("r", encoding="utf-8") as file:
                    data = json.load(file)
                return data if isinstance(data, dict) else {}
            except (FileNotFoundError, json.JSONDecodeError, OSError):
                return {}

    def save(self, data: dict[str, Any]) -> None:
        if not isinstance(data, dict):
            raise ValueError("La configuration doit être un objet JSON.")

        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temp_path = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
            try:
                with temp_path.open("w", encoding="utf-8") as file:
                    json.dump(data, file, ensure_ascii=False, indent=2)
                    file.write("\n")
                os.replace(temp_path, self.path)
            finally:
                temp_path.unlink(missing_ok=True)

    def resource_path(self, resource: str) -> Path:
        default = DEFAULT_RESOURCE_FILES.get(resource)
        if default is None:
            raise KeyError(f"Unknown datasource: {resource}")

        configured = self.load().get(resource)
        if configured:
            candidate = Path(str(configured)).expanduser()
            if not candidate.is_absolute():
                candidate = self.base_dir / candidate
            candidate = candidate.resolve()
            if candidate.exists():
                return candidate
        return (self.base_dir / default).resolve()

    def llm_settings(self) -> dict[str, Any]:
        raw = self.load()
        settings = {**DEFAULT_LLM_SETTINGS, **raw}
        try:
            settings["llamafile_port"] = int(settings.get("llamafile_port", 8080))
        except (TypeError, ValueError):
            settings["llamafile_port"] = 8080
        port = settings["llamafile_port"]
        settings["llamafile_url"] = str(
            settings.get("llamafile_url") or f"http://localhost:{port}"
        ).rstrip("/")

        for key in ("gguf_path", "llamafile_path"):
            value = settings.get(key)
            if value:
                path = Path(str(value)).expanduser()
                if not path.is_absolute():
                    path = self.base_dir / path
                settings[key] = str(path.resolve())
            else:
                settings[key] = ""
        return settings

    def fingerprint(self) -> tuple[Any, ...]:
        llm = self.llm_settings()
        return (
            llm.get("llm_backend"),
            llm.get("gguf_path"),
            llm.get("llamafile_path"),
            llm.get("llamafile_port"),
            llm.get("llamafile_url"),
        )


@dataclass(frozen=True)
class Settings:
    base_dir: Path
    config_path: Path
    session_secret: str
    session_max_age: int = 8 * 60 * 60
    cookie_secure: bool = False
    auto_start_llamafile: bool = True

    @classmethod
    def from_env(cls) -> "Settings":
        base_dir = Path(os.getenv("SMARTPMS_BASE_DIR", Path(__file__).resolve().parent.parent)).resolve()
        config_path = Path(
            os.getenv("SMARTPMS_CONFIG_PATH", base_dir / "datasource_config.json")
        ).resolve()
        return cls(
            base_dir=base_dir,
            config_path=config_path,
            session_secret=os.getenv("SMARTPMS_SECRET_KEY") or secrets.token_hex(32),
            session_max_age=max_age_seconds(),
            cookie_secure=env_flag("SMARTPMS_COOKIE_SECURE", False),
            auto_start_llamafile=env_flag("SMARTPMS_AUTO_START_LLAMAFILE", True),
        )

    @property
    def static_dir(self) -> Path:
        return self.base_dir / "static"


def env_flag(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def max_age_seconds() -> int:
    try:
        return int(os.getenv("SMARTPMS_SESSION_MAX_AGE", str(8 * 60 * 60)))
    except ValueError:
        return 8 * 60 * 60
