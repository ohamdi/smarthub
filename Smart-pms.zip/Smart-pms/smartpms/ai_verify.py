"""Contrôle des chiffres et des sigles cités par le modèle.

Un modèle 3B peut recopier un montant en perdant un chiffre, ou nommer un
ticker qui n'est pas dans l'univers. Plutôt que de faire confiance la sortie
brute, on extrait tous les nombres de la réponse et on vérifie qu'ils figurent
dans le contexte effectivement envoyé au modèle ; ceux qui n'y sont pas sont
remontés à l'interface comme « à vérifier ».

C'est une garde-barre, pas une preuve : le but est d'alerter l'utilisateur, pas
de certifier la réponse. Le contrôle porte sur les montants significatifs
(>= 1 000) — les petits nombres sont des pourcentages, des quantités ou des
numéros de ligne, trop bruyants et trop souvent arrondis.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Set

#: 1 234 567,89 / 1,234,567.89 / 1 234 567
_NUMBER_RE = re.compile(r"\d[\d\s .,]{0,18}\d|\d")
#: Ticker boursier avec suffixe d'échange (AI.PA, MSFT.DE)
_TICKER_RE = re.compile(r"\b[A-Z]{2,6}\.[A-Z]{2}\b")
#: Ticker nu, sans suffixe (MSFT, NVDA, CW8)
_BARE_TICKER_RE = re.compile(r"\b[A-Z][A-Z0-9-]{1,7}\b")
#: Marqueurs Markdown et de mise en forme, retirés avant toute extraction.
_MD_RE = re.compile(r"[*_`#>\[\]•·—–]")

#: Sigles financiers et unités que le modèle emploie légitimement sans qu'ils
#: soient des tickers.
ACRONYMS = {
    "ESG", "PEA", "PEA-PM", "AUM", "AUR", "TRS", "PM", "UCITS", "ETF", "ISR",
    "ESGSCORE", "ESGSCORES", "IA", "AI", "TTR", "VAR", "P&L", "PNL", "OU",
    "IG", "EM", "DEVISE", "TR", "OD", "UC", "PE", "FC", "AC", "MV", "NAV",
    "SRRI", "SFDR", "CSRD", "KYC", "AML", "LBO", "MBO", "IPO", "ROE", "ROA",
    "PER", "PBR", "RENDEMENT", "DIVIDENDE", "COURS", "VOLATILITE", "BETA",
}

#: Titres de section du contexte : ils apparaissent en capitales dans les
#: réponses structurées et ne désignent jamais un ticker.
SECTION_WORDS = {
    "PORTEFEUILLES", "INDICATEURS", "POSITIONS", "TRESORERIE", "OPERATIONS",
    "VALEURS", "FILTRES", "CONTRAINTE", "CONTRAINTES", "EXCLUSIONS", "TITRES",
    "ALLOCATIONS", "SECTEURS", "PAYS", "DEVISE", "DEVISES", "PERFORMANCE",
    "SYNTHESE", "CONCLUSION", "RISQUES", "RISQUE", "RECOMMANDATION",
    "RECOMMANDATIONS", "ANALYSE", "REPONSE", "AVERTISSEMENT", "BILAN",
    "GLOBAL", "GLOBAUX", "GLOBALE", "CASH", "LIQUIDITE", "EXPOSITION",
    "DIVERSIFICATION", "CONCENTRATION", "PROFIL", "OBJECTIF", "HORIZON",
    "MOYENNES", "MOYENNE", "PONDERE", "NON", "COURT", "MOYEN", "LONG",
    "TERME", "TOTAL", "TOTAUX", "DETAIL", "DETAILLE", "TOP", "AUTRES",
    "EVOLUTION", "PERF", "YTD", "MENSUEL", "ANNUEL", "ACTIF", "ACTIFS",
    "PASSIF", "PATRIMOINE", "GESTION", "FUND", "FUNDS", "RISQUES",
}

#: En dessous de ce seuil, un nombre est un pourcentage ou une quantité :
#: arrondis légitimes, bruit inutile. Au-dessus, c'est un montant.
SIGNIFICANT_FROM = 1000.0
REL_TOLERANCE = 0.005  # 0,5 %


def _to_float(raw: str) -> Optional[float]:
    """Normalise un nombre écrit à la française ou à l'anglaise."""
    # Espace insécable et espace fine : le modèle les utilise comme
    # séparateurs de milliers, au même titre que l'espace ordinaire.
    s = raw.strip().replace("\u00a0", " ").replace("\u202f", " ")
    # Les espaces internes sont des séparateurs de milliers : on les retire tous.
    s = re.sub(r"[ \u00a0\u202f\u2009]", "", s)
    if not re.search(r"\d", s):
        return None
    if "," in s and "." in s:
        # Le séparateur le plus à droite est le séparateur décimal.
        s = (
            s.replace(",", "")
            if s.rindex(".") > s.rindex(",")
            else s.replace(".", "").replace(",", ".")
        )
    elif "," in s:
        s = s.replace(",", ".")
    s = s.replace(".", "", 1) if s.count(".") > 1 else s
    try:
        return float(s)
    except ValueError:
        return None


def _numbers(text: str) -> List[float]:
    out: List[float] = []
    for match in _NUMBER_RE.finditer(text or ""):
        value = _to_float(match.group(0))
        if value is not None:
            out.append(abs(value))
    return out


def _format(raw: str) -> str:
    return re.sub(r"\s+", " ", raw).strip(" .,%")


def known_values(context_text: str, extra: Optional[Iterable[Any]] = None) -> Set[float]:
    """Ensemble des valeurs autorisées : tout ce qui figure dans le contexte.

    On enregistre aussi les arrondis usuels (unité, dixième, centième) et les
    multiples de milliers, car le modèle convertit volontiers 3 250 000 en
    « 3,25 M » ou en « 3 250 k€ » sans que ce soit une invention.
    """
    values: Set[float] = set()
    for n in _numbers(context_text):
        values.add(n)
        values.add(round(n))
        values.add(round(n, 1))
        values.add(round(n, 2))
        if n >= 1000:
            values.add(round(n / 1000.0, 1))
            values.add(round(n / 1000.0))
            values.add(round(n / 1000.0, 2))
            values.add(round(n / 1000000.0, 2))
            values.add(round(n / 1000000.0, 3))
    for raw in extra or ():
        try:
            values.add(abs(float(raw)))
        except (TypeError, ValueError):
            continue
    return values


def _is_known(value: float, pool: Iterable[float]) -> bool:
    if value in pool:
        return True
    for candidate in pool:
        if candidate <= 0:
            continue
        if abs(candidate - value) / max(abs(candidate), 1.0) <= REL_TOLERANCE:
            return True
    return False


def _mentioned_in(token: str, context: str) -> bool:
    """Le sigle figure-t-il tel quel dans le contexte fourni au modèle ?"""
    if not context or not token:
        return False
    return (
        re.search(
            rf"(?<![A-Za-z0-9]){re.escape(token)}(?![A-Za-z0-9])",
            context,
            re.IGNORECASE,
        )
        is not None
    )


def _unknown_tickers(answer: str, known: Set[str], context: str = "") -> Set[str]:
    """Sigles en capitales ne correspondant à aucun titre de l'univers.

    Couvre les deux formes rencontrées dans les données : le ticker avec
    suffixe d'échange (`AI.PA`) et le ticker nu (`MSFT`). Le Markdown est
    neutralisé au préalable pour ne pas confondre `**SYNTHESE**` avec un ticker.

    Un sigle qui figure tel quel dans le contexte est accepté même s'il n'est
    pas un ticker : le modèle peut citer légitimement un nom de secteur ou un
    libellé présent dans les données.
    """
    if not known:
        return set()
    text = _MD_RE.sub(" ", answer or "")
    dotted = {t.upper() for t in _TICKER_RE.findall(text)}
    # Les tickers à suffixe sont neutralisés avant la recherche des nus, sinon
    # « AI.PA » serait aussi lu comme deux sigles « AI » et « PA ».
    bare_text = _TICKER_RE.sub(" ", text)
    bare = {t.upper() for t in _BARE_TICKER_RE.findall(bare_text)}
    roots = {t.split(".")[0] for t in known}
    return {
        t
        for t in dotted | bare
        if t not in known
        and t.split(".")[0] not in roots
        and t not in ACRONYMS
        and t not in SECTION_WORDS
        and not _mentioned_in(t, context)
    }


def check(
    answer: str,
    context_text: str,
    tickers: Optional[Iterable[str]] = None,
    extra_values: Optional[Iterable[Any]] = None,
) -> Dict[str, Any]:
    """Vérifie la réponse : montants et tickers contre le contexte connu."""
    pool = known_values(context_text, extra_values)
    known_tickers = {t.upper() for t in (tickers or [])}

    unverified: List[Dict[str, Any]] = []
    checked = 0
    seen: Set[str] = set()
    for match in _NUMBER_RE.finditer(answer or ""):
        raw = match.group(0)
        value = _to_float(raw)
        if value is None:
            continue
        value = abs(value)
        if value < SIGNIFICANT_FROM:
            continue
        label = _format(raw)
        if label in seen:
            continue
        seen.add(label)
        checked += 1
        if not _is_known(value, pool):
            unverified.append({"value": label, "number": value})

    unknown = sorted(_unknown_tickers(answer, known_tickers, context_text))
    return {
        "ok": not unverified and not unknown,
        "numbers_checked": checked,
        "unverified_numbers": unverified[:8],
        "unknown_tickers": unknown[:8],
    }


def warning(result: Dict[str, Any]) -> str:
    """Message court affiché dans l'interface si la vérification échoue."""
    if result.get("ok"):
        return ""
    parts: List[str] = []
    nums = result.get("unverified_numbers") or []
    if nums:
        parts.append(
            "montant(s) absent(s) des données : "
            + ", ".join(n["value"] for n in nums)
        )
    tickers = result.get("unknown_tickers") or []
    if tickers:
        parts.append("ticker(s) inconnu(s) : " + ", ".join(tickers))
    return "À vérifier — " + " ; ".join(parts)