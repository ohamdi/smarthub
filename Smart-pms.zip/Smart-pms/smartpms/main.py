from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from starlette.concurrency import run_in_threadpool
from starlette.middleware.sessions import SessionMiddleware

from .config import DataSourceConfig, Settings
from .errors import APIError
from .llm import LLMService
from .routes import router
from .services import ApplicationService
from .storage import ParquetRepository

logger = logging.getLogger(__name__)


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or Settings.from_env()
    config = DataSourceConfig(app_settings.base_dir, app_settings.config_path)
    repository = ParquetRepository(config)
    llm = LLMService(config)
    service = ApplicationService(app_settings, config, repository)
    service.llm = llm

    @asynccontextmanager
    async def lifespan(_application: FastAPI) -> AsyncIterator[None]:
        if app_settings.auto_start_llamafile:
            await run_in_threadpool(llm.start_llamafile)
        yield
        await run_in_threadpool(llm.stop_llamafile)

    application = FastAPI(
        title="SmartPMS API",
        version="2.0.0",
        description="API de gestion de portefeuilles SmartPMS, migrée de Flask vers FastAPI.",
        lifespan=lifespan,
    )
    application.state.settings = app_settings
    application.state.config = config
    application.state.repository = repository
    application.state.llm = llm
    application.state.service = service

    application.add_middleware(
        SessionMiddleware,
        secret_key=app_settings.session_secret,
        max_age=app_settings.session_max_age,
        same_site="lax",
        https_only=app_settings.cookie_secure,
    )

    @application.exception_handler(APIError)
    async def api_error_handler(_request: Request, exc: APIError) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content=exc.payload())

    @application.exception_handler(RequestValidationError)
    async def validation_error_handler(
        _request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        message = "; ".join(
            f"{'.'.join(str(part) for part in error['loc'][1:])}: {error['msg']}"
            for error in exc.errors()
        )
        return JSONResponse(
            status_code=422,
            content={"error": message or "Invalid request"},
        )

    @application.get("/health", tags=["system"])
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    application.include_router(router)

    @application.get("/{full_path:path}", include_in_schema=False)
    async def frontend(full_path: str) -> FileResponse:
        if full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="API route not found")
        static_dir = app_settings.static_dir.resolve()
        candidate = (static_dir / full_path).resolve()
        try:
            candidate.relative_to(static_dir)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail="Not found") from exc
        if candidate.is_file():
            return FileResponse(candidate)
        index = static_dir / "index.html"
        if not index.is_file():
            raise HTTPException(status_code=404, detail="Frontend not found")
        return FileResponse(index)

    return application


app = create_app()
