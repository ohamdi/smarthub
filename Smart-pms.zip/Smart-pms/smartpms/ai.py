from __future__ import annotations

import json
import math
import re
import unicodedata
from collections import defaultdict
from datetime import date, datetime
from typing import Any

VISUALIZATION_KINDS = {
    "top_positions",
    "position_weights",
    "sector_allocation",
    "country_allocation",
    "currency_allocation",
    "asset_allocation",
    "portfolio_comparison",
    "pnl_by_position",
    "esg_scores",
}

TABLE_KINDS = {
    "top_positions",
    "sector_allocation",
    "country_allocation",
    "asset_allocation",
    "portfolio_comparison",
    "pnl_by_position",
}

# Keep generated tables within the response contract (AITableResponse.rows).
AI_TABLE_MAX_ROWS = 20

_VISUALIZATION_ALIASES = {
    "top": "top_positions",
    "top holding": "top_positions",
    "top holdings": "top_positions",
    "top position": "top_positions",
    "top positions": "top_positions",
    "holding": "top_positions",
    "holdings": "top_positions",
    "position": "top_positions",
    "positions": "top_positions",
    "plus grosses positions": "top_positions",
    "principales positions": "top_positions",
    "weight": "position_weights",
    "weights": "position_weights",
    "poids": "position_weights",
    "concentration": "position_weights",
    "sector": "sector_allocation",
    "sectors": "sector_allocation",
    "secteur": "sector_allocation",
    "secteurs": "sector_allocation",
    "country": "country_allocation",
    "countries": "country_allocation",
    "pays": "country_allocation",
    "geo": "country_allocation",
    "geography": "country_allocation",
    "geographique": "country_allocation",
    "currency": "currency_allocation",
    "currencies": "currency_allocation",
    "devise": "currency_allocation",
    "devises": "currency_allocation",
    "monnaie": "currency_allocation",
    "monnaies": "currency_allocation",
    "asset": "asset_allocation",
    "assets": "asset_allocation",
    "allocation": "asset_allocation",
    "classe actif": "asset_allocation",
    "repartition": "asset_allocation",
    "portfolio": "portfolio_comparison",
    "portfolios": "portfolio_comparison",
    "portefeuille": "portfolio_comparison",
    "portefeuilles": "portfolio_comparison",
    "comparison": "portfolio_comparison",
    "comparaison": "portfolio_comparison",
    "pnl": "pnl_by_position",
    "p l": "pnl_by_position",
    "p and l": "pnl_by_position",
    "profit": "pnl_by_position",
    "loss": "pnl_by_position",
    "gain": "pnl_by_position",
    "gains": "pnl_by_position",
    "perte": "pnl_by_position",
    "pertes": "pnl_by_position",
    "performance": "pnl_by_position",
    "rentabilite": "pnl_by_position",
    "esg": "esg_scores",
    "score esg": "esg_scores",
    "scores esg": "esg_scores",
    "notation esg": "esg_scores",
    "durabilite": "esg_scores",
}
_TABLE_ALIASES = {
    "none": "none",
    "aucun": "none",
    "sans tableau": "none",
    **_VISUALIZATION_ALIASES,
}


def _key(value: Any) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(character for character in text if not unicodedata.combining(character))
    return re.sub(r"[^a-zA-Z0-9]+", " ", text).strip().casefold()


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return list(value)
    return [value]


def _parse_json_object(text: str) -> dict[str, Any] | None:
    candidate = text.strip()
    fenced = re.fullmatch(
        r"```(?:json)?\s*(.*?)\s*```", candidate, flags=re.IGNORECASE | re.DOTALL
    )
    if fenced:
        candidate = fenced.group(1).strip()
    start = candidate.find("{")
    end = candidate.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        payload = json.loads(candidate[start : end + 1])
    except (json.JSONDecodeError, TypeError):
        return None
    return payload if isinstance(payload, dict) else None


def _normalise_selection(value: Any, aliases: dict[str, str], allowed: set[str]) -> list[str]:
    selected: list[str] = []
    for item in _as_list(value):
        normalised = _key(item)
        kind = aliases.get(normalised)
        if kind is None:
            candidate = normalised.replace(" ", "_")
            kind = candidate if candidate in allowed else None
        if kind is None and "top" in normalised and _contains(
            normalised, "position", "positions", "holding", "holdings"
        ):
            kind = "top_positions"
        if kind is None and _contains(normalised, "secteur", "secteurs", "sector", "sectors"):
            kind = "sector_allocation"
        if kind in allowed and kind not in selected:
            selected.append(kind)
    return selected


def _strip_markdown(text: str) -> str:
    """The chat renders plain text, so emphasis markers are removed."""
    cleaned = re.sub(r"(\*\*|__)(.*?)\1", r"\2", text, flags=re.DOTALL)
    cleaned = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"\1", cleaned)
    return cleaned.replace("`", "")


def _clean_plain_answer(text: str) -> str:
    """Recover a readable French answer from a model reply that is not valid JSON.

    Small local models often emit a fenced, truncated JSON object. Showing that
    raw to the user is useless, so the ``answer`` field is extracted when
    possible before falling back to the plain text.
    """
    candidate = str(text or "").strip()
    fenced = re.fullmatch(
        r"```(?:json)?\s*(.*?)(?:\s*```)?$", candidate, flags=re.IGNORECASE | re.DOTALL
    )
    if fenced:
        candidate = fenced.group(1).strip()
    if candidate[:1] in "{[" and _parse_json_object(candidate) is None:
        match = re.search(
            r'"answer"\s*:\s*"((?:[^"\\]|\\.)*)"', candidate, flags=re.DOTALL
        )
        if match:
            try:
                candidate = json.loads(f'"' + match.group(1) + '"')
            except (json.JSONDecodeError, TypeError):
                candidate = match.group(1)
    candidate = _strip_markdown(candidate)
    candidate = "\n".join(line.rstrip() for line in candidate.splitlines())
    candidate = re.sub(r"\n{3,}", "\n\n", candidate).strip()
    return candidate


def _normalise_measure(value: Any) -> str | None:
    """Resolve a measure name to a MEASURES key, ignoring internal ones."""
    if not isinstance(value, str) or not value.strip():
        return None
    normalised = _key(value)
    if normalised in MEASURES and not MEASURES[normalised].get("internal"):
        return normalised
    for key, definition in MEASURES.items():
        if definition.get("internal"):
            continue
        if normalised == _key(definition["label"]) or normalised == _key(key):
            return key
    return None


def _normalise_dimension(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    normalised = _key(value)
    if normalised in DIMENSIONS:
        return normalised
    for key, definition in DIMENSIONS.items():
        if normalised == _key(definition["label"]) or normalised == _key(key):
            return key
    return None


def _normalise_aggregate(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    normalised = _key(value)
    if normalised in AGGREGATES:
        return normalised
    if normalised in {"moyenne", "average", "avg", "mean"}:
        return "average"
    if normalised in {"total", "somme", "sum"}:
        return "sum"
    if normalised in {"nombre", "count", "nb"}:
        return "count"
    if normalised in {"part", "share", "portion", "poids"}:
        return "share"
    return None


def _normalise_group_spec(payload: dict[str, Any]) -> dict[str, Any] | None:
    """Validate a declarative "group by / measure" request from the model.

    An unknown dimension or measure name is dropped rather than guessed, so the
    caller falls back to keyword detection instead of charting something else.
    """
    dimension = _normalise_dimension(payload.get("group_by") or payload.get("groupBy"))
    if not dimension:
        return None
    measure = _normalise_measure(payload.get("measure") or payload.get("metric"))
    if not measure:
        return None
    spec: dict[str, Any] = {"group_by": dimension, "measure": measure}
    aggregate = _normalise_aggregate(payload.get("aggregate") or payload.get("agg"))
    if aggregate:
        spec["aggregate"] = aggregate
    chart_type = _normalise_chart_type(
        payload.get("chart_type") or payload.get("chartType")
    )
    if chart_type:
        spec["chart_type"] = chart_type
    limit = payload.get("top") or payload.get("limit")
    if isinstance(limit, (int, float)) and not isinstance(limit, bool):
        spec["limit"] = max(1, min(int(limit), 20))
    order = _key(payload.get("order") or payload.get("sort") or "")
    if order in {"ascendant", "asc", "croissant"}:
        spec["sort"] = "ascending"
    elif order in {"absolu", "abs", "amplitude"}:
        spec["sort"] = "abs"
    return spec


def parse_ai_reply(raw_answer: str) -> dict[str, Any]:
    """Parse the model reply into a safe instruction set."""

    answer = _clean_plain_answer(raw_answer)
    payload = _parse_json_object(answer)
    if payload is None:
        return {
            "answer": answer,
            "visualizations": [],
            "table": "none",
            "selection_provided": False,
        }

    parsed_answer = payload.get("answer")
    if isinstance(parsed_answer, str) and parsed_answer.strip():
        answer = _strip_markdown(parsed_answer).strip()

    selection_provided = any(
        key in payload for key in ("visualizations", "visualization", "charts", "chart", "table")
    )
    raw_visualizations = payload.get("visualizations")
    if raw_visualizations is None:
        for key in ("visualization", "charts", "chart"):
            if key in payload:
                raw_visualizations = payload.get(key)
                break
    if isinstance(raw_visualizations, dict):
        raw_visualizations = [
            raw_visualizations.get("kind")
            or raw_visualizations.get("visualization")
            or raw_visualizations.get("type")
        ]
    visualizations = _normalise_selection(
        raw_visualizations, _VISUALIZATION_ALIASES, VISUALIZATION_KINDS
    )
    table_values = _normalise_selection(
        payload.get("table"), _TABLE_ALIASES, TABLE_KINDS | {"none"}
    )
    table_kind = table_values[0] if table_values else "none"
    chart_type = _normalise_chart_type(
        payload.get("chart_type") or payload.get("chartType")
    )
    selection_provided = selection_provided or chart_type is not None
    requested_filter: dict[str, str] | None = None
    raw_filter = payload.get("filter")
    if raw_filter is None:
        raw_filter = payload.get("filters")
    if isinstance(raw_filter, list):
        raw_filter = next((item for item in raw_filter if isinstance(item, dict)), None)
    if isinstance(raw_filter, dict):
        field = _key(raw_filter.get("field")).replace(" ", "_")
        value = raw_filter.get("value", raw_filter.get("label"))
        if field in FILTER_FIELDS and isinstance(value, str) and value.strip():
            requested_filter = {"field": field, "value": value.strip()}
            selection_provided = True
    group_spec = _normalise_group_spec(payload)
    if group_spec is not None:
        selection_provided = True
        if chart_type and "chart_type" not in group_spec:
            group_spec["chart_type"] = chart_type
    return {
        "answer": answer,
        "visualizations": visualizations[:2],
        "group_spec": group_spec,
        "table": table_kind,
        "chart_type": chart_type,
        "filter": requested_filter,
        "selection_provided": selection_provided,
    }


_CHART_TYPE_ALIASES = {
    "bar": "bar",
    "bar chart": "bar",
    "barres": "bar",
    "graphique en barres": "bar",
    "histogramme": "bar",
    "column chart": "bar",
    "barchart": "bar",
    "doughnut": "doughnut",
    "donut": "doughnut",
    "pie": "doughnut",
    "pie chart": "doughnut",
    "camembert": "doughnut",
    "anneau": "doughnut",
    "circulaire": "doughnut",
}


def _normalise_chart_type(value: Any) -> str | None:
    """Only allow the two chart types the frontend can render."""
    if value is None:
        return None
    for item in _as_list(value):
        normalised = _key(item)
        resolved = _CHART_TYPE_ALIASES.get(normalised)
        if resolved:
            return resolved
        if normalised in {"bar", "doughnut"}:
            return normalised
    return None


def _contains(question: str, *terms: str) -> bool:
    return any(term in question for term in terms)


#: Indicator aliases used by the keyword fallback, in priority order.
_MEASURE_ALIASES: dict[str, tuple[str, ...]] = {
    "market_value": (
        "valeur de marche",
        "valeurs de marche",
        "market value",
        "valorisation",
        "montant",
    ),
    "weight": ("poids", "ponderation", "weight", "concentration"),
    "pnl": (
        "pnl",
        "p l",
        "gain",
        "gains",
        "perte",
        "pertes",
        "performance",
        "rentabilite",
        "resultat",
    ),
    "yield": ("rendement", "rendements", "yield"),
    "coupon": ("coupon", "coupons", "taux d interet", "taux fixe"),
    "esg_score": (
        "score esg",
        "scores esg",
        "note esg",
        "notation esg",
        "note de durabilite",
    ),
    "price": ("cours", "cotation", "price"),
    "maturity": ("maturite", "duree residuelle", "anciennete"),
    "quantity": ("quantite", "quantities", "nombre de titres"),
    "market_exposure": ("exposition de marche", "exposition", "beta"),
    "count": (
        "nombre de positions",
        "combien de positions",
        "nb de positions",
        "nombre de lignes",
    ),
}

#: A (dimension, measure) pair that maps exactly onto one of the original
#: chart kinds, so established answers keep their identifier and wording.
_LEGACY_BY_PAIR: dict[tuple[str, str], str] = {
    ("sector", "weight"): "sector_allocation",
    ("country", "weight"): "country_allocation",
    ("currency", "weight"): "currency_allocation",
    ("category", "weight"): "asset_allocation",
    ("position", "market_value"): "top_positions",
    ("position", "weight"): "position_weights",
    ("fund", "market_value"): "portfolio_comparison",
    ("position", "pnl"): "pnl_by_position",
    ("position", "esg_score"): "esg_scores",
}


def infer_chart_type(question: str) -> str | None:
    """Detect a requested chart style in the question text."""
    normalised = _key(question)
    if _contains(
        normalised,
        "barchart",
        "bar chart",
        "graphique en barre",
        "en barres",
        "barres",
        "histogramme",
    ):
        return "bar"
    if _contains(
        normalised,
        "camembert",
        "pie chart",
        "donut",
        "doughnut",
        "circulaire",
        "anneau",
    ):
        return "doughnut"
    return None


def _infer_limit(question: str, default: int | None) -> int | None:
    """Read an explicit "top 5" / "5 premières positions" cap."""
    normalised = _key(question)
    match = re.search(r"\b(?:top|les)\s*(\d{1,2})\b", normalised) or re.search(
        r"\b(\d{1,2})\s*(?:premiers|premieres|principales|plus gros|plus grandes)\b",
        normalised,
    )
    if not match:
        return default
    return max(1, min(int(match.group(1)), 20))


def _infer_dimension(question: str) -> str | None:
    """First dimension named in the question, most specific first.

    ``DIMENSIONS`` is ordered so that "position" — whose aliases are very broad —
    is only considered once every classification dimension is ruled out.
    """
    normalised = _key(question)
    for key in DIMENSIONS:
        if any(alias in normalised for alias in DIMENSIONS[key]["aliases"]):
            return key
    return None


def _infer_measure(question: str) -> str | None:
    normalised = _key(question)
    for key, aliases in _MEASURE_ALIASES.items():
        if any(alias in normalised for alias in aliases):
            return key
    return None


def _infer_specs(question: str) -> list[dict[str, Any]]:
    """Turn a free-form question into validated engine specs.

    This is the deterministic fallback: the model only has to supply prose, and
    the request is still answered with a chart whenever the question names a
    dimension, an indicator, or both.
    """
    dimension = _infer_dimension(question)
    measure = _infer_measure(question)
    if dimension is None and measure is None:
        return []

    if dimension is None:
        dimension = "position"
    elif measure is None:
        # "repartition sectorielle" asks for a share; "principales positions"
        # asks for position sizes.
        measure = "market_value" if dimension == "position" else "weight"

    spec: dict[str, Any] = {
        "group_by": dimension,
        "measure": measure,
        "aggregate": MEASURES[measure]["aggregate"],
        "kind": _LEGACY_BY_PAIR.get((dimension, measure), "grouped"),
    }
    chart_type = infer_chart_type(question)
    if chart_type is None:
        # A share reads well as a ring, everything else as bars.
        chart_type = (
            "doughnut"
            if spec["aggregate"] == "share" and dimension != "position"
            else "bar"
        )
    spec["chart_type"] = chart_type
    limit = _infer_limit(question, 9 if chart_type == "doughnut" else 12)
    if limit is not None:
        spec["limit"] = limit
    if spec["aggregate"] == "share" and dimension != "position":
        spec["others"] = True
    if measure in {"pnl", "esg_score"}:
        spec["drop_zero"] = True
    if measure == "esg_score":
        spec["rounding"] = 1
    if measure == "pnl":
        spec["sort"] = "abs"
    return [spec]


def infer_visualizations(question: str) -> list[str]:
    """Chart kinds the keyword fallback would request (kept for callers/tests)."""
    kinds: list[str] = []
    for spec in _infer_specs(question):
        if spec["kind"] not in kinds:
            kinds.append(str(spec["kind"]))
    return kinds


def _float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if math.isfinite(result) else default


def _safe_sum(values: Any, default: float = 0.0) -> float:
    total = default
    try:
        for value in values:
            total += _float(value)
            if not math.isfinite(total):
                return default
    except (TypeError, ValueError):
        return default
    return total


def _safe_add(left: Any, right: Any) -> float:
    result = _float(left) + _float(right)
    return result if math.isfinite(result) else 0.0


def _cap_ordered_groups(
    ordered: list[tuple[str, float]], max_rows: int = AI_TABLE_MAX_ROWS
) -> list[tuple[str, float]]:
    """Keep the largest groups and aggregate the rest into an "Autres" row."""
    if len(ordered) <= max_rows:
        return ordered
    head = ordered[: max_rows - 1]
    other = _safe_sum(value for _, value in ordered[max_rows - 1 :])
    return [*head, ("Autres", other)]


def _label(value: Any, fallback: str) -> str:
    if value is None:
        return fallback
    text = str(value).strip()
    if not text or text.casefold() in {"nan", "none", "<na>"}:
        return fallback
    return text


def _shorten(value: str, limit: int) -> str:
    return value if len(value) <= limit else f"{value[: limit - 1].rstrip()}…"


def _position_label(holding: dict[str, Any]) -> str:
    ticker = _label(holding.get("ticker"), "")
    name = _label(holding.get("name"), "")
    if ticker and name and ticker.casefold() != name.casefold():
        return _shorten(f"{ticker} · {name}", 52)
    return _shorten(ticker or name or _label(holding.get("isin"), "Position"), 52)


def _portfolio_map(portfolios: list[dict[str, Any]]) -> dict[str, str]:
    result: dict[str, str] = {}
    for portfolio in portfolios:
        portfolio_id = str(portfolio.get("id") or "")
        if portfolio_id:
            result[portfolio_id] = _label(
                portfolio.get("fund_name") or portfolio.get("fund_code"), portfolio_id
            )
    return result


def _market_total(holdings: list[dict[str, Any]]) -> float:
    return _safe_sum(max(_float(holding.get("market_value")), 0.0) for holding in holdings)


# Fields a caller may filter on. The model may only name one of these keys, so
# an arbitrary column can never be targeted.
FILTER_FIELDS: dict[str, tuple[str, tuple[str, ...]]] = {
    "sector": ("sector", ("secteur", "secteurs", "sector", "sectors", "industry")),
    "country": (
        "country",
        ("pays", "geographique", "geographiquement", "country", "countries", "region"),
    ),
    "currency": ("currency", ("devise", "devises", "monnaie", "monnaies", "currency")),
    "category": (
        "category",
        (
            "classe d actif",
            "classes d actifs",
            "classe actif",
            "type d actif",
            "asset class",
            "category",
        ),
    ),
    "portfolio": (
        "fund_id",
        ("portefeuille", "portefeuilles", "fonds", "portfolio", "fund"),
    ),
    "issuer": ("issuer", ("emetteur", "emetteurs", "issuer", "issuers")),
    "rating": ("rating", ("notation", "notations", "rating", "ratings")),
}


def _fuzzy_key(value: Any) -> str:
    """Aggressive normalisation so "semi-conducteurs" matches "Semi-conducteurs"."""
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(character for character in text if not unicodedata.combining(character))
    return re.sub(r"[^a-zA-Z0-9]+", "", text).casefold()


def _filter_values(
    holdings: list[dict[str, Any]], portfolios: list[dict[str, Any]]
) -> dict[str, list[str]]:
    """Distinct filterable values present in the authorised dataset."""
    names = _portfolio_map(portfolios)
    result: dict[str, list[str]] = {}
    for field, (column, _terms) in FILTER_FIELDS.items():
        seen: list[str] = []
        keys: set[str] = set()
        for holding in holdings:
            if column == "fund_id":
                raw = names.get(str(holding.get("fund_id") or "")) or holding.get("fund_id")
            else:
                raw = holding.get(column)
            label = _label(raw, "")
            key = _fuzzy_key(label)
            if not label or not key or key in keys:
                continue
            keys.add(key)
            seen.append(label)
        result[field] = seen
    return result


def _resolve_filter(
    requested: dict[str, str] | None,
    holdings: list[dict[str, Any]],
    portfolios: list[dict[str, Any]],
) -> dict[str, str] | None:
    """Match the requested filter against values really present in the data.

    Returns None when nothing matches, so a hallucinated sector simply degrades
    to an unfiltered chart instead of an empty or wrong one.
    """
    if not requested:
        return None
    field = _key(requested.get("field")).replace(" ", "_")
    if field not in FILTER_FIELDS:
        return None
    wanted = _fuzzy_key(requested.get("value"))
    if len(wanted) < 2:
        return None
    candidates = _filter_values(holdings, portfolios).get(field, [])
    for candidate in candidates:
        if _fuzzy_key(candidate) == wanted:
            return {"field": field, "value": candidate}
    matches = [c for c in candidates if wanted in _fuzzy_key(c) and len(wanted) >= 4]
    if len(matches) == 1:
        return {"field": field, "value": matches[0]}
    for candidate in candidates:
        key = _fuzzy_key(candidate)
        if len(key) >= 4 and (key in wanted or wanted in key):
            return {"field": field, "value": candidate}
    return None


def _apply_filter(
    holdings: list[dict[str, Any]],
    portfolios: list[dict[str, Any]],
    resolved: dict[str, str] | None,
) -> list[dict[str, Any]]:
    if not resolved:
        return holdings
    column = FILTER_FIELDS[resolved["field"]][0]
    names = _portfolio_map(portfolios)
    wanted = _fuzzy_key(resolved["value"])
    return [
        holding
        for holding in holdings
        if _fuzzy_key(
            names.get(str(holding.get("fund_id") or ""))
            if column == "fund_id"
            else holding.get(column)
        )
        == wanted
    ]


_CURRENCY_SYNONYMS = {
    "dollars": "USD",
    "dollar": "USD",
    "usd": "USD",
    "euros": "EUR",
    "euro": "EUR",
    "eur": "EUR",
    "livres": "GBP",
    "livre": "GBP",
    "gbp": "GBP",
    "yens": "JPY",
    "yen": "JPY",
    "jpy": "JPY",
    "francs": "CHF",
    "franc": "CHF",
    "chf": "CHF",
}


def _detect_filter_from_question(
    question: str, holdings: list[dict[str, Any]], portfolios: list[dict[str, Any]]
) -> dict[str, str] | None:
    """Find a filterable value literally mentioned in the question."""
    text = _fuzzy_key(question)
    if not text:
        return None
    for field, (_column, _terms) in FILTER_FIELDS.items():
        for candidate in _filter_values(holdings, portfolios).get(field, []):
            key = _fuzzy_key(candidate)
            if len(key) >= 4 and key in text:
                return {"field": field, "value": candidate}
    for word, currency in _CURRENCY_SYNONYMS.items():
        if len(word) >= 4 and word in text:
            available = {
                _fuzzy_key(value)
                for value in _filter_values(holdings, portfolios).get("currency", [])
            }
            if _fuzzy_key(currency) in available:
                return {"field": "currency", "value": currency}
    return None


def _guess_filter_field(question: str) -> str:
    """Which dimension the question is talking about, from its wording."""
    normalised = _key(question)
    best_field, best_position = "", -1
    for field, (_column, terms) in FILTER_FIELDS.items():
        for term in terms:
            position = normalised.find(term)
            if position >= 0 and (best_position < 0 or position < best_position):
                best_field, best_position = field, position
    return best_field


def _guess_filter_value(question: str) -> str:
    """Text following the dimension keyword, e.g. « sur les semi-conducteurs »."""
    normalised = _key(question)
    field = _guess_filter_field(question)
    terms = FILTER_FIELDS.get(field, ("", ()))[1] if field else ()
    positions = [normalised.find(term) for term in terms]
    positions = [p for p in positions if p >= 0]
    if not positions:
        return ""
    tail = normalised[min(positions) :]
    tail = re.sub(
        r"^(?:sur|des|de|du|la|le|les|en|dans|pour|par|et|de)\s*", "", tail
    ).strip()
    return tail[:60]


def _filter_suffix(resolved: dict[str, str] | None) -> str:
    if not resolved:
        return ""
    labels = {
        "sector": "secteur",
        "country": "pays",
        "currency": "devise",
        "category": "classe d'actif",
        "portfolio": "portefeuille",
        "issuer": "émetteur",
        "rating": "notation",
    }
    return f" — {labels.get(resolved['field'], resolved['field'])}: {resolved['value']}"


def _is_allocation_kind(kind: str) -> bool:
    return kind in {
        "sector_allocation",
        "country_allocation",
        "currency_allocation",
        "asset_allocation",
    }


def _allocation_is_degenerate(
    kind: str, holdings: list[dict[str, Any]]
) -> bool:
    """True when a breakdown of this subset would yield a single slice."""
    field = _ALLOCATION_FIELD.get(kind)
    if not field:
        return False
    values = {
        _fuzzy_key(holding.get(field))
        for holding in holdings
        if _fuzzy_key(holding.get(field))
    }
    return len(values) <= 1


_ALLOCATION_FIELD = {
    "sector_allocation": "sector",
    "country_allocation": "country",
    "currency_allocation": "currency",
    "asset_allocation": "category",
}


# ---------------------------------------------------------------------------
# Generic analytics engine
#
# Any question is answered as "group the authorised records by this dimension,
# measure this indicator, aggregate like this". The caller only ever names
# registry keys; every figure is recomputed here from the records themselves.
# ---------------------------------------------------------------------------

_MATURITY_BUCKETS: tuple[tuple[float, str], ...] = (
    (1.0, "Échéance < 1 an"),
    (3.0, "Échéance 1-3 ans"),
    (5.0, "Échéance 3-5 ans"),
    (10.0, "Échéance 5-10 ans"),
    (float("inf"), "Échéance > 10 ans"),
)
_ESG_BUCKETS: tuple[tuple[float, str], ...] = (
    (40.0, "ESG < 40"),
    (50.0, "ESG 40-50"),
    (60.0, "ESG 50-60"),
    (70.0, "ESG 60-70"),
    (float("inf"), "ESG ≥ 70"),
)

# Dimensions a caller may group by. "column" is the holding field to read;
# "bucket" computes a banded label instead of reading a raw value.
DIMENSIONS: dict[str, dict[str, Any]] = {
    "sector": {
        "label": "Secteur",
        "column": "sector",
        "aliases": ("secteur", "secteurs", "sector", "sectors", "industry", "industries"),
    },
    "country": {
        "label": "Pays",
        "column": "country",
        # "marche" is deliberately absent: it occurs inside "valeur de marché".
        "aliases": (
            "pays",
            "geographique",
            "geographiquement",
            "geographie",
            "country",
            "countries",
            "region",
        ),
    },
    "currency": {
        "label": "Devise",
        "column": "currency",
        "aliases": ("devise", "devises", "monnaie", "monnaies", "currency"),
    },
    "category": {
        "label": "Classe d'actif",
        "column": "category",
        "aliases": (
            "classe d actif",
            "classes d actifs",
            "classe actif",
            "type d actif",
            "types d actifs",
            "asset class",
            "category",
            "actifs",
        ),
    },
    "issuer": {
        "label": "Émetteur",
        "column": "issuer",
        "aliases": ("emetteur", "emetteurs", "issuer", "issuers"),
    },
    "rating": {
        "label": "Notation",
        "column": "rating",
        "aliases": ("notation", "notations", "rating", "ratings", "credit", "grade"),
    },
    "fund": {
        "label": "Portefeuille",
        "column": "fund_id",
        "aliases": (
            "portefeuille",
            "portefeuilles",
            "fonds",
            "portfolio",
            "portfolios",
            "fund",
        ),
    },
    "maturity": {
        "label": "Échéance",
        "column": "maturity_date",
        "bucket": "maturity",
        "aliases": ("echeance", "echeances", "maturite", "maturity", "duration", "tenor"),
    },
    "esg": {
        "label": "Tranche ESG",
        "column": "esg_score",
        "bucket": "esg",
        "aliases": ("esg", "notation esg", "score esg", "durabilite", "sustainability"),
    },
    "position": {
        "label": "Position",
        "column": None,
        "aliases": (
            "position",
            "positions",
            "titre",
            "titres",
            "holding",
            "holdings",
            "ligne",
            "lignes",
        ),
    },
}

# Indicators a caller may measure. "aggregate" is the sensible default.
MEASURES: dict[str, dict[str, Any]] = {
    "market_value": {
        "label": "Valeur de marché",
        "column": "market_value",
        "format": "currency",
        "aggregate": "sum",
        "unit": "Valeur de marché brute, hors conversion de devise",
    },
    "weight": {
        "label": "Poids",
        # A portfolio weight is the share of market value; the declared per-fund
        # weight is not additive across funds and stays a separate measure.
        "column": "market_value",
        "format": "percent",
        "aggregate": "share",
        "unit": "% de la valeur de marché brute (hors conversion)",
    },
    "pnl": {
        "label": "P&L latent",
        "column": "total_pnl",
        "format": "currency",
        "aggregate": "sum",
        "unit": "Gain/perte latent",
        "signed": True,
    },
    "yield": {
        "label": "Rendement",
        "column": "yield",
        "format": "percent",
        "aggregate": "average",
        "unit": "Rendement moyen pondéré par la valeur de marché",
    },
    "coupon": {
        "label": "Coupon",
        "column": "coupon",
        "format": "percent",
        "aggregate": "average",
        "unit": "Coupon moyen pondéré par la valeur de marché",
    },
    "esg_score": {
        "label": "Score ESG",
        "column": "esg_score",
        "format": "number",
        "aggregate": "average",
        "unit": "Score ESG moyen pondéré par la valeur de marché",
    },
    "price": {
        "label": "Cours",
        "column": "price",
        "format": "number",
        "aggregate": "average",
        "unit": "Cours moyen pondéré par la valeur de marché",
    },
    "maturity": {
        "label": "Maturité",
        "format": "number",
        "aggregate": "average",
        "unit": "Maturité moyenne (années)",
        "derived": "residual_years",
    },
    "quantity": {
        "label": "Quantité",
        "column": "quantity",
        "format": "number",
        "aggregate": "sum",
        "unit": "Quantité détenue",
    },
    "market_exposure": {
        "label": "Exposition de marché",
        "column": "market_exposure",
        "format": "number",
        "aggregate": "sum",
        "unit": "Exposition de marché",
    },
    "count": {
        "label": "Nombre de positions",
        "format": "number",
        "aggregate": "count",
        "unit": "Nombre de positions",
    },
    # Internal only: the per-fund declared weight, not additive across funds.
    "declared_weight": {
        "label": "Poids déclaré",
        "column": "weight",
        "format": "percent",
        "aggregate": "sum",
        "unit": "Poids déclaré (au sein de chaque fonds)",
        "internal": True,
    },
}

AGGREGATES = {"sum", "average", "count", "min", "max", "share"}

# Legacy kinds whose style the caller may still override; the others (positions,
# ESG, P&L, concentration) only read well as bar charts.
_CHART_TYPE_OVERRIDABLE = {
    "sector_allocation",
    "country_allocation",
    "currency_allocation",
    "asset_allocation",
}

# The nine original chart kinds, expressed as specs of the engine above. Titles,
# units, limits and orientation are kept identical to the previous behaviour.
_LEGACY_SPECS: dict[str, dict[str, Any]] = {
    "sector_allocation": {
        "group_by": "sector",
        "measure": "weight",
        "chart_type": "doughnut",
        "title": "Répartition sectorielle",
        "unit": "% de la valeur de marché brute (hors conversion)",
        "orientation": "vertical",
        "limit": 9,
        "others": True,
    },
    "country_allocation": {
        "group_by": "country",
        "measure": "weight",
        "chart_type": "doughnut",
        "title": "Répartition géographique",
        "unit": "% de la valeur de marché brute (hors conversion)",
        "orientation": "vertical",
        "limit": 9,
        "others": True,
    },
    "currency_allocation": {
        "group_by": "currency",
        "measure": "weight",
        "chart_type": "doughnut",
        "title": "Répartition par devise",
        "unit": "% de la valeur de marché brute (hors conversion)",
        "orientation": "vertical",
        "limit": 9,
        "others": True,
    },
    "asset_allocation": {
        "group_by": "category",
        "measure": "weight",
        "chart_type": "doughnut",
        "title": "Répartition par classe d'actif",
        "unit": "% de la valeur de marché brute (hors conversion)",
        "orientation": "vertical",
        "limit": 9,
        "others": True,
    },
    "top_positions": {
        "group_by": "position",
        "measure": "market_value",
        "chart_type": "bar",
        "title": "Principales positions",
        "unit": "Valeur de marché",
        "orientation": "horizontal",
        "limit": 12,
        "others": False,
    },
    "position_weights": {
        "group_by": "position",
        "measure": "weight",
        "chart_type": "bar",
        "title": "Concentration par position",
        "unit": "% de la valeur de marché",
        "orientation": "horizontal",
        "limit": 10,
        "others": True,
    },
    "portfolio_comparison": {
        "group_by": "fund",
        "measure": "market_value",
        "chart_type": "bar",
        "title": "Valeur de marché par portefeuille",
        "unit": "Valeur de marché brute, hors conversion de devise",
        "orientation": "horizontal",
        "limit": 15,
        "others": False,
    },
    "pnl_by_position": {
        "group_by": "position",
        "measure": "pnl",
        "chart_type": "bar",
        "title": "P&L latent par position",
        "unit": "Gain/perte latent",
        "orientation": "horizontal",
        "limit": 12,
        "others": False,
        "sort": "abs",
        "drop_zero": True,
    },
    "esg_scores": {
        "group_by": "position",
        "measure": "esg_score",
        "chart_type": "bar",
        "title": "Scores ESG des positions",
        "unit": "Score ESG",
        "orientation": "horizontal",
        "limit": 12,
        "others": False,
        "rounding": 1,
        "drop_zero": True,
    },
}


def _residual_years(holding: dict[str, Any], reference: date) -> float | None:
    raw = str(holding.get("maturity_date") or "").strip()
    if not raw:
        return None
    try:
        target = datetime.fromisoformat(raw[:10]).date()
    except ValueError:
        return None
    return round((target - reference).days / 365.25, 2)


def _bucket_label(value: float, buckets: tuple[tuple[float, str], ...]) -> str:
    if not math.isfinite(value):
        return "Non renseigné"
    for limit, label in buckets:
        if value < limit:
            return label
    return buckets[-1][1]


def _dimension_value(
    key: str, holding: dict[str, Any], portfolios: list[dict[str, Any]], reference: date
) -> str:
    definition = DIMENSIONS.get(key)
    if not definition:
        return "Non renseigné"
    if key == "position":
        return _position_label(holding)
    if key == "fund":
        fund_id = str(holding.get("fund_id") or "")
        names = _portfolio_map(portfolios)
        return _label(names.get(fund_id) or fund_id, "Non renseigné")
    bucket = definition.get("bucket")
    if bucket == "maturity":
        years = _residual_years(holding, reference)
        return "Non renseigné" if years is None else _bucket_label(years, _MATURITY_BUCKETS)
    if bucket == "esg":
        score = _float(holding.get(definition["column"]))
        return _bucket_label(score, _ESG_BUCKETS) if score > 0 else "Non renseigné"
    return _label(holding.get(definition["column"]), "Non renseigné")


def _measure_value(key: str, holding: dict[str, Any], reference: date) -> float | None:
    """Indicator value for one holding, or None when it is not available."""
    definition = MEASURES.get(key)
    if not definition:
        return None
    if definition.get("aggregate") == "count":
        return 1.0
    if definition.get("derived") == "residual_years":
        return _residual_years(holding, reference)
    return _float(holding.get(definition.get("column")))


def _aggregate_group(
    values: list[float], weights: list[float], aggregate: str
) -> float:
    if not values:
        return 0.0
    if aggregate == "count":
        return float(len(values))
    if aggregate == "sum":
        return _safe_sum(values)
    if aggregate == "min":
        return min(values)
    if aggregate == "max":
        return max(values)
    # Averages of rates are weighted by market value; that is the only reading
    # that stays meaningful across holdings of very different sizes.
    total_weight = _safe_sum(weights)
    if total_weight > 0:
        return _safe_sum(value * weight for value, weight in zip(values, weights)) / total_weight
    return _safe_sum(values) / len(values)


def _grouped_series(
    spec: dict[str, Any],
    holdings: list[dict[str, Any]],
    portfolios: list[dict[str, Any]],
    reference: date,
) -> list[tuple[str, float]]:
    """Aggregate the authorised holdings according to a validated spec."""
    dimension = str(spec["group_by"])
    measure = str(spec["measure"])
    definition = MEASURES.get(measure)
    if not definition or dimension not in DIMENSIONS:
        return []
    aggregate = str(spec.get("aggregate") or definition["aggregate"])
    if aggregate not in AGGREGATES:
        aggregate = str(definition["aggregate"])
    drop_zero = bool(spec.get("drop_zero"))
    # Market values and declared weights only make sense as positive sums.
    positive_only = measure in {"market_value", "declared_weight"}

    buckets: defaultdict[str, tuple[list[float], list[float]]] = defaultdict(
        lambda: ([], [])
    )
    for holding in holdings:
        value = _measure_value(measure, holding, reference)
        if value is None:
            # The indicator does not apply to this holding (no maturity on an
            # equity): counting it as zero would invent a value.
            continue
        if positive_only and value <= 0:
            continue
        if drop_zero and value == 0:
            continue
        label = _dimension_value(dimension, holding, portfolios, reference)
        values, weights = buckets[label]
        values.append(value)
        weights.append(max(_float(holding.get("market_value")), 0.0))

    if aggregate == "share":
        totals = {
            label: _safe_sum(values) for label, (values, _weights) in buckets.items()
        }
        grand_total = _safe_sum(totals.values())
        if grand_total <= 0:
            return []
        series = [(label, total / grand_total * 100) for label, total in totals.items()]
    else:
        series = [
            (label, _aggregate_group(values, weights, aggregate))
            for label, (values, weights) in buckets.items()
        ]

    reverse = spec.get("sort") != "ascending"
    if spec.get("sort") == "abs":
        series.sort(key=lambda item: abs(item[1]), reverse=reverse)
    else:
        series.sort(key=lambda item: item[1], reverse=reverse)
    return [(label, value) for label, value in series if math.isfinite(value)]


def _capped_series(
    series: list[tuple[str, float]], spec: dict[str, Any]
) -> list[tuple[str, float]]:
    limit = spec.get("limit")
    if not limit or len(series) <= int(limit):
        return series
    keep = int(limit)
    head = series[:keep]
    if spec.get("others"):
        head.append(("Autres", _safe_sum(value for _, value in series[keep:])))
    return head


def _dimension_phrase(label: str) -> str:
    """Lowercase a dimension label for use mid-sentence, keeping acronyms intact.

    "Tranche ESG" becomes "tranche ESG" rather than "tranche esg".
    """

    def replace(match: re.Match[str]) -> str:
        token = match.group(0)
        return token if token.isupper() else token.lower()

    return re.sub(r"[^\W\d_]+", replace, label, flags=re.UNICODE)


def _grouped_title(spec: dict[str, Any]) -> str:
    dimension = str(DIMENSIONS.get(str(spec["group_by"]), {}).get("label", "Poste"))
    measure = str(MEASURES.get(str(spec["measure"]), {}).get("label", "Valeur"))
    measure_definition = MEASURES.get(str(spec["measure"]), {})
    aggregate = str(spec.get("aggregate") or measure_definition.get("aggregate") or "sum")
    phrase = _dimension_phrase(dimension)
    if aggregate == "count":
        return f"Nombre de positions par {phrase}"
    if aggregate == "share":
        return f"{measure} par {phrase}"
    if _key(dimension) == _key(measure):
        # Grouping an indicator by its own dimension ("score ESG par score ESG").
        return measure
    prefix = "Moyenne" if aggregate == "average" else "Total"
    return f"{prefix} {measure} par {phrase}"


def _build_grouped_chart(
    spec: dict[str, Any],
    holdings: list[dict[str, Any]],
    portfolios: list[dict[str, Any]],
    reference: date,
    kind: str = "grouped",
) -> dict[str, Any] | None:
    if not holdings:
        return None
    series = _grouped_series(spec, holdings, portfolios, reference)
    if not series:
        return None
    series = _capped_series(series, spec)
    rounding = int(spec.get("rounding") or 2)
    data = [
        {"label": label, "value": round(value, rounding)}
        for label, value in series
        if math.isfinite(value)
    ]
    if not data:
        return None
    definition = MEASURES.get(str(spec["measure"]), {})
    dimension = str(spec["group_by"])
    chart_type = "doughnut" if spec.get("chart_type") == "doughnut" else "bar"
    return {
        "id": spec.get("id") or kind,
        "kind": kind,
        "type": chart_type,
        "title": spec.get("title") or _grouped_title(spec),
        "data": data[:20],
        "value_format": spec.get("value_format") or definition.get("format") or "number",
        "unit": spec.get("unit") or definition.get("unit") or "",
        "orientation": spec.get("orientation")
        or ("horizontal" if dimension == "position" else "vertical"),
        "signed": bool(definition.get("signed")) or bool(spec.get("signed")),
    }


def _build_chart(
    spec: dict[str, Any],
    holdings: list[dict[str, Any]],
    portfolios: list[dict[str, Any]],
    reference: date | None = None,
) -> dict[str, Any] | None:
    """Build one chart from a validated spec (legacy kind or generic request)."""
    if not holdings:
        return None
    kind = str(spec.get("kind") or "grouped")
    resolved = dict(_LEGACY_SPECS.get(kind, {}))
    resolved.update({key: value for key, value in spec.items() if key != "kind"})
    if not resolved.get("group_by") or not resolved.get("measure"):
        return None
    has_market_value = _market_total(holdings) > 0

    if kind == "top_positions" and not has_market_value:
        resolved["measure"] = "declared_weight"
        resolved["value_format"] = "percent"
        resolved["unit"] = "Poids déclaré"
    if not has_market_value and str(resolved.get("measure")) == "weight":
        return None
    return _build_grouped_chart(
        resolved, holdings, portfolios, reference or date.today(), kind=kind
    )


def _table_top_positions(holdings: list[dict[str, Any]], portfolios: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not holdings:
        return None
    names = _portfolio_map(portfolios)
    ranked = sorted(
        holdings,
        key=lambda holding: (
            _float(holding.get("market_value")),
            _float(holding.get("weight")),
        ),
        reverse=True,
    )[:12]
    rows = [
        {
            "position": _position_label(holding),
            "portfolio": _label(names.get(str(holding.get("fund_id") or "")), "Non renseigné"),
            "sector": _label(holding.get("sector"), "Non renseigné"),
            "market_value": round(_float(holding.get("market_value")), 2),
            "weight": round(_float(holding.get("weight")), 2),
            "pnl": round(_float(holding.get("total_pnl")), 2),
        }
        for holding in ranked
    ]
    return {
        "title": "Principales positions",
        "columns": [
            {"key": "position", "label": "Position", "format": "text"},
            {"key": "portfolio", "label": "Portefeuille", "format": "text"},
            {"key": "sector", "label": "Secteur", "format": "text"},
            {"key": "market_value", "label": "Valeur de marché", "format": "currency"},
            {"key": "weight", "label": "Poids", "format": "percent"},
            {"key": "pnl", "label": "P&L", "format": "currency", "signed": True},
        ],
        "rows": rows,
    }


def _table_group_allocation(
    kind: str, holdings: list[dict[str, Any]]
) -> dict[str, Any] | None:
    field, title = {
        "sector_allocation": ("sector", "Répartition sectorielle"),
        "country_allocation": ("country", "Répartition géographique"),
        "asset_allocation": ("category", "Répartition par classe d'actif"),
    }.get(kind, ("", ""))
    if not field:
        return None
    values: defaultdict[str, float] = defaultdict(float)
    for holding in holdings:
        label = _label(holding.get(field), "Non renseigné")
        values[label] = _safe_add(
            values[label], max(_float(holding.get("market_value")), 0.0)
        )
    total = _safe_sum(values.values())
    if total <= 0:
        return None
    ordered = sorted(values.items(), key=lambda item: item[1], reverse=True)
    ordered = _cap_ordered_groups(ordered)
    rows = [
        {
            "label": label,
            "market_value": round(value, 2),
            "share": round(value / total * 100, 2),
        }
        for label, value in ordered
    ]
    return {
        "title": title,
        "columns": [
            {"key": "label", "label": title.removeprefix("Répartition "), "format": "text"},
            {"key": "market_value", "label": "Valeur de marché", "format": "currency"},
            {"key": "share", "label": "Part", "format": "percent"},
        ],
        "rows": rows,
    }


def _table_portfolio_comparison(
    holdings: list[dict[str, Any]], portfolios: list[dict[str, Any]]
) -> dict[str, Any] | None:
    if not holdings:
        return None
    names = _portfolio_map(portfolios)
    groups: defaultdict[str, dict[str, float]] = defaultdict(
        lambda: {"market_value": 0.0, "pnl": 0.0, "positions": 0.0}
    )
    for holding in holdings:
        fund_id = str(holding.get("fund_id") or "")
        label = _label(names.get(fund_id) or holding.get("fund_id"), "Non renseigné")
        groups[label]["market_value"] = _safe_add(
            groups[label]["market_value"], max(_float(holding.get("market_value")), 0.0)
        )
        groups[label]["pnl"] = _safe_add(
            groups[label]["pnl"], _float(holding.get("total_pnl"))
        )
        groups[label]["positions"] = _safe_add(groups[label]["positions"], 1)
    ordered = sorted(
        groups.items(), key=lambda item: item[1]["market_value"], reverse=True
    )
    if len(ordered) > AI_TABLE_MAX_ROWS:
        head = ordered[: AI_TABLE_MAX_ROWS - 1]
        other = {
            "market_value": _safe_sum(
                values["market_value"] for _, values in ordered[AI_TABLE_MAX_ROWS - 1 :]
            ),
            "pnl": _safe_sum(
                values["pnl"] for _, values in ordered[AI_TABLE_MAX_ROWS - 1 :]
            ),
            "positions": _safe_sum(
                values["positions"] for _, values in ordered[AI_TABLE_MAX_ROWS - 1 :]
            ),
        }
        ordered = [*head, ("Autres", other)]
    rows = [
        {
            "portfolio": label,
            "market_value": round(values["market_value"], 2),
            "pnl": round(values["pnl"], 2),
            "positions": int(values["positions"]),
        }
        for label, values in ordered
    ]
    return {
        "title": "Comparaison des portefeuilles",
        "columns": [
            {"key": "portfolio", "label": "Portefeuille", "format": "text"},
            {"key": "market_value", "label": "Valeur de marché", "format": "currency"},
            {"key": "pnl", "label": "P&L", "format": "currency", "signed": True},
            {"key": "positions", "label": "Positions", "format": "number"},
        ],
        "rows": rows,
    }


def _table_pnl(holdings: list[dict[str, Any]]) -> dict[str, Any] | None:
    moved = [
        holding for holding in holdings if _float(holding.get("total_pnl")) != 0
    ]
    ranked = sorted(
        moved,
        key=lambda holding: abs(_float(holding.get("total_pnl"))),
        reverse=True,
    )[:12]
    if not ranked:
        return None
    rows = [
        {
            "position": _position_label(holding),
            "market_value": round(_float(holding.get("market_value")), 2),
            "pnl": round(_float(holding.get("total_pnl")), 2),
        }
        for holding in ranked
    ]
    return {
        "title": "P&L latent par position",
        "columns": [
            {"key": "position", "label": "Position", "format": "text"},
            {"key": "market_value", "label": "Valeur de marché", "format": "currency"},
            {"key": "pnl", "label": "P&L", "format": "currency", "signed": True},
        ],
        "rows": rows,
    }


# Phrases a small model emits when it wrongly believes the data is missing.
# The server computed the figures itself, so a refusal next to a rendered chart
# would be plainly contradicted by the screen.
_REFUSAL_MARKERS = (
    "pas disponible",
    "pas disponiblee",
    "non disponible",
    "ne peux pas",
    "je ne peux",
    "impossible de",
    "aucune donnee",
    "pas de donnee",
    "donnees non",
    "pas fourni",
    "non fourni",
    "ne fournit pas",
    "ne figure pas",
    "n apparait pas",
    "n apparait",
    "insuffisant",
    "aucun chiffre",
    "indisponible",
)


def _looks_like_refusal(answer: str) -> bool:
    normalised = _key(answer)
    return any(marker in normalised for marker in _REFUSAL_MARKERS)


def _describe_spec(spec: dict[str, Any]) -> str:
    """A grammatical French description of one aggregation, for fallback prose."""
    measure = str(MEASURES.get(str(spec.get("measure")), {}).get("label", "Valeur"))
    phrase = _dimension_phrase(
        str(DIMENSIONS.get(str(spec.get("group_by")), {}).get("label", "Poste"))
    )
    aggregate = str(spec.get("aggregate") or "")
    if aggregate == "count":
        return f"le nombre de positions par {phrase}"
    if aggregate == "share":
        return f"la répartition en pourcentage par {phrase}"
    if aggregate == "average":
        return f"la moyenne de {measure} par {phrase}"
    return f"le total de {measure} par {phrase}"


def _build_table(
    kind: str, holdings: list[dict[str, Any]], portfolios: list[dict[str, Any]]
) -> dict[str, Any] | None:
    if kind == "top_positions":
        return _table_top_positions(holdings, portfolios)
    if kind in {"sector_allocation", "country_allocation", "asset_allocation"}:
        return _table_group_allocation(kind, holdings)
    if kind == "portfolio_comparison":
        return _table_portfolio_comparison(holdings, portfolios)
    if kind == "pnl_by_position":
        return _table_pnl(holdings)
    return None


def build_ai_analysis(
    question: str,
    portfolios: list[dict[str, Any]],
    holdings: list[dict[str, Any]],
    instructions: dict[str, Any],
) -> dict[str, Any]:
    """Build metrics, validated chart specs and tables from authorised records."""

    provided = bool(instructions.get("selection_provided"))
    # A spec is either a legacy chart kind or a "group by / measure" request.
    specs: list[dict[str, Any]] = [
        {"kind": kind} for kind in (instructions.get("visualizations") or [])
    ]
    if not provided:
        specs = _infer_specs(question)
    elif instructions.get("group_spec"):
        # An explicit "group by" is the more specific request: it comes first.
        specs = [dict(instructions["group_spec"])] + specs

    # A filter narrows the whole analysis; it is only honoured when its value
    # really exists in the authorised data. Exact string matching is resolved
    # server-side (the question itself, then the model's hint) because small
    # local models cannot reliably copy a value like "Semi-conducteurs".
    resolved_filter = _resolve_filter(instructions.get("filter"), holdings, portfolios)
    if resolved_filter is None:
        resolved_filter = _resolve_filter(
            {"field": _guess_filter_field(question), "value": _guess_filter_value(question)},
            holdings,
            portfolios,
        )
    if resolved_filter is None:
        resolved_filter = _detect_filter_from_question(question, holdings, portfolios)
    scoped = _apply_filter(holdings, portfolios, resolved_filter)
    # "graphe des positions en dollars": a filter was detected but no chart was
    # requested, so default to the most informative view of the subset.
    if resolved_filter and not specs:
        specs = [{"kind": "top_positions"}]

    chart_type = _normalise_chart_type(instructions.get("chart_type")) or infer_chart_type(
        question
    )
    suffix = _filter_suffix(resolved_filter)
    reference = date.today()

    visualizations: list[dict[str, Any]] = []
    described: list[str] = []
    for spec in specs[:2]:
        resolved_spec = dict(spec)
        kind = str(resolved_spec.get("kind") or "grouped")
        if kind in _LEGACY_SPECS:
            merged = dict(_LEGACY_SPECS[kind])
            merged["kind"] = kind
            merged.update(
                {key: value for key, value in resolved_spec.items() if key != "kind"}
            )
            # A breakdown of a filtered subset is usually a single slice, which
            # renders as an empty-looking chart. Show the positions inside the
            # subset instead: that is what "a bar chart on X" really asks for.
            if (
                resolved_filter
                and _is_allocation_kind(kind)
                and _allocation_is_degenerate(kind, scoped)
            ):
                merged = dict(_LEGACY_SPECS["top_positions"])
                merged["kind"] = "top_positions"
            resolved_spec = merged
        if chart_type and (kind == "grouped" or kind in _CHART_TYPE_OVERRIDABLE):
            # An explicitly requested style wins over the preset default, but a
            # bar-oriented preset (positions, ESG, P&L) stays a bar chart: those
            # views only read well as bars.
            resolved_spec["chart_type"] = chart_type
        chart = _build_chart(resolved_spec, scoped, portfolios, reference)
        if not chart:
            continue
        if suffix:
            chart["title"] = f"{chart['title']}{suffix}"
        if chart not in visualizations:
            visualizations.append(chart)
            described.append(_describe_spec(resolved_spec))

    # Metrics and the table describe the filtered subset when one is active.
    total_market_value = _safe_sum(
        max(_float(holding.get("market_value")), 0.0) for holding in scoped
    )
    total_pnl = _safe_sum(_float(holding.get("total_pnl")) for holding in scoped)
    metrics = [
        {
            "label": "Valeur de marché brute",
            "value": round(total_market_value, 2),
            "format": "currency",
            "trend": "neutral",
        },
        {
            "label": "P&L latent",
            "value": round(total_pnl, 2),
            "format": "currency",
            "trend": "positive" if total_pnl > 0 else "negative" if total_pnl < 0 else "neutral",
        },
        {
            "label": "Positions",
            "value": len(scoped),
            "format": "number",
            "trend": "neutral",
        },
    ]
    table = _build_table(str(instructions.get("table") or "none"), scoped, portfolios)
    if table and suffix:
        table["title"] = f"{table['title']}{suffix}"
    answer = str(instructions.get("answer") or "").strip()
    if described and _looks_like_refusal(answer):
        # The figures below were computed from the authorised records, so a
        # refusal from the model would contradict the chart shown next to it.
        # Replace it with a factual statement of what was actually charted.
        scope = f"sur {len(scoped)} position(s) autorisée(s)"
        answer = f"Voici {described[0]}, {scope}."
    return {
        "answer": answer,
        "metrics": metrics,
        "visualizations": visualizations,
        "table": table,
    }
