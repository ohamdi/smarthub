from __future__ import annotations

import logging
import math
import os
import threading
import uuid
from datetime import date, datetime, time
from decimal import Decimal
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import DataSourceConfig

logger = logging.getLogger(__name__)


def dataframe_to_records(frame: pd.DataFrame | None) -> list[dict[str, Any]]:
    """Convert a DataFrame to JSON-compatible records without NaN/NumPy values."""
    if frame is None or frame.empty:
        return []
    return [{key: _json_safe(value) for key, value in row.items()} for row in frame.to_dict("records")]


def _json_safe(value: Any) -> Any:
    if value is None or value is pd.NaT:
        return None
    if isinstance(value, np.generic):
        return _json_safe(value.item())
    if isinstance(value, (pd.Timestamp, datetime, date, time)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, float) and not math.isfinite(value):
        return None
    try:
        missing = pd.isna(value)
        if isinstance(missing, bool) and missing:
            return None
    except (TypeError, ValueError):
        pass
    return value


class ParquetRepository:
    """Parquet-backed repository with process-local locking and atomic writes."""

    def __init__(self, config: DataSourceConfig) -> None:
        self.config = config
        self._lock = threading.RLock()

    def path(self, resource: str) -> Path:
        return self.config.resource_path(resource)

    def read(self, resource: str) -> pd.DataFrame:
        path = self.path(resource)
        try:
            with self._lock:
                return pd.read_parquet(path)
        except FileNotFoundError:
            return pd.DataFrame()
        except Exception:
            logger.exception("Unable to read Parquet datasource %s (%s)", resource, path)
            return pd.DataFrame()

    def records(self, resource: str) -> list[dict[str, Any]]:
        return dataframe_to_records(self.read(resource))

    def save_records(self, resource: str, records: list[dict[str, Any]]) -> None:
        self.save_frame(resource, pd.DataFrame(records))

    def save_frame(self, resource: str, frame: pd.DataFrame) -> None:
        path = self.path(resource)
        with self._lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            temp_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
            try:
                frame.to_parquet(temp_path, index=False)
                os.replace(temp_path, path)
            finally:
                temp_path.unlink(missing_ok=True)
