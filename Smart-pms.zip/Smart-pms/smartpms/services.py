from __future__ import annotations

import math
import re
import secrets
import unicodedata
from datetime import datetime
from typing import Any

import pandas as pd

from . import ai_config
from .ai import build_ai_analysis
from .auth import AuthService, Principal
from .config import DataSourceConfig, Settings
from .storage import ParquetRepository, dataframe_to_records

EXCLUSION_ISIN_COLUMNS = (
    "isin",
    "ISIN",
    "security_isin",
    "asset_isin",
    "fund_isin",
)
EXCLUSION_NAME_COLUMNS = (
    "security_name",
    "name",
    "security",
    "asset_name",
    "instrument_name",
    "description",
)
EXCLUSION_TYPE_COLUMNS = (
    "exclusion",
    "exclusion_type",
    "type",
    "excluded_type",
    "motif",
)
EXCLUSION_REASON_COLUMNS = (
    "exclusion_reason",
    "reason",
    "comment",
    "commentaire",
    "exclusion_comment",
)
ESG_SI_COLUMNS = (
    "si",
    "si_pct",
    "si_percent",
    "pct_si",
    "sustainable_investment",
    "sustainable_invest",
    "sri_share",
    "%si",
)
ESG_TAXONOMY_COLUMNS = (
    "taxonomie",
    "taxonomy",
    "taxonomy_alignment",
    "taxo",
    "taxonomie_alignment",
)
ESG_LABEL_COLUMNS = (
    "esg_label",
    "label",
    "esglabel",
    "label_esg",
    "sri_label",
    "esg_label_name",
)
GROUP_DIMENSIONS = {
    "max_category_weight": ("category", False),
    "min_category_weight": ("category", False),
    "max_sector_weight": ("sector", False),
    "min_sector_weight": ("sector", False),
    "max_country_weight": ("country", False),
    "min_country_weight": ("country", False),
    "max_issuer_weight": ("issuer", True),
    "min_issuer_weight": ("issuer", True),
    "max_currency_weight": ("currency", False),
    "min_currency_weight": ("currency", False),
}
ISIN_TYPES = (
    "max_isin_weight",
    "min_isin_weight",
    "max_isin_list_weight",
    "min_isin_list_weight",
)
CATEGORY_LIKE_COLUMNS = (
    "category",
    "asset_class",
    "asset_classification",
    "assetclass",
    "instrument_type",
    "security_type",
    "instrument",
    "class",
    "type",
)
BOND_FIELDS = (
    "maturity_date",
    "maturity",
    "rating",
    "coupon",
    "yield",
    "bond_rating",
    "bond_maturity",
)
FUND_ID_COLUMNS = (
    "fund_id",
    "portfolio_id",
    "portfolio",
    "fund_code",
    "fund",
)
MARKET_EXPOSURE_COLUMNS = (
    "market_exposure",
    "marketExposure",
    "MarketExposure",
    "market_exp",
    "Market_Exposure",
    "mkt_exposure",
    "exposure",
    "exposure_pct",
)
ISSUER_LIKE_COLUMNS = (
    "issuer",
    "Issuer",
    "émetteur",
    "emetteur",
    "issue",
    "company",
    "Company",
    "institution",
    "entity",
)
UG_COLUMNS = (
    "ug",
    "unitegestion",
    "unite_gestion",
    "unite_de_gestion",
    "unite-gestion",
    "UG",
)
OG_COLUMNS = (
    "og",
    "orientationgestion",
    "orientation_gestion",
    "orientation_de_gestion",
    "orientation-gestion",
    "OG",
)

SECTORS = [
    "Aéro & Défense",
    "Automobile",
    "Consommation",
    "Coopératif",
    "Cybersécurité",
    "Finance",
    "Fonds",
    "Industrie",
    "Infrastructure",
    "Luxe",
    "Matières premières",
    "Semi-conducteurs",
    "Services publics",
    "Souverain",
    "Santé",
    "Technologie",
    "Télécom",
    "Énergie",
]
COUNTRIES = ["CH", "CN", "DE", "FR", "IE", "IT", "NL", "TW", "UK", "US"]

# Holdings files often mix English and French sector labels (Technology vs
# Technologie, Financials vs Finance). They are folded onto the canonical French
# SECTORS list so allocations never split a single sector across several slices.
# Labels with no safe equivalent (e.g. "Government" for sovereign bonds) are
# deliberately left untouched rather than forced into a wrong bucket.
_SECTOR_SYNONYMS = {
    "tech": "Technologie",
    "technology": "Technologie",
    "technologies": "Technologie",
    "information technology": "Technologie",
    "bank": "Finance",
    "banks": "Finance",
    "banque": "Finance",
    "banques": "Finance",
    "financial": "Finance",
    "financials": "Finance",
    "assurance": "Finance",
    "insurance": "Finance",
    "consumption": "Consommation",
    "consumer": "Consommation",
    "consumer goods": "Consommation",
    "retail": "Consommation",
    "distribution": "Consommation",
    "health": "Santé",
    "healthcare": "Santé",
    "health care": "Santé",
    "pharma": "Santé",
    "pharmaceutical": "Santé",
    "pharmaceuticals": "Santé",
    "biotech": "Santé",
    "energy": "Énergie",
    "energies": "Énergie",
    "oil": "Énergie",
    "oil gas": "Énergie",
    "petroleum": "Énergie",
    "gas": "Énergie",
    "semiconductor": "Semi-conducteurs",
    "semiconductors": "Semi-conducteurs",
    "semi conductor": "Semi-conducteurs",
    "semi conductors": "Semi-conducteurs",
    "chips": "Semi-conducteurs",
    "industrial": "Industrie",
    "industrials": "Industrie",
    "industry": "Industrie",
    "industriel": "Industrie",
    "infrastructures": "Infrastructure",
    "utilities": "Services publics",
    "utility": "Services publics",
    "public utilities": "Services publics",
    "automotive": "Automobile",
    "auto": "Automobile",
    "cars": "Automobile",
    "material": "Matières premières",
    "materials": "Matières premières",
    "commodities": "Matières premières",
    "mining": "Matières premières",
    "metals": "Matières premières",
    "telecom": "Télécom",
    "telecoms": "Télécom",
    "telecommunication": "Télécom",
    "telecommunications": "Télécom",
    "telco": "Télécom",
    "defense": "Aéro & Défense",
    "defence": "Aéro & Défense",
    "aerospace": "Aéro & Défense",
    "aeronautics": "Aéro & Défense",
    "aeronautique": "Aéro & Défense",
    "cyber security": "Cybersécurité",
    "cybersecurity": "Cybersécurité",
    "cooperative": "Coopératif",
    "coop": "Coopératif",
    "fund": "Fonds",
    "funds": "Fonds",
    "etf": "Fonds",
    "etfs": "Fonds",
    "sicav": "Fonds",
    "fcp": "Fonds",
    "luxury": "Luxe",
    "luxury goods": "Luxe",
    "government": "Souverain",
    "government bonds": "Souverain",
    "sovereign": "Souverain",
    "sovereigns": "Souverain",
    "sovereign bonds": "Souverain",
    "govie": "Souverain",
    "govies": "Souverain",
    "treasury": "Souverain",
    "treasuries": "Souverain",
    "etat": "Souverain",
    "emprunts d etat": "Souverain",
    "public debt": "Souverain",
}


def _sector_key(value: Any) -> str:
    """Accent- and case-insensitive lookup key for a sector label."""
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(character for character in text if not unicodedata.combining(character))
    # casefold() must happen before the regex, otherwise initial capitals are
    # dropped as non-matching characters.
    return re.sub(r"[^a-z0-9]+", " ", text.casefold()).strip()


def _build_sector_lookup() -> dict[str, str]:
    lookup = {_sector_key(label): label for label in SECTORS}
    lookup.update(_SECTOR_SYNONYMS)
    return lookup


_SECTOR_LOOKUP = _build_sector_lookup()


def normalize_sector(value: Any) -> Any:
    """Map a sector label onto the canonical French SECTORS entry.

    Unknown labels are returned unchanged so no information is ever lost.
    """
    if not _non_empty(value):
        return value
    return _SECTOR_LOOKUP.get(_sector_key(value), str(value).strip())


def _non_empty(value: Any) -> bool:
    if value is None:
        return False
    try:
        if pd.isna(value):
            return False
    except (TypeError, ValueError):
        pass
    return str(value).strip() not in ("", "nan", "None")


def _name_is_bond(name: Any) -> bool:
    return bool(
        re.search(
            r"\s+\d+(?:\.\d+)?%?\s+(?:\d{4}|\d{2}/\d{2})\s*$",
            str(name or "").strip(),
        )
    )


def normalize_asset_type(value: Any) -> str | None:
    normalized = str(value or "").strip().lower()
    if not normalized:
        return None
    if any(key in normalized for key in ("oblig", "bond", "fix", "debt", "credit")):
        return "Obligation"
    if any(key in normalized for key in ("action", "equit", "stock", "share")):
        return "Action"
    return None


def infer_asset_type(row: dict[str, Any]) -> str:
    if any(_non_empty(row.get(field)) for field in BOND_FIELDS) or _name_is_bond(
        row.get("name")
    ):
        return "Obligation"
    return "Action"


def derive_issuer(row: dict[str, Any]) -> str:
    name = str(row.get("name") or "").strip()
    if str(row.get("category") or "").lower() == "obligation" or _name_is_bond(name):
        issuer = re.sub(
            r"\s+\d+(?:\.\d+)?%?\s+(?:\d{4}|\d{2}/\d{2})\s*$",
            "",
            name,
        ).strip()
        if issuer:
            return issuer
    return name or str(row.get("ticker") or "--")


def enrich_holdings(frame: pd.DataFrame | None) -> pd.DataFrame:
    if frame is None or frame.empty:
        return pd.DataFrame() if frame is None else frame.copy()

    result = frame.copy()
    category_column = next(
        (column for column in CATEGORY_LIKE_COLUMNS if column in result.columns), None
    )
    if category_column and category_column != "category":
        result["category"] = result[category_column]
    elif "category" not in result.columns:
        result["category"] = None

    def resolve_category(value: Any) -> Any:
        normalized = normalize_asset_type(value)
        if normalized:
            return normalized
        return value if _non_empty(value) else None

    result["category"] = result["category"].apply(resolve_category)
    missing = result["category"].isna()
    if missing.any():
        result.loc[missing, "category"] = result.loc[missing].apply(
            infer_asset_type, axis=1
        )

    if "sector" in result.columns:
        result["sector"] = result["sector"].apply(normalize_sector)

    market_exposure_column = next(
        (column for column in MARKET_EXPOSURE_COLUMNS if column in result.columns), None
    )
    if market_exposure_column:
        result["market_exposure"] = result[market_exposure_column]
    elif "market_exposure" not in result.columns:
        result["market_exposure"] = None
    result["market_exposure"] = pd.to_numeric(
        result["market_exposure"], errors="coerce"
    )

    issuer_column = next(
        (column for column in ISSUER_LIKE_COLUMNS if column in result.columns), None
    )
    if issuer_column:
        result["issuer"] = result[issuer_column]
    elif "issuer" not in result.columns:
        result["issuer"] = None
    result["issuer"] = result["issuer"].astype(str).str.strip().replace(
        {"": None, "nan": None, "None": None}
    )
    missing_issuer = result["issuer"].isna()
    if missing_issuer.any():
        result.loc[missing_issuer, "issuer"] = result.loc[missing_issuer].apply(
            derive_issuer, axis=1
        )
    result.loc[result["issuer"].astype(str).str.strip() == "", "issuer"] = None
    return result


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or pd.isna(value):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _pick_column(frame: pd.DataFrame, aliases: tuple[str, ...]) -> str | None:
    return next((column for column in aliases if column in frame.columns), None)


def _fr_number(value: Any, decimals: int = 0) -> str:
    """Format a number the French way, so the model mirrors it in its answers."""
    number = _safe_float(value)
    if not math.isfinite(number):
        number = 0.0
    text = f"{number:,.{decimals}f}"
    return text.replace(",", " ").replace(".", ",")


def _filter_fund_frame(
    frame: pd.DataFrame,
    allowed_ids: set[str] | None,
    fund_id: str = "",
    column: str = "fund_id",
) -> pd.DataFrame:
    result = frame
    if column == "fund_id" and column not in result.columns:
        alias = next((name for name in FUND_ID_COLUMNS if name in result.columns), None)
        if alias:
            result = result.copy()
            result[column] = result[alias]
    if allowed_ids is not None:
        # Authorization must fail closed: a source without its portfolio key
        # cannot be attributed to an allowed portfolio.
        if column not in result.columns:
            return result.iloc[0:0].copy()
        allowed_text = {str(identifier) for identifier in allowed_ids}
        result = result[result[column].astype(str).isin(allowed_text)]
    if fund_id and column in result.columns:
        result = result[result[column].astype(str) == str(fund_id)]
    return result


def _cash_available(cash_df: pd.DataFrame) -> float:
    total = 0.0
    for record in cash_df.to_dict("records"):
        available = record.get("available")
        if available is None or pd.isna(available):
            available = _safe_float(record.get("balance")) - _safe_float(
                record.get("blocked")
            )
        total += _safe_float(available)
    return total


def _compare(value: float, operator: str, threshold: float) -> bool:
    try:
        if operator == "<=":
            return value <= threshold
        if operator == ">=":
            return value >= threshold
        if operator == "<":
            return value < threshold
        if operator == ">":
            return value > threshold
        if operator == "==":
            return value == threshold
    except (TypeError, ValueError):
        return False
    return True


class ApplicationService:
    def __init__(
        self,
        settings: Settings,
        config: DataSourceConfig,
        repository: ParquetRepository,
    ) -> None:
        self.settings = settings
        self.config = config
        self.repository = repository
        self.auth = AuthService(repository)
        # Initialized by create_app; kept on the service for dependency-injected routes.
        self.llm: Any = None
        self.clients: list[dict[str, Any]] = [
            {
                "id": "client_hamdi",
                "name": "Hamdi",
                "email": "hamdi@example.com",
                "phone": "+33 6 00 00 00 00",
                "risk_profile": "moderate",
                "notes": "",
            }
        ]
        self.benchmarks: list[dict[str, Any]] = [
            {
                "id": 1,
                "name": "Euro Stoxx 50",
                "components": [
                    {
                        "ticker": "^STOXX50E",
                        "label": "Euro Stoxx 50",
                        "weight": 50,
                    },
                    {"ticker": "^FCHI", "label": "CAC 40", "weight": 25},
                    {"ticker": "^GDAXI", "label": "DAX", "weight": 25},
                ],
            }
        ]

    def load_portfolios(self) -> list[dict[str, Any]]:
        portfolios = self.repository.records("portfolios_path")
        normalized: list[dict[str, Any]] = []
        for portfolio in portfolios:
            item = dict(portfolio)
            if "ug" not in item:
                column = next((name for name in UG_COLUMNS if name in item), None)
                item["ug"] = item.get(column) if column else None
            if "og" not in item:
                column = next((name for name in OG_COLUMNS if name in item), None)
                item["og"] = item.get(column) if column else None
            normalized.append(item)
        return normalized

    def allowed_portfolio_ids(self, principal: Principal) -> set[str] | None:
        if principal.is_admin:
            return None
        records = [
            record
            for record in self.repository.records("users_portfolios_path")
            if str(record.get("username", "")).strip().lower() == principal.username.lower()
        ]
        if not records:
            return set()

        portfolios = self.load_portfolios()
        allowed: set[str] = set()
        for record in records:
            association_type = record.get("association_type", "")
            association_value = str(record.get("association_value", "") or "")
            if not association_value:
                continue
            if association_type == "name":
                allowed.add(association_value)
            elif association_type == "ug":
                allowed.update(
                    str(portfolio["id"])
                    for portfolio in portfolios
                    if str(portfolio.get("ug") or "").strip()
                    == association_value.strip()
                )
            elif association_type == "manager":
                allowed.update(
                    str(portfolio["id"])
                    for portfolio in portfolios
                    if str(portfolio.get("fund_manager") or "").strip()
                    == association_value.strip()
                )
        return allowed

    def list_portfolios(self, principal: Principal) -> list[dict[str, Any]]:
        allowed = self.allowed_portfolio_ids(principal)
        portfolios = self.load_portfolios()
        if allowed is None:
            return portfolios
        return [portfolio for portfolio in portfolios if portfolio.get("id") in allowed]

    def create_portfolio(self, data: dict[str, Any]) -> dict[str, Any]:
        fund_code = str(data.get("fund_code", "") or "").strip()
        portfolio_id = fund_code or f"fund_{secrets.token_hex(4)}"
        portfolio = {
            "id": portfolio_id,
            "fund_code": data.get("fund_code", ""),
            "fund_name": data.get("fund_name", ""),
            "fund_currency": data.get("fund_currency", "EUR"),
            "fund_manager": data.get("fund_manager", ""),
            "custodian": data.get("custodian", ""),
            "entity": data.get("entity", ""),
            "classification": data.get("classification", ""),
            "ug": data.get("ug", ""),
            "og": data.get("og", ""),
            "portfolio_year": data.get("portfolio_year"),
            "initial_aum": data.get("initial_aum"),
            "created_at": datetime.now().isoformat(),
        }
        portfolios = self.load_portfolios()
        portfolios.append(portfolio)
        self.repository.save_records("portfolios_path", portfolios)
        return portfolio

    def delete_portfolio(self, portfolio_id: str) -> None:
        portfolios = [
            portfolio
            for portfolio in self.load_portfolios()
            if str(portfolio.get("id")) != portfolio_id
        ]
        self.repository.save_records("portfolios_path", portfolios)

    def holdings(
        self,
        principal: Principal,
        fund_id: str = "",
    ) -> list[dict[str, Any]]:
        frame = _filter_fund_frame(
            self.repository.read("holdings_path"),
            self.allowed_portfolio_ids(principal),
            fund_id,
        )
        return dataframe_to_records(enrich_holdings(frame))

    def esg(self) -> list[dict[str, Any]]:
        frame = self.repository.read("esg_path").copy()
        if frame.empty:
            return []
        si_column = _pick_column(frame, ESG_SI_COLUMNS)
        taxonomy_column = _pick_column(frame, ESG_TAXONOMY_COLUMNS)
        label_column = _pick_column(frame, ESG_LABEL_COLUMNS)
        frame["si"] = frame[si_column] if si_column else None
        frame["si"] = pd.to_numeric(frame["si"], errors="coerce")
        frame["taxonomie"] = frame[taxonomy_column] if taxonomy_column else None
        frame["esg_label"] = frame[label_column] if label_column else None
        for column in ("taxonomie", "esg_label"):
            frame[column] = frame[column].astype(str).str.strip().replace(
                {"": None, "nan": None, "None": None}
            )
        return dataframe_to_records(frame)

    def operations(
        self,
        principal: Principal,
        fund_id: str = "",
        date_from: str = "",
        date_to: str = "",
    ) -> list[dict[str, Any]]:
        frame = _filter_fund_frame(
            self.repository.read("operations_path"),
            self.allowed_portfolio_ids(principal),
            fund_id,
        )
        if "date" in frame.columns:
            if date_from:
                frame = frame[frame["date"].astype(str) >= date_from]
            if date_to:
                frame = frame[frame["date"].astype(str) <= date_to]
        return dataframe_to_records(frame)

    def inventories(self) -> list[dict[str, Any]]:
        return self.repository.records("inventories_path")

    def exclusions(self) -> list[dict[str, Any]]:
        frame = self.repository.read("exclusions_path").copy()
        if frame.empty:
            return []
        output = pd.DataFrame()
        mappings = {
            "isin": EXCLUSION_ISIN_COLUMNS,
            "name": EXCLUSION_NAME_COLUMNS,
            "exclusion": EXCLUSION_TYPE_COLUMNS,
            "reason": EXCLUSION_REASON_COLUMNS,
        }
        for target, aliases in mappings.items():
            column = _pick_column(frame, aliases)
            output[target] = (
                frame[column].astype(str).str.strip().str.upper()
                if target == "isin" and column
                else frame[column]
                if column
                else None
            )
        for column in output.columns:
            output[column] = output[column].astype(str).str.strip().replace(
                {"": None, "nan": None, "None": None}
            )
        return dataframe_to_records(output)

    def cash(self, principal: Principal) -> list[dict[str, Any]]:
        frame = _filter_fund_frame(
            self.repository.read("cash_path"), self.allowed_portfolio_ids(principal)
        )
        return dataframe_to_records(frame)

    def dashboard(self, principal: Principal) -> dict[str, Any]:
        allowed = self.allowed_portfolio_ids(principal)
        portfolios = self.load_portfolios()
        if allowed is not None:
            portfolios = [
                portfolio for portfolio in portfolios if portfolio.get("id") in allowed
            ]
        holdings = _filter_fund_frame(
            self.repository.read("holdings_path"), allowed
        )
        total_aum = (
            float(pd.to_numeric(holdings.get("market_value"), errors="coerce").fillna(0).sum())
            if "market_value" in holdings
            else 0.0
        )
        total_pnl = (
            float(pd.to_numeric(holdings.get("total_pnl"), errors="coerce").fillna(0).sum())
            if "total_pnl" in holdings
            else 0.0
        )
        esg_scores = (
            pd.to_numeric(holdings["esg_score"], errors="coerce").dropna()
            if "esg_score" in holdings
            else pd.Series(dtype=float)
        )
        average_esg = float(esg_scores.mean()) if not esg_scores.empty else None

        dashboard_portfolios: list[dict[str, Any]] = []
        for original in portfolios:
            portfolio = dict(original)
            portfolio_id = str(portfolio.get("id", ""))
            fund_holdings = (
                holdings[holdings["fund_id"] == portfolio_id]
                if not holdings.empty and "fund_id" in holdings
                else pd.DataFrame()
            )
            portfolio["name"] = portfolio.pop(
                "fund_name", portfolio.get("fund_code", "")
            )
            portfolio["type"] = portfolio.pop("classification", "Custom")
            portfolio["aum"] = (
                round(
                    float(
                        pd.to_numeric(
                            fund_holdings.get("market_value"), errors="coerce"
                        )
                        .fillna(0)
                        .sum()
                    ),
                    2,
                )
                if "market_value" in fund_holdings
                else 0
            )
            portfolio["pnl"] = (
                round(
                    float(
                        pd.to_numeric(
                            fund_holdings.get("total_pnl"), errors="coerce"
                        )
                        .fillna(0)
                        .sum()
                    ),
                    2,
                )
                if "total_pnl" in fund_holdings
                else 0
            )
            portfolio["position_count"] = len(fund_holdings)
            fund_esg = (
                pd.to_numeric(fund_holdings["esg_score"], errors="coerce").dropna()
                if "esg_score" in fund_holdings
                else pd.Series(dtype=float)
            )
            portfolio["esg_score"] = (
                round(float(fund_esg.mean()), 1) if not fund_esg.empty else None
            )
            portfolio_year = portfolio.get("portfolio_year")
            initial_aum = portfolio.get("initial_aum")
            performance = None
            if portfolio_year is not None and initial_aum is not None:
                initial_value = _safe_float(initial_aum, 0.0)
                performance = (
                    round((float(portfolio["aum"]) - initial_value) / initial_value * 100, 2)
                    if initial_value
                    else None
                )
            portfolio["performance"] = performance
            dashboard_portfolios.append(portfolio)

        return {
            "portfolios": dashboard_portfolios,
            "total_value": len(dashboard_portfolios),
            "total_aum": round(total_aum, 2),
            "total_pnl": round(total_pnl, 2),
            "avg_esg": round(average_esg, 1) if average_esg is not None else None,
            "positions_count": len(holdings),
            "clients": self.clients,
        }

    def check_constraints(
        self,
        principal: Principal,
        fund_id: str = "",
    ) -> dict[str, Any]:
        allowed = self.allowed_portfolio_ids(principal)
        holdings = _filter_fund_frame(
            self.repository.read("holdings_path"), allowed, fund_id
        )
        cash = _filter_fund_frame(
            self.repository.read("cash_path"), allowed, fund_id
        )
        return self._evaluate_constraints(enrich_holdings(holdings), cash)

    def _evaluate_constraints(
        self,
        holdings: pd.DataFrame,
        cash_df: pd.DataFrame,
    ) -> dict[str, Any]:
        holdings = enrich_holdings(holdings)
        constraints = [
            constraint
            for constraint in self.repository.records("constraints_path")
            if constraint.get("enabled", True)
        ]
        total_aum = (
            float(
                pd.to_numeric(holdings.get("market_value"), errors="coerce")
                .fillna(0)
                .sum()
            )
            if "market_value" in holdings
            else 0.0
        )
        available_cash = _cash_available(cash_df)
        results: list[dict[str, Any]] = []

        for constraint in constraints:
            constraint_type = str(constraint.get("type", ""))
            operator = str(constraint.get("operator") or "<=")
            scope = str(constraint.get("scope") or "all").strip()
            threshold = _safe_float(constraint.get("value"))
            if scope.lower() in ("all", "*", "tous", "toutes"):
                subset = holdings
                scoped_cash = cash_df
            else:
                subset = (
                    holdings[holdings["fund_id"] == scope]
                    if not holdings.empty and "fund_id" in holdings
                    else holdings
                )
                scoped_cash = (
                    cash_df[cash_df["fund_id"] == scope]
                    if not cash_df.empty and "fund_id" in cash_df
                    else cash_df
                )
            scoped_aum = (
                float(
                    pd.to_numeric(subset.get("market_value"), errors="coerce")
                    .fillna(0)
                    .sum()
                )
                if "market_value" in subset
                else 0.0
            )
            scoped_cash = _cash_available(scoped_cash)
            records = subset.to_dict("records") if not subset.empty else []
            result: dict[str, Any] = {
                "id": constraint.get("id"),
                "name": constraint.get("name") or constraint_type,
                "type": constraint_type,
                "scope": scope,
                "operator": operator,
                "value": threshold,
                "current": None,
                "status": "NO_DATA",
                "violations": [],
            }

            if constraint_type in ("min_cash_pct", "max_cash_pct"):
                current = (
                    round(scoped_cash / scoped_aum * 100, 2) if scoped_aum else None
                )
                result["current"] = current
                if current is None:
                    result["status"] = "NO_DATA"
                elif _compare(current, operator, threshold):
                    result["status"] = "OK"
                else:
                    result["status"] = "VIOLATION"
                    result["violations"].append(
                        {
                            "detail": "Cash disponible %s%% vs limite %s%%"
                            % (current, threshold)
                        }
                    )
                results.append(result)
                continue

            if constraint_type in GROUP_DIMENSIONS:
                field, derive_issuer_value = GROUP_DIMENSIONS[constraint_type]
                groups: dict[str, float] = {}
                for record in records:
                    if derive_issuer_value:
                        key = str(record.get("issuer") or "").strip() or derive_issuer(
                            record
                        )
                    else:
                        key = str(record.get(field) or "--")
                    groups[key] = groups.get(key, 0.0) + _safe_float(record.get("weight"))
                parameter = str(constraint.get("param") or "").strip()
                if parameter.lower() in ("*", "all", "tous", "toutes"):
                    parameter = ""
                if parameter and parameter != "--":
                    groups = {key: value for key, value in groups.items() if key == parameter}
                if groups:
                    values = list(groups.values())
                    is_minimum = constraint_type.startswith("min_") or operator in (">=", ">")
                    result["current"] = round(min(values) if is_minimum else max(values), 2)
                    offenders = [
                        (key, value)
                        for key, value in groups.items()
                        if not _compare(value, operator, threshold)
                    ]
                    if offenders:
                        result["status"] = "VIOLATION"
                        result["violations"] = [
                            {"detail": f"{key}: {round(value, 2)}%"}
                            for key, value in sorted(
                                offenders, key=lambda item: -item[1]
                            )
                        ]
                    else:
                        result["status"] = "OK"
                results.append(result)
                continue

            if constraint_type in ISIN_TYPES:
                isins = {
                    item.strip().upper()
                    for item in re.split(
                        r"[;,\s]+", str(constraint.get("param") or "")
                    )
                    if item.strip()
                }
                if not isins:
                    results.append(result)
                    continue
                matched = [
                    record
                    for record in records
                    if str(record.get("isin") or "").strip().upper() in isins
                ]
                current = round(
                    sum(_safe_float(record.get("weight")) for record in matched), 2
                )
                result["current"] = current
                if not matched:
                    result["status"] = "NO_DATA"
                elif _compare(current, operator, threshold):
                    result["status"] = "OK"
                else:
                    result["status"] = "VIOLATION"
                    result["violations"] = [
                        {
                            "ticker": record.get("ticker"),
                            "name": record.get("name"),
                            "detail": "poids=%s%%"
                            % round(_safe_float(record.get("weight")), 2),
                        }
                        for record in matched
                    ]
                results.append(result)
                continue

            field = "esg_score" if constraint_type == "min_esg_score" else "weight"
            offenders: list[dict[str, Any]] = []
            values: list[float] = []
            for record in records:
                raw_value = record.get(field)
                if raw_value is None or pd.isna(raw_value):
                    continue
                value = _safe_float(raw_value)
                values.append(value)
                if not _compare(value, operator, threshold):
                    offenders.append(
                        {
                            "ticker": record.get("ticker"),
                            "name": record.get("name"),
                            "detail": f"{field}={round(value, 2)}",
                        }
                    )
            if not values:
                result["status"] = "NO_DATA"
            else:
                is_minimum = constraint_type.startswith("min_") or operator in (">=", ">")
                result["current"] = round(min(values) if is_minimum else max(values), 2)
                if offenders:
                    result["status"] = "VIOLATION"
                    result["violations"] = offenders[:20]
                else:
                    result["status"] = "OK"
            results.append(result)

        return {
            "checked_at": datetime.now().isoformat(),
            "total_aum": round(total_aum, 2),
            "cash_available": round(available_cash, 2),
            "constraints_total": len(constraints),
            "violation_count": sum(
                1 for result in results if result["status"] == "VIOLATION"
            ),
            "results": results,
        }

    def expanded_user_portfolios(
        self, principal: Principal
    ) -> list[dict[str, Any]]:
        allowed = self.allowed_portfolio_ids(principal)
        portfolios = self.load_portfolios()
        if allowed is not None:
            portfolios = [
                portfolio for portfolio in portfolios if portfolio.get("id") in allowed
            ]
        portfolio_map = {str(portfolio.get("id")): portfolio for portfolio in portfolios}
        ug_portfolios: dict[str, list[str]] = {}
        manager_portfolios: dict[str, list[str]] = {}
        for portfolio in portfolios:
            portfolio_id = str(portfolio.get("id"))
            ug = str(portfolio.get("ug") or "").strip()
            if ug:
                ug_portfolios.setdefault(ug, []).append(portfolio_id)
            manager = str(portfolio.get("fund_manager") or "").strip()
            if manager:
                manager_portfolios.setdefault(manager, []).append(portfolio_id)

        result: list[dict[str, Any]] = []
        for record in self.repository.records("users_portfolios_path"):
            username = record.get("username", "")
            association_type = record.get("association_type", "")
            association_value = str(record.get("association_value", "") or "")
            if association_type in ("ug", "manager"):
                index = ug_portfolios if association_type == "ug" else manager_portfolios
                for portfolio_id in index.get(association_value.strip(), []):
                    portfolio = portfolio_map.get(portfolio_id, {})
                    result.append(
                        self._association_result(
                            username,
                            association_type,
                            association_value,
                            portfolio_id,
                            portfolio,
                        )
                    )
            else:
                portfolio = portfolio_map.get(association_value, {})
                result.append(
                    self._association_result(
                        username,
                        "name",
                        association_value,
                        association_value,
                        portfolio,
                    )
                )
        return result

    @staticmethod
    def _association_result(
        username: Any,
        association_type: str,
        association_value: str,
        portfolio_id: str,
        portfolio: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "username": username,
            "association_type": association_type,
            "association_value": association_value,
            "portfolio_id": portfolio_id,
            "portfolio_name": portfolio.get("fund_name")
            or portfolio.get("fund_code")
            or portfolio_id,
            "ug": portfolio.get("ug", ""),
            "og": portfolio.get("og", ""),
            "fund_manager": portfolio.get("fund_manager", ""),
        }

    def report(
        self,
        principal: Principal,
        portfolio_id: str = "",
        period: str = "1Y",
    ) -> dict[str, Any]:
        allowed = self.allowed_portfolio_ids(principal)
        portfolios = self.load_portfolios()
        if allowed is not None:
            portfolios = [
                portfolio for portfolio in portfolios if portfolio.get("id") in allowed
            ]
        selected = next(
            (
                portfolio
                for portfolio in portfolios
                if str(portfolio.get("id")) == portfolio_id
            ),
            None,
        )
        frame = _filter_fund_frame(
            self.repository.read("holdings_path"), allowed, portfolio_id
        )
        frame = enrich_holdings(frame)
        holdings = dataframe_to_records(frame)
        total_aum = (
            round(
                float(
                    pd.to_numeric(frame.get("market_value"), errors="coerce")
                    .fillna(0)
                    .sum()
                ),
                2,
            )
            if "market_value" in frame
            else 0
        )
        total_pnl = (
            round(
                float(
                    pd.to_numeric(frame.get("total_pnl"), errors="coerce")
                    .fillna(0)
                    .sum()
                ),
                2,
            )
            if "total_pnl" in frame
            else 0
        )
        top10 = sorted(
            holdings,
            key=lambda holding: _safe_float(holding.get("market_value")),
            reverse=True,
        )[:10]
        asset_allocation: dict[str, float] = {}
        geo_allocation: dict[str, float] = {}
        sector_allocation: dict[str, float] = {}
        equity_value = 0.0
        bond_value = 0.0
        for holding in holdings:
            market_value = _safe_float(holding.get("market_value"))
            category = holding.get("category") or "Autre"
            country = holding.get("country") or "Autre"
            sector = holding.get("sector") or "Autre"
            asset_allocation[category] = asset_allocation.get(category, 0.0) + market_value
            geo_allocation[country] = geo_allocation.get(country, 0.0) + market_value
            sector_allocation[sector] = sector_allocation.get(sector, 0.0) + market_value
            normalized_category = str(category).lower()
            if normalized_category in ("action", "equity"):
                equity_value += market_value
            elif normalized_category in ("obligation", "bond"):
                bond_value += market_value

        def allocation_list(values: dict[str, float]) -> list[dict[str, Any]]:
            return sorted(
                [
                    {
                        "name": name,
                        "value": round(value, 2),
                        "pct": round(value / total_aum * 100, 1) if total_aum else 0,
                    }
                    for name, value in values.items()
                ],
                key=lambda item: -item["value"],
            )

        esg_values = [
            _safe_float(holding.get("esg_score"))
            for holding in holdings
            if holding.get("esg_score") is not None
        ]
        pe_values = [
            _safe_float(holding.get("pe_ratio"))
            for holding in holdings
            if holding.get("pe_ratio") is not None
        ]
        dividend_values = [
            _safe_float(holding.get("dividend_yield"))
            for holding in holdings
            if holding.get("dividend_yield") is not None
        ]
        performance = None
        if (
            selected
            and selected.get("portfolio_year") is not None
            and selected.get("initial_aum") is not None
        ):
            initial_aum = _safe_float(selected.get("initial_aum"), 0.0)
            performance = (
                round((total_aum - initial_aum) / initial_aum * 100, 2)
                if initial_aum
                else None
            )
        period_labels = {
            "1M": "1 Mois",
            "3M": "3 Mois",
            "6M": "6 Mois",
            "1Y": "1 An",
            "YTD": "YTD",
        }
        return {
            "portfolio": selected,
            "portfolios": portfolios,
            "clients": self.clients,
            "holdings": holdings,
            "top10": top10,
            "total_aum": total_aum,
            "total_pnl": total_pnl,
            "position_count": len(holdings),
            "avg_esg": round(sum(esg_values) / len(esg_values), 1)
            if esg_values
            else None,
            "performance": performance,
            "asset_allocation": allocation_list(asset_allocation),
            "geo_allocation": allocation_list(geo_allocation),
            "sector_allocation": allocation_list(sector_allocation),
            "equity_pct": round(equity_value / total_aum * 100, 1)
            if total_aum
            else 0,
            "bond_pct": round(bond_value / total_aum * 100, 1) if total_aum else 0,
            "avg_pe": round(sum(pe_values) / len(pe_values), 2) if pe_values else None,
            "dividend_yield": round(sum(dividend_values) / len(dividend_values), 2)
            if dividend_values
            else None,
            "benchmark": self.benchmarks[0] if self.benchmarks else None,
            "generated_at": datetime.now().strftime("%d/%m/%Y"),
            "period_label": period_labels.get(period, period),
        }

    def _holdings_with_esg(self, holdings: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Enrich already-authorised holdings with ESG scores from the ESG source.

        The ESG Parquet is a separate, broader dataset: only rows matching an
        authorised holding (by ticker or ISIN) are copied across.
        """
        enriched = [dict(holding) for holding in holdings]
        esg_by_identifier: dict[str, Any] = {}
        for record in self.esg():
            for field in ("ticker", "isin"):
                identifier = str(record.get(field) or "").strip().casefold()
                if identifier:
                    esg_by_identifier[identifier] = record.get("esg_score")
        for holding in enriched:
            if _non_empty(holding.get("esg_score")):
                continue
            for field in ("ticker", "isin"):
                identifier = str(holding.get(field) or "").strip().casefold()
                if identifier in esg_by_identifier:
                    holding["esg_score"] = esg_by_identifier[identifier]
                    break
        return enriched

    def ai_settings(self) -> dict[str, Any]:
        """Generation settings, whether or not an engine is attached to the service."""
        if self.llm is not None:
            return self.llm.ai_config()
        return ai_config.load(self.settings.base_dir)

    def ai_context(self, principal: Principal, detail: str = "") -> str:
        """The block of facts the model is allowed to reason on.

        `detail` trades breadth for tokens: `rapide` keeps the aggregates only,
        `standard` adds the main positions and the filterable values, `complet`
        adds every position plus cash, recent operations and exclusions. The
        model never reads a file: it only ever sees this text.
        """
        level = detail or self.ai_settings()["default_detail"]
        if level not in ai_config.DETAIL_LEVELS:
            level = ai_config.DEFAULT_DETAIL
        allowed = self.allowed_portfolio_ids(principal)
        portfolios = [
            portfolio
            for portfolio in self.load_portfolios()
            if allowed is None or str(portfolio.get("id")) in allowed
        ]
        holdings = self._holdings_with_esg(self.holdings(principal))
        total_market_value = sum(
            max(_safe_float(holding.get("market_value")), 0.0) for holding in holdings
        )
        total_pnl = sum(_safe_float(holding.get("total_pnl")) for holding in holdings)
        esg_scores = [
            _safe_float(holding.get("esg_score"))
            for holding in holdings
            if _safe_float(holding.get("esg_score")) > 0
        ]
        detailed = level in {"standard", "complet"}
        lines = ["PORTEFEUILLES:"]
        for portfolio in portfolios[:20]:
            lines.append(
                "- %s | UG: %s | OG: %s | Manager: %s | Devise: %s"
                % (
                    portfolio.get("fund_name")
                    or portfolio.get("fund_code")
                    or portfolio.get("id"),
                    portfolio.get("ug") or "-",
                    portfolio.get("og") or "-",
                    portfolio.get("fund_manager") or "-",
                    portfolio.get("fund_currency") or "-",
                )
            )
        if len(portfolios) > 20:
            lines.append(f"- … et {len(portfolios) - 20} autre(s) portefeuille(s)")
        lines.append(f"TOTAL PORTEFEUILLES: {len(portfolios)}")
        lines.append("INDICATEURS GLOBAUX:")
        lines.append(
            "- Positions: %d | Valeur de marché brute: %s | P&L latent: %s"
            % (
                len(holdings),
                _fr_number(total_market_value),
                _fr_number(total_pnl),
            )
        )
        if esg_scores:
            lines.append(
                "- Score ESG moyen (positions notées): %s"
                % _fr_number(sum(esg_scores) / len(esg_scores), 1)
            )
        if not detailed:
            return "\n".join(lines)

        lines.append("POSITIONS (les plus importantes):")
        by_fund: dict[Any, list[dict[str, Any]]] = {}
        for holding in holdings:
            by_fund.setdefault(holding.get("fund_id"), []).append(holding)
        portfolio_names = {
            portfolio.get("id"): portfolio.get("fund_name")
            or portfolio.get("fund_code")
            for portfolio in portfolios
        }
        for fund_id, fund_holdings in by_fund.items():
            market_value = sum(
                _safe_float(holding.get("market_value")) for holding in fund_holdings
            )
            lines.append(
                "- %s (%d positions, mkt val %s)"
                % (
                    portfolio_names.get(fund_id, fund_id),
                    len(fund_holdings),
                    _fr_number(market_value),
                )
            )
        ranked = sorted(
            holdings,
            key=lambda item: _safe_float(item.get("market_value")),
            reverse=True,
        )
        position_limit = len(ranked) if level == "complet" else 25
        for holding in ranked[:position_limit]:
            lines.append(
                "  * %s | %s | secteur: %s | pays: %s | devise: %s | mkt %s | "
                "poids %s%% | P&L %s | ESG %s | nom: %s"
                % (
                    holding.get("ticker")
                    or holding.get("isin")
                    or holding.get("name"),
                    holding.get("category") or "-",
                    holding.get("sector") or "-",
                    holding.get("country") or "-",
                    holding.get("currency") or "-",
                    _fr_number(holding.get("market_value")),
                    _fr_number(holding.get("weight"), 1),
                    _fr_number(holding.get("total_pnl")),
                    _fr_number(holding.get("esg_score"), 1)
                    if _safe_float(holding.get("esg_score"))
                    else "-",
                    holding.get("name") or "-",
                )
            )
        if position_limit < len(holdings):
            lines.append(
                f"  … et {len(holdings) - position_limit} autre(s) position(s) "
                "non détaillée(s)."
            )
        # Explicit values so the model can filter with an exact match.
        filterable: dict[str, list[str]] = {}
        for field, column in (
            ("sector", "sector"),
            ("country", "country"),
            ("currency", "currency"),
            ("category", "category"),
            ("issuer", "issuer"),
            ("rating", "rating"),
        ):
            values: list[str] = []
            for holding in holdings:
                value = holding.get(column)
                if value and str(value) not in values:
                    values.append(str(value))
            if values:
                filterable[field] = sorted(values)
        if filterable:
            lines.append("VALEURS EXACTES POUR LES FILTRES (filter.field / filter.value):")
            for field, values in filterable.items():
                lines.append(f"- {field}: " + ", ".join(values[:25]))
        # The server can chart any indicator, including derived ones the position
        # lines above do not spell out, so the model never rules them out.
        derived: list[str] = []
        for label, column, minimum in (
            ("rating", "rating", 0.0),
            ("maturity", "maturity_date", None),
            ("coupon", "coupon", 0.0),
            ("yield", "yield", 0.0),
            ("market_exposure", "market_exposure", None),
        ):
            present = sum(
                1
                for holding in holdings
                if str(holding.get(column) or "").strip()
                and (minimum is None or _safe_float(holding.get(column)) > minimum)
            )
            if present:
                derived.append(f"{label} ({present} positions)")
        lines.append(
            "INDICATEURS CALCULABLES PAR LE SERVEUR: market_value, weight, pnl, "
            "esg_score, price, quantity, market_exposure, count"
            + (" ; aussi disponibles : " + ", ".join(derived) if derived else "")
            + "."
        )
        if level == "complet":
            lines.extend(self._ai_context_extra(principal, portfolios, portfolio_names))
        return "\n".join(lines)

    def _ai_context_extra(
        self,
        principal: Principal,
        portfolios: list[dict[str, Any]],
        portfolio_names: dict[Any, Any],
    ) -> list[str]:
        """Trésorerie, opérations récentes et exclusions : le niveau `complet`."""
        lines: list[str] = []

        balances = self.cash(principal)
        total_cash = sum(_safe_float(balance.get("balance")) for balance in balances)
        lines.append("TRESORERIE:")
        lines.append(
            "- %d compte(s) | solde total: %s"
            % (len(balances), _fr_number(total_cash))
        )
        for balance in balances[:20]:
            lines.append(
                "- %s | %s | solde: %s | disponible: %s"
                % (
                    portfolio_names.get(balance.get("fund_id"), balance.get("fund_id")),
                    balance.get("currency") or "-",
                    _fr_number(balance.get("balance")),
                    _fr_number(balance.get("available"))
                    if balance.get("available") is not None
                    else "-",
                )
            )
        if len(balances) > 20:
            lines.append(f"- … et {len(balances) - 20} autre(s) compte(s)")

        operations = sorted(
            self.operations(principal),
            key=lambda item: str(item.get("date") or ""),
            reverse=True,
        )
        if operations:
            lines.append("OPERATIONS RECENTES:")
            for operation in operations[:30]:
                lines.append(
                    "- %s | %s | %s | %s | qté %s | prix %s | montant %s | statut %s"
                    % (
                        str(operation.get("date") or "")[:10],
                        portfolio_names.get(
                            operation.get("fund_id"), operation.get("fund_id")
                        ),
                        operation.get("type") or "-",
                        operation.get("ticker") or operation.get("name") or "-",
                        _fr_number(operation.get("quantity")),
                        _fr_number(operation.get("price")),
                        _fr_number(operation.get("amount")),
                        operation.get("status") or "-",
                    )
                )
            if len(operations) > 30:
                lines.append(f"- … et {len(operations) - 30} autre(s) opération(s)")

        exclusions = self.exclusions()
        if exclusions:
            lines.append("TITRES EXCLUS DE L'UNIVERS:")
            for row in exclusions[:20]:
                lines.append(
                    "- %s (%s)"
                    % (
                        row.get("security_name") or row.get("isin") or "-",
                        row.get("exclusion") or "exclu",
                    )
                )
        return lines

    def ai_context_payload(
        self, principal: Principal, detail: str = ""
    ) -> dict[str, Any]:
        """Contexte + sa description, pour l'onglet « données envoyées au modèle »."""
        text = self.ai_context(principal, detail)
        return {
            "text": text,
            "detail": detail or self.ai_settings()["default_detail"],
            "scope": self.ai_scope(principal),
            "chars": len(text),
        }

    def ai_tickers(self, principal: Principal) -> list[str]:
        """Sigles de l'univers autorisé, pour le contrôle des citations.

        Seules les positions réellement accessibles au principal comptent : la
        vérification ne doit jamais valider un ticker d'un portefeuille fermé.
        """
        return sorted(
            {
                str(holding.get("ticker"))
                for holding in self.holdings(principal)
                if holding.get("ticker")
            }
        )

    def ai_scope(self, principal: Principal) -> str:
        """Libellé du périmètre autorisé, repris tel quel dans l'interface."""
        if principal.is_admin:
            return "Tous les portefeuilles"
        allowed = self.allowed_portfolio_ids(principal)
        if allowed is None:
            return "Tous les portefeuilles"
        names = [
            str(portfolio.get("fund_name") or portfolio.get("fund_code") or portfolio.get("id"))
            for portfolio in self.load_portfolios()
            if str(portfolio.get("id")) in allowed
        ]
        return ", ".join(names) if names else "Aucun portefeuille"

    def ai_analysis_response(
        self,
        principal: Principal,
        question: str,
        instructions: dict[str, Any],
    ) -> dict[str, Any]:
        """Create safe AI response visualisations from authorised portfolio data."""

        portfolios = self.list_portfolios(principal)
        # Same authorised dataset as the model context, including ESG enrichment.
        holdings = self._holdings_with_esg(self.holdings(principal))
        return build_ai_analysis(question, portfolios, holdings, instructions)
