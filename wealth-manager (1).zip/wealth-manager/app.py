import os
import sys
import json
import math
import secrets
from datetime import datetime, timedelta

import pandas as pd
from flask import Flask, jsonify, request, session, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

app = Flask(__name__, static_folder="static", static_url_path="")
app.secret_key = secrets.token_hex(32)
app.permanent_session_lifetime = timedelta(hours=8)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

CONFIG_PATH = os.path.join(BASE_DIR, "datasource_config.json")


def _path(name):
    return os.path.join(BASE_DIR, name)


def load_config():
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except Exception:
        return {}


def get_parquet_path(key, default):
    cfg = load_config()
    p = cfg.get(key)
    if p:
        if not os.path.isabs(p):
            p = os.path.join(BASE_DIR, p)
        if os.path.exists(p):
            return p
    return _path(default)


CLIENTS_PATH = get_parquet_path("clients_path", "clients.parquet")
ACCOUNTS_PATH = get_parquet_path("accounts_path", "accounts.parquet")
HOLDINGS_PATH = get_parquet_path("holdings_path", "holdings.parquet")
VALUATION_PATH = get_parquet_path("valuation_path", "valuation.parquet")
REFERENCE_PATH = get_parquet_path("reference_path", "reference.parquet")

USERS = {
    "admin": {"password": "admin123", "role": "admin", "client_id": None},
    "gestionnaire": {"password": "wealth123", "role": "user", "client_id": None},
}


def df_to_json(df):
    df = df.copy()
    for col in df.columns:
        df[col] = df[col].astype(object).where(df[col].notna(), None)
    return df.to_dict("records")


def _safe_num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def load_table(path, cols):
    try:
        df = pd.read_parquet(path)
    except Exception:
        return pd.DataFrame(columns=cols)
    for c in cols:
        if c not in df.columns:
            df[c] = None
    return df[cols]


def save_table(path, df):
    df = df.copy()
    for col in df.columns:
        if df[col].dtype == object or str(df[col].dtype) == "string" or str(df[col].dtype).startswith("String"):
            has_nan = df[col].isna().any()
            raw = df[col].where(df[col].notna(), None)
            if not has_nan:
                num = pd.to_numeric(raw.replace("", None), errors="coerce")
                non_null = raw.replace("", None).notna()
                if non_null.any() and num[non_null].notna().all():
                    df[col] = num
                    continue
            df[col] = raw
    df.to_parquet(path, index=False)


def _reference_fallback():
    from seed import ACCOUNT_TYPES, ASSET_CLASSES, RISK_LABELS, SECURITIES
    return {
        "account_types": ACCOUNT_TYPES,
        "risk_labels": RISK_LABELS,
        "asset_classes": ASSET_CLASSES,
        "securities": SECURITIES,
    }


def _load_reference():
    try:
        df = pd.read_parquet(REFERENCE_PATH)
    except Exception:
        return _reference_fallback()
    if df.empty or "domain" not in df.columns or "key" not in df.columns:
        return _reference_fallback()
    kv = lambda dom: {r["key"]: r["value"] for r in df[df["domain"] == dom].to_dict("records")}
    account_types = kv("account_type")
    risk_labels = kv("risk_label")
    asset_classes = df[df["domain"] == "asset_class"]["key"].astype(str).tolist()
    securities = []
    for r in df[df["domain"] == "security"].to_dict("records"):
        px = r.get("px")
        if px is None or (isinstance(px, float) and math.isnan(px)):
            px = 0.0
        securities.append({"ticker": r["key"], "name": r["value"], "isin": r.get("isin") or "",
                           "class": r.get("class") or "", "sector": r.get("sector") or "",
                           "px": float(px)})
    if not (account_types and risk_labels and asset_classes and securities):
        return _reference_fallback()
    return {"account_types": account_types, "risk_labels": risk_labels,
            "asset_classes": asset_classes, "securities": securities}


_REF = _load_reference()
RISK_LABELS = _REF["risk_labels"]
ACCOUNT_TYPES = _REF["account_types"]
ASSET_CLASSES = _REF["asset_classes"]
SECURITIES = _REF["securities"]


def load_clients():
    return load_table(CLIENTS_PATH, ["id", "name", "email", "phone", "risk_profile",
                                     "country", "birth_year", "advisor", "notes", "created_at"])


def load_accounts():
    return load_table(ACCOUNTS_PATH, ["id", "client_id", "account_name", "account_type",
                                      "currency", "cash", "opening_date", "advisor",
                                      "notes", "created_at"])


def load_holdings():
    return load_table(HOLDINGS_PATH, ["id", "account_id", "ticker", "name", "isin",
                                      "asset_class", "sector", "currency", "quantity",
                                      "unit_cost", "unit_price", "buy_date",
                                      "last_price_date", "perf_ytd", "perf_1y",
                                      "perf_3y", "perf_5y", "market_value", "cost_value",
                                      "total_pnl", "pnl_pct", "weight_pct"])


def load_valuation():
    return load_table(VALUATION_PATH, ["id", "account_id", "date", "market_value",
                                       "cash", "total_value"])


def enrich_holdings(df):
    df = df.copy()
    for col in ["quantity", "unit_cost", "unit_price", "market_value", "cost_value",
                "total_pnl", "pnl_pct", "weight_pct"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def login_required(f):
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            return jsonify({"error": "Unauthorized", "login_required": True}), 401
        return f(*args, **kwargs)

    return decorated


@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json() or {}
    username = data.get("username", "").strip().lower()
    password = data.get("password", "")
    user = USERS.get(username)
    if not user or user["password"] != password:
        return jsonify({"error": "Identifiants invalides"}), 401
    session.permanent = True
    session["user"] = username
    session["role"] = user["role"]
    session["client_id"] = user["client_id"]
    return jsonify({"username": username, "role": user["role"]})


@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/me")
@login_required
def api_me():
    return jsonify({"username": session["user"], "role": session["role"]})


# ------------------------------------------------------------------ dashboard
@app.route("/api/dashboard")
@login_required
def api_dashboard():
    client_id = request.args.get("client_id", "")
    clients = df_to_json(load_clients())
    accounts = df_to_json(load_accounts())
    holdings = enrich_holdings(load_holdings())
    valuation = load_valuation()

    context_client = None
    if client_id:
        for c in clients:
            if c["id"] == client_id:
                context_client = c
                break
        account_ids = set(a["id"] for a in accounts if a["client_id"] == client_id)
        accounts = [a for a in accounts if a["id"] in account_ids]
        if not holdings.empty:
            holdings = holdings[holdings["account_id"].isin(account_ids)]
        if not valuation.empty:
            valuation = valuation[valuation["account_id"].isin(account_ids)]

    cash_map = {a["id"]: _safe_num(a.get("cash")) for a in accounts}

    total_aum = float(holdings["market_value"].sum()) + sum(cash_map.values())
    total_pnl = float(holdings["total_pnl"].sum())
    cost_total = float(holdings["cost_value"].sum())

    acct_map = {a["id"]: a for a in accounts}
    client_map = {c["id"]: c for c in clients}

    # per account aggregates
    per_account = {}
    for r in holdings.to_dict("records"):
        aid = r["account_id"]
        acc = per_account.setdefault(aid, {"mv": 0.0, "pnl": 0.0, "cost": 0.0, "count": 0})
        acc["mv"] += r["market_value"]
        acc["pnl"] += r["total_pnl"]
        acc["cost"] += r["cost_value"]
        acc["count"] += 1

    account_rows = []
    for aid, acc in per_account.items():
        a = acct_map.get(aid, {})
        cash = cash_map.get(aid, 0.0)
        account_rows.append({
            "account_id": aid,
            "account_name": a.get("account_name", aid),
            "account_type": a.get("account_type", ""),
            "client_id": a.get("client_id", ""),
            "client_name": client_map.get(a.get("client_id"), {}).get("name", "—"),
            "market_value": round(acc["mv"], 2),
            "cash": round(cash, 2),
            "total_value": round(acc["mv"] + cash, 2),
            "pnl": round(acc["pnl"], 2),
            "pnl_pct": round(acc["pnl"] / acc["cost"] * 100, 2) if acc["cost"] else 0.0,
            "position_count": acc["count"],
        })

    # per client aggregates
    client_rows = []
    for c in clients:
        client_accounts = [a for a in account_rows if a["client_id"] == c["id"]]
        mv = sum(a["market_value"] for a in client_accounts)
        cash = sum(cash_map[a["id"]] for a in accounts if a["client_id"] == c["id"])
        pnl = sum(a["pnl"] for a in client_accounts)
        cost = sum(per_account[a["account_id"]]["cost"] for a in client_accounts if a["account_id"] in per_account)
        client_rows.append({
            "client_id": c["id"],
            "name": c.get("name", ""),
            "risk_profile": c.get("risk_profile", ""),
            "risk_label": RISK_LABELS.get(c.get("risk_profile", ""), c.get("risk_profile", "")),
            "advisor": c.get("advisor", ""),
            "accounts": len(client_accounts),
            "positions": sum(a["position_count"] for a in client_accounts),
            "aum": round(mv + cash, 2),
            "market_value": round(mv, 2),
            "cash": round(cash, 2),
            "pnl": round(pnl, 2),
            "pnl_pct": round(pnl / cost * 100, 2) if cost else 0.0,
        })

    # allocation by asset class & sector
    asset_class = {}
    sector = {}
    for r in holdings.to_dict("records"):
        ac = r["asset_class"] or "—"
        asset_class[ac] = asset_class.get(ac, 0.0) + r["market_value"]
        sec = r["sector"] or "—"
        sector[sec] = sector.get(sec, 0.0) + r["market_value"]

    allocation_by_class = [{"label": k, "value": round(v, 2)} for k, v in sorted(asset_class.items(), key=lambda x: -x[1])]
    allocation_by_sector = [{"label": k, "value": round(v, 2)} for k, v in sorted(sector.items(), key=lambda x: -x[1])]

    # valuation series
    valuation_series = []
    if not valuation.empty:
        val_df = valuation.copy()
        val_df["date"] = val_df["date"].astype(str)
        val_df["total_value"] = pd.to_numeric(val_df["total_value"], errors="coerce")
        for r in val_df.to_dict("records"):
            valuation_series.append({
                "date": r["date"],
                "account_id": r["account_id"],
                "account_name": acct_map.get(r["account_id"], {}).get("account_name", r["account_id"]),
                "client_id": acct_map.get(r["account_id"], {}).get("client_id", ""),
                "total_value": round(r["total_value"] or 0, 2),
                "cash": round(r["cash"] or 0, 2),
            })

    return jsonify({
        "clients_count": len(clients),
        "accounts_count": len(accounts),
        "positions_count": int(len(holdings)),
        "total_aum": round(total_aum, 2),
        "total_pnl": round(total_pnl, 2),
        "total_pnl_pct": round(total_pnl / cost_total * 100, 2) if cost_total else 0.0,
        "context_client": context_client,
        "clients": client_rows,
        "accounts": account_rows,
        "allocation_by_class": allocation_by_class,
        "allocation_by_sector": allocation_by_sector,
        "valuation": valuation_series,
        "risk_labels": RISK_LABELS,
    })


# ------------------------------------------------------------------ clients
@app.route("/api/clients")
@login_required
def api_clients():
    return jsonify(df_to_json(load_clients()))


@app.route("/api/clients", methods=["POST"])
@login_required
def api_create_client():
    data = request.get_json() or {}
    cid = data.get("id") or "cl_" + secrets.token_hex(4)
    client = {
        "id": cid,
        "name": data.get("name", ""),
        "email": data.get("email", ""),
        "phone": data.get("phone", ""),
        "risk_profile": data.get("risk_profile", "equilibre"),
        "country": data.get("country", ""),
        "birth_year": data.get("birth_year", ""),
        "advisor": data.get("advisor", ""),
        "notes": data.get("notes", ""),
        "created_at": datetime.now().isoformat(),
    }
    df = load_clients()
    df = pd.concat([df, pd.DataFrame([client])], ignore_index=True)
    save_table(CLIENTS_PATH, df)
    return jsonify(client), 201


@app.route("/api/clients/<cid>", methods=["PUT"])
@login_required
def api_update_client(cid):
    data = request.get_json() or {}
    df = load_clients()
    df.loc[df["id"] == cid, [k for k in data.keys() if k in df.columns]] = [
        data[k] for k in data.keys() if k in df.columns
    ]
    save_table(CLIENTS_PATH, df)
    return jsonify({"ok": True})


@app.route("/api/clients/<cid>", methods=["DELETE"])
@login_required
def api_delete_client(cid):
    df = load_clients()
    df = df[df["id"] != cid]
    save_table(CLIENTS_PATH, df)
    return jsonify({"ok": True})


# ------------------------------------------------------------------ accounts
@app.route("/api/accounts")
@login_required
def api_accounts():
    client_id = request.args.get("client_id", "")
    df = load_accounts()
    if client_id:
        df = df[df["client_id"] == client_id]
    return jsonify(df_to_json(df))


@app.route("/api/accounts", methods=["POST"])
@login_required
def api_create_account():
    data = request.get_json() or {}
    acc = {
        "id": data.get("id") or "acc_" + secrets.token_hex(4),
        "client_id": data.get("client_id", ""),
        "account_name": data.get("account_name", ""),
        "account_type": data.get("account_type", "ct"),
        "currency": data.get("currency", "EUR"),
        "cash": data.get("cash", 0),
        "opening_date": data.get("opening_date", ""),
        "advisor": data.get("advisor", ""),
        "notes": data.get("notes", ""),
        "created_at": datetime.now().isoformat(),
    }
    df = load_accounts()
    df = pd.concat([df, pd.DataFrame([acc])], ignore_index=True)
    save_table(ACCOUNTS_PATH, df)
    return jsonify(acc), 201


@app.route("/api/accounts/<aid>", methods=["PUT"])
@login_required
def api_update_account(aid):
    data = request.get_json() or {}
    df = load_accounts()
    cols = [k for k in data.keys() if k in df.columns]
    if cols:
        df.loc[df["id"] == aid, cols] = [data[k] for k in cols]
        save_table(ACCOUNTS_PATH, df)
    return jsonify({"ok": True})


@app.route("/api/accounts/<aid>", methods=["DELETE"])
@login_required
def api_delete_account(aid):
    df = load_accounts()
    df = df[df["id"] != aid]
    save_table(ACCOUNTS_PATH, df)
    h = load_holdings()
    h = h[h["account_id"] != aid]
    save_table(HOLDINGS_PATH, h)
    v = load_valuation()
    v = v[v["account_id"] != aid]
    save_table(VALUATION_PATH, v)
    return jsonify({"ok": True})


# ------------------------------------------------------------------ holdings
@app.route("/api/holdings")
@login_required
def api_holdings():
    account_id = request.args.get("account_id", "")
    client_id = request.args.get("client_id", "")
    df = enrich_holdings(load_holdings())
    if account_id:
        df = df[df["account_id"] == account_id]
    if client_id:
        accounts = load_accounts()
        ids = set(accounts[accounts["client_id"] == client_id]["id"])
        df = df[df["account_id"].isin(ids)]
    df = df.sort_values("market_value", ascending=False)
    return jsonify(df_to_json(df))


@app.route("/api/holdings", methods=["POST"])
@login_required
def api_create_holding():
    data = request.get_json() or {}
    h = {
        "id": data.get("id") or "h_" + secrets.token_hex(4),
        "account_id": data.get("account_id", ""),
        "ticker": data.get("ticker", ""),
        "name": data.get("name", ""),
        "isin": data.get("isin", ""),
        "asset_class": data.get("asset_class", "Action"),
        "sector": data.get("sector", ""),
        "currency": data.get("currency", "EUR"),
        "quantity": data.get("quantity", 0),
        "unit_cost": data.get("unit_cost", 0),
        "unit_price": data.get("unit_price", 0),
        "buy_date": data.get("buy_date", ""),
        "last_price_date": data.get("last_price_date", ""),
        "perf_ytd": data.get("perf_ytd", 0),
        "perf_1y": data.get("perf_1y", 0),
        "perf_3y": data.get("perf_3y", 0),
        "perf_5y": data.get("perf_5y", 0),
    }
    df = load_holdings()
    df = pd.concat([df, pd.DataFrame([h])], ignore_index=True)
    save_table(HOLDINGS_PATH, df)
    return jsonify(h), 201


@app.route("/api/holdings/<hid>", methods=["PUT"])
@login_required
def api_update_holding(hid):
    data = request.get_json() or {}
    df = load_holdings()
    cols = [k for k in data.keys() if k in df.columns]
    if cols:
        df.loc[df["id"] == hid, cols] = [data[k] for k in cols]
        save_table(HOLDINGS_PATH, df)
    return jsonify({"ok": True})


@app.route("/api/holdings/<hid>", methods=["DELETE"])
@login_required
def api_delete_holding(hid):
    df = load_holdings()
    df = df[df["id"] != hid]
    save_table(HOLDINGS_PATH, df)
    return jsonify({"ok": True})


# ------------------------------------------------------------------ valuation
@app.route("/api/valuation")
@login_required
def api_valuation():
    account_id = request.args.get("account_id", "")
    client_id = request.args.get("client_id", "")
    df = load_valuation()
    if account_id:
        df = df[df["account_id"] == account_id]
    if client_id:
        accounts = load_accounts()
        ids = set(accounts[accounts["client_id"] == client_id]["id"])
        df = df[df["account_id"].isin(ids)]
    if "date" in df.columns:
        df = df.sort_values("date")
    return jsonify(df_to_json(df))


# ------------------------------------------------------------------ reporting
@app.route("/api/report")
@login_required
def api_report():
    client_id = request.args.get("client_id", "")
    clients = df_to_json(load_clients())
    accounts = df_to_json(load_accounts())
    holdings = enrich_holdings(load_holdings())
    valuation = load_valuation()

    period = request.args.get("period", "all")
    start_arg = (request.args.get("start") or "").strip()
    end_arg = (request.args.get("end") or "").strip()
    today = datetime.now().date()
    try:
        end_d = datetime.strptime(end_arg, "%Y-%m-%d").date() if end_arg else today
    except ValueError:
        end_d = today
    if start_arg:
        try:
            start_d = datetime.strptime(start_arg, "%Y-%m-%d").date()
        except ValueError:
            start_d = None
    else:
        period_map = {
            "1m": lambda: end_d - timedelta(days=30),
            "3m": lambda: end_d - timedelta(days=91),
            "6m": lambda: end_d - timedelta(days=183),
            "1y": lambda: end_d - timedelta(days=365),
            "ytd": lambda: datetime(end_d.year, 1, 1).date(),
        }
        start_d = period_map.get(period, lambda: None)()

    context_client = None
    if client_id:
        for c in clients:
            if c["id"] == client_id:
                context_client = c
                break
        account_ids = set(a["id"] for a in accounts if a["client_id"] == client_id)
        accounts = [a for a in accounts if a["id"] in account_ids]
        clients = [c for c in clients if c["id"] == client_id]
        if not holdings.empty:
            holdings = holdings[holdings["account_id"].isin(account_ids)]
        if not valuation.empty:
            valuation = valuation[valuation["account_id"].isin(account_ids)]

    acct_map = {a["id"]: a for a in accounts}
    cash_map = {a["id"]: _safe_num(a.get("cash")) for a in accounts}
    client_map = {c["id"]: c for c in clients}

    holdings_rows = []
    for r in holdings.to_dict("records"):
        a = acct_map.get(r["account_id"], {})
        holdings_rows.append({
            **r,
            "account_name": a.get("account_name", ""),
            "client_id": a.get("client_id", ""),
            "client_name": client_map.get(a.get("client_id"), {}).get("name", ""),
            "market_value": round(r["market_value"], 2),
            "cost_value": round(r["cost_value"], 2),
            "total_pnl": round(r["total_pnl"], 2),
            "pnl_pct": round(r["pnl_pct"], 2),
            "weight_pct": round(r["weight_pct"], 2),
        })

    # regroup by account
    account_report = {a["id"]: {
        "account_id": a["id"],
        "client_id": a.get("client_id", ""),
        "client_name": client_map.get(a.get("client_id", ""), {}).get("name", ""),
        "account_name": a.get("account_name", a["id"]),
        "account_type": a.get("account_type", ""),
        "positions": [],
        "mv": 0.0, "cost": 0.0, "pnl": 0.0,
    } for a in accounts}
    for r in holdings_rows:
        aid = r["account_id"]
        row = account_report.setdefault(aid, {
            "account_id": aid,
            "client_id": r["client_id"],
            "client_name": r["client_name"],
            "account_name": r["account_name"],
            "account_type": "",
            "positions": [],
            "mv": 0.0, "cost": 0.0, "pnl": 0.0,
        })
        row["positions"].append(r)
        row["mv"] += r["market_value"]
        row["cost"] += r["cost_value"]
        row["pnl"] += r["total_pnl"]

    for aid, row in account_report.items():
        row["cash"] = cash_map.get(aid, 0.0)
        row["total_value"] = round(row["mv"] + row["cash"], 2)
        row["mv"] = round(row["mv"], 2)
        row["cost"] = round(row["cost"], 2)
        row["pnl"] = round(row["pnl"], 2)
        row["pnl_pct"] = round(row["pnl"] / row["cost"] * 100, 2) if row["cost"] else 0.0
        row["positions"].sort(key=lambda p: -p["market_value"])
        row["positions"] = row["positions"][:15]

    # clients report
    client_report = []
    for c in clients:
        ca = [acct_map[a] for a in acct_map if acct_map[a]["client_id"] == c["id"]]
        ch = [r for r in holdings_rows if r["client_id"] == c["id"]]
        mv = sum(r["market_value"] for r in ch)
        cost = sum(r["cost_value"] for r in ch)
        pnl = sum(r["total_pnl"] for r in ch)
        cash = sum(cash_map.get(a["id"], 0.0) for a in ca)
        client_report.append({
            **c,
            "risk_label": RISK_LABELS.get(c.get("risk_profile", ""), ""),
            "accounts": len(ca),
            "positions": len(ch),
            "aum": round(mv + cash, 2),
            "market_value": round(mv, 2),
            "cash": round(cash, 2),
            "pnl": round(pnl, 2),
            "pnl_pct": round(pnl / cost * 100, 2) if cost else 0.0,
            "accounts_detail": account_report,
        })

    # performance per account from valuation series (within selected period)
    perf = {}
    if not valuation.empty:
        v = valuation.copy()
        v["total_value"] = pd.to_numeric(v["total_value"], errors="coerce")
        v["date"] = v["date"].astype(str)
        dmin = start_d.isoformat() if start_d else None
        dmax = end_d.isoformat()
        for aid, g in v.groupby("account_id"):
            g = g.sort_values("date")
            if dmin:
                g = g[(g["date"] >= dmin) & (g["date"] <= dmax)]
            else:
                g = g[g["date"] <= dmax]
            if len(g) >= 2:
                first = float(g.iloc[0]["total_value"])
                last = float(g.iloc[-1]["total_value"])
                perf[aid] = {
                    "start": g.iloc[0]["date"],
                    "end": g.iloc[-1]["date"],
                    "start_value": round(first, 2),
                    "end_value": round(last, 2),
                    "growth": round(last - first, 2),
                    "growth_pct": round((last / first - 1) * 100, 2) if first else 0.0,
                }

    return jsonify({
        "generated_at": datetime.now().isoformat(),
        "period": {"key": period, "start": start_d.isoformat() if start_d else None, "end": end_d.isoformat()},
        "total_aum": round(sum(r["mv"] for r in account_report.values()) + sum(cash_map.values()), 2),
        "total_pnl": round(sum(r["pnl"] for r in account_report.values()), 2),
        "context_client": context_client,
        "clients": client_report,
        "accounts": account_report,
        "holdings": holdings_rows,
        "performance": perf,
    })


@app.route("/api/export")
@login_required
def api_export():
    import csv
    import io
    kind = request.args.get("kind", "holdings")
    si = io.StringIO()
    w = csv.writer(si)
    if kind == "holdings":
        rows = enrich_holdings(load_holdings()).to_dict("records")
        acct = {a["id"]: a for a in df_to_json(load_accounts())}
        cli = {c["id"]: c for c in df_to_json(load_clients())}
        w.writerow(["Client", "Compte", "Ticker", "Nom", "ISIN", "Classe", "Secteur", "Qté",
                    "PRU", "Cours", "Valorisation", "Coût", "P&L", "P&L %", "Poids %", "Date achat"])
        for r in sorted(rows, key=lambda x: -x["market_value"]):
            a = acct.get(r["account_id"], {})
            w.writerow([
                cli.get(a.get("client_id"), {}).get("name", ""), a.get("account_name", ""),
                r["ticker"], r["name"], r["isin"], r["asset_class"], r["sector"], r["quantity"],
                r["unit_cost"], r["unit_price"], round(r["market_value"], 2), round(r["cost_value"], 2),
                round(r["total_pnl"], 2), round(r["pnl_pct"], 2), round(r["weight_pct"], 2), r["buy_date"],
            ])
    elif kind == "clients":
        rep = api_report().get_json()["clients"]
        w.writerow(["Client", "Profil de risque", "Conseiller", "Comptes", "Positions",
                    "Valorisation", "Cash", "AuM", "P&L", "P&L %"])
        for c in rep:
            w.writerow([c["name"], c["risk_label"], c.get("advisor", ""), c["accounts"],
                        c["positions"], c["market_value"], c["cash"], c["aum"], c["pnl"], c["pnl_pct"]])
    elif kind == "accounts":
        rep = api_report().get_json()["accounts"]
        w.writerow(["Client", "Compte", "Valorisation", "Cash", "Total", "P&L", "P&L %", "Positions"])
        for a in rep.values():
            w.writerow([a["client_name"], a["account_name"], a["mv"], a["cash"], a["total_value"],
                        a["pnl"], a["pnl_pct"], len(a["positions"])])
    return si.getvalue(), 200, {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": f"attachment; filename=wealth_{kind}.csv",
    }


# -------------------------------------------------------------- factsheet
def _period_matrix(valuation, accounts, today, group_map=None):
    """Multi-périodes : variation % de chaque compte (ou groupe via group_map)
    et du portefeuille sur 1 mois / 3 mois / 6 mois / YTD / 1 an."""
    periods = {"1m": 30, "3m": 91, "6m": 183, "ytd": None, "1y": 365}
    rows = {}
    if valuation.empty:
        return rows
    v = valuation.copy()
    v["total_value"] = pd.to_numeric(v["total_value"], errors="coerce")
    v["date"] = v["date"].astype(str)
    if accounts:
        v = v[v["account_id"].isin(set(accounts.keys()))]
    if group_map:
        v["_g"] = v["account_id"].map(group_map).fillna("?")
        groups = [(g, gd) for g, gd in v.groupby("_g")]
    else:
        groups = [(aid, g) for aid, g in v.groupby("account_id")]
    daily = v.groupby("date")["total_value"].sum().reset_index().sort_values("date")
    if not daily.empty:
        groups.append(("portfolio", daily))
    for aid, g in groups:
        g = g.groupby("date", as_index=False)["total_value"].sum().sort_values("date")
        row = {}
        for key, days in periods.items():
            d0 = (today - timedelta(days=days)).isoformat() if days else f"{today.year}-01-01"
            d1 = today.isoformat()
            seg = g[(g["date"] >= d0) & (g["date"] <= d1)]
            if len(seg) >= 2:
                f = float(seg.iloc[0]["total_value"])
                l = float(seg.iloc[-1]["total_value"])
                row[key] = round((l / f - 1) * 100, 2) if f else None
            else:
                row[key] = None
        rows[aid] = row
    return rows


def _global_series(valuation, accounts):
    if valuation.empty:
        return []
    v = valuation.copy()
    v["total_value"] = pd.to_numeric(v["total_value"], errors="coerce")
    v["date"] = v["date"].astype(str)
    if accounts:
        v = v[v["account_id"].isin(set(accounts.keys()))]
    s = v.groupby("date")["total_value"].sum().sort_index()
    return [{"date": d, "value": round(float(x), 2)} for d, x in s.items()]


def _factsheet_report():
    report = api_report().get_json()
    try:
        valuation = load_valuation()
        accounts = report.get("accounts") or {}
        today = datetime.now().date()
        report["period_matrix"] = _period_matrix(valuation, accounts, today)
        report["series_global"] = _global_series(valuation, accounts)
        if report.get("context_client"):
            report["period_matrix_group"] = None
        else:
            group_map = {a.get("account_id"): a.get("client_id") for a in accounts.values()}
            report["period_matrix_group"] = _period_matrix(valuation, accounts, today, group_map)
    except Exception:
        report.setdefault("period_matrix", {})
        report.setdefault("period_matrix_group", {})
        report.setdefault("series_global", [])
    return report


@app.route("/api/report/excel")
@login_required
def api_report_excel():
    from factsheet import build_excel
    report = _factsheet_report()
    try:
        data = build_excel(report)
    except Exception:
        import traceback
        traceback.print_exc()
        return jsonify({"error": "Erreur génération Excel"}), 500
    ctx = report.get("context_client") or {}
    fname = (ctx.get("id") or "all_clients") + "_factsheet.xlsx"
    return data, 200, {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": f"attachment; filename={fname}",
    }


@app.route("/api/report/pdf")
@login_required
def api_report_pdf():
    from factsheet import build_pdf
    report = _factsheet_report()
    try:
        data = build_pdf(report)
    except Exception:
        import traceback
        traceback.print_exc()
        return jsonify({"error": "Erreur génération PDF"}), 500
    ctx = report.get("context_client") or {}
    fname = (ctx.get("id") or "all_clients") + "_factsheet.pdf"
    return data, 200, {
        "Content-Type": "application/pdf",
        "Content-Disposition": f"attachment; filename={fname}",
    }


@app.route("/api/meta")
@login_required
def api_meta():
    return jsonify({
        "account_types": ACCOUNT_TYPES,
        "securities": [{"ticker": s["ticker"], "name": s["name"], "isin": s["isin"],
                        "class": s["class"], "sector": s["sector"], "px": s["px"]} for s in SECURITIES],
        "risk_labels": RISK_LABELS,
        "asset_classes": ASSET_CLASSES,
    })


# -------------------------------------------------------------- datasource
DS_FIELDS = [
    ("clients_path", "clients.parquet", "Clients"),
    ("accounts_path", "accounts.parquet", "Comptes"),
    ("holdings_path", "holdings.parquet", "Positions"),
    ("valuation_path", "valuation.parquet", "Valorisations"),
    ("reference_path", "reference.parquet", "Référence"),
]


def _table_info(path, cols):
    info = {"configured": path, "exists": False, "rows": 0, "cols": []}
    try:
        if os.path.exists(path):
            df = pd.read_parquet(path)
            info["exists"] = True
            info["rows"] = int(len(df))
            info["cols"] = list(df.columns)
    except Exception:
        info["exists"] = False
    return info


@app.route("/api/config/datasource")
@login_required
def api_datasource_config():
    cfg = load_config()
    resolved = {}
    for key, default, label in DS_FIELDS:
        resolved[key] = {
            "label": label,
            "configured": cfg.get(key, ""),
            "resolved": get_parquet_path(key, default),
            **{k: v for k, v in _table_info(get_parquet_path(key, default), []).items()},
        }
    return jsonify({"config": cfg, "tables": resolved, "base_dir": BASE_DIR})


@app.route("/api/config/datasource", methods=["POST"])
@login_required
def api_save_datasource_config():
    data = request.get_json() or {}
    action = data.get("action", "save")
    if action == "reset":
        try:
            os.remove(CONFIG_PATH)
        except OSError:
            pass
        for _, default, _ in DS_FIELDS:
            path = _path(default)
            try:
                if os.path.exists(path):
                    os.remove(path)
            except OSError:
                pass
        from seed import main as seed_main
        seed_main()
        return jsonify({"ok": True, "message": "Données de démo régénérées"})
    cfg = {}
    for key, _, _ in DS_FIELDS:
        v = str(data.get(key, "") or "").strip()
        if v:
            cfg[key] = v
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
    return jsonify({"ok": True, "message": "Config enregistrée — redémarrez le serveur pour appliquer"})


@app.route("/")
def index():
    return send_from_directory("static", "index.html")


@app.route("/<path:path>")
def static_files(path):
    try:
        return send_from_directory("static", path)
    except Exception:
        return send_from_directory("static", "index.html")


def ensure_demo_data():
    if not os.path.exists(CLIENTS_PATH):
        from seed import main as seed_main
        print("Données de démo absentes -> génération...")
        seed_main()


if __name__ == "__main__":
    ensure_demo_data()
    app.run(host="0.0.0.0", port=5001)
