import io
from datetime import datetime


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _eur(v):
    return "{:,.2f}".format(_num(v)).replace(",", " ").replace(".", ",") + " €"


def _pct(v):
    return "{:,.2f}".format(_num(v)).replace(",", " ").replace(".", ",") + " %"


def _spct(v):
    if v is None:
        return "—"
    s = "{:,.2f}".format(abs(_num(v))).replace(",", " ").replace(".", ",")
    return ("+" if _num(v) >= 0 else "-") + s + " %"


def _short(v):
    x = _num(v)
    neg = "-" if x < 0 else ""
    a = abs(x)
    if a >= 1e6:
        return neg + "{:,.2f}".format(a / 1e6).replace(",", " ").replace(".", ",") + " M€"
    if a >= 1e3:
        return neg + "{:,.1f}".format(a / 1e3).replace(",", " ").replace(".", ",") + " k€"
    return neg + "{:,.0f}".format(a).replace(",", " ").replace(".", ",") + " €"


_MONTHS_FR = ["", "janvier", "février", "mars", "avril", "mai", "juin",
              "juillet", "août", "septembre", "octobre", "novembre", "décembre"]


def _month_fr(dt):
    return (_MONTHS_FR[dt.month] + " " + str(dt.year)).upper()


def _d_fr(d):
    try:
        return datetime.strptime(str(d)[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
    except (ValueError, TypeError):
        return "—"


def _truncate(s, n):
    return s if len(s) <= n else s[:n - 1] + "…"


_RISK_FR = {"conservateur": "Conservateur", "equilibre": "Équilibré", "dynamique": "Dynamique"}


def _risk_label(v):
    return _RISK_FR.get(str(v or "").lower(), str(v or "—"))


def _line_chart(series, w=490, h=150):
    """Petit graphique de série temporelle (valorisation consolidée)."""
    from reportlab.graphics.shapes import Drawing, String, Line, PolyLine, Polygon
    from reportlab.lib import colors
    d = Drawing(w, h)
    n = len(series)
    if n < 2:
        d.add(String(w / 2, h / 2, "Historique insuffisant", fontSize=9,
                     fillColor=colors.HexColor("#6C757D"), textAnchor="middle"))
        return d
    vals = [_num(p.get("value")) for p in series]
    lo, hi = min(vals), max(vals)
    pad = (hi - lo) * 0.12 or (hi * 0.1) or 1.0
    lo -= pad
    hi += pad
    span = hi - lo or 1.0
    if span >= 1e6:
        unit, unit_lbl = 1e6, "M€"
    elif span >= 1e3:
        unit, unit_lbl = 1e3, "k€"
    else:
        unit, unit_lbl = 1.0, "€"
    ml, mr, mt, mb = 46, 12, 14, 26
    pw = w - ml - mr
    ph = h - mt - mb

    def X(i):
        return ml + pw * (i / (n - 1))

    def Y(v):
        return mt + ph * (1 - (v - lo) / span)

    for k in range(5):
        f = k / 4
        vy = lo + f * span
        y = Y(vy)
        d.add(Line(ml, y, w - mr, y, strokeColor=colors.HexColor("#E5E7EB"), strokeWidth=0.5))
        lbl = "{:,.1f}".format(vy / unit).replace(",", " ").replace(".", ",")
        d.add(String(ml - 5, y - 3, lbl, fontSize=7,
                     fillColor=colors.HexColor("#6C757D"), textAnchor="end"))
    d.add(Line(ml, mt, ml, mt + ph, strokeColor=colors.HexColor("#9CA3AF"), strokeWidth=0.8))
    d.add(Line(ml, mt, w - mr, mt, strokeColor=colors.HexColor("#9CA3AF"), strokeWidth=0.8))
    for i in sorted(set([0, n - 1, n // 3, 2 * n // 3])):
        lbl = str(series[i]["date"])[2:7]
        anchor = "start" if i == 0 else ("end" if i == n - 1 else "middle")
        d.add(String(X(i), mt - 10, lbl, fontSize=7,
                     fillColor=colors.HexColor("#6C757D"), textAnchor=anchor))
    pts = [ml, mt]
    for i, p in enumerate(series):
        pts += [X(i), Y(_num(p.get("value")))]
    pts += [w - mr, mt]
    d.add(Polygon(pts, fillColor=colors.HexColor("#E8F5EE"), strokeColor=None))
    line_pts = []
    for i, p in enumerate(series):
        line_pts += [X(i), Y(_num(p.get("value")))]
    d.add(PolyLine(line_pts, strokeColor=colors.HexColor("#0D6E4F"), strokeWidth=1.8))
    d.add(String(w - mr, mt + ph - 12, "(" + unit_lbl + ")",
                 fontSize=7, fillColor=colors.HexColor("#6C757D"), textAnchor="end"))
    return d


def _allocation(holdings):
    by_class = {}
    by_sector = {}
    total = 0.0
    for h in holdings:
        mv = _num(h.get("market_value"))
        total += mv
        c = h.get("asset_class") or "—"
        by_class[c] = by_class.get(c, 0.0) + mv
        s = h.get("sector") or "—"
        by_sector[s] = by_sector.get(s, 0.0) + mv
    rows_class = [{"label": k, "value": v, "weight": (v / total * 100) if total else 0}
                  for k, v in sorted(by_class.items(), key=lambda x: -x[1])]
    rows_sector = [{"label": k, "value": v, "weight": (v / total * 100) if total else 0}
                   for k, v in sorted(by_sector.items(), key=lambda x: -x[1])]
    return rows_class, rows_sector


def _top_holdings(holdings, n=10):
    return sorted(holdings, key=lambda h: -_num(h.get("market_value")))[:n]


def _top_holdings_agg(holdings, n=10):
    agg = {}
    for h in holdings:
        k = h.get("ticker") or h.get("name") or "?"
        b = agg.setdefault(k, {"market_value": 0.0, "ticker": h.get("ticker") or "",
                               "name": h.get("name") or k,
                               "asset_class": h.get("asset_class") or "—"})
        b["market_value"] += _num(h.get("market_value"))
    return sorted(agg.values(), key=lambda b: -b["market_value"])[:n]


def _allocation_by_account(holdings):
    buckets = {}
    for h in holdings:
        aid = h.get("account_id") or "?"
        b = buckets.setdefault(aid, {"name": h.get("account_name") or aid, "by_class": {}, "total": 0.0})
        mv = _num(h.get("market_value"))
        b["total"] += mv
        c = h.get("asset_class") or "—"
        b["by_class"][c] = b["by_class"].get(c, 0.0) + mv
    result = []
    for aid, b in buckets.items():
        rows = [{"label": k, "value": v, "weight": (v / b["total"] * 100) if b["total"] else 0}
                for k, v in sorted(b["by_class"].items(), key=lambda x: -x[1])]
        result.append({"account_id": aid, "account_name": b["name"], "total": round(b["total"], 2), "rows": rows})
    result.sort(key=lambda x: -x["total"])
    return result


def _pie_drawing(rows, w=260, h=150, palette=None, legend_cols=2):
    from reportlab.graphics.shapes import Drawing, Wedge, String, Rect
    from reportlab.lib import colors
    import math
    if palette is None:
        palette = ["#0D6E4F", "#0EA5E9", "#F59E0B", "#8B5CF6", "#14B8A6",
                   "#EF4444", "#EC4899", "#F97316", "#64748B", "#15803D"]
    rows = [r for r in rows if _num(r.get("value")) > 0]
    d = Drawing(w, h)
    if not rows:
        d.add(String(w / 2, h / 2, "Aucune donnée", fontSize=8,
                     fillColor=colors.HexColor("#6C757D"), textAnchor="middle"))
        return d
    total = sum(_num(r.get("value")) for r in rows) or 1
    r = min(w * 0.30, h * 0.42)
    cx = r + 8
    cy = h / 2
    a = 0.0
    for i, row in enumerate(rows):
        span = _num(row.get("value")) / total * 360.0
        d.add(Wedge(cx, cy, r, a, a + span,
                    fillColor=colors.HexColor(palette[i % len(palette)]),
                    strokeColor=colors.white, strokeWidth=1.2))
        mid = math.radians(a + span / 2)
        lx = cx + r * 0.60 * math.cos(mid)
        ly = cy + r * 0.60 * math.sin(mid)
        d.add(String(lx, ly, f"{_num(row.get('weight')):.0f}%", fontSize=7,
                     fillColor=colors.white, textAnchor="middle", fontName="Helvetica-Bold"))
        a += span
    lx0 = cx + r + 16
    col_w = max((w - lx0) / legend_cols, 50)
    per_col = max(math.ceil(len(rows) / legend_cols), 1)
    row_h = min(12, max(8, (h - 8) / per_col))
    for i, row in enumerate(rows):
        col = i // per_col
        rw = i % per_col
        lx = lx0 + col * col_w
        yy = h - 9 - rw * row_h
        d.add(Rect(lx, yy - 5, 6, 6,
                   fillColor=colors.HexColor(palette[i % len(palette)]),
                   strokeWidth=0.2, strokeColor=colors.HexColor("#9CA3AF")))
        d.add(String(lx + 9, yy, f"{row['label']}", fontSize=6.5,
                     fillColor=colors.HexColor("#1F2937")))
    return d


# ================================================================== EXCEL
def build_excel(report):
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    ctx = report.get("context_client")
    title = (ctx.get("name") if ctx else "Vue globale — Tous les clients")
    is_single = bool(ctx)
    holdings = report.get("holdings", [])
    accounts = report.get("accounts", {})
    perf = report.get("performance", {})
    rows_class, rows_sector = _allocation(holdings)

    GREEN = "0D6E4F"
    LGREEN = "E8F5EE"
    wb = openpyxl.Workbook()

    # ---------------------------------------------------------- Synthèse
    ws = wb.active
    ws.title = "Synthèse"
    ws["B2"] = "FACTSHEET PATRIMOINE"
    ws["B2"].font = Font(bold=True, size=16, color=GREEN)
    ws["B3"] = ("Client : " + title) if is_single else ("Périmètre : " + title)
    ws["B3"].font = Font(bold=True, size=12)
    ws["B4"] = "Généré le " + datetime.now().strftime("%d/%m/%Y à %H:%M")
    ws["B4"].font = Font(size=9, color="777777")

    if is_single:
        info = [
            ("Identifiant", ctx.get("id", "")),
            ("Profil de risque", (ctx.get("risk_label") or ctx.get("risk_profile") or "")),
            ("Pays", ctx.get("country") or ""),
            ("Conseiller", ctx.get("advisor") or ""),
        ]
        r = 6
        for k, v in info:
            ws.cell(row=r, column=2, value=k).font = Font(bold=True, size=10)
            ws.cell(row=r, column=3, value=v).font = Font(size=10)
            r += 1

    r = 6
    if not is_single:
        r = 5
    ws.cell(row=r, column=2, value="Indicateurs").font = Font(bold=True, size=12, color=GREEN)
    r += 1
    kpis = [
        ("Actifs sous gestion (AuM)", report.get("total_aum", 0), "0.00"),
        ("P&L totale", report.get("total_pnl", 0), "0.00"),
        ("Nombre de comptes", len(accounts), "0"),
        ("Nombre de positions", len(holdings), "0"),
    ]
    for i, (label, val, fmt) in enumerate(kpis):
        c1 = ws.cell(row=r, column=2, value=label)
        c2 = ws.cell(row=r, column=3, value=val)
        c1.font = Font(size=10)
        c2.font = Font(bold=True, size=10)
        c2.number_format = fmt
        r += 1

    ws.column_dimensions["A"].width = 2
    ws.column_dimensions["B"].width = 26
    ws.column_dimensions["C"].width = 22

    # ---------------------------------------------------------- Allocation
    ws2 = wb.create_sheet("Allocation")
    ws2["A1"] = "Allocation par classe d'actifs"
    ws2["A1"].font = Font(bold=True, size=12, color=GREEN)
    header = ["Classe d'actifs", "Valorisation", "Poids"]
    for j, h in enumerate(header, start=1):
        c = ws2.cell(row=3, column=j, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=GREEN)
    for i, row in enumerate(rows_class):
        ws2.cell(row=4 + i, column=1, value=row["label"])
        ws2.cell(row=4 + i, column=2, value=round(row["value"], 2)).number_format = "#,##0.00"
        ws2.cell(row=4 + i, column=3, value=round(row["weight"], 2)).number_format = "0.00\" %\""

    if rows_class:
        from openpyxl.chart import PieChart, Reference
        pie = PieChart()
        pie.title = "Répartition par classe d'actifs"
        labels = Reference(ws2, min_col=1, min_row=4, max_row=3 + len(rows_class))
        data = Reference(ws2, min_col=2, min_row=3, max_row=3 + len(rows_class))
        pie.add_data(data, titles_from_data=True)
        pie.set_categories(labels)
        pie.dataLabels = None
        from openpyxl.chart.label import DataLabelList
        pie.dataLabels = DataLabelList()
        pie.dataLabels.showPercent = True
        pie.width = 18
        pie.height = 12
        ws2.add_chart(pie, "F3")

    start_sector = 4 + len(rows_class) + 2
    ws2.cell(row=start_sector, column=1, value="Allocation par secteur").font = Font(bold=True, size=12, color=GREEN)
    for j, h in enumerate(header, start=1):
        c = ws2.cell(row=start_sector + 1, column=j, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=GREEN)
    for i, row in enumerate(rows_sector):
        ws2.cell(row=start_sector + 2 + i, column=1, value=row["label"])
        ws2.cell(row=start_sector + 2 + i, column=2, value=round(row["value"], 2)).number_format = "#,##0.00"
        ws2.cell(row=start_sector + 2 + i, column=3, value=round(row["weight"], 2)).number_format = "0.00\" %\""
    for col in ("A", "B", "C"):
        ws2.column_dimensions[col].width = 28

    # ---------------------------------------------------------- Allocation par compte
    from openpyxl.chart import PieChart, Reference
    from openpyxl.chart.label import DataLabelList
    alloc_acc = _allocation_by_account(holdings)
    if alloc_acc:
        start_acc = start_sector + len(rows_sector) + 3
        ws2.cell(row=start_acc, column=1, value="Allocation par compte").font = Font(bold=True, size=12, color=GREEN)
        r = start_acc + 2
        for acc in alloc_acc:
            ws2.cell(row=r - 1, column=1, value=acc["account_name"]).font = Font(bold=True, size=10)
            for j, h in enumerate(header, start=1):
                c = ws2.cell(row=r, column=j, value=h)
                c.font = Font(bold=True, color="FFFFFF")
                c.fill = PatternFill("solid", fgColor=GREEN)
            for i, row in enumerate(acc["rows"]):
                ws2.cell(row=r + 1 + i, column=1, value=row["label"])
                ws2.cell(row=r + 1 + i, column=2, value=round(row["value"], 2)).number_format = "#,##0.00"
                ws2.cell(row=r + 1 + i, column=3, value=round(row["weight"], 2)).number_format = "0.00\" %\""
            if acc["rows"]:
                pie = PieChart()
                pie.title = acc["account_name"]
                labels = Reference(ws2, min_col=1, min_row=r + 1, max_row=r + len(acc["rows"]))
                data = Reference(ws2, min_col=2, min_row=r, max_row=r + len(acc["rows"]))
                pie.add_data(data, titles_from_data=True)
                pie.set_categories(labels)
                pie.dataLabels = DataLabelList()
                pie.dataLabels.showPercent = True
                pie.width = 9
                pie.height = 6.5
                ws2.add_chart(pie, "F" + str(r))
            r += len(acc["rows"]) + 4

    # ---------------------------------------------------------- Positions
    ws3 = wb.create_sheet("Positions")
    ws3["A1"] = "Positions en portefeuille"
    ws3["A1"].font = Font(bold=True, size=12, color=GREEN)
    header = ["Ticker", "Nom", "ISIN", "Classe", "Secteur", "Compte", "Quantité", "PRU", "Cours",
              "Valorisation", "Poids", "P&L", "P&L %"]
    for j, h in enumerate(header, start=1):
        c = ws3.cell(row=3, column=j, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=GREEN)
        c.alignment = Alignment(horizontal="center")
    for i, h in enumerate(sorted(holdings, key=lambda x: -_num(x.get("market_value")))):
        vals = [h.get("ticker"), h.get("name"), h.get("isin"), h.get("asset_class"), h.get("sector"),
                h.get("account_name"), _num(h.get("quantity")), _num(h.get("unit_cost")),
                _num(h.get("unit_price")), _num(h.get("market_value")), _num(h.get("weight_pct")),
                _num(h.get("total_pnl")), _num(h.get("pnl_pct"))]
        for j, v in enumerate(vals, start=1):
            ws3.cell(row=4 + i, column=j, value=v)
        ws3.cell(row=4 + i, column=7).number_format = "#,##0.0000"
        ws3.cell(row=4 + i, column=8).number_format = "#,##0.00"
        ws3.cell(row=4 + i, column=9).number_format = "#,##0.00"
        ws3.cell(row=4 + i, column=10).number_format = "#,##0.00"
        ws3.cell(row=4 + i, column=11).number_format = "0.00\" %\""
        ws3.cell(row=4 + i, column=12).number_format = "#,##0.00"
        ws3.cell(row=4 + i, column=13).number_format = "0.00\" %\""
    widths = [10, 28, 16, 12, 14, 18, 12, 10, 10, 14, 10, 14, 10]
    for j, w in enumerate(widths, start=1):
        ws3.column_dimensions[get_column_letter(j)].width = w

    # ---------------------------------------------------------- Comptes
    ws4 = wb.create_sheet("Comptes & Performance")
    ws4["A1"] = "Reporting par compte"
    ws4["A1"].font = Font(bold=True, size=12, color=GREEN)
    header = ["Client", "Compte", "Valorisation", "Cash", "Total", "P&L", "P&L %", "Positions"]
    for j, h in enumerate(header, start=1):
        c = ws4.cell(row=3, column=j, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=GREEN)
    r = 4
    for a in sorted(accounts.values(), key=lambda x: -_num(x.get("total_value"))):
        vals = [a.get("client_name"), a.get("account_name"), a.get("mv"), a.get("cash"),
                a.get("total_value"), a.get("pnl"), a.get("pnl_pct"), len(a.get("positions", []))]
        for j, v in enumerate(vals, start=1):
            ws4.cell(row=r, column=j, value=v)
        for col in (3, 4, 5, 6):
            ws4.cell(row=r, column=col).number_format = "#,##0.00"
        ws4.cell(row=r, column=7).number_format = "0.00\" %\""
        r += 1

    r += 1
    ws4.cell(row=r, column=1, value="Performance des comptes (période)").font = Font(bold=True, size=12, color=GREEN)
    r += 1
    header = ["Compte", "Période", "Début", "Fin", "Variation", "Var. %"]
    for j, h in enumerate(header, start=1):
        c = ws4.cell(row=r, column=j, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=GREEN)
    r += 1
    for aid, p in perf.items():
        name = accounts.get(aid, {}).get("account_name", aid)
        vals = [name, f"{p['start']} → {p['end']}", p.get("start_value"), p.get("end_value"),
                p.get("growth"), p.get("growth_pct")]
        for j, v in enumerate(vals, start=1):
            ws4.cell(row=r, column=j, value=v)
        for col in (3, 4, 5):
            ws4.cell(row=r, column=col).number_format = "#,##0.00"
        ws4.cell(row=r, column=6).number_format = "0.00\" %\""
        r += 1

    r += 1
    ws4.cell(row=r, column=1, value="Performance des comptes (1 mois / 3 mois / 6 mois / YTD / 1 an)").font = \
        Font(bold=True, size=12, color=GREEN)
    r += 1
    header = ["Compte", "1 mois", "3 mois", "6 mois", "YTD", "1 an"]
    for j, h in enumerate(header, start=1):
        c = ws4.cell(row=r, column=j, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=GREEN)
    r += 1
    matrix = report.get("period_matrix", {})
    matrix_rows = [(aid, m) for aid, m in matrix.items() if aid != "portfolio"]
    matrix_rows.sort(key=lambda t: -_num(accounts.get(t[0], {}).get("total_value")))
    for aid, m in matrix_rows:
        name = accounts.get(aid, {}).get("account_name", aid)
        for j, key in enumerate(["1m", "3m", "6m", "ytd", "1y"], start=2):
            ws4.cell(row=r, column=j, value=m.get(key))
        ws4.cell(row=r, column=1, value=name)
        for col in (2, 3, 4, 5, 6):
            ws4.cell(row=r, column=col).number_format = "0.00\" %\""
        r += 1
    if matrix.get("portfolio"):
        ws4.cell(row=r, column=1, value="PORTEFEUILLE").font = Font(bold=True, size=10, color=GREEN)
        for j, key in enumerate(["1m", "3m", "6m", "ytd", "1y"], start=2):
            c = ws4.cell(row=r, column=j, value=matrix["portfolio"].get(key))
            c.number_format = "0.00\" %\""
            c.font = Font(bold=True, size=10, color=GREEN)
        r += 1
    for col, w in zip("ABCDEFGH", [18, 18, 14, 12, 14, 12, 10, 10]):
        ws4.column_dimensions[col].width = w

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.getvalue()


# ================================================================== PDF
def build_pdf(report):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                    HRFlowable, PageBreak)
    from reportlab.pdfgen import canvas as _canvas

    class _NumberedCanvas(_canvas.Canvas):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._saved_page_states = []

        def showPage(self):
            self._saved_page_states.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            num_pages = len(self._saved_page_states)
            for state in self._saved_page_states:
                self.__dict__.update(state)
                self.setFont("Helvetica", 7.5)
                self.setFillColor(colors.HexColor("#9CA3AF"))
                self.drawCentredString(A4[0] / 2, 8 * mm,
                                       f"Page {self._pageNumber} sur {num_pages}  |  Smart Wealth Manager")
                super().showPage()
            super().save()

    ctx = report.get("context_client")
    is_single = bool(ctx)
    title = ctx.get("name") if is_single else "Vue globale — Tous les clients"
    holdings = report.get("holdings", [])
    accounts = report.get("accounts", {})
    perf = report.get("performance", {})
    matrix = report.get("period_matrix", {})
    series = report.get("series_global", [])
    rows_class, rows_sector = _allocation(holdings)
    total_aum = _num(report.get("total_aum"))
    total_pnl = _num(report.get("total_pnl"))
    period = report.get("period", {})
    today = datetime.now()

    GREEN = colors.HexColor("#0D6E4F")
    LGREEN = colors.HexColor("#E8F5EE")
    GREY = colors.HexColor("#6C757D")
    DARK = colors.HexColor("#1F2937")
    BORDER = colors.HexColor("#D1D5DB")

    styles = getSampleStyleSheet()
    brand_style = ParagraphStyle("brand", parent=styles["Normal"], fontSize=9, textColor=GREY)
    title_style = ParagraphStyle("t", parent=styles["Title"], fontSize=19, textColor=GREEN,
                                 spaceAfter=1, alignment=0)
    sub_style = ParagraphStyle("s", parent=styles["Normal"], fontSize=11.5, textColor=DARK,
                               fontName="Helvetica-Bold", spaceAfter=1)
    gen_style = ParagraphStyle("g", parent=styles["Normal"], fontSize=8.5, textColor=GREY)
    h2_style = ParagraphStyle("h2", parent=styles["Heading2"], fontSize=11.5, textColor=GREEN,
                              spaceBefore=10, spaceAfter=4)
    h3_style = ParagraphStyle("h3", parent=styles["Heading2"], fontSize=9.5, textColor=GREEN,
                              spaceBefore=6, spaceAfter=3)
    cell_style = ParagraphStyle("c", parent=styles["Normal"], fontSize=8, leading=10)
    cellb_style = ParagraphStyle("cb", parent=cell_style, fontName="Helvetica-Bold")
    head_style = ParagraphStyle("h", parent=cell_style, textColor=colors.white, fontName="Helvetica-Bold")
    small_style = ParagraphStyle("sm", parent=styles["Normal"], fontSize=7.5, leading=9.5, textColor=GREY)
    note_style = ParagraphStyle("nt", parent=small_style, fontSize=6.5, leading=8)
    para_style = ParagraphStyle("para", parent=styles["Normal"], fontSize=8.5, leading=11.5, spaceAfter=4)

    def pct_par(v):
        if v is None:
            return Paragraph("—", cell_style)
        col = "#0D6E4F" if _num(v) >= 0 else "#DC2626"
        return Paragraph(f'<font color="{col}"><b>{_spct(v)}</b></font>', cell_style)

    def fcell(label, value, color=DARK, size=9):
        l = Paragraph(f'<font color="#6C757D"><b>{label}</b></font>',
                      ParagraphStyle("fl", parent=cell_style, fontSize=7.5, spaceAfter=1))
        v = Paragraph(f'<font color="{color}">{value}</font>',
                      ParagraphStyle("fv", parent=cell_style, fontSize=size, fontName="Helvetica-Bold"))
        return [l, v]

    story = []
    # ------------------------------------------------------------------ entête
    hdr = Table(
        [[Paragraph("SMART WEALTH MANAGER", brand_style),
          Paragraph("REPORTING MENSUEL — " + _month_fr(today), brand_style)]],
        colWidths=[252, 252])
    hdr.setStyle(TableStyle([
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    story.append(hdr)
    story.append(Paragraph("FACTSHEET PATRIMOINE", title_style))
    story.append(Paragraph(("CLIENT : <b>" + title + "</b>") if is_single
                           else ("PÉRIMÈTRE : <b>" + title + "</b>"), sub_style))
    story.append(Paragraph("Généré le " + today.strftime("%d/%m/%Y à %H:%M"), gen_style))
    story.append(HRFlowable(width="100%", thickness=1.2, color=GREEN, spaceBefore=4, spaceAfter=8))

    # ------------------------------------------------------------------ panneau faits (gauche)
    facts = [[Paragraph("PORTEFEUILLE", head_style), ""]]
    facts.append(fcell("Actif total sous gestion", _short(total_aum), color="#0D6E4F", size=12))
    facts.append(fcell("P&L totale", _eur(total_pnl),
                       color="#DC2626" if total_pnl < 0 else "#0D6E4F"))
    facts.append(fcell("Liquidités (cash)",
                       _eur(sum(_num(a.get("cash")) for a in accounts.values()))))
    if is_single:
        facts.append(fcell("Identifiant", str(ctx.get("id") or "—")))
        facts.append(fcell("Profil de risque", _risk_label(ctx.get("risk_profile"))))
        facts.append(fcell("Pays", ctx.get("country") or "—"))
        facts.append(fcell("Conseiller", ctx.get("advisor") or "—"))
    facts.append(fcell("Nombre de comptes", str(len(accounts))))
    facts.append(fcell("Nombre de positions", str(len(holdings))))
    per_txt = ("du " + _d_fr(period.get("start")) + " au " + _d_fr(period.get("end"))
               if period.get("start") else "historique complet jusqu'au " + _d_fr(period.get("end")))
    facts.append([Paragraph(f"<b>Période de valorisation :</b> {per_txt}", note_style), ""])
    if is_single:
        rp = _risk_label(ctx.get("risk_profile"))
        obj = ("constitution d'un patrimoine adapté à un profil de risque « " + rp + " »."
               if rp and rp != "—" else "gestion patrimoniale personnalisée.")
        facts.append([Paragraph("<b>Objectif :</b> " + obj, note_style), ""])
    fact_t = Table(facts, colWidths=[102, 83])
    fact_t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (1, 0), GREEN),
        ("SPAN", (0, 0), (1, 0)),
        ("GRID", (0, 0), (-1, -1), 0.3, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))

    # ------------------------------------------------------------------ tableau PERIODE (droite)
    acc_list = sorted(accounts.values(), key=lambda a: -_num(a.get("total_value")))
    mg = report.get("period_matrix_group") or {}
    if is_single:
        period_rows = [(a.get("account_id"), a) for a in acc_list]
        matrix_use = matrix
    else:
        period_rows = [(c.get("id"), c) for c in report.get("clients", [])]
        matrix_use = mg
    period_rows = sorted(period_rows, key=lambda t: -_num(t[1].get("total_value", t[1].get("aum", 0))))
    top = period_rows[:8]
    rest = len(period_rows) - len(top)
    per_data = [[Paragraph("", head_style), Paragraph("1 MOIS", head_style),
                 Paragraph("3 MOIS", head_style), Paragraph("6 MOIS", head_style),
                 Paragraph("YTD", head_style), Paragraph("1 AN", head_style)]]
    for key, item in top:
        m = matrix_use.get(key, {})
        if is_single:
            lbl = Paragraph(_truncate(str(item.get("account_name") or "—"), 18), cell_style)
        else:
            lbl = Paragraph(_truncate(str(item.get("name") or "—"), 18), cellb_style)
        per_data.append([lbl,
                         pct_par(m.get("1m")), pct_par(m.get("3m")), pct_par(m.get("6m")),
                         pct_par(m.get("ytd")), pct_par(m.get("1y"))])
    pf = matrix.get("portfolio", {})
    per_data.append([Paragraph("PORTEFEUILLE", cellb_style),
                     pct_par(pf.get("1m")), pct_par(pf.get("3m")), pct_par(pf.get("6m")),
                     pct_par(pf.get("ytd")), pct_par(pf.get("1y"))])
    if rest:
        per_data.append([Paragraph(f"… et {rest} autres comptes", small_style), "", "", "", "", ""])
    pf_row = len(per_data) - 1 - (1 if rest else 0)
    per_t = Table(per_data, colWidths=[100, 44, 44, 44, 44, 53])
    per_t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GREEN),
        ("GRID", (0, 0), (-1, -1), 0.3, BORDER),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LGREEN]),
        ("BACKGROUND", (0, pf_row), (-1, pf_row), LGREEN),
        ("ALIGN", (1, 1), (-1, -1), "CENTER"),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
    ]))

    left_block = [Paragraph("PORTEFEUILLE", h3_style), fact_t]
    right_block = [Paragraph("PERIODE", h3_style), per_t, Spacer(1, 3),
                   Paragraph("Variations calculées sur la première et la dernière valorisation "
                             "disponible de chaque période (— si historique insuffisant).", note_style)]
    layout = Table([[left_block, right_block]], colWidths=[185, 319])
    layout.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, 0), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(layout)

    # ------------------------------------------------------------------ performances
    story.append(Paragraph("PERFORMANCES DU PORTEFEUILLE", h2_style))
    story.append(_line_chart(series, w=504, h=150))
    story.append(Paragraph("Valorisation totale consolidée de l'ensemble des comptes. "
                           "Les performances passées ne préjugent pas des performances futures.", note_style))

    # ------------------------------------------------------------------ allocation
    story.append(Paragraph("ALLOCATION D'ACTIFS", h2_style))
    alloc_left = [Paragraph("Répartition par classe d'actifs", h3_style),
                  _pie_drawing(rows_class, w=252, h=150, legend_cols=2)]
    alloc_right = [Paragraph("Répartition par secteur", h3_style),
                   _pie_drawing(rows_sector, w=252, h=150, legend_cols=2)]
    alloc_t = Table([[alloc_left, alloc_right]], colWidths=[252, 252])
    alloc_t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, 0), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(alloc_t)

    story.append(PageBreak())

    # ------------------------------------------------------------------ page 2 : top positions + caractéristiques
    story.append(Paragraph("PORTEFEUILLE — DÉTAIL", h2_style))
    top_h = _top_holdings_agg(holdings, 10)
    pos_data = [[Paragraph("#", head_style), Paragraph("Position", head_style),
                 Paragraph("Classe", head_style), Paragraph("% Actif net", head_style)]]
    for i, h in enumerate(top_h, start=1):
        wgt = _num(h.get("market_value")) / total_aum * 100 if total_aum else 0
        pos_data.append([Paragraph(str(i), cell_style),
                         Paragraph(str(h.get("name") or h.get("ticker") or "—"), cell_style),
                         Paragraph(str(h.get("asset_class") or "—"), cell_style),
                         Paragraph(_pct(wgt), cell_style)])
    if not top_h:
        pos_data.append([Paragraph("Aucune position", cell_style), "", "", ""])
    pos_t = Table(pos_data, colWidths=[24, 104, 66, 58])
    pos_t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GREEN),
        ("GRID", (0, 0), (-1, -1), 0.3, BORDER),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LGREEN]),
        ("ALIGN", (3, 1), (-1, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
    ]))

    total_mv = sum(_num(h.get("market_value")) for h in holdings)
    cost = sum(_num(h.get("cost_value")) for h in holdings)
    expo_action = sum(_num(h.get("market_value")) for h in holdings if h.get("asset_class") == "Action")
    expo_oblig = sum(_num(h.get("market_value")) for h in holdings if h.get("asset_class") == "Obligation")
    chars = [
        ["Nombre de positions", str(len(holdings))],
        ["Exposition actions", _pct(expo_action / total_mv * 100) if total_mv else "—"],
        ["Exposition obligations", _pct(expo_oblig / total_mv * 100) if total_mv else "—"],
        ["Liquidités (cash)", _eur(sum(_num(a.get("cash")) for a in accounts.values()))],
        ["P&L totale", _eur(total_pnl)],
        ["P&L (%)", _pct(total_pnl / cost * 100) if cost else "—"],
        ["Nombre de comptes", str(len(accounts))],
    ]
    char_t = Table(chars, colWidths=[150, 102])
    char_t.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.3, BORDER),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.white, LGREEN]),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ]))

    pos_block = [Paragraph("PRINCIPALES POSITIONS (en % de l'actif net)", h3_style), pos_t]
    char_block = [Paragraph("CARACTÉRISTIQUES DU PORTEFEUILLE", h3_style), char_t,
                  Spacer(1, 3),
                  Paragraph("Toute composition de portefeuille est fournie à titre d'illustration "
                            "uniquement. La composition du portefeuille a vocation à évoluer.", note_style)]
    detail_t = Table([[pos_block, char_block]], colWidths=[252, 252])
    detail_t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, 0), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(detail_t)

    # ------------------------------------------------------------------ commentaire
    story.append(Paragraph("COMMENTAIRE", h2_style))
    p1y = pf.get("1y")
    p1m = pf.get("1m")
    scope_txt = "le portefeuille" if is_single else "le portefeuille global"
    parts = []
    per_txt2 = (f"du {_d_fr(period.get('start'))} au {_d_fr(period.get('end'))}"
                if period.get("start") else f"jusqu'au {_d_fr(period.get('end'))}")
    parts.append(f"Au cours de la période analysée ({per_txt2}), {scope_txt} présente une valorisation totale de "
                 f"<b>{_short(total_aum)}</b>, répartie sur <b>{len(accounts)} comptes</b> et "
                 f"<b>{len(holdings)} positions</b>.")
    if p1y is not None:
        parts.append(f"Sur les douze derniers mois, la performance s'établit à <b>{_spct(p1y)}</b>"
                     + (f" et sur le dernier mois à <b>{_spct(p1m)}</b>." if p1m is not None else "."))
    if rows_class:
        top3 = " ; ".join(f"{r['label']} ({_pct(r['weight'])})" for r in rows_class[:3])
        parts.append(f"La répartition par classe d'actifs est dominée par : {top3}.")
    if is_single:
        rp = _risk_label(ctx.get("risk_profile"))
        parts.append(f"Ce document est établi pour le client <b>{ctx.get('name', '')}</b> "
                     f"(profil de risque : {rp}).")
    parts.append("Les performances passées ne préjugent pas des performances futures.")
    for p in parts:
        story.append(Paragraph(p, para_style))

    # ------------------------------------------------------------------ comptes
    story.append(Paragraph("COMPTES (REPORTING PAR COMPTE)", h2_style))
    acc_data = [[Paragraph("Client", head_style), Paragraph("Compte", head_style),
                 Paragraph("Valorisation", head_style), Paragraph("Cash", head_style),
                 Paragraph("Total", head_style), Paragraph("P&L", head_style),
                 Paragraph("P&L %", head_style)]]
    for a in acc_list:
        acc_data.append([Paragraph(str(a.get("client_name") or "—"), cell_style),
                         Paragraph(str(a.get("account_name") or "—"), cell_style),
                         Paragraph(_eur(a.get("mv")), cell_style),
                         Paragraph(_eur(a.get("cash")), cell_style),
                         Paragraph(_eur(a.get("total_value")), cell_style),
                         Paragraph(_eur(a.get("pnl")), cell_style),
                         Paragraph(_pct(a.get("pnl_pct")), cell_style)])
    t = Table(acc_data, colWidths=[30 * mm, 28 * mm, 24 * mm, 20 * mm, 24 * mm, 24 * mm, 20 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GREEN),
        ("GRID", (0, 0), (-1, -1), 0.3, BORDER),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LGREEN]),
        ("ALIGN", (2, 1), (-1, -1), "RIGHT"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(t)

    story.append(PageBreak())

    # ------------------------------------------------------------------ page 3 : performance période
    story.append(Paragraph("PERFORMANCE DES COMPTES (PÉRIODE APPLIQUÉE)", h2_style))
    perf_data = [[Paragraph("Compte", head_style), Paragraph("Période", head_style),
                  Paragraph("Début", head_style), Paragraph("Fin", head_style),
                  Paragraph("Variation", head_style), Paragraph("Var. %", head_style)]]
    for aid, p in perf.items():
        name = accounts.get(aid, {}).get("account_name", aid)
        perf_data.append([Paragraph(str(name), cell_style),
                          Paragraph(f"{_d_fr(p.get('start'))} → {_d_fr(p.get('end'))}", cell_style),
                          Paragraph(_eur(p.get("start_value")), cell_style),
                          Paragraph(_eur(p.get("end_value")), cell_style),
                          Paragraph(_eur(p.get("growth")), cell_style),
                          Paragraph(_pct(p.get("growth_pct")), cell_style)])
    t = Table(perf_data, colWidths=[30 * mm, 40 * mm, 26 * mm, 26 * mm, 26 * mm, 22 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GREEN),
        ("GRID", (0, 0), (-1, -1), 0.3, BORDER),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LGREEN]),
        ("ALIGN", (2, 1), (-1, -1), "RIGHT"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(t)

    # ------------------------------------------------------------------ avertissement
    story.append(Paragraph("AVERTISSEMENT / INFORMATIONS IMPORTANTES", h2_style))
    story.append(Paragraph(
        "Document généré automatiquement par Smart Wealth Manager, à titre informatif. "
        "Il ne constitue ni une offre de souscription, ni un conseil en investissement, un conseil "
        "juridique ou un conseil fiscal. L'information contenue dans ce document ne tient pas compte "
        "des circonstances individuelles spécifiques à chaque client et ne peut, en aucun cas, être "
        "considérée comme un conseil personnalisé en investissement. Le traitement fiscal dépend de la "
        "situation individuelle de chaque client et peut faire l'objet de changements dans le futur. "
        "Le portefeuille présente un risque de fluctuation de marché et de perte en capital. "
        "Les valeurs passées ne préjugent pas des performances futures. "
        "Toute composition de portefeuille est fournie à titre d'illustration uniquement et est "
        "susceptible d'évoluer.",
        small_style))

    # ------------------------------------------------------------------ glossaire
    story.append(Paragraph("GLOSSAIRE", h2_style))
    gloss = [
        ("Actif sous gestion (AuM)",
         "Valeur totale du patrimoine couvert par ce document (positions + liquidités)."),
        ("P&L",
         "Plus ou moins-value latente : différence entre la valorisation au cours actuel et le coût "
         "d'acquisition (quantité × PRU)."),
        ("Variation de période",
         "Évolution de la valorisation du compte entre la première et la dernière date de la période "
         "retenue."),
        ("PRU",
         "Prix de revient unitaire : coût moyen d'acquisition d'une position."),
        ("Classe d'actifs",
         "Catégorie d'investissement : actions, obligations, ETF, immobilier, fonds, liquidités."),
        ("Profil de risque",
         "Niveau de risque adapté au client : conservateur, équilibré, dynamique."),
    ]
    gdata = [[Paragraph(f"<b>{k}</b>", cell_style), Paragraph(v, small_style)] for k, v in gloss]
    gt = Table(gdata, colWidths=[50 * mm, 120 * mm])
    gt.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.3, BORDER),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.white, LGREEN]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(gt)

    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", thickness=0.6, color=GREY, spaceBefore=4, spaceAfter=4))
    story.append(Paragraph("© " + str(today.year) + " Smart Wealth Manager — Document confidentiel.", small_style))

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=16 * mm, rightMargin=16 * mm,
                            topMargin=14 * mm, bottomMargin=16 * mm,
                            title="Factsheet Patrimoine — " + title, author="Smart Wealth Manager")
    doc.build(story, canvasmaker=_NumberedCanvas)
    buf.seek(0)
    return buf.getvalue()
