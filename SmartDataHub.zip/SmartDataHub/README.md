# SmartDataHub

Application web de visualisation du référentiel des titres (**MasterData**), du
pilotage des **contrôles de données** (un fichier Parquet = un contrôle) et
d'**assistant IA local** sur fichier `.gguf`.

Inspirée de l'architecture de [Smart-pms](../Smart-pms) : FastAPI + interface
statique unique (Bootstrap 5 / Chart.js), configuration des sources dans un
JSON, modèle GGUF chargé en mémoire par `llama-cpp-python`.

## Onglets

| Onglet | Contenu |
| --- | --- |
| **Dashboard** | KPI + graphiques : code valeurs par *security group* (bar), par *security type* (doughnut), créations en 2026 (doughnut + mensuel), principaux émetteurs, devises |
| **MasterData** | Table complète des titres : code valeur, code ISIN, security type, security group, libellé, devise, émetteur, date de création — recherche, filtres, tri, pagination, export CSV |
| **Dashboard Control** | Bar chart global (nombre de codes valeur concernés par contrôle) + liste évolutive des contrôles, détail des anomalies dans une fenêtre modale |
| **Assistant IA** | Interrogation d'un fichier `.gguf` local, périmètre = données réellement chargées (contexte consultable), réglages de génération |
| **Datasource** | Emplacement du MasterData, du dossier des contrôles et du modèle GGUF ; colonnes détectées ; génération du jeu de démo |

## Démarrage

```bash
pip install -r requirements.txt
pip install -r requirements-llm.txt   # optionnel : assistant IA (GGUF)

python -m smartdatahub.demo_data      # jeu de données de démonstration
python app.py                         # http://localhost:5001
```

ou, avec Uvicorn :

```bash
uvicorn smartdatahub.main:app --host 0.0.0.0 --port 5001
```

Variables d'environnement : `SMARTDATAHUB_HOST`, `SMARTDATAHUB_PORT`,
`SMARTDATAHUB_BASE_DIR`, `SMARTDATAHUB_CONFIG_PATH`.

## Configuration

`datasource_config.json` (onglet **Datasource**, écriture atomique) :

```json
{
  "masterdata_path": "data/masterdata.parquet",
  "controls_dir": "data/controls",
  "gguf_path": "/home/ohamdi/Models/Ministral-3-3B-Instruct-2512-Q4_K_M.gguf"
}
```

`ai_config.json` (paramètres de génération) : `n_ctx`, `n_threads`, `n_batch`,
`temperature`, `max_tokens`, `top_p`, `repeat_penalty`, `max_context_chars`.

### Colonnes du MasterData

Les colonnes sont reconnues par alias : `codeValeur`, `CODE_VALEUR`,
`code_valeur`, `Code Valeur`… sont tous ramenés à `code_valeur`. Champs
attendus et alias :

| Champ | Alias acceptés |
| --- | --- |
| `code_valeur` | codevaleur, codeval, securitycode, code, ticker, mnemonique |
| `code_isin` | codeisin, isin, isincode |
| `security_type` | securitytype, typevaleur, typesecurite, typeinstrument, type, classe |
| `security_group` | securitygroup, groupeseurite, groupevaleur, groupe, group, category, categorie |
| `libelle` | libelle, designation, intitule, nom, name, label |
| `devise` | devise, currency, monnaie, ccy |
| `emetteur` | emetteur, issuer, societeemetrice, societe, teneur |
| `date_creation` | datecreation, datedecreation, creationdate, datecrea, date |

Le mapping réel est affiché dans l'onglet **Datasource** ; les champs absents
sont signalés sans bloquer l'application.

#### Colonnes supplémentaires (dynamiques)

Toute colonne du fichier qui n'est **pas** reconnue comme champ métier est
affichée automatiquement à la fin de la table de l'onglet **MasterData**, avec
un « ＋ » dans l'en-tête et la mention *supplémentaire* dans l'onglet
**Datasource**. Aucune configuration ni redéploiement : **ajouter une colonne
au Parquet suffit**.

- **Tri** : cliquer l'en-tête de la colonne la trie aussi (côté serveur).
- **Recherche** : les colonnes texte supplémentaires sont incluses dans la
  recherche globale.
- **Export CSV** : les colonnes supplémentaires sont en fin d'en-tête.
- **Libellé** : `secteur_activite` est présenté « Secteur activite ».
- **Filtres** (type / groupe / devise) et agrégats du dashboard restent
  réservés aux 8 champs métier.
- La démo contient une colonne d'exemple : `Secteur`.

### Contrôles

Tout fichier `.parquet` déposé dans `controls_dir` devient un contrôle : son
nom de fichier donne l'identifiant et le libellé (`controle_2_…` →
« Contrôle 2 : … »). Le décompte porte sur les **codes valeur distincts** du
fichier ; si une colonne de statut existe (`anomalie`, `status`, `conforme`…),
seules les lignes marquées en anomalie sont comptées.

## API

| Méthode | Route | Rôle |
| --- | --- | --- |
| GET | `/api/dashboard` | agrégats du Dashboard |
| GET | `/api/masterdata` | titres filtrés/triés/paginés (`q`, `type`, `group`, `devise`, `sort`, `order`, `offset`, `limit`) |
| GET | `/api/masterdata/facets` | valeurs distinctes pour les filtres + mapping des colonnes |
| GET | `/api/masterdata/export` | export CSV filtré (séparateur `;`, BOM UTF-8) |
| GET | `/api/controls` | liste des contrôles découverts + total d'anomalies |
| GET | `/api/controls/{id}` | détail des anomalies d'un contrôle |
| GET/POST | `/api/datasource` | lecture/écriture des emplacements |
| POST | `/api/datasource/demo` | (re)génération des données de démonstration |
| GET | `/api/ai/status` | état du moteur, modèles détectés, réglages |
| GET | `/api/ai/context` | contexte réellement envoyé au modèle |
| POST | `/api/ai/chat` | question/réponse sur les données chargées |
| POST | `/api/ai/warmup` · `/api/ai/unload` | chargement / libération du modèle |
| GET/POST | `/api/ai/config` | réglages de génération |

## Structure

```
SmartDataHub/
├── app.py                    # point d'entrée (uvicorn)
├── datasource_config.json    # emplacements des fichiers
├── requirements.txt          # FastAPI, pandas, pyarrow…
├── requirements-llm.txt      # llama-cpp-python (optionnel)
├── data/
│   ├── masterdata.parquet    # démo : 600 titres
│   └── controls/             # démo : 5 contrôles
├── smartdatahub/
│   ├── main.py               # fabrique FastAPI + services statiques
│   ├── routes.py             # API
│   ├── services.py           # agrégats, requêtes, contexte IA
│   ├── repository.py         # lecture Parquet + détection des colonnes
│   ├── llm.py                # modèle GGUF (chargement paresseux)
│   ├── config.py             # datasource_config.json
│   ├── ai_config.py          # ai_config.json + détection des .gguf
│   └── demo_data.py          # jeu de démonstration (python -m smartdatahub.demo_data)
└── static/index.html         # interface single-page (5 onglets)
```

## Tests

```bash
python -m pytest tests/ -q     # tests métier (20 tests)

# test de bout en bout de l'interface (Playwright + Chromium)
python -m venv .venv-ui && .venv-ui/bin/pip install playwright
.venv-ui/bin/python -m playwright install chromium
.venv-ui/bin/python tests/e2e_ui.py     # 25 contrôles, nécessite un serveur lancé
```
