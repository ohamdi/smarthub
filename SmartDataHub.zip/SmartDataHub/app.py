"""Point d'entrée de SmartDataHub.

Lancement :

    python app.py
    uvicorn smartdatahub.main:app --host 0.0.0.0 --port 5001
"""

from __future__ import annotations

import os

import uvicorn

from smartdatahub.main import app

__all__ = ["app"]


if __name__ == "__main__":
    uvicorn.run(
        app,
        host=os.getenv("SMARTDATAHUB_HOST", "0.0.0.0"),
        port=int(os.getenv("SMARTDATAHUB_PORT", "5001")),
    )
