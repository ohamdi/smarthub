"""Tests métier de SmartDataHub : détection des colonnes, agrégats, API."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest
from fastapi.testclient import TestClient

from smartdatahub import demo_data
from smartdatahub.config import DataSourceConfig, Settings
from smartdatahub.main import create_app
from smartdatahub.repository import FIELD_ORDER, ParquetRepository, control_label, detect_columns
from smartdatahub.services import ApplicationService


# -- détection des colonnes ------------------------------------------------
@pytest.mark.parametrize(
    "columns,expected",
    [
        # Alias français, camelCase, MAJUSCULES et séparés : tout converge.
        (["CodeValeur", "CodeISIN", "SecurityType"], {"code_valeur": "CodeValeur", "code_isin": "CodeISIN", "security_type": "SecurityType"}),
        (["CODE_VALEUR", "code isin", "SECURITY_GROUP"], {"code_valeur": "CODE_VALEUR", "code_isin": "code isin", "security_group": "SECURITY_GROUP"}),
        (["Code Valeur", "Libellé", "Émetteur", "Devise"], {"code_valeur": "Code Valeur", "libelle": "Libellé", "emetteur": "Émetteur", "devise": "Devise"}),
    ],
)
def test_detect_columns_aliases(columns, expected):
    mapping = detect_columns(columns)
    for field, actual in expected.items():
        assert mapping[field] == actual


def test_detect_columns_never_reuses_a_column():
    # « type » peut servir de security_type mais pas aussi de security_group.
    mapping = detect_columns(["type", "groupe"])
    assert mapping["security_type"] == "type"
    assert mapping["security_group"] == "groupe"
    assert mapping["code_valeur"] is None


def test_control_label():
    assert control_label("controle_1_cours_invariant") == "Contrôle 1 : Cours invariant"
    assert control_label("controle_2_produits_structures_100") == "Contrôle 2 : Produits structurés 100"
    assert control_label("controle_5_maturite_depassee") == "Contrôle 5 : Maturité dépassée"
    assert control_label("qualite_donnees") == "Qualite donnees"


# -- jeu de données de démonstration ---------------------------------------
@pytest.fixture(scope="module")
def workspace(tmp_path_factory) -> Path:
    base = tmp_path_factory.mktemp("smartdatahub")
    demo_data.generate(base, rows=120, seed=7)
    # L'interface est servie depuis <base>/static : on la relie au vrai dossier.
    static_link = base / "static"
    if not static_link.exists():
        static_link.symlink_to(Path(__file__).resolve().parent.parent / "static")
    return base


@pytest.fixture(scope="module")
def service(workspace: Path) -> ApplicationService:
    settings = Settings(base_dir=workspace, config_path=workspace / "datasource_config.json")
    config = DataSourceConfig(settings.base_dir, settings.config_path)
    return ApplicationService(settings, config, ParquetRepository(config))


def test_demo_data_written(workspace: Path):
    assert (workspace / "data" / "masterdata.parquet").is_file()
    controls = sorted(p.name for p in (workspace / "data" / "controls").glob("*.parquet"))
    assert len(controls) == 5
    assert controls[0] == "controle_1_cours_invariant.parquet"


def test_dashboard_aggregates(service: ApplicationService):
    dash = service.dashboard()
    assert dash["available"] is True
    total = dash["source"]["rows"]
    assert total == 120
    assert sum(group["count"] for group in dash["groups"]) == total
    assert sum(item["count"] for item in dash["types"]) == total
    assert 0 < dash["creations"]["in_2026"] <= total
    assert sum(month["count"] for month in dash["creations"]["months"]) == dash["creations"]["in_2026"]
    assert dash["controls"]["count"] == 5
    assert dash["controls"]["anomalies"] > 0
    assert dash["missing"] == []


def test_masterdata_query_filters_sorts_and_pages(service: ApplicationService):
    everything = service.query_masterdata(limit=5)
    assert everything["total"] == 120
    assert len(everything["rows"]) == 5
    assert everything["rows"][0]["code_valeur"] <= everything["rows"][1]["code_valeur"]

    descending = service.query_masterdata(order="desc", limit=1)
    assert descending["rows"][0]["code_valeur"] == service.query_masterdata(
        offset=119, limit=1
    )["rows"][0]["code_valeur"]

    groups = service.facets()["security_group"]
    assert "Actions" in groups
    filtered = service.query_masterdata(security_group="Actions", limit=1000)
    assert filtered["total"] < 120
    assert {row["security_group"] for row in filtered["rows"]} == {"Actions"}

    # Recherche insensible à la casse sur code / ISIN / libellé / émetteur.
    needle = filtered["rows"][0]["code_valeur"]
    found = service.query_masterdata(search=needle.lower())
    assert found["total"] >= 1
    assert all(needle.upper() in row["code_valeur"].upper() for row in found["rows"])

    # Dates normalisées en ISO pour l'interface.
    assert filtered["rows"][0]["date_creation"][:4].isdigit()


def test_masterdata_export_csv(service: ApplicationService):
    csv = service.export_masterdata(security_group="Actions")
    lines = [line for line in csv.strip().splitlines() if line]
    header = lines[0].split(";")
    assert header[0] == "code_valeur"
    assert len(lines) - 1 == service.query_masterdata(
        security_group="Actions", limit=1000
    )["total"]


def test_extra_columns_are_dynamic(tmp_path: Path):
    """Un Parquet enrichi de nouvelles colonnes les expose sans configuration.

    Colonnes affichées, triables, cherchables et exportables : ajouter une
    colonne au fichier suffit, aucune modification de code n'est nécessaire.
    """
    base = tmp_path / "dynamic"
    demo_data.generate(base, rows=30, seed=1)
    # On réécrit le MasterData avec 3 champs standards + 2 colonnes neuves.
    pd.DataFrame(
        {
            "CodeValeur": ["AAA1", "BBB2", "CCC3"],
            "Libellé": ["Titre A", "Titre B", "Titre C"],
            "SecurityType": ["Action", "Action", "Obligation"],
            "Secteur_Activite": ["Banque", "Énergie", "Santé"],
            "Notation": [3, 1, 2],
        }
    ).to_parquet(base / "data" / "masterdata.parquet", index=False)

    settings = Settings(base_dir=base, config_path=base / "datasource_config.json")
    config = DataSourceConfig(settings.base_dir, settings.config_path)
    service = ApplicationService(settings, config, ParquetRepository(config))

    listing = service.query_masterdata()
    keys = [column["key"] for column in listing["columns"]]
    assert keys[: len(FIELD_ORDER)] == list(FIELD_ORDER)  # 8 champs en tête
    assert keys[len(FIELD_ORDER):] == ["Secteur_Activite", "Notation"]
    meta = {column["key"]: column for column in listing["columns"]}
    assert meta["Secteur_Activite"]["extra"] is True
    assert meta["Secteur_Activite"]["label"] == "Secteur Activite"
    assert meta["code_valeur"]["extra"] is False

    # Les valeurs remontent avec les champs standards.
    row = next(r for r in listing["rows"] if r["code_valeur"] == "AAA1")
    assert row["Secteur_Activite"] == "Banque"

    # Tri et recherche sur les colonnes supplémentaires.
    ordered = service.query_masterdata(sort="Notation", order="desc")
    assert [r["Notation"] for r in ordered["rows"]] == [3, 2, 1]
    assert service.query_masterdata(search="énergie")["total"] == 1

    # Export CSV : standards d'abord, supplémentaires en fin d'en-tête.
    header = service.export_masterdata().splitlines()[0].split(";")
    assert header[0] == "code_valeur"
    assert header[-2:] == ["Secteur_Activite", "Notation"]

    # Onglet Datasource : les colonnes supplémentaires sont signalées.
    columns = service.masterdata_state()["columns"]
    assert [column["field"] for column in columns[: len(FIELD_ORDER)]] == list(FIELD_ORDER)
    extras = [column for column in columns if column["extra"]]
    assert [column["field"] for column in extras] == ["Secteur_Activite", "Notation"]
    assert all(column["detected"] for column in extras)


def test_controls_are_discovered_and_counted(service: ApplicationService):
    summaries = service.control_summaries()
    assert len(summaries) == 5
    labels = [item["label"] for item in summaries]
    assert labels[0].startswith("Contrôle 1")
    for item in summaries:
        assert item["error"] is None
        assert item["count"] == item["rows"]  # lignes = anomalies dans la démo
        assert "CodeValeur" in item["columns"]

    detail = service.control_detail("controle_3_isin_manquant_ou_doublon")
    assert detail["total"] > 0
    motifs = {row["Motif"] for row in detail["rows"]}
    assert motifs <= {"ISIN manquant", "ISIN en doublon"}


def test_control_status_column_filters_anomalies(service: ApplicationService, workspace: Path):
    """Un contrôle avec une colonne de statut ne compte que les anomalies."""
    directory = service.repository.controls_dir()
    pd.DataFrame(
        {
            "CODE_VALEUR": ["A", "A", "B", "C"],
            "Statut": ["anomalie", "ok", "NOK", "conforme"],
        }
    ).to_parquet(directory / "controle_9_statut_test.parquet", index=False)

    try:
        summary = next(
            item
            for item in service.control_summaries()
            if item["id"] == "controle_9_statut_test"
        )
        assert summary["count"] == 2  # A et B, les lignes « ok » sont exclues
        assert summary["label"] == "Contrôle 9 : Statut test"
        assert summary["anomaly_column"] == "Statut"
    finally:
        (directory / "controle_9_statut_test.parquet").unlink()


def test_unknown_control_returns_nothing(service: ApplicationService):
    assert service.control_detail("controle_999_absent") == {}


# -- API -------------------------------------------------------------------
@pytest.fixture(scope="module")
def client(workspace: Path) -> TestClient:
    settings = Settings(base_dir=workspace, config_path=workspace / "datasource_config.json")
    app = create_app(settings)
    with TestClient(app) as test_client:
        yield test_client


def test_health(client: TestClient):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_dashboard_route(client: TestClient):
    payload = client.get("/api/dashboard").json()
    assert payload["available"] is True
    assert len(payload["groups"]) >= 2


def test_masterdata_route(client: TestClient):
    payload = client.get("/api/masterdata", params={"limit": 10, "order": "desc"}).json()
    assert payload["total"] == 120
    assert len(payload["rows"]) == 10
    assert payload["columns"][0]["key"] == "code_valeur"
    assert payload["columns"][0]["extra"] is False
    # La démo contient une colonne hors standard, exposée automatiquement.
    extras = [column for column in payload["columns"] if column["extra"]]
    assert [column["key"] for column in extras] == ["Secteur"]


def test_masterdata_unknown_filter_is_harmless(client: TestClient):
    payload = client.get("/api/masterdata", params={"type": "Inexistant"}).json()
    assert payload["total"] == 0


def test_controls_routes(client: TestClient):
    listing = client.get("/api/controls").json()
    assert listing["count"] == 5
    control_id = listing["items"][0]["id"]

    detail = client.get(f"/api/controls/{control_id}").json()
    assert detail["control"]["id"] == control_id

    missing = client.get("/api/controls/pas-la")
    assert missing.status_code == 404
    assert "error" in missing.json()


def test_datasource_roundtrip(client: TestClient):
    before = client.get("/api/datasource").json()
    assert before["masterdata"]["available"] is True

    saved = client.post(
        "/api/datasource", json={"controls_dir": "data/controls"}
    ).json()
    assert saved["sources"][1]["key"] == "controls_dir"
    assert saved["controls"]["count"] == 5


def test_export_route_is_csv(client: TestClient):
    response = client.get("/api/masterdata/export", params={"type": "Action"})
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/csv")
    assert response.text.lstrip("﻿").splitlines()[0].startswith("code_valeur;")


def test_frontend_is_served(client: TestClient):
    response = client.get("/")
    assert response.status_code == 200
    assert "SmartDataHub" in response.text
    # Route API inconnue → 404 JSON, pas le HTML.
    assert client.get("/api/inconnu").status_code == 404
    # Tentative de traversée de dossier (encodée, sinon le client la normalise).
    assert client.get("/%2e%2e/%2e%2e/etc/passwd").status_code == 404
    assert client.get("/fichier-inexistant.html").status_code == 200  # fallback index
