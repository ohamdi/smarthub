"""Test de bout en bout de l'interface SmartDataHub (Playwright + Chromium).

Prérequis : un serveur lancé (``python app.py``) et Playwright installé
(``pip install playwright && playwright install chromium``).

    .venv-ui/bin/python tests/e2e_ui.py [url]
"""

from __future__ import annotations

import sys

from playwright.sync_api import sync_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5001"

results: list[tuple[bool, str]] = []
console_errors: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    results.append((bool(condition), f"{name}{f' — {detail}' if detail and not condition else ''}"))


def main() -> int:
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch()
        page = browser.new_page(viewport={"width": 1500, "height": 1000})
        page.on(
            "console",
            lambda message: console_errors.append(message.text)
            if message.type == "error"
            else None,
        )
        page.on("pageerror", lambda error: console_errors.append(f"pageerror: {error}"))

        page.goto(BASE, wait_until="networkidle")

        # ------------------------------------------------------------------
        # Dashboard
        # ------------------------------------------------------------------
        check("titre de la page", "SmartDataHub" in page.title(), page.title())
        page.wait_for_function("() => state.dash && state.dash.available === true", timeout=15000)
        total = page.evaluate("state.dash.source.rows")
        check("KPI titres", page.inner_text("#cardTitles").replace("\u202f", "").replace(" ", "") != "—")
        check("6 graphiques dessinés", page.evaluate("Object.keys(state.charts).length") == 6,
              str(page.evaluate("Object.keys(state.charts)")))
        check("top émetteurs en colonnes verticales",
              page.evaluate("state.charts.issuers.options.indexAxis") == "x")
        check("groupes cohérents",
              page.evaluate("state.dash.groups.reduce((s, g) => s + g.count, 0)") == total)
        check("créations 2026",
              page.evaluate("state.dash.creations.months.reduce((s, m) => s + m.count, 0)")
              == page.evaluate("state.dash.creations.in_2026"))
        # Le canvas doit contenir des pixels peints (pas un graphique vide).
        painted = page.evaluate(
            """() => {
                const c = document.getElementById('chartGroups');
                const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
                for (let i = 3; i < d.length; i += 4) if (d[i] !== 0) return true;
                return false;
            }"""
        )
        check("bar chart non vide", painted)

        # ------------------------------------------------------------------
        # MasterData
        # ------------------------------------------------------------------
        page.click('[data-tab="masterdata"]')
        # On attend le vrai rendu (la ligne « Chargement… » statique fausse
        # un simple wait_for_selector) : en-tête dynamique + compteur rempli.
        page.wait_for_function(
            "document.querySelectorAll('#mdHead th').length >= 9"
            " && document.getElementById('mdCount').textContent.includes('titres')",
            timeout=10000,
        )
        rows = page.locator("#mdBody tr").count()
        check("table MasterData peuplée", rows >= 1, f"{rows} lignes")
        head_text = page.inner_text("#mdHead")
        check("8 champs standards en tête", "Code valeur" in head_text and "Date de création" in head_text,
              head_text.replace("\n", " "))
        check("colonne dynamique affichée", "Secteur" in head_text, head_text.replace("\n", " "))
        check("marqueur de colonne supplémentaire", page.locator("#mdHead .extra-mark").count() >= 1)
        count_before = page.inner_text("#mdCount")
        check("compteur d'enregistrements", str(total).replace(" ", "") in count_before.replace("\u202f", "").replace(" ", ""),
              count_before)

        page.click('#mdHead th[data-col="libelle"]')   # tri par libellé
        page.wait_for_timeout(700)
        first_sorted = page.locator("#mdBody tr td:first-child").first.inner_text()
        sort_class = page.get_attribute('#mdHead th[data-col="libelle"]', "class") or ""
        check("tri par libellé actif", "sort-" in sort_class, sort_class)
        check("le tri ne casse pas la table", first_sorted.strip() != "")

        page.select_option("#mdGroup", index=1)
        page.wait_for_timeout(700)
        filtered = page.inner_text("#mdCount")
        check("filtre par security group", filtered != count_before, filtered)
        page.click("#mdReset")
        page.wait_for_timeout(700)

        # ------------------------------------------------------------------
        # Dashboard Control
        # ------------------------------------------------------------------
        page.click('[data-tab="control"]')
        page.wait_for_selector("#ctlList .control-row", timeout=10000)
        control_rows = page.locator("#ctlList .control-row").count()
        check("contrôles listés", control_rows == 5, f"{control_rows}")
        check("bar chart des contrôles", page.evaluate("Object.keys(state.charts).includes('controls')"))
        check("barres verticales", page.evaluate("state.charts.controls.options.indexAxis") == "x")
        check("libellés complets sur 2 lignes",
              page.evaluate("Array.isArray(state.charts.controls.data.labels[0])"))
        distinct = page.evaluate("new Set(state.charts.controls.data.datasets[0].backgroundColor).size")
        check("couleur distincte par contrôle", distinct >= 5, f"{distinct} couleurs")
        check("pastilles de couleur dans la liste", page.locator("#ctlList .ctl-dot").count() == 5)

        page.locator("#ctlList .control-row").first.click()
        page.wait_for_selector("#controlModal.show", timeout=10000)
        page.wait_for_selector("#cmBody tr td", timeout=10000)
        modal_rows = page.locator("#cmBody tr").count()
        check("modale des anomalies peuplée", modal_rows >= 1, f"{modal_rows} lignes")
        check("titre du contrôle", page.inner_text("#cmTitle").startswith("Contrôle"), page.inner_text("#cmTitle"))
        page.click("#controlModal .btn-close")

        # ------------------------------------------------------------------
        # Assistant IA
        # ------------------------------------------------------------------
        page.click('[data-tab="ai"]')
        page.wait_for_function("() => state.ai.status !== null", timeout=10000)
        state_label = page.inner_text("#aiState")
        check("état du moteur IA affiché", state_label.strip() not in ("", "—"), state_label)
        scope = page.inner_text("#aiScope")
        check("périmètre IA (titres, contrôles)", "titres" in scope and "contrôles" in scope, scope)
        page.click('[data-bs-target="#aiContextPanel"]')   # déplier l'accordéon
        page.wait_for_timeout(500)
        page.click("#aiContextRefreshBtn")
        page.wait_for_timeout(800)
        context = page.inner_text("#aiContextText")
        check("contexte IA non vide", len(context) > 500, f"{len(context)} caractères")
        check("contexte = données chargées", "MasterData" in context and "Contrôles" in context)

        # ------------------------------------------------------------------
        # Datasource
        # ------------------------------------------------------------------
        page.click('[data-tab="datasource"]')
        # Le placeholder « — » compte pour une ligne : on attend les 8 champs réels.
        page.wait_for_function(
            "document.querySelectorAll('#mapperTable tbody tr').length >= 8",
            timeout=10000,
        )
        mapper_rows = page.locator("#mapperTable tbody tr").count()
        check("champs mappés (8 standards + dynamiques)", mapper_rows >= 9, f"{mapper_rows} lignes")
        check("colonne supplémentaire signalée", page.locator("#mapperTable .pill-ok").count() >= 1)
        check("MasterData renseigné", page.input_value("#srcMasterdata").strip() != "")
        check("dossier contrôles renseigné", page.input_value("#srcControls").strip() != "")
        check("modèle GGUF renseigné", page.input_value("#srcGguf").strip().endswith(".gguf"))
        check("fichiers de contrôle listés",
              page.locator("#srcControlsFiles .src-line").count() == 5)

        # ------------------------------------------------------------------
        # Retour au Dashboard (l'onglet se recharge sans erreur)
        # ------------------------------------------------------------------
        page.click('[data-tab="dashboard"]')
        page.wait_for_timeout(500)
        check("retour Dashboard sans erreur", page.locator("#dashCharts:not(.d-none)").count() == 1)

        browser.close()

    for ok, label in results:
        print(f"  [{'OK ' if ok else 'FAIL'}] {label}")
    if console_errors:
        print("\nErreurs console :")
        for error in console_errors[:20]:
            print(f"  - {error}")
    failed = sum(1 for ok, _ in results if not ok)
    print(f"\n{len(results) - failed}/{len(results)} contrôles réussis")
    return 1 if failed or console_errors else 0


if __name__ == "__main__":
    sys.exit(main())
