from __future__ import annotations

from typing import Any


class APIError(Exception):
    """Erreur métier renvoyée au client sous forme de payload JSON."""

    def __init__(self, status_code: int, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message

    def payload(self) -> dict[str, Any]:
        return {"error": self.message}
