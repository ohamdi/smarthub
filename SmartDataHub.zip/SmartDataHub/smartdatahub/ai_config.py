"""Configuration du module IA : paramètres de génération et détection des modèles.

Ces réglages vivent dans ``ai_config.json`` ; le chemin du modèle reste dans
``datasource_config.json`` (``gguf_path``), comme dans Smart-pms : c'est un
chemin, il appartient donc à l'onglet Data Source.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

DEFAULTS: dict[str, Any] = {
    "n_ctx": 8192,
    # 0 = tous les cœurs détectés par llama-cpp-python.
    "n_threads": 0,
    "n_batch": 2048,
    "temperature": 0.3,
    "max_tokens": 900,
    "top_p": 0.9,
    "repeat_penalty": 1.1,
    "max_context_chars": 12000,
}

#: Bornes de validation : hors bornes, la valeur n'est pas écrite.
BOUNDS: dict[str, tuple[int, int]] = {
    "n_ctx": (2048, 131072),
    "n_threads": (0, 256),
    "n_batch": (32, 8192),
    "max_tokens": (16, 8192),
    "max_context_chars": (2000, 200000),
}

FLOATS = {"temperature", "top_p", "repeat_penalty"}

#: Dossiers scannés pour proposer des modèles dans l'interface.
MODEL_DIRS = [
    Path.home() / "Models",
    Path.home() / "Documents",
    Path.home() / "Downloads",
]


def config_path(base_dir: Path) -> Path:
    return Path(base_dir) / "ai_config.json"


def expand(path: str, base_dir: Path) -> Path:
    """Résout un chemin éventuel (relatif ou commençant par ``~``)."""
    expanded = os.path.expandvars(os.path.expanduser(str(path or "")))
    candidate = Path(expanded)
    return candidate if candidate.is_absolute() else Path(base_dir) / candidate


def _coerce(key: str, value: Any) -> Any:
    """Ramène une valeur JSON au type attendu, ou ``None`` si elle est fausse."""
    if key in FLOATS:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    low, high = BOUNDS.get(key, (None, None))
    if low is not None and not low <= number <= high:
        return None
    return number


def load(base_dir: Path) -> dict[str, Any]:
    """Configuration effective = défauts bornés + ``ai_config.json``."""
    stored: dict[str, Any] = {}
    try:
        with config_path(base_dir).open("r", encoding="utf-8") as handle:
            raw = json.load(handle)
        if isinstance(raw, dict):
            stored = raw
    except (OSError, json.JSONDecodeError):
        pass

    config = dict(DEFAULTS)
    for key, default in DEFAULTS.items():
        if key not in stored:
            continue
        if key in FLOATS or key in BOUNDS:
            coerced = _coerce(key, stored[key])
        else:
            coerced = stored[key]
        config[key] = coerced if coerced is not None else default
    return config


def save(base_dir: Path, values: dict[str, Any]) -> dict[str, Any]:
    """Écrit les valeurs fournies (clés autorisées uniquement) et renvoie la config."""
    current = load(base_dir)
    for key, default in DEFAULTS.items():
        if key not in values or values[key] is None:
            continue
        if key in FLOATS or key in BOUNDS:
            coerced = _coerce(key, values[key])
        else:
            coerced = values[key]
        current[key] = coerced if coerced is not None else default

    path = config_path(base_dir)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(current, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return current


def list_models(base_dir: Path, current_path: str = "") -> list[dict[str, Any]]:
    """Liste les fichiers ``.gguf`` disponibles sur la machine."""
    directories = list(MODEL_DIRS)
    active = expand(current_path, base_dir) if current_path else None
    if active is not None and active.parent.is_dir():
        directories.insert(0, active.parent)

    seen: dict[Path, dict[str, Any]] = {}
    for directory in directories:
        if not directory.is_dir():
            continue
        for candidate in sorted(directory.glob("*.gguf")):
            if candidate in seen or not candidate.is_file():
                continue
            # Un mmproj-*.gguf n'est pas un modèle de language.
            if candidate.name.startswith("mmproj-"):
                continue
            try:
                size_mb = round(candidate.stat().st_size / (1024 * 1024), 1)
            except OSError:
                continue
            seen[candidate] = {
                "name": candidate.name,
                "path": str(candidate),
                "size_mb": size_mb,
                "dir": str(candidate.parent),
            }
    return sorted(seen.values(), key=lambda model: model["name"].lower())


def describe_model(base_dir: Path, model_path: str) -> dict[str, Any]:
    """État du modèle sélectionné (présence et taille sur disque)."""
    resolved = expand(model_path, base_dir) if model_path else None
    exists = bool(resolved and resolved.is_file())
    size_mb = 0.0
    if exists and resolved is not None:
        try:
            size_mb = round(resolved.stat().st_size / (1024 * 1024), 1)
        except OSError:
            exists = False
    return {
        "configured": str(model_path or ""),
        "resolved": str(resolved) if resolved else "",
        "exists": exists,
        "size_mb": size_mb,
    }
