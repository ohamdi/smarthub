"""Génération des données de démonstration : MasterData + fichiers de contrôles.

Utilisable depuis l'onglet Data Source (« Générer les données de démo ») ou en
ligne de commande : ``python -m smartdatahub.demo_data``.

Les données sont synthétiques : noms d'émetteurs réels mais codes, ISIN et
montants fabriqués. Un jeu de démo suffit à explorer les 5 onglets ; les vrais
fichiers se branchent ensuite dans l'onglet Data Source.
"""

from __future__ import annotations

import random
import string
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import pandas as pd

from .config import DataSourceConfig, Settings

TODAY = datetime(2026, 10, 8)
SEED = 20261008

EQUITY_NAMES = [
    "Air France-KLM", "Alstom SA", "Altarea Cogedim", "Arval SA", "AXA SA",
    "Banco BPM SPA", "BNP Paribas SA", "Bouygues SA", "Capgemini SA",
    "Carrefour SA", "Crédit Agricole SA", "Danone SA", "Dassault Systèmes SA",
    "Edenred SA", "Engie SA", "EssilorLuxottica SA", "Eurofins Scientific SE",
    "Hermès International SA", "Iberdrola SA", "ING Groep NV",
    "Intesa Sanpaolo SPA", "JCDecaux SA", "L'Oréal SA", "LVMH SA", "Legrand SA",
    "Lufthansa AG", "Michelin SA", "Moncler SA", "Nestlé SA", "Novartis AG",
    "Orange SA", "Pernod Ricard SA", "Philips NV", "Publicis Groupe SA",
    "Recordati SA", "Renault SA", "Repsol SA", "Schneider Electric SE",
    "Siemens AG", "Société Générale SA", "Sodexo SA", "Stellantis NV",
    "STMicroelectronics NV", "Telefónica SA", "Thales SA", "TotalEnergies SE",
    "UniCredit SPA", "Vinci SA", "Volkswagen AG", "Walmart Inc", "Apple Inc",
    "Microsoft Corp", "Amazon.com Inc", "Schlumberger NV", "BNY Mellon SA",
]

BOND_ISSUERS = [
    "État Français", "BNP Paribas SA", "Société Générale SA",
    "Crédit Agricole SA", "Deutsche Bank AG", "ING Groep NV", "UniCredit SPA",
    "Banco Santander SA", "CaixaBank SA", "General Electric Co",
    "Ford Motor Credit", "AT&T Inc", "Volkswagen AG", "Toyota Motor Credit",
    "KfW", "Airbus SE", "Enel SPA", "Iberdrola Financiación SA",
]

STRUCTURED_ISSUERS = [
    "Société Générale SA", "BNP Paribas CIB", "Natixis SA",
    "Crédit Agricole CIB", "J.P. Morgan Securities", "Goldman Sachs International",
    "UBS AG", "BofA Securities",
]

UNDERLYINGS = ["CAC 40", "Euro Stoxx 50", "S&P 500", "Or", "Nasdaq 100", "Bund", "Pétrole Brent"]

FUNDS = [
    "Équité Europe Décisionnaire", "Obligations Euro Dynamique", "Actions Monde",
    "Rendement ISR", "Euro Small Caps", "Mandat Horizon", "Crédit Sélectif",
    "Allocation Flexible", "Équité Amérique du Nord", "Dette Souveraine Euro",
]

CURRENCY_BY_TYPE: dict[str, list[tuple[str, int]]] = {
    "Action": [("EUR", 72), ("USD", 18), ("GBP", 5), ("CHF", 3), ("JPY", 2)],
    "Obligation": [("EUR", 78), ("USD", 15), ("GBP", 4), ("CHF", 3)],
    "ETF": [("EUR", 70), ("USD", 25), ("GBP", 5)],
    "OPCVM": [("EUR", 85), ("USD", 10), ("CHF", 5)],
    "Fonds": [("EUR", 88), ("USD", 12)],
    "Produit structuré": [("EUR", 75), ("USD", 25)],
    "Warrant": [("EUR", 65), ("USD", 35)],
    "Titre monétaire": [("EUR", 92), ("USD", 8)],
}

TYPE_WEIGHTS = [
    ("Action", 40),
    ("Obligation", 30),
    ("ETF", 8),
    ("OPCVM", 7),
    ("Fonds", 5),
    ("Produit structuré", 6),
    ("Warrant", 2),
    ("Titre monétaire", 2),
]

TYPE_TO_GROUP = {
    "Action": "Actions",
    "Obligation": "Obligations",
    "ETF": "Fonds & OPCVM",
    "OPCVM": "Fonds & OPCVM",
    "Fonds": "Fonds & OPCVM",
    "Produit structuré": "Produits structurés",
    "Warrant": "Produits structurés",
    "Titre monétaire": "Monétaire",
}

ISIN_COUNTRIES = ["FR", "DE", "US", "GB", "NL", "IT", "ES", "CH", "LU", "JP", "CA", "SE"]

#: Colonne volontairement hors des 8 champs standards : l'interface doit la
#: détecter et l'afficher automatiquement (colonnes dynamiques).
SECTEURS = [
    "Banque",
    "Énergie",
    "Santé",
    "Technologie",
    "Industrie",
    "Consommation",
    "Immobilier",
    "Distribution",
]


# -- utilitaires ------------------------------------------------------------
def _check_digit(body: str) -> str:
    """Chiffre de contrôle ISIN (Luhn sur la forme numérique)."""
    digits: list[str] = []
    for char in body.upper():
        digits.append(str(int(char)) if char.isdigit() else str(ord(char) - ord("A") + 10))
    flattened = "".join(digits)
    total = 0
    for index, char in enumerate(reversed(flattened)):
        value = int(char)
        if index % 2 == 0:
            value *= 2
            if value > 9:
                value -= 9
        total += value
    return str((10 - total % 10) % 10)


def _isin(country: str, rng: random.Random) -> str:
    nsin = "".join(rng.choice(string.digits) for _ in range(8)) + rng.choice(
        string.digits + string.ascii_uppercase
    )
    body = country + nsin
    return body + _check_digit(body)


def _weighted(pairs: list[tuple[Any, int]], rng: random.Random) -> Any:
    values, weights = zip(*pairs)
    return rng.choices(values, weights=weights, k=1)[0]


def _unique_codes(count: int, rng: random.Random) -> list[str]:
    codes: set[str] = set()
    while len(codes) < count:
        if rng.random() < 0.7:
            code = str(rng.randint(1000000, 9999999))
        else:
            code = "".join(rng.choices(string.ascii_uppercase, k=4)) + str(rng.randint(10, 99))
        codes.add(code)
    return sorted(codes)


def _creation_date(rng: random.Random) -> pd.Timestamp:
    if rng.random() < 0.15:
        start = datetime(2026, 1, 1)
        end = TODAY
    else:
        year = rng.randint(2015, 2025)
        start = datetime(year, 1, 1)
        end = datetime(year, 12, 31)
    span = max((end - start).days, 1)
    return pd.Timestamp(start + timedelta(days=rng.randint(0, span)))


def _libelle(sec_type: str, index: int, rng: random.Random) -> tuple[str, str]:
    """Retourne (libellé, émetteur) pour un type de titre donné."""
    if sec_type == "Action":
        name = rng.choice(EQUITY_NAMES)
        return name, name
    if sec_type == "Obligation":
        issuer = rng.choice(BOND_ISSUERS)
        coupon = round(rng.uniform(0.25, 7.0), 2)
        year = rng.randint(2026, 2045)
        return f"{issuer} O. {coupon:.2f}% {year}", issuer
    if sec_type == "ETF":
        name = f"ETF {rng.choice(['CAC 40', 'Euro Stoxx 50', 'S&P 500', 'Obligations Euro', 'Water', 'Cybersécurité', 'Small Caps Europe'])}"
        issuer = "Amundi ETF" if rng.random() < 0.5 else "Lyxor ETF"
        return f"{name} {issuer}", issuer
    if sec_type == "OPCVM":
        fund = rng.choice(FUNDS)
        issuer = rng.choice(["Amundi", "Natixis IM", "Cardiff Gestion", "La Française Asset Mgmt"])
        return f"{fund} {issuer} – C", issuer
    if sec_type == "Fonds":
        fund = rng.choice(FUNDS)
        issuer = rng.choice(["AXA WF", "BNP Paribas AM", "Generali Investments"])
        return f"{fund} ({issuer})", issuer
    if sec_type == "Produit structuré":
        issuer = rng.choice(STRUCTURED_ISSUERS)
        underlying = rng.choice(UNDERLYINGS)
        year = rng.randint(2026, 2030)
        return f"Certificat {underlying} {year} {issuer}", issuer
    if sec_type == "Warrant":
        issuer = rng.choice(STRUCTURED_ISSUERS)
        underlying = rng.choice(UNDERLYINGS)
        return f"Warrant {underlying} {rng.randint(100, 999)} {issuer}", issuer
    issuer = rng.choice(BOND_ISSUERS)
    return f"Titre de créance {year_placeholder(index)} {issuer}", issuer


def year_placeholder(index: int) -> int:
    return 2026 + (index % 4)


def _build_masterdata(rng: random.Random, rows: int) -> pd.DataFrame:
    codes = _unique_codes(rows, rng)
    types = [_weighted(TYPE_WEIGHTS, rng) for _ in range(rows)]

    records = []
    for index, code in enumerate(codes):
        sec_type = types[index]
        libelle, emetteur = _libelle(sec_type, index, rng)
        country = rng.choice(ISIN_COUNTRIES)
        devise = _weighted(CURRENCY_BY_TYPE[sec_type], rng)
        records.append(
            {
                "CodeValeur": code,
                "CodeISIN": _isin(country, rng),
                "SecurityType": sec_type,
                "SecurityGroup": TYPE_TO_GROUP[sec_type],
                "Libellé": libelle,
                "Devise": devise,
                "Émetteur": emetteur,
                "DateCreation": _creation_date(rng),
                "Secteur": rng.choice(SECTEURS),
                "QuantiteGlobale": 1_000 + ((index * 7919) % 5_000_000),
            }
        )

    frame = pd.DataFrame(records)

    # Incohérences maîtrisées, reprises par le contrôle n°3 : ISIN manquants
    # et doublons, pour que la démo montre de vraies anomalies.
    missing = rng.sample(range(rows), 5)
    for position in missing:
        frame.at[position, "CodeISIN"] = None
    duplicates = rng.sample([p for p in range(rows) if p not in missing], 2)
    for position in duplicates:
        frame.at[position, "CodeISIN"] = frame.at[missing[0], "CodeISIN"]
    return frame, missing, duplicates


# -- contrôles --------------------------------------------------------------
def _sample_rows(frame: pd.DataFrame, count: int, rng: random.Random) -> pd.DataFrame:
    positions = rng.sample(range(len(frame)), min(count, len(frame)))
    return frame.iloc[sorted(positions)].reset_index(drop=True)


def _control_cours_invariant(master: pd.DataFrame, rng: random.Random) -> pd.DataFrame:
    rows = _sample_rows(master, 14, rng).copy()
    cours = [round(rng.uniform(5, 500), 4) for _ in range(len(rows))]
    variation = [round(rng.uniform(0.5, 12.0), 4) for _ in range(len(rows))]
    return pd.DataFrame(
        {
            "CodeValeur": rows["CodeValeur"],
            "Libellé": rows["Libellé"],
            "DateCours": pd.Timestamp(TODAY.date()),
            "CoursJour": [round(c + c * v / 100, 4) for c, v in zip(cours, variation)],
            "CoursVeille": cours,
            "EcartPct": variation,
            "Motif": "Le cours du jour doit être identique à celui de la veille (instrument non coté).",
        }
    )


def _control_structured_100(master: pd.DataFrame, rng: random.Random) -> pd.DataFrame:
    rows = master[master["SecurityType"].isin(["Produit structuré", "Warrant"])].head(9)
    if rows.empty:
        rows = _sample_rows(master, 6, rng)
    rows = rows.reset_index(drop=True)
    cours = [round(rng.uniform(45, 118), 4) for _ in range(len(rows))]
    return pd.DataFrame(
        {
            "CodeValeur": rows["CodeValeur"],
            "Libellé": rows["Libellé"],
            "CodeISIN": rows["CodeISIN"],
            "Cours": cours,
            "PariteDeReference": [100.0] * len(rows),
            "EcartPts": [round(c - 100.0, 4) for c in cours],
            "Motif": ["Cours éloigné de la parité de 100"] * len(rows),
        }
    )


def _control_isin(
    master: pd.DataFrame, missing: list[int], duplicates: list[int], rng: random.Random
) -> pd.DataFrame:
    positions = sorted(missing + duplicates)
    rows = master.iloc[positions]
    motifs = ["ISIN manquant"] * len(missing) + ["ISIN en doublon"] * len(duplicates)
    return pd.DataFrame(
        {
            "CodeValeur": rows["CodeValeur"].values,
            "Libellé": rows["Libellé"].values,
            "CodeISIN": rows["CodeISIN"].values,
            "Motif": motifs,
        }
    )


def _control_devise(master: pd.DataFrame, rng: random.Random) -> pd.DataFrame:
    rows = _sample_rows(master, 6, rng).copy()
    reference = rows["Devise"].tolist()
    cotes = []
    for devise in reference:
        cotes.append({"EUR": "USD", "USD": "EUR", "GBP": "EUR", "CHF": "EUR"}.get(devise, "USD"))
    return pd.DataFrame(
        {
            "CodeValeur": rows["CodeValeur"],
            "Libellé": rows["Libellé"],
            "DeviseReference": reference,
            "DeviseCours": cotes,
            "Motif": ["Devise de cotation incohérente avec la devise de référence"] * len(rows),
        }
    )


def _control_maturite(master: pd.DataFrame, rng: random.Random) -> pd.DataFrame:
    obligations = master[master["SecurityType"] == "Obligation"]
    rows = _sample_rows(obligations if len(obligations) >= 5 else master, 5, rng).copy()
    maturites = [
        pd.Timestamp(TODAY.date()) - timedelta(days=rng.randint(30, 900))
        for _ in range(len(rows))
    ]
    return pd.DataFrame(
        {
            "CodeValeur": rows["CodeValeur"],
            "Libellé": rows["Libellé"],
            "DateMaturite": maturites,
            "JoursDepassement": [max((TODAY.date() - m.date()).days, 0) for m in maturites],
            "Motif": ["Date de maturité dépassée alors que le titre est toujours en portefeuille"] * len(rows),
        }
    )


# -- point d'entrée ---------------------------------------------------------
def generate(
    base_dir: Path | None = None,
    rows: int = 600,
    seed: int = SEED,
) -> dict[str, Any]:
    """Écrit le MasterData de démo et les fichiers de contrôle."""
    settings = Settings.from_env() if base_dir is None else Settings(
        base_dir=Path(base_dir).resolve(), config_path=Path(base_dir).resolve() / "datasource_config.json"
    )
    config = DataSourceConfig(settings.base_dir, settings.config_path)
    rng = random.Random(seed)

    master_path = config.resolve("masterdata_path")
    controls_dir = config.resolve("controls_dir")
    if master_path is None:
        master_path = settings.base_dir / "data" / "masterdata.parquet"
    if controls_dir is None:
        controls_dir = settings.base_dir / "data" / "controls"
    master_path.parent.mkdir(parents=True, exist_ok=True)
    controls_dir.mkdir(parents=True, exist_ok=True)

    master, missing, duplicates = _build_masterdata(rng, rows)
    master.to_parquet(master_path, index=False)

    controls = {
        "controle_1_cours_invariant.parquet": _control_cours_invariant(master, rng),
        "controle_2_produits_structures_100.parquet": _control_structured_100(master, rng),
        "controle_3_isin_manquant_ou_doublon.parquet": _control_isin(
            master, missing, duplicates, rng
        ),
        "controle_4_devise_incoherente.parquet": _control_devise(master, rng),
        "controle_5_maturite_depassee.parquet": _control_maturite(master, rng),
    }
    written = []
    for name, frame in controls.items():
        target = controls_dir / name
        frame.to_parquet(target, index=False)
        written.append({"file": name, "rows": int(len(frame))})
    # Aucun fichier n'est supprimé : le dossier peut contenir de vrais
    # contrôles, la génération se contente d'écrire ses 5 fichiers de démo.

    return {
        "masterdata": {"path": str(master_path), "rows": int(len(master))},
        "controls": written,
    }


if __name__ == "__main__":  # pragma: no cover - CLI
    summary = generate()
    print(f"MasterData : {summary['masterdata']['rows']} titres → {summary['masterdata']['path']}")
    for item in summary["controls"]:
        print(f"  - {item['file']} : {item['rows']} anomalie(s)")
    sys.exit(0)
