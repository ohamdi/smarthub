"""SmartDataHub — visualisation MasterData, contrôles et assistant IA local."""

__all__ = ["__version__"]

__version__ = "1.0.0"
