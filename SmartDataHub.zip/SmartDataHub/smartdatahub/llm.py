"""Enveloppe du modèle GGUF local (llama-cpp-python), chargée à la demande.

Le chargement coûte plusieurs dizaines de secondes : le modèle est donc mis en
cache et sa « signature » (chemin + paramètres de chargement) fait foi. Changer
de modèle ou de fenêtre dans l'interface décharge et recharge le modèle, car
llama-cpp ne peut pas redimensionner une fenêtre en place.
"""

from __future__ import annotations

import logging
import os
import threading
from pathlib import Path
from typing import Any

from . import ai_config
from .config import DataSourceConfig

logger = logging.getLogger(__name__)


class LLMService:
    """Charge, interroge et libère le modèle GGUF configuré."""

    def __init__(self, config: DataSourceConfig) -> None:
        self.config = config
        self._lock = threading.RLock()
        self._llm: Any = None
        self._signature: tuple[Any, ...] | None = None
        self._error: str | None = None

    # -- paramètres ---------------------------------------------------------
    @property
    def base_dir(self) -> Path:
        return self.config.base_dir

    def generation(self) -> dict[str, Any]:
        """Réglages de génération, relus à chaque appel."""
        return ai_config.load(self.base_dir)

    def model_path(self) -> Path | None:
        return self.config.resolve("gguf_path")

    # -- modèle -------------------------------------------------------------
    def _get(self) -> Any:
        generation = self.generation()
        model_path = self.model_path()
        if model_path is None or not model_path.is_file():
            raise RuntimeError(
                "Modèle GGUF introuvable. Renseignez son chemin dans l'onglet "
                "Data Source."
            )
        signature = (
            str(model_path),
            generation["n_ctx"],
            generation["n_threads"],
            generation["n_batch"],
        )
        with self._lock:
            if self._llm is None or self._signature != signature:
                try:
                    from llama_cpp import Llama
                except ImportError as exc:
                    raise RuntimeError(
                        "llama-cpp-python n'est pas installé : "
                        "pip install -r requirements-llm.txt"
                    ) from exc
                threads = int(generation["n_threads"]) or (os.cpu_count() or 4)
                self._llm = Llama(
                    model_path=str(model_path),
                    n_ctx=int(generation["n_ctx"]),
                    n_threads=threads,
                    n_batch=int(generation["n_batch"]),
                    verbose=False,
                )
                self._signature = signature
                self._error = None
            return self._llm

    def chat(
        self,
        messages: list[dict[str, str]],
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> dict[str, Any]:
        generation = self.generation()
        model = self._get()
        return model.create_chat_completion(
            messages,
            max_tokens=int(max_tokens if max_tokens is not None else generation["max_tokens"]),
            temperature=float(
                temperature if temperature is not None else generation["temperature"]
            ),
            top_p=float(generation["top_p"]),
            repeat_penalty=float(generation["repeat_penalty"]),
        )

    def warmup(self) -> None:
        """Charge le modèle avant la première question, pour annoncer le délai."""
        try:
            self._get()
        except Exception as exc:
            # Gardé pour l'endpoint de statut : un échec doit être explicable
            # dans l'interface plutôt que de réapparaître en 503 à la question.
            self._error = str(exc)
            raise

    def unload(self) -> None:
        """Libère le modèle et la mémoire qu'il occupe."""
        with self._lock:
            self._llm = None
            self._signature = None
            self._error = None

    def config_changed(self) -> None:
        """Décharge le modèle si le chemin configuré a changé."""
        with self._lock:
            current = self.model_path()
            if self._llm is None:
                return
            if self._signature is None or str(current) != self._signature[0]:
                self._llm = None
                self._signature = None

    def model_status(self) -> dict[str, Any]:
        """État du moteur pour l'onglet Assistant IA."""
        generation = self.generation()
        model_path = self.model_path()
        available = bool(model_path and model_path.is_file())
        error = self._error
        if not available:
            error = "Fichier .gguf introuvable ou non renseigné."
        return {
            "backend": "gguf",
            "loaded": self._llm is not None,
            "available": available,
            "model_name": model_path.name if model_path and model_path.is_file() else "",
            "model_path": str(model_path or ""),
            "size_mb": (
                round(model_path.stat().st_size / (1024 * 1024), 1)
                if available and model_path is not None
                else 0
            ),
            "error": error,
            "config": generation,
            "llama_cpp_installed": self._llama_cpp_installed(),
        }

    @staticmethod
    def _llama_cpp_installed() -> bool:
        try:
            import llama_cpp  # noqa: F401
        except ImportError:
            return False
        return True
