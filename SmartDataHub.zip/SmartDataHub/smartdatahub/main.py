"""Fabrique de l'application FastAPI SmartDataHub."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse

from . import __version__
from .config import DataSourceConfig, Settings
from .errors import APIError
from .llm import LLMService
from .routes import router
from .services import ApplicationService
from .repository import ParquetRepository

logger = logging.getLogger(__name__)


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or Settings.from_env()
    config = DataSourceConfig(app_settings.base_dir, app_settings.config_path)
    repository = ParquetRepository(config)
    llm = LLMService(config)
    service = ApplicationService(app_settings, config, repository, llm)

    @asynccontextmanager
    async def lifespan(_application: FastAPI) -> AsyncIterator[None]:
        yield
        # Libère la mémoire du modèle GGUF à l'arrêt du serveur.
        llm.unload()

    application = FastAPI(
        title="SmartDataHub API",
        version=__version__,
        description=(
            "MasterData, contrôles Parquet et assistant IA local de SmartDataHub."
        ),
        lifespan=lifespan,
    )
    application.state.settings = app_settings
    application.state.config = config
    application.state.repository = repository
    application.state.llm = llm
    application.state.service = service

    @application.exception_handler(APIError)
    async def api_error_handler(_request: Request, exc: APIError) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content=exc.payload())

    @application.exception_handler(RequestValidationError)
    async def validation_error_handler(
        _request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        message = "; ".join(
            f"{'.'.join(str(part) for part in error['loc'][1:])}: {error['msg']}"
            for error in exc.errors()
        )
        return JSONResponse(
            status_code=422,
            content={"error": message or "Requête invalide"},
        )

    @application.get("/api/health", tags=["system"])
    async def health() -> dict[str, str]:
        return {"status": "ok", "version": __version__}

    application.include_router(router)

    @application.get("/{full_path:path}", include_in_schema=False)
    async def frontend(full_path: str) -> FileResponse:
        if full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Route API inconnue")
        static_dir = app_settings.static_dir.resolve()
        candidate = (static_dir / full_path).resolve()
        try:
            candidate.relative_to(static_dir)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail="Introuvable") from exc
        if candidate.is_file():
            return FileResponse(candidate)
        index = static_dir / "index.html"
        if not index.is_file():
            raise HTTPException(status_code=404, detail="Interface introuvable")
        return FileResponse(index)

    return application


app = create_app()
