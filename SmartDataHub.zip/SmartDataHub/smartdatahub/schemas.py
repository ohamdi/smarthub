"""Schémas des requêtes API (validation Pydantic)."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


class DatasourceConfigRequest(BaseModel):
    masterdata_path: Optional[str] = None
    controls_dir: Optional[str] = None
    gguf_path: Optional[str] = None


class AIChatMessage(BaseModel):
    role: str = Field(pattern="^(user|assistant|system)$")
    content: str = ""


class AIChatRequest(BaseModel):
    question: str
    history: list[AIChatMessage] = []


class AIConfigRequest(BaseModel):
    n_ctx: Optional[int] = None
    n_threads: Optional[int] = None
    n_batch: Optional[int] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    repeat_penalty: Optional[float] = None
    max_context_chars: Optional[int] = None

    def values(self) -> dict[str, Any]:
        return self.model_dump(exclude_unset=True)
