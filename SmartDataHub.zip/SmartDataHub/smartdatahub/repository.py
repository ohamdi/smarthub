"""Accès aux fichiers Parquet : MasterData et contrôles.

Un contrôle = un fichier Parquet du dossier des contrôles. Le nom du fichier
sert d'identifiant et de libellé, ce qui rend la liste évolutive sans
modification du code : déposer un fichier suffit.

Les colonnes sont détectées par alias (``codeValeur``, ``CODE_VALEUR``,
``code_valeur``… deviennent tous ``code_valeur``) pour absorber les
conventions de nommage des différents producteurs de fichiers.
"""

from __future__ import annotations

import re
import threading
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

#: Champs attendus du MasterData → alias acceptés (après normalisation).
FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "code_valeur": (
        "codevaleur",
        "codeval",
        "securitycode",
        "codevaleurinterne",
        "code",
        "ticker",
        "mnemonique",
    ),
    "code_isin": ("codeisin", "isin", "isincode"),
    "security_type": (
        "securitytype",
        "typevaleur",
        "typesecurite",
        "typeinstrument",
        "type",
        "classe",
    ),
    "security_group": (
        "securitygroup",
        "groupeseurite",
        "groupevaleur",
        "groupe",
        "group",
        "category",
        "categorie",
    ),
    "libelle": ("libelle", "designation", "intitule", "nom", "name", "label"),
    "devise": ("devise", "currency", "monnaie", "ccy"),
    "emetteur": ("emetteur", "issuer", "societeemetrice", "societe", "teneur"),
    "date_creation": (
        "datecreation",
        "datedecreation",
        "creationdate",
        "datecrea",
        "date",
    ),
}

#: Ordre d'affichage des champs du MasterData.
FIELD_ORDER: tuple[str, ...] = (
    "code_valeur",
    "code_isin",
    "security_type",
    "security_group",
    "libelle",
    "devise",
    "emetteur",
    "date_creation",
)

FIELD_LABELS: dict[str, str] = {
    "code_valeur": "Code valeur",
    "code_isin": "Code ISIN",
    "security_type": "Security type",
    "security_group": "Security group",
    "libelle": "Libellé",
    "devise": "Devise",
    "emetteur": "Émetteur",
    "date_creation": "Date de création",
}


def humanize_label(column: Any) -> str:
    """Libellé d'une colonne hors champ métier.

    ``secteur_activite`` → ``Secteur activite``, ``QuantiteGlobale`` →
    ``Quantite Globale``.
    """
    text = re.sub(r"[_\-.]+", " ", str(column)).strip()
    text = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text[:1].upper() + text[1:] if text else str(column)

#: Colonnes pouvant marquer une anomalie dans un fichier de contrôle.
ANOMALY_ALIASES: tuple[str, ...] = (
    "anomalie",
    "anomalies",
    "anomaly",
    "flaganomalie",
    "isanomalie",
    "flag",
    "status",
    "statut",
    "resultat",
    "conforme",
    "ok",
)

#: Valeurs considérées comme « anomalie » dans une colonne textuelle.
ANOMALY_TEXT_VALUES = {
    "anomalie",
    "anomaly",
    "ko",
    "nok",
    "false",
    "non",
    "non conforme",
    "nonconforme",
    "fail",
    "failed",
    "1",
    "true_anomaly",
}

#: Valeurs considérées comme « conforme » (à exclure du décompte).
NORMAL_TEXT_VALUES = {"ok", "conforme", "true", "non anomaly", "0", ""}


def normalize_name(name: Any) -> str:
    """Minuscules sans accent ni ponctuation : ``Code Vautéur`` → ``codevaleur``."""
    text = unicodedata.normalize("NFKD", str(name))
    text = "".join(char for char in text if not unicodedata.combining(char))
    return re.sub(r"[^0-9a-zA-Z]+", "", text).lower()


def detect_columns(columns: Iterable[Any]) -> dict[str, str | None]:
    """Associe chaque champ métier à la colonne réellement présente.

    Une colonne ne peut servir que deux champs : la première affectation gagne.
    """
    present = {normalize_name(column): str(column) for column in columns}
    mapping: dict[str, str | None] = {}
    used: set[str] = set()
    for field_name, aliases in FIELD_ALIASES.items():
        actual = None
        for alias in aliases:
            candidate = present.get(alias)
            if candidate is not None and candidate not in used:
                actual = candidate
                break
        mapping[field_name] = actual
        if actual:
            used.add(actual)
    return mapping


#: Colonnes candidates pour la « quantité globale » d'un titre (somme par
#: asset group dans le Dashboard). La détection est volontairement large pour
#: absorber les conventions de nommage ; le repli cherche « quantit… ».
QUANTITY_ALIASES: tuple[str, ...] = (
    "quantite",
    "quantites",
    "quantiteglobale",
    "quantiteglobal",
    "quantiteglobaleportefeuille",
    "quantitetotale",
    "quantitetotal",
    "quantitedetenue",
    "quantitedetenu",
    "quantity",
    "qty",
    "qte",
    "quant",
    "globale",
    "global",
)


def detect_quantity_column(columns: Iterable[Any]) -> str | None:
    """Colonne « quantité globale » du MasterData, si le fichier en fournit une."""
    present = {normalize_name(column): str(column) for column in columns}
    for alias in QUANTITY_ALIASES:
        if alias in present:
            return present[alias]
    for normalized, actual in present.items():
        if normalized.startswith("quantit"):
            return actual
    return None


#: Corrections de libellés déduits du nom de fichier (ASCII) : le nom du
#: fichier ne porte ni accent ni sigle, on restitue l'orthographe usuelle.
LABEL_WORD_FIXES: dict[str, str] = {
    "controle": "contrôle",
    "controles": "contrôles",
    "isin": "ISIN",
    "isins": "ISINs",
    "maturite": "maturité",
    "depassee": "dépassée",
    "incoherente": "incohérente",
    "incoherent": "incohérent",
    "incoherence": "incohérence",
    "structures": "structurés",
    "libelle": "libellé",
    "ecart": "écart",
    "ecarts": "écarts",
    "securite": "sécurité",
    "absente": "absente",
    "manquante": "manquante",
    "dupliquee": "dupliquée",
}


def control_label(stem: str) -> str:
    """``controle_2_produits_structures_100`` → ``Contrôle 2 : Produits structurés 100``."""
    text = stem.replace("-", " ").replace("_", " ").strip()
    match = re.match(r"^(?:controle|control)\s*(\d+)\s*(.*)$", text, flags=re.IGNORECASE)
    if match:
        rest_text = match.group(2).strip(" .:-")
        rest_words = [LABEL_WORD_FIXES.get(word.lower(), word) for word in rest_text.split()]
        rest = " ".join(rest_words) or "Sans titre"
        return f"Contrôle {match.group(1)} : {rest[:1].upper()}{rest[1:]}"
    words = [LABEL_WORD_FIXES.get(word.lower(), word) for word in text.split()]
    human = " ".join(words)
    return human[:1].upper() + human[1:] if human else stem


@dataclass
class MasterData:
    """MasterData chargé, colonnes normalisées et métadonnées de mapping."""

    frame: pd.DataFrame
    mapping: dict[str, str | None]
    source: dict[str, Any]
    missing: list[str] = field(default_factory=list)

    @property
    def available(self) -> bool:
        return not self.frame.empty


@dataclass
class ControlFile:
    """Un fichier de contrôle : libellé, effectifs et colonnes."""

    control_id: str
    label: str
    path: Path
    frame: pd.DataFrame
    code_column: str | None
    anomaly_column: str | None
    error: str | None = None


class ParquetRepository:
    """Cache de lecture Parquet + mapping des colonnes."""

    def __init__(self, config: Any) -> None:
        self.config = config
        self._lock = threading.RLock()
        self._cache: dict[str, tuple[tuple[Any, ...], pd.DataFrame]] = {}

    # -- lecture ------------------------------------------------------------
    def _read(self, path: Path) -> pd.DataFrame:
        """Lit un Parquet en le mettant en cache (invalidation par mtime/taille)."""
        stat = path.stat()
        key = str(path)
        signature = (stat.st_mtime_ns, stat.st_size)
        with self._lock:
            cached = self._cache.get(key)
            if cached is not None and cached[0] == signature:
                return cached[1]
        frame = pd.read_parquet(path)
        with self._lock:
            self._cache[key] = (signature, frame)
        return frame

    def invalidate(self) -> None:
        with self._lock:
            self._cache.clear()

    def _stat_info(self, path: Path, rows: int) -> dict[str, Any]:
        try:
            stat = path.stat()
            modified = pd.Timestamp(stat.st_mtime, unit="s").isoformat()
            size = stat.st_size
        except OSError:
            modified, size = None, 0
        return {
            "path": str(path),
            "exists": True,
            "rows": rows,
            "modified": modified,
            "size_kb": round(size / 1024, 1),
        }

    # -- MasterData ---------------------------------------------------------
    def masterdata_path(self) -> Path | None:
        return self.config.resolve("masterdata_path")

    def masterdata(self) -> MasterData | None:
        """Charge le MasterData, ou ``None`` si le fichier est absent."""
        path = self.masterdata_path()
        if path is None or not path.is_file():
            return None
        try:
            frame = self._read(path)
        except Exception:
            return None
        mapping = detect_columns(frame.columns)
        # Renomme sur les colonnes canoniques en conservant les colonnes en plus.
        rename = {actual: canonical for canonical, actual in mapping.items() if actual}
        working = frame.rename(columns=rename)
        missing = [f for f in FIELD_ORDER if mapping.get(f) is None]
        source = self._stat_info(path, len(frame))
        source["columns"] = [str(column) for column in frame.columns]
        return MasterData(frame=working, mapping=mapping, source=source, missing=missing)

    # -- Contrôles ----------------------------------------------------------
    def controls_dir(self) -> Path | None:
        return self.config.resolve("controls_dir")

    def control_paths(self) -> list[Path]:
        """Tous les ``.parquet`` du dossier des contrôles, triés par nom.

        La recherche est **récursive** (les sous-dossiers sont acceptés) et
        l'extension est reconnue **sans tenir compte de la casse**
        (``.parquet``, ``.PARQUET``…). Les fichiers cachés et les fichiers
        temporaires (``.~lock``, ``~$…``) sont ignorés.
        """
        directory = self.controls_dir()
        if directory is None or not directory.is_dir():
            return []
        return sorted(
            (
                path
                for path in directory.rglob("*")
                if path.is_file()
                and path.suffix.lower() == ".parquet"
                and not path.name.startswith((".", "~$"))
            ),
            key=lambda path: path.relative_to(directory).as_posix().lower(),
        )

    def control_id(self, path: Path) -> str:
        """Identifiant unique d'un contrôle.

        Un fichier posé directement dans le dossier garde son nom de fichier
        (comportement historique) ; dans un sous-dossier, le chemin relatif
        sans extension est utilisé pour éviter les collisions entre homonymes.
        """
        stem = path.stem
        directory = self.controls_dir()
        if directory is None:
            return stem
        try:
            relative = path.resolve().relative_to(directory.resolve())
        except ValueError:
            return stem
        if relative.parent == Path("."):
            return stem
        return relative.with_suffix("").as_posix()

    def control_dir_report(self) -> dict[str, Any]:
        """Diagnostic du dossier des contrôles (fichiers trouvés et ignorés)."""
        directory = self.controls_dir()
        report: dict[str, Any] = {
            "directory": str(directory) if directory else "",
            "exists": bool(directory and directory.is_dir()),
            "count": 0,
            "ignored": 0,
            "other_extensions": [],
        }
        if not report["exists"]:
            return report
        files = [
            path
            for path in directory.rglob("*")
            if path.is_file() and not path.name.startswith((".", "~$"))
        ]
        parquet = [path for path in files if path.suffix.lower() == ".parquet"]
        others = [path for path in files if path.suffix.lower() != ".parquet"]
        report["count"] = len(parquet)
        report["ignored"] = len(others)
        report["other_extensions"] = sorted(
            {path.suffix.lower() or "(sans extension)" for path in others}
        )
        return report

    def _detect_code_column(self, frame: pd.DataFrame) -> str | None:
        mapping = detect_columns(frame.columns)
        return mapping.get("code_valeur")

    @staticmethod
    def _detect_anomaly_column(frame: pd.DataFrame) -> str | None:
        present = {normalize_name(column): str(column) for column in frame.columns}
        for alias in ANOMALY_ALIASES:
            if alias in present:
                return present[alias]
        return None

    @staticmethod
    def _anomaly_mask(frame: pd.DataFrame, column: str) -> pd.Series:
        """Masque des lignes réellement en anomalie dans la colonne de statut."""
        series = frame[column]
        if pd.api.types.is_bool_dtype(series):
            return series.fillna(False).astype(bool)
        if pd.api.types.is_numeric_dtype(series):
            return series.fillna(0).astype(float) != 0
        values = series.astype("string").str.strip().str.lower().fillna("")
        return values.isin(ANOMALY_TEXT_VALUES)

    def control(self, path: Path) -> ControlFile:
        """Charge un fichier de contrôle, en isolant les lignes en anomalie."""
        control_id = self.control_id(path)
        label = control_label(path.stem)
        try:
            frame = self._read(path)
        except Exception as exc:  # fichier illisible : signalé dans l'interface
            return ControlFile(
                control_id=control_id,
                label=label,
                path=path,
                frame=pd.DataFrame(),
                code_column=None,
                anomaly_column=None,
                error=f"{type(exc).__name__}: {exc}",
            )
        code_column = self._detect_code_column(frame)
        anomaly_column = self._detect_anomaly_column(frame)
        if anomaly_column is not None:
            frame = frame[self._anomaly_mask(frame, anomaly_column)]
        return ControlFile(
            control_id=control_id,
            label=label,
            path=path,
            frame=frame.reset_index(drop=True),
            code_column=code_column,
            anomaly_column=anomaly_column,
        )

    def controls(self) -> list[ControlFile]:
        return [self.control(path) for path in self.control_paths()]

    def control_by_id(self, control_id: str) -> ControlFile | None:
        # Résolution uniquement parmi les fichiers réellement découverts dans
        # le dossier des contrôles : aucune traversée de chemin possible.
        for path in self.control_paths():
            if self.control_id(path) == control_id:
                return self.control(path)
        return None
