"""Configuration des sources de données de SmartDataHub.

Deux fichiers distincts, comme dans Smart-pms :
- ``datasource_config.json`` : les chemins (MasterData, contrôles, modèle GGUF) ;
- ``ai_config.json``        : les paramètres de génération du modèle local.
"""

from __future__ import annotations

import json
import os
import threading
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

#: Clés lues/écrites par l'onglet Data Source.
DEFAULTS: dict[str, str] = {
    "masterdata_path": "data/masterdata.parquet",
    "controls_dir": "data/controls",
    "gguf_path": "",
}

KNOWN_KEYS = tuple(DEFAULTS)

#: Libellés français affichés dans l'onglet Data Source.
LABELS: dict[str, str] = {
    "masterdata_path": "Fichier MasterData (.parquet)",
    "controls_dir": "Dossier des contrôles (.parquet)",
    "gguf_path": "Modèle IA (.gguf)",
}


def expand_path(value: str, base_dir: Path) -> Path | None:
    """Résout un chemin relatif / ``~`` / variable d'environnement."""
    text = os.path.expandvars(os.path.expanduser(str(value or "").strip()))
    if not text:
        return None
    path = Path(text)
    if not path.is_absolute():
        path = base_dir / path
    return path.resolve()


class DataSourceConfig:
    """Lit et écrit atomiquement ``datasource_config.json``."""

    def __init__(self, base_dir: Path, config_path: Path | None = None) -> None:
        self.base_dir = base_dir.resolve()
        self.path = (config_path or self.base_dir / "datasource_config.json").resolve()
        self._lock = threading.RLock()

    # -- lecture / écriture -------------------------------------------------
    def load(self) -> dict[str, Any]:
        with self._lock:
            try:
                with self.path.open("r", encoding="utf-8") as handle:
                    data = json.load(handle)
                return data if isinstance(data, dict) else {}
            except (FileNotFoundError, json.JSONDecodeError, OSError):
                return {}

    def save(self, data: dict[str, Any]) -> dict[str, Any]:
        """Fusionne les clés connues dans la configuration puis la réécrit."""
        if not isinstance(data, dict):
            raise ValueError("La configuration doit être un objet JSON.")
        with self._lock:
            current = self.load()
            for key in KNOWN_KEYS:
                if key in data and data[key] is not None:
                    current[key] = str(data[key]).strip()
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temp_path = self.path.with_name(f".{self.path.name}.{uuid.uuid4().hex}.tmp")
            try:
                with temp_path.open("w", encoding="utf-8") as handle:
                    json.dump(current, handle, ensure_ascii=False, indent=2)
                    handle.write("\n")
                os.replace(temp_path, self.path)
            finally:
                temp_path.unlink(missing_ok=True)
            return current

    # -- accès --------------------------------------------------------------
    def value(self, key: str) -> str:
        """Valeur configurée, ou valeur par défaut si absente/vide."""
        configured = self.load().get(key)
        if configured not in (None, ""):
            return str(configured)
        return DEFAULTS.get(key, "")

    def resolve(self, key: str) -> Path | None:
        """Chemin résolu de la ressource, ou ``None`` si non renseigné."""
        return expand_path(self.value(key), self.base_dir)

    def describe(self) -> dict[str, Any]:
        """État de chaque source pour l'onglet Data Source."""
        entries = []
        for key in KNOWN_KEYS:
            configured = self.value(key)
            resolved = expand_path(configured, self.base_dir)
            exists = bool(resolved and resolved.exists())
            entries.append(
                {
                    "key": key,
                    "label": LABELS.get(key, key),
                    "value": configured,
                    "resolved": str(resolved) if resolved else "",
                    "exists": exists,
                    "is_dir": bool(resolved and resolved.is_dir()),
                    "is_file": bool(resolved and resolved.is_file()),
                    "default": DEFAULTS.get(key, ""),
                }
            )
        return {
            "base_dir": str(self.base_dir),
            "config_path": str(self.path),
            "sources": entries,
        }

    def fingerprint(self) -> tuple[str, ...]:
        return tuple(self.value(key) for key in KNOWN_KEYS)


@dataclass(frozen=True)
class Settings:
    """Réglages d'exécution de l'application."""

    base_dir: Path
    config_path: Path

    @classmethod
    def from_env(cls) -> "Settings":
        base_dir = Path(
            os.getenv("SMARTDATAHUB_BASE_DIR", Path(__file__).resolve().parent.parent)
        ).resolve()
        config_path = Path(
            os.getenv("SMARTDATAHUB_CONFIG_PATH", base_dir / "datasource_config.json")
        ).resolve()
        return cls(base_dir=base_dir, config_path=config_path)

    @property
    def static_dir(self) -> Path:
        return self.base_dir / "static"

    @property
    def data_dir(self) -> Path:
        return self.base_dir / "data"
