import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import os
import sys

np.random.seed(42)

SECTORS = [
    "Technology",
    "Healthcare",
    "Financials",
    "Consumer Discretionary",
    "Industrials",
    "Energy",
    "Materials",
    "Utilities",
    "Real Estate",
    "Communication",
]
ASSET_CLASSES = ["Equities", "Fixed Income", "Alternatives", "Cash", "Commodities"]
GEOGRAPHIES = ["North America", "Europe", "Asia Pacific", "Emerging Markets"]
STATUSES = ["Active", "Exited", "Written Off"]


def generate_portfolios():
    portfolios = [
        {
            "id": "P001",
            "name": "Alpha Growth Fund",
            "type": "Long/Short Equity",
            "aum": 245_000_000,
            "benchmark": "S&P 500",
            "inception": "2019-01-15",
            "ytd_return": 12.4,
            "total_return": 87.3,
            "sharpe": 1.42,
            "max_dd": -8.2,
        },
        {
            "id": "P002",
            "name": "Fixed Income Plus",
            "type": "Fixed Income",
            "aum": 180_000_000,
            "benchmark": "Bloomberg Agg",
            "inception": "2018-06-01",
            "ytd_return": 4.2,
            "total_return": 32.1,
            "sharpe": 1.18,
            "max_dd": -3.1,
        },
        {
            "id": "P003",
            "name": "Global Macro Fund",
            "type": "Global Macro",
            "aum": 320_000_000,
            "benchmark": "HFRI Macro",
            "inception": "2017-03-20",
            "ytd_return": 8.7,
            "total_return": 156.4,
            "sharpe": 1.67,
            "max_dd": -12.5,
        },
        {
            "id": "P004",
            "name": "Tech Innovation Fund",
            "type": "Growth Equity",
            "aum": 95_000_000,
            "benchmark": "NASDAQ 100",
            "inception": "2021-09-10",
            "ytd_return": 18.9,
            "total_return": 34.2,
            "sharpe": 1.23,
            "max_dd": -15.8,
        },
        {
            "id": "P005",
            "name": "Diversified Multi-Strategy",
            "type": "Multi-Strategy",
            "aum": 450_000_000,
            "benchmark": "HFRI Fund Weighted",
            "inception": "2016-01-04",
            "ytd_return": 7.3,
            "total_return": 198.7,
            "sharpe": 1.89,
            "max_dd": -6.4,
        },
    ]
    return portfolios


def generate_positions(portfolio_id):
    n_positions = np.random.randint(15, 35)
    positions = []

    tickers = [
        "AAPL",
        "MSFT",
        "GOOGL",
        "AMZN",
        "NVDA",
        "META",
        "TSLA",
        "BRK.B",
        "JPM",
        "JNJ",
        "UNH",
        "HD",
        "PG",
        "MA",
        "DIS",
        "PYPL",
        "NFLX",
        "ADBE",
        "CRM",
        "INTC",
        "VZ",
        "T",
        "PFE",
        "MRK",
        "KO",
        "PEP",
        "WMT",
        "COST",
        "NKE",
        "MCD",
        "XOM",
        "CVX",
        "BAC",
        "C",
        "GS",
        "MS",
        "BLK",
        "AXP",
        "V",
        "SQ",
    ]

    for i in range(min(n_positions, len(tickers))):
        sector = np.random.choice(SECTORS)
        geo = np.random.choice(GEOGRAPHIES, p=[0.45, 0.25, 0.2, 0.1])
        weight = np.random.uniform(1, 12)

        entry_price = np.random.uniform(20, 500)
        current_price = entry_price * (1 + np.random.uniform(-0.3, 0.5))

        isin_base = ["US", "EU", "FR", "DE", "GB", "CH", "NL"][i % 7]
        isin = f"{isin_base}{tickers[i].replace('.', '')}{np.random.randint(100000, 999999)}"

        position = {
            "id": f"{portfolio_id}-POS-{i + 1:03d}",
            "ticker": tickers[i],
            "isin": isin,
            "name": f"{tickers[i]} Inc.",
            "sector": sector,
            "geography": geo,
            "weight": round(weight, 2),
            "shares": np.random.randint(100, 10000),
            "entry_price": round(entry_price, 2),
            "current_price": round(current_price, 2),
            "market_value": 0,
            "unrealized_pnl": 0,
            "unrealized_pnl_pct": 0,
            "status": "Active" if np.random.random() > 0.1 else "Exited",
        }
        position["market_value"] = round(
            position["shares"] * position["current_price"], 2
        )
        position["unrealized_pnl"] = round(
            position["shares"] * (position["current_price"] - position["entry_price"]),
            2,
        )
        position["unrealized_pnl_pct"] = round(
            (position["current_price"] / position["entry_price"] - 1) * 100, 2
        )

        positions.append(position)

    total_weight = sum(p["weight"] for p in positions)
    for p in positions:
        p["weight"] = round(p["weight"] / total_weight * 100, 2)

    return sorted(positions, key=lambda x: x["weight"], reverse=True)


def generate_performance_history(portfolio_id, days=365):
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)

    dates = pd.date_range(start=start_date, end=end_date, freq="D")
    dates = [d for d in dates if d.weekday() < 5]

    returns = np.random.normal(0.0005, 0.015, len(dates))
    cumulative = (1 + returns).cumprod()

    benchmark_returns = np.random.normal(0.0004, 0.012, len(dates))
    benchmark_cumulative = (1 + benchmark_returns).cumprod()

    records = []
    for i, d in enumerate(dates):
        records.append(
            {
                "date": d.strftime("%Y-%m-%d"),
                "portfolio_value": round((cumulative[i] * 100), 2),
                "benchmark_value": round((benchmark_cumulative[i] * 100), 2),
                "portfolio_return": round(
                    ((cumulative[i] / cumulative[0]) - 1) * 100, 2
                ),
                "benchmark_return": round(
                    ((benchmark_cumulative[i] / benchmark_cumulative[0]) - 1) * 100, 2
                ),
            }
        )

    return records


def generate_transactions(portfolio_id, n_trans=50):
    transactions = []
    tickers = [
        "AAPL",
        "MSFT",
        "GOOGL",
        "AMZN",
        "NVDA",
        "META",
        "TSLA",
        "JPM",
        "JNJ",
        "UNH",
    ]

    for i in range(n_trans):
        date = datetime.now() - timedelta(days=np.random.randint(1, 365))
        ticker = np.random.choice(tickers)

        trans = {
            "id": f"{portfolio_id}-TXN-{i + 1:04d}",
            "date": date.strftime("%Y-%m-%d"),
            "ticker": ticker,
            "type": np.random.choice(["BUY", "SELL"], p=[0.6, 0.4]),
            "shares": np.random.randint(50, 500),
            "price": round(np.random.uniform(50, 400), 2),
            "amount": 0,
            "fees": round(np.random.uniform(1, 50), 2),
        }
        trans["amount"] = round(trans["shares"] * trans["price"] + trans["fees"], 2)
        transactions.append(trans)

    return sorted(transactions, key=lambda x: x["date"], reverse=True)


def generate_allocation_data(positions):
    sector_alloc = {}
    for p in positions:
        sector = p["sector"]
        sector_alloc[sector] = sector_alloc.get(sector, 0) + p["weight"]

    geo_alloc = {}
    for p in positions:
        geo = p["geography"]
        geo_alloc[geo] = geo_alloc.get(geo, 0) + p["weight"]

    return {
        "sector": [
            {"sector": k, "weight": round(v, 2)} for k, v in sector_alloc.items()
        ],
        "geography": [
            {"geography": k, "weight": round(v, 2)} for k, v in geo_alloc.items()
        ],
    }


def get_data_path():
    if getattr(sys, "frozen", False):
        return os.path.join(sys._MEIPASS, "data", "portfolios.json")
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "portfolios.json")


def save_data():
    portfolios = generate_portfolios()
    data = {"portfolios": portfolios}

    for p in portfolios:
        p["positions"] = generate_positions(p["id"])
        p["performance"] = generate_performance_history(p["id"])
        p["transactions"] = generate_transactions(p["id"])
        p["allocation"] = generate_allocation_data(p["positions"])

    data_path = os.path.dirname(get_data_path())
    os.makedirs(data_path, exist_ok=True)
    with open(get_data_path(), "w") as f:
        json.dump(data, f, indent=2)

    return data


def load_data():
    path = get_data_path()
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return save_data()


if __name__ == "__main__":
    data = save_data()
    print(f"Generated {len(data['portfolios'])} portfolios")
    for p in data["portfolios"]:
        print(f"  - {p['name']}: {len(p['positions'])} positions")
