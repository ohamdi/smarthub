"""Analytics page - Comparative analysis and benchmarks"""

import dash
from dash import html, dcc
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.graph_objects as go

dash.register_page(__name__, path="/analytics", name="Analytics", order=2)
from components.components import MetricCard, format_pct
from data.demo_data import load_data

data = load_data()


def PerformanceComparisonChart():
    """Multi-portfolio performance comparison"""
    fig = go.Figure()
    colors = ["#58a6ff", "#3fb950", "#d29922", "#f85149", "#a371f7"]

    for i, portfolio in enumerate(data["portfolios"]):
        perf = portfolio["performance"]
        df = pd.DataFrame(perf)

        fig.add_trace(
            go.Scatter(
                x=df["date"],
                y=df["portfolio_return"],
                name=portfolio["name"][:20],
                line=dict(color=colors[i % len(colors)], width=2),
            )
        )

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=400,
        margin=dict(l=0, r=0, t=20, b=0),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        xaxis=dict(showgrid=True, gridcolor="rgba(48, 54, 61, 0.5)", color="#8b949e"),
        yaxis=dict(
            showgrid=True,
            gridcolor="rgba(48, 54, 61, 0.5)",
            color="#8b949e",
            tickformat=".1f",
        ),
        hovermode="x unified",
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def AllocationComparisonChart():
    """Stacked bar chart for sector allocation comparison"""
    fig = go.Figure()

    sectors = [
        "Technology",
        "Healthcare",
        "Financials",
        "Consumer Discretionary",
        "Industrials",
    ]

    for sector in sectors:
        values = []
        for p in data["portfolios"]:
            sector_pct = next(
                (
                    s["weight"]
                    for s in p["allocation"]["sector"]
                    if s["sector"] == sector
                ),
                0,
            )
            values.append(sector_pct)

        fig.add_trace(
            go.Bar(
                name=sector,
                x=[p["name"][:15] for p in data["portfolios"]],
                y=values,
            )
        )

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=350,
        barmode="stack",
        margin=dict(l=0, r=0, t=20, b=0),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        xaxis=dict(color="#8b949e"),
        yaxis=dict(color="#8b949e", tickformat=".0f", title="Weight %"),
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def RiskReturnScatter():
    """Risk vs Return scatter plot"""
    fig = go.Figure()

    for i, p in enumerate(data["portfolios"]):
        fig.add_trace(
            go.Scatter(
                x=[p["max_dd"] * -1],
                y=[p["ytd_return"]],
                mode="markers+text",
                marker=dict(size=20, color="#58a6ff"),
                text=[p["name"][:15]],
                textposition="top center",
                name=p["name"][:20],
            )
        )

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=350,
        margin=dict(l=0, r=0, t=40, b=0),
        xaxis=dict(
            title="Max Drawdown (%)", color="#8b949e", gridcolor="rgba(48, 54, 61, 0.5)"
        ),
        yaxis=dict(
            title="YTD Return (%)", color="#8b949e", gridcolor="rgba(48, 54, 61, 0.5)"
        ),
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})


layout = html.Div(
    [
        dbc.Row(
            [
                dbc.Col(
                    [
                        MetricCard(
                            "Avg Portfolio Return",
                            "10.3%",
                            delta="+2.1% vs benchmark",
                            delta_type="positive",
                        )
                    ],
                    width=3,
                ),
                dbc.Col(
                    [
                        MetricCard(
                            "Avg Sharpe Ratio",
                            "1.48",
                            delta="+0.23 vs benchmark",
                            delta_type="positive",
                        )
                    ],
                    width=3,
                ),
                dbc.Col(
                    [
                        MetricCard(
                            "Avg Max Drawdown",
                            "-9.2%",
                            delta="Within limit",
                            delta_type="neutral",
                        )
                    ],
                    width=3,
                ),
                dbc.Col(
                    [
                        MetricCard(
                            "Correlation Avg",
                            "0.42",
                            delta="Diversified",
                            delta_type="neutral",
                        )
                    ],
                    width=3,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Portfolio Performance Comparison",
                                    className="card-header-custom",
                                ),
                                dbc.CardBody([PerformanceComparisonChart()]),
                            ],
                            className="card-custom",
                        )
                    ],
                    width=8,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Risk vs Return", className="card-header-custom"
                                ),
                                dbc.CardBody([RiskReturnScatter()]),
                            ],
                            className="card-custom",
                        )
                    ],
                    width=4,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Sector Allocation Comparison",
                                    className="card-header-custom",
                                ),
                                dbc.CardBody([AllocationComparisonChart()]),
                            ],
                            className="card-custom",
                        )
                    ],
                    width=12,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Portfolio Statistics",
                                    className="card-header-custom",
                                ),
                                dbc.CardBody(
                                    [
                                        dbc.Table(
                                            [
                                                html.Thead(
                                                    html.Tr(
                                                        [
                                                            html.Th("Portfolio"),
                                                            html.Th("Benchmark"),
                                                            html.Th("YTD vs BM"),
                                                            html.Th("Total Return"),
                                                            html.Th("Volatility"),
                                                            html.Th("Sharpe"),
                                                            html.Th("Max DD"),
                                                        ]
                                                    )
                                                ),
                                                html.Tbody(
                                                    [
                                                        html.Tr(
                                                            [
                                                                html.Td(p["name"]),
                                                                html.Td(p["benchmark"]),
                                                                html.Td(
                                                                    f"+{p['ytd_return'] - 8.2:.1f}%",
                                                                    className="text-success"
                                                                    if p["ytd_return"]
                                                                    > 8.2
                                                                    else "text-danger",
                                                                ),
                                                                html.Td(
                                                                    f"{p['total_return']:.1f}%"
                                                                ),
                                                                html.Td("14.2%"),
                                                                html.Td(
                                                                    f"{p['sharpe']:.2f}"
                                                                ),
                                                                html.Td(
                                                                    f"{p['max_dd']:.1f}%",
                                                                    className="text-danger",
                                                                ),
                                                            ]
                                                        )
                                                        for p in data["portfolios"]
                                                    ]
                                                ),
                                            ],
                                            bordered=False,
                                            hover=True,
                                            responsive=True,
                                        )
                                    ]
                                ),
                            ],
                            className="card-custom",
                        )
                    ],
                    width=12,
                )
            ]
        ),
    ],
    className="fade-in",
)
