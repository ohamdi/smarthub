"""Overview page - KPIs across all portfolios"""

import dash
from dash import html, dcc, callback, Output, Input
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from data.demo_data import load_data

dash.register_page(__name__, path="/", name="Overview", order=0)

data = load_data()


def format_currency(value):
    if abs(value) >= 1_000_000_000:
        return f"${abs(value) / 1_000_000_000:.2f}B"
    elif abs(value) >= 1_000_000:
        return f"${abs(value) / 1_000_000:.1f}M"
    elif abs(value) >= 1_000:
        return f"${abs(value) / 1_000:.1f}K"
    return f"${value:.0f}"


def format_pct(value):
    return f"{value:+.2f}%"


def generate_sector_alloc():
    sector_totals = {}
    for p in data["portfolios"]:
        for pos in p["positions"]:
            sector = pos["sector"]
            sector_totals[sector] = sector_totals.get(sector, 0) + pos["market_value"]
    total = sum(sector_totals.values())
    return [
        {"sector": k, "value": v, "pct": v / total * 100}
        for k, v in sorted(sector_totals.items(), key=lambda x: -x[1])
    ]


layout = html.Div(
    [
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardBody(
                                    [
                                        html.H6(
                                            "Total AUM", className="text-muted mb-1"
                                        ),
                                        html.H3(
                                            format_currency(
                                                sum(
                                                    p["aum"] for p in data["portfolios"]
                                                )
                                            ),
                                            className="text-primary mb-0",
                                        ),
                                        html.Small(
                                            f"+{format_currency(sum(p['aum'] for p in data['portfolios']) * 0.05)} MTD",
                                            className="text-success",
                                        ),
                                    ]
                                )
                            ],
                            className="h-100",
                        )
                    ],
                    width=3,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardBody(
                                    [
                                        html.H6(
                                            "Avg YTD Return",
                                            className="text-muted mb-1",
                                        ),
                                        html.H3(
                                            format_pct(
                                                sum(
                                                    p["ytd_return"]
                                                    for p in data["portfolios"]
                                                )
                                                / len(data["portfolios"])
                                            ),
                                            className="text-success mb-0",
                                        ),
                                        html.Small(
                                            "+2.1% vs benchmark", className="text-muted"
                                        ),
                                    ]
                                )
                            ],
                            className="h-100",
                        )
                    ],
                    width=3,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardBody(
                                    [
                                        html.H6(
                                            "Avg Sharpe Ratio",
                                            className="text-muted mb-1",
                                        ),
                                        html.H3(
                                            f"{sum(p['sharpe'] for p in data['portfolios']) / len(data['portfolios']):.2f}",
                                            className="text-info mb-0",
                                        ),
                                        html.Small(
                                            "Risk-adjusted return",
                                            className="text-muted",
                                        ),
                                    ]
                                )
                            ],
                            className="h-100",
                        )
                    ],
                    width=3,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardBody(
                                    [
                                        html.H6(
                                            "Total Portfolios",
                                            className="text-muted mb-1",
                                        ),
                                        html.H3(
                                            f"{len(data['portfolios'])}",
                                            className="text-warning mb-0",
                                        ),
                                        html.Small(
                                            f"{sum(len(p['positions']) for p in data['portfolios'])} positions",
                                            className="text-muted",
                                        ),
                                    ]
                                )
                            ],
                            className="h-100",
                        )
                    ],
                    width=3,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Portfolio Performance (YTD)", className="fw-bold"
                                ),
                                dbc.CardBody(
                                    [
                                        dbc.Table(
                                            [
                                                html.Thead(
                                                    [
                                                        html.Tr(
                                                            [
                                                                html.Th("Portfolio"),
                                                                html.Th("AUM"),
                                                                html.Th("YTD"),
                                                                html.Th("Total Return"),
                                                                html.Th("Sharpe"),
                                                                html.Th("Max DD"),
                                                            ]
                                                        )
                                                    ]
                                                ),
                                                html.Tbody(
                                                    [
                                                        html.Tr(
                                                            [
                                                                html.Td(p["name"]),
                                                                html.Td(
                                                                    format_currency(
                                                                        p["aum"]
                                                                    )
                                                                ),
                                                                html.Td(
                                                                    format_pct(
                                                                        p["ytd_return"]
                                                                    ),
                                                                    className="text-success"
                                                                    if p["ytd_return"]
                                                                    > 0
                                                                    else "text-danger",
                                                                ),
                                                                html.Td(
                                                                    format_pct(
                                                                        p[
                                                                            "total_return"
                                                                        ]
                                                                    )
                                                                ),
                                                                html.Td(
                                                                    f"{p['sharpe']:.2f}"
                                                                ),
                                                                html.Td(
                                                                    format_pct(
                                                                        p["max_dd"]
                                                                    ),
                                                                    className="text-danger",
                                                                ),
                                                            ]
                                                        )
                                                        for p in data["portfolios"]
                                                    ]
                                                ),
                                            ],
                                            bordered=True,
                                            hover=True,
                                            size="sm",
                                            className="mb-0",
                                        )
                                    ]
                                ),
                            ]
                        )
                    ],
                    width=12,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Top Holdings by Weight", className="fw-bold"
                                ),
                                dbc.CardBody(
                                    [
                                        dbc.Table(
                                            [
                                                html.Thead(
                                                    [
                                                        html.Tr(
                                                            [
                                                                html.Th("Ticker"),
                                                                html.Th("Name"),
                                                                html.Th("Portfolio"),
                                                                html.Th("Weight"),
                                                                html.Th("Market Value"),
                                                            ]
                                                        )
                                                    ]
                                                ),
                                                html.Tbody(
                                                    [
                                                        html.Tr(
                                                            [
                                                                html.Td(pos["ticker"]),
                                                                html.Td(pos["name"]),
                                                                html.Td(p["name"]),
                                                                html.Td(
                                                                    f"{pos['weight']:.2f}%"
                                                                ),
                                                                html.Td(
                                                                    format_currency(
                                                                        pos[
                                                                            "market_value"
                                                                        ]
                                                                    )
                                                                ),
                                                            ]
                                                        )
                                                        for p in data["portfolios"]
                                                        for pos in sorted(
                                                            p["positions"],
                                                            key=lambda x: x["weight"],
                                                            reverse=True,
                                                        )[:5]
                                                    ][:10]
                                                ),
                                            ],
                                            bordered=True,
                                            hover=True,
                                            size="sm",
                                            className="mb-0",
                                        )
                                    ]
                                ),
                            ]
                        )
                    ],
                    width=8,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader("Sector Exposure", className="fw-bold"),
                                dbc.CardBody([html.Div(id="sector-chart")]),
                            ]
                        )
                    ],
                    width=4,
                ),
            ]
        ),
        dcc.Store(
            id="kpi-data",
            data={
                "portfolios": data["portfolios"],
                "sector_alloc": generate_sector_alloc(),
            },
        ),
    ]
)


@callback(Output("sector-chart", "children"), Input("kpi-data", "data"))
def update_sector_chart(data):
    sectors = data["sector_alloc"]

    fig = go.Figure(
        data=[
            go.Bar(
                x=[s["sector"] for s in sectors],
                y=[s["pct"] for s in sectors],
                marker_color=[
                    "#0d6efd",
                    "#6610f2",
                    "#6f42c1",
                    "#d63384",
                    "#dc3545",
                    "#fd7e14",
                    "#ffc107",
                    "#198754",
                    "#20c997",
                    "#0dcaf0",
                ],
            )
        ]
    )

    fig.update_layout(
        margin=dict(l=20, r=20, t=20, b=60),
        height=250,
        paper_bgcolor="transparent",
        plot_bgcolor="transparent",
        font=dict(size=10),
        xaxis=dict(tickangle=-45),
        yaxis=dict(title="%", ticksuffix="%"),
    )

    return dcc.Graph(
        figure=fig, config={"displayModeBar": False}, style={"height": "250px"}
    )
