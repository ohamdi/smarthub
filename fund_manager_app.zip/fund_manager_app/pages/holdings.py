"""Holdings page - Select portfolio to view detailed positions"""

import dash
from dash import html, dcc, callback, Output, Input
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from data.demo_data import load_data

dash.register_page(__name__, path="/holdings", name="Holdings", order=1)

data = load_data()
portfolio_options = [{"label": p["name"], "value": p["id"]} for p in data["portfolios"]]


def format_currency(value):
    return f"${abs(value):,.2f}"


def format_pct(value):
    return f"{value:+.2f}%"


def create_heatmap(positions):
    sectors = sorted(list(set(p["sector"] for p in positions)))
    isins = [p.get("isin", p["ticker"]) for p in positions[:15]]

    z_data = []
    for pos in positions[:15]:
        row = [pos["weight"] if pos["sector"] == s else None for s in sectors]
        z_data.append(row)

    fig = go.Figure(
        data=go.Heatmap(
            z=z_data,
            x=sectors,
            y=isins,
            colorscale="Blues",
            showscale=True,
            colorbar=dict(title="Weight %"),
            text=[
                [pos["weight"] if pos["sector"] == s else "" for s in sectors]
                for pos in positions[:15]
            ],
            texttemplate="%{text:.1f}%",
            textfont={"size": 8, "color": "white"},
            hovertemplate="ISIN: %{y}<br>Sector: %{x}<br>Weight: %{z:.2f}%<extra></extra>",
            connectgaps=False,
        )
    )
    fig.update_layout(
        height=max(400, len(isins) * 30),
        margin=dict(l=120, r=50, t=30, b=80),
        paper_bgcolor="#161b22",
        font=dict(size=9, color="#c9d1d9"),
        xaxis=dict(
            tickangle=-45,
            gridcolor="#30363d",
            title=dict(text="Sectors", font=dict(size=10)),
        ),
        yaxis=dict(
            autorange="reversed",
            gridcolor="#30363d",
            title=dict(text="ISIN", font=dict(size=10)),
        ),
    )
    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def create_table(positions):
    rows = [
        html.Tr(
            [
                html.Th("ISIN"),
                html.Th("Sector"),
                html.Th("Geo"),
                html.Th("Qty", className="text-end"),
                html.Th("Entry", className="text-end"),
                html.Th("Current", className="text-end"),
                html.Th("Market Value", className="text-end"),
                html.Th("+/- Val", className="text-end"),
                html.Th("+/- %", className="text-end"),
                html.Th("Weight", className="text-end"),
            ]
        )
    ]
    for pos in positions:
        pnl_class = "text-success" if pos["unrealized_pnl"] >= 0 else "text-danger"
        rows.append(
            html.Tr(
                [
                    html.Td(
                        html.Code(pos.get("isin", pos["ticker"])),
                        style={"fontSize": "0.65rem"},
                    ),
                    html.Td(pos["sector"], style={"fontSize": "0.75rem"}),
                    html.Td(pos["geography"], style={"fontSize": "0.75rem"}),
                    html.Td(
                        f"{pos['shares']:,}",
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(pos["entry_price"]),
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(pos["current_price"]),
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(pos["market_value"]),
                        className="text-end fw-bold",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_currency(pos["unrealized_pnl"]),
                        className=f"text-end {pnl_class}",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        format_pct(pos["unrealized_pnl_pct"]),
                        className=f"text-end {pnl_class}",
                        style={"fontSize": "0.75rem"},
                    ),
                    html.Td(
                        f"{pos['weight']:.2f}%",
                        className="text-end",
                        style={"fontSize": "0.75rem"},
                    ),
                ]
            )
        )
    return dbc.Table(
        rows, bordered=True, hover=True, size="sm", className="holdings-table"
    )


initial_portfolio = data["portfolios"][0]
initial_positions = sorted(
    initial_portfolio["positions"], key=lambda x: x["weight"], reverse=True
)
initial_total_mv = sum(p["market_value"] for p in initial_positions)
initial_total_pnl = sum(p["unrealized_pnl"] for p in initial_positions)
initial_winners = len([p for p in initial_positions if p["unrealized_pnl"] > 0])
initial_losers = len([p for p in initial_positions if p["unrealized_pnl"] < 0])
initial_pnl_color = "text-success" if initial_total_pnl >= 0 else "text-danger"


layout = html.Div(
    [
        html.H4("Portfolio Holdings", className="mb-3"),
        dbc.Card(
            [
                dbc.CardBody(
                    [
                        dbc.Row(
                            [
                                dbc.Col(
                                    [
                                        html.Label(
                                            "Select Portfolio", className="fw-bold"
                                        ),
                                        dbc.Select(
                                            id="portfolio-selector",
                                            options=portfolio_options,
                                            value=initial_portfolio["id"],
                                        ),
                                    ],
                                    width=4,
                                ),
                                dbc.Col(
                                    [
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    [
                                                        html.Span(
                                                            "AUM: ",
                                                            className="text-muted",
                                                        ),
                                                        html.Strong(
                                                            format_currency(
                                                                initial_portfolio["aum"]
                                                            )
                                                        ),
                                                    ],
                                                    className="border-end text-center p-2",
                                                ),
                                                dbc.Col(
                                                    [
                                                        html.Span(
                                                            "YTD: ",
                                                            className="text-muted",
                                                        ),
                                                        html.Strong(
                                                            format_pct(
                                                                initial_portfolio[
                                                                    "ytd_return"
                                                                ]
                                                            )
                                                        ),
                                                    ],
                                                    className="border-end text-center p-2",
                                                ),
                                                dbc.Col(
                                                    [
                                                        html.Span(
                                                            "Sharpe: ",
                                                            className="text-muted",
                                                        ),
                                                        html.Strong(
                                                            f"{initial_portfolio['sharpe']:.2f}"
                                                        ),
                                                    ],
                                                    className="text-center p-2",
                                                ),
                                            ]
                                        ),
                                    ],
                                    width=8,
                                ),
                            ]
                        ),
                    ]
                )
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    [
                                        html.Span("Holdings - ", className="fw-bold"),
                                        html.Span(
                                            f"{len(initial_positions)} positions",
                                            className="text-muted",
                                        ),
                                    ],
                                    className="d-flex justify-content-between",
                                ),
                                dbc.CardBody(
                                    [
                                        html.Div(
                                            id="holdings-table-container",
                                            children=[create_table(initial_positions)],
                                            style={
                                                "maxHeight": "500px",
                                                "overflowY": "auto",
                                            },
                                        )
                                    ]
                                ),
                            ]
                        ),
                    ],
                    width=12,
                ),
            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    "Sector / ISIN Heatmap", className="fw-bold"
                                ),
                                dbc.CardBody([create_heatmap(initial_positions)]),
                            ]
                        ),
                    ],
                    width=6,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader("Summary", className="fw-bold"),
                                dbc.CardBody(
                                    [
                                        dbc.Row(
                                            [
                                                dbc.Col(
                                                    [
                                                        html.Div(
                                                            [
                                                                html.Div(
                                                                    "Market Value",
                                                                    className="small text-muted",
                                                                ),
                                                                html.H5(
                                                                    format_currency(
                                                                        initial_total_mv
                                                                    ),
                                                                    className="mb-0 text-primary",
                                                                ),
                                                            ]
                                                        )
                                                    ],
                                                    width=3,
                                                ),
                                                dbc.Col(
                                                    [
                                                        html.Div(
                                                            [
                                                                html.Div(
                                                                    "Unrealized P&L",
                                                                    className="small text-muted",
                                                                ),
                                                                html.H5(
                                                                    format_currency(
                                                                        initial_total_pnl
                                                                    ),
                                                                    className=f"mb-0 {initial_pnl_color}",
                                                                ),
                                                            ]
                                                        )
                                                    ],
                                                    width=3,
                                                ),
                                                dbc.Col(
                                                    [
                                                        html.Div(
                                                            [
                                                                html.Div(
                                                                    "Winning",
                                                                    className="small text-muted",
                                                                ),
                                                                html.H5(
                                                                    f"{initial_winners}",
                                                                    className="mb-0 text-success",
                                                                ),
                                                            ]
                                                        )
                                                    ],
                                                    width=3,
                                                ),
                                                dbc.Col(
                                                    [
                                                        html.Div(
                                                            [
                                                                html.Div(
                                                                    "Losing",
                                                                    className="small text-muted",
                                                                ),
                                                                html.H5(
                                                                    f"{initial_losers}",
                                                                    className="mb-0 text-danger",
                                                                ),
                                                            ]
                                                        )
                                                    ],
                                                    width=3,
                                                ),
                                            ]
                                        ),
                                    ]
                                ),
                            ]
                        ),
                    ],
                    width=6,
                ),
            ]
        ),
    ]
)


@callback(
    [
        Output("holdings-table-container", "children"),
        Output("portfolio-selector", "value"),
    ],
    [Input("portfolio-selector", "value")],
)
def update_table(portfolio_id):
    portfolio = next(
        (p for p in data["portfolios"] if p["id"] == portfolio_id),
        data["portfolios"][0],
    )
    positions = sorted(portfolio["positions"], key=lambda x: x["weight"], reverse=True)
    return create_table(positions), portfolio_id
