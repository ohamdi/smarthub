# SmartPMS — Documentation technique

> SmartPMS (Portfolio Management System) : application web de gestion de portefeuilles financiers (fonds, actions, obligations, cash, ESG).

- **Stack** : Python 3 + Flask + Pandas (backend), HTML/CSS/JS monofichier + Bootstrap 5 + Chart.js (frontend)
- **Stockage** : fichiers **Parquet** (pas de base de données)
- **Langue du code** : en anglais, mais commentaires/UI en anglais ; la doc est en français

---

## 1. Analyse de l'application

### 1.1 Architecture globale

```
Smart-pms/
├── app.py                    # Backend Flask (API + rendu de l'index)
├── datasource_config.json    # Chemins des fichiers Parquet (configurable)
├── portfolios.parquet        # Source de données : fonds
├── holdings.parquet          # Source de données : positions
├── esg.parquet               # Source de données : scores ESG
├── operations.parquet        # Source de données : opérations (achats/ventes)
├── inventories.parquet       # Source de données : inventaires physiques
├── cash.parquet              # Source de données : liquidités
├── constraints.parquet       # Source de données : contraintes pre-trade
├── static/
│   └── index.html            # TOUT le frontend (HTML + CSS + JS)
└── app.log                   # Logs (généré au lancement)
```

**Modèle d'exécution** :
1. Le navigateur charge `index.html` (route `GET /`).
2. Le frontend appelle des endpoints JSON (`/api/*`) via `fetch` (cookie de session).
3. Flask lit les fichiers Parquet avec Pandas, transforme en JSON (`df_to_json`).
4. Les écritures (création/suppression de fonds) réécrivent le Parquet.

### 1.2 Fonctionnalités

| Onglet | Fonctionnalité | État |
|---|---|---|
| Dashboard | KPIs globaux (AuM, P&L, positions, ESG), cartes de portefeuilles, vue manager | ✅ fonctionnel |
| Global Position | Table/vue arborescente des positions (toutes catégories), filtres, graphiques | ✅ fonctionnel |
| EquityView | Idem mais filtré `category == 'action'` | ✅ fonctionnel |
| BondView | Idem mais filtré `category == 'obligation'` (+ rating, maturité) | ✅ fonctionnel |
| Cash Management | Positions cash (table + graphiques) et flux de trésorerie calculés depuis `operations` | ✅ fonctionnel |
| Operations | Journal des opérations (filtres fond/date, tri) | ✅ fonctionnel |
| Pre-Trade | Contraintes de poids par position/catégorie/secteur/émetteur/pays/devise/ISIN (+ liste d'ISIN), ESG, cash ; contrôle pre-trade visible aussi dans Global Position | ✅ fonctionnel |
| Pending Order | Module prévu | ⛔ « coming soon » |
| Analysis (Advanced) | Vue d'ensemble avec KPIs calculés | ⚠️ partiel (performance/risque : « coming soon ») |
| AI Model | Calcul de scores « IA » **simulés (aléatoires)** | ⚠️ simulé, pas de vraie IA |
| Benchmark | Gestion de benchmarks | ⛔ « coming soon » |
| Reporting | Génération de rapport HTML (aperçu, export PDF/HTML) | ✅ fonctionnel |
| Data Source | Configuration des chemins des fichiers Parquet | ✅ fonctionnel |

### 1.3 Backend — endpoints API (`app.py`)

| Méthode | Route | Rôle | Auth |
|---|---|---|---|
| POST | `/api/login` | Authentification (créé la session) | non |
| POST | `/api/logout` | Vide la session | non |
| GET | `/api/me` | Infos de l'utilisateur connecté | oui |
| GET | `/api/portfolio` | Liste des fonds | oui |
| POST | `/api/portfolio` | Créer un fonds | oui |
| DELETE | `/api/portfolio/<id>` | Supprimer un fonds | oui |
| GET | `/api/holdings?fund_id=` | Positions (filtre par fond) | oui |
| GET | `/api/esg` | Données ESG | oui |
| GET | `/api/operations?fund_id=&from=&to=` | Opérations (filtres) | oui |
| GET | `/api/inventories` | Inventaires | oui |
| GET | `/api/cash` | Cash | oui |
| GET | `/api/constraints` | Liste des contraintes pre-trade | oui |
| POST | `/api/constraints` | Créer une contrainte | oui |
| PUT | `/api/constraints/<id>` | Mettre à jour (ex. activer/désactiver) | oui |
| DELETE | `/api/constraints/<id>` | Supprimer une contrainte | oui |
| GET | `/api/constraints/check?fund_id=` | Évalue les contraintes actives vs positions+cash | oui |
| GET | `/api/portfolio/export` | Export CSV des fonds | oui |
| GET | `/api/dashboard` | KPIs agrégés (AuM, P&L, ESG, etc.) | oui |
| GET | `/api/sectors` | Liste des secteurs (constante) | oui |
| GET | `/api/countries` | Liste des pays (constante) | oui |
| GET/POST | `/api/clients` | Clients (liste **en mémoire**, non persistée) | oui |
| GET/POST | `/api/config/benchmarks` | Benchmarks (**en mémoire**, non persistés) | oui |
| GET | `/api/report` | Données de reporting | oui |
| GET/POST | `/api/config/datasource` | Lire/écrire `datasource_config.json` | **non** ⚠️ |
| GET | `/` | `index.html` | non |
| GET | `/<path>` | Fichiers statiques | non |

> ⚠️ **Endpoints non branchés sur l'UI** : `/api/portfolio/export`, `/api/clients` et `/api/config/benchmarks` existent côté serveur mais ne sont **jamais appelés** par le frontend (laissés pour une utilisation API directe).

> ⚠️ **Sécurité** : la route `/api/config/datasource` n'est **pas** protégée par `login_required`.

### 1.4 Frontend (`static/index.html`)

Tout est dans un seul fichier : `state` global (ligne 458), helper `api()` (ligne 471), helper `fmt()`/`esc()`, fonctions `loadXxx()` par onglet.

Points clés à connaître avant de modifier :
- `state` contient toutes les données chargées : `portfolios`, `positions`, `equity`, `bonds`, `cash`, `operations`, `esgData`, `inventories`, `sectors`, `countries`.
- Les vues positions (Global/Equity/Bond) sont pilotées par **3 contextes** (`POS_CTX`, `EQUITY_CTX`, `BOND_CTX` — lignes 880-942) qui définissent colonnes, graphiques, filtres, regroupements.
- Les colonnes affichées viennent de `POS_COL_DEFS` / `BOND_COL_DEFS` (lignes 813-844) et les formats de cellule de `POS_CELL_FMT` / `BOND_CELL_FMT` (lignes 845-857).

---

## 2. Sources de données — champs par source

La liste complète des champs, **telle que lue par l'application** (dtypes PyArrow/Parquet réels).

### 2.1 `portfolios.parquet` — Fonds
Fichier de référence des fonds/portefeuilles. **Écrit par** l'API `POST /api/portfolio`.

| Champ | Type | Description | Utilisé par |
|---|---|---|---|
| `id` | str | Identifiant du fond (ex. `F001`) — référence croisée `fund_id` partout | dashboard, filtres |
| `fund_code` | str | Code du fond | UI fonds |
| `fund_name` | str | Nom du fond | affichage partout (`name`) |
| `fund_currency` | str | Devise du fond (`EUR`, `USD`…) | création de fond |
| `fund_manager` | str | Gérant | Dashboard (vue manager), export CSV |
| `custodian` | str | Dépositaire | export CSV |
| `entity` | str | Entité (`Fund`, `SMA`…) | export CSV |
| `classification` | str | Classification → devient `type` du dashboard | dashboard |
| `created_at` | str (ISO) | Date de création | export CSV |

### 2.2 `holdings.parquet` — Positions
Le cœur de l'app. **Lecture seule** (les écritures se font via `POST /api/portfolio` uniquement pour les fonds).

| Champ | Type | Description | Utilisé par |
|---|---|---|---|
| `id` | str | Identifiant position (ex. `pos_ec78bec8`, `bond_001`) | interne |
| `fund_id` | str | **Référence croisée** → `portfolios.id` | filtres fonds |
| `isin` | str | ISIN du titre | table positions |
| `ticker` | str | Symbole (ex. `AAPL`) — **référence croisée** → `esg.ticker` | tables, graphiques, AI Model |
| `name` | str | Nom du titre | tables |
| `quantity` | int | Quantité | tables |
| `price` | float | Prix unitaire | tables |
| `market_value` | float | Valeur marchande (= quantité × prix) | AuM, sous-totaux, KPIs |
| `weight` | float | Poids (%) | graphiques allocation |
| `total_pnl` | float | P&L | KPIs, rapports |
| `currency` | str | Devise | tables |
| `sector` | str | Secteur | filtres, graphiques |
| `country` | str | Pays | filtres, graphiques |
| `esg_score` | float | Score ESG (ou renseigné depuis `esg.parquet`) | dashboard, tables |
| `category` | str (optionnel) | **`action`** ou **`obligation`** (vérifié en minuscule) — détermine EquityView vs BondView. **Si absente**, déduite automatiquement (champs obligataires / motif coupon+échéance dans le nom) | vues, filtres |
| `maturity_date` | str (YYYY-MM-DD) | Échéance (obligations) | BondView, bucket de maturité |
| `rating` | str | Rating (ex. `A`, `BBB`) | BondView |
| `coupon` | float | Coupon (%) | BondView |
| `yield` | float | Rendement (%) | **non utilisé** dans le frontend |

### 2.3 `esg.parquet` — Scores ESG
Enrichit les positions par `ticker` (dans le frontend, ligne 963-970).

| Champ | Type | Description | Utilisé par |
|---|---|---|---|
| `ticker` | str | **Référence croisée** → `holdings.ticker` | jointure ESG |
| `isin` | str | ISIN | — |
| `name` | str | Nom | — |
| `esg_score` | float | Score global (ex. 30.0) | positions (`??` : seulement si position vide) |
| `environmental` | float | Pilier E | enrichit la position |
| `social` | float | Pilier S | enrichit la position |
| `governance` | float | Pilier G | enrichit la position |
| `rating` | str | Rating ESG → devient `esg_rating` | enrichit la position |

> Les champs `environmental`, `social`, `governance`, `rating` sont enrichis dans le frontend mais **non affichés** dans les colonnes actuelles.

### 2.4 `operations.parquet` — Opérations
Journal des trades. Alimente aussi les **flux de trésorerie** du Cash Management (ligne 1466).

| Champ | Type | Description | Utilisé par |
|---|---|---|---|
| `id` | str | Identifiant opération | interne |
| `fund_id` | str | → `portfolios.id` | filtres |
| `date` | str | Date (filtres `from`/`to` par comparaison de chaînes) | filtres, tri, flux |
| `type` | str | `BUY`, `SELL`, `DIV`, `FEE`, `TAX`, `SUB`, `RED`, `COMMISSION`, `REBATE` | badge + **signe du flux** (table `SIGN`) |
| `ticker` | str | Symbole | table |
| `isin` | str | ISIN | table |
| `name` | str | Nom | table, flux |
| `quantity` | float | Quantité | table, calcul flux |
| `price` | float | Prix | table, calcul flux |
| `amount` | float | Montant | table, **flux** |
| `status` | str | `EXECUTED`, `PENDING`, autre | couleur |
| `trade_date` | str | Date de négoce | table |
| `value_date` | str | Date de valeur | table |

**Logique des flux cash** (frontend ligne 1466) :
`SIGN = {BUY:-1, SELL:1, DIV:1, FEE:-1, TAX:-1, SUB:1, RED:-1, COMMISSION:-1, REBATE:1}` ; flux = `amount × SIGN[type]`. Les types absents de `SIGN` produisent un flux nul (exclus).

### 2.5 `inventories.parquet` — Inventaires
Chargés dans `state.inventories` mais **très peu affichés** actuellement.

| Champ | Type | Description | Utilisé par |
|---|---|---|---|
| `fund_ticker` | str | Ticker du fond (ex. `IGLN.L`) | chargé |
| `fund_isin` | str | ISIN du fond | chargé |
| `ticker` | str | Position d'inventaire (`GOLD-LON`, `SWAP-CASH`…) | chargé |
| `name` | str | Nom | chargé |
| `isin` | str | ISIN | chargé |
| `quantity` | float | Quantité | chargé |
| `price` | float | Prix | chargé |
| `weight` | float | Poids | chargé |
| `sector` | str | Secteur | chargé |
| `country` | str | Pays | chargé |

### 2.6 `cash.parquet` — Liquidités

| Champ | Type | Description | Utilisé par |
|---|---|---|---|
| `id` | str | Identifiant (ex. `cash_001`) | interne |
| `fund_id` | str | → `portfolios.id` | filtre fond, table |
| `currency` | str | Devise (`EUR`, `USD`…) | filtre devise, graphique, groupement |
| `balance` | float | Solde brut | table, graphiques, sous-totaux |
| `blocked` | float | Bloqué | table, sous-totaux |
| `updated_at` | str | Date de mise à jour | table |
| `available` | float | Disponible (si absent → calculé `balance - blocked`) | table |

### 2.7 `constraints.parquet` — Contraintes pre-trade
Fichier **écrit par** l'API (`POST`/`PUT`/`DELETE /api/constraints`). Évalué par `/api/constraints/check` (voir § 6).

| Champ | Type | Description | Utilisé par |
|---|---|---|---|
| `id` | str | Identifiant (ex. `ct_pos_w`) | CRUD, résultats |
| `name` | str | Nom affiché de la contrainte | table Pre-Trade, résultats |
| `type` | str | Type (voir tableau ci-dessous) | moteur d'évaluation |
| `operator` | str | `<=`, `>=`, `<`, `>`, `==` | comparaison |
| `value` | float | Seuil de la limite | comparaison |
| `param` | str | Cible (voir tableau) : valeur de la dimension, ISIN ou liste d'ISIN ; vide = toutes les valeurs | filtrage de l'évaluation |
| `scope` | str | `all` (seul périmètre actif) | — |
| `enabled` | bool | Contrainte active ou non | `/api/constraints/check` |

**Types supportés par le moteur d'évaluation :**

| Type | Description | Évaluation | `param` |
|---|---|---|---|
| `max_position_weight` / `min_position_weight` | Poids max/min par position (%) | par ligne : `weight` vs limite | ignoré |
| `max_category_weight` / `min_category_weight` | Poids max/min par catégorie (%) | somme des `weight` groupés par `category` | catégorie cible ou vide |
| `max_sector_weight` / `min_sector_weight` | Poids max/min par secteur (%) | somme des `weight` groupés par `sector` | secteur cible ou vide |
| `max_country_weight` / `min_country_weight` | Poids max/min par pays (%) | somme des `weight` groupés par `country` | pays cible ou vide |
| `max_issuer_weight` / `min_issuer_weight` | Poids max/min par émetteur (%) | somme des `weight` groupés par émetteur (`derive_issuer`) | émetteur cible ou vide |
| `max_currency_weight` / `min_currency_weight` | Poids max/min par devise (%) | somme des `weight` groupés par `currency` | devise cible ou vide |
| `max_isin_weight` / `min_isin_weight` | Poids max/min d'un ISIN (%) | somme des `weight` des lignes dont `isin == param` | **ISIN obligatoire** |
| `max_isin_list_weight` / `min_isin_list_weight` | Poids max/min d'une liste d'ISIN (%) | somme des `weight` des lignes dont `isin ∈ param` | **liste d'ISIN** (séparés par `,` `;` espaces) |
| `min_esg_score` | Score ESG minimum | par ligne : `esg_score` | ignoré |
| `min_cash_pct` | Cash minimum (% AuM) | `cash disponible / total_aum × 100` | ignoré |
| `max_cash_pct` | Cash maximum (% AuM) | idem | ignoré |

> Pour les types groupés (`category`, `sector`, `country`, `issuer`, `currency`), `param` vide (ou `*`, `all`, `tous`) → la contrainte s'applique à **toutes** les valeurs de la dimension ; sinon uniquement à la valeur cible. Les valeurs acceptées comme spéciales : `*`, `all`, `tous`, `toutes`.
> Le cash disponible = somme des `available` (ou `balance - blocked`). `total_aum` = somme des `market_value` des holdings (filtrés par `fund_id` si fourni).
> L'émetteur est dérivé comme dans le frontend (`derive_issuer`) : pour les obligations, le nom est nettoyé de la mention coupon/échéance en fin de chaîne.

**Structure de la réponse de `/api/constraints/check`** (par contrainte) :
`{ id, name, type, operator, value, current, status ("OK"|"VIOLATION"|"NO_DATA"), violations: [{ticker, name, detail}] }` + agrégats `{ total_aum, cash_available, constraints_total, violation_count }`.
> `current` pour une contrainte **min** = pire groupe (valeur min) ; pour une **max** = pire groupe (valeur max). Pour les types ISIN = poids agrégé des lignes ciblées. `violations` contient `ticker`+`name` pour les types par position/ISIN/ESG (→ surlignage Global Position) et uniquement `detail` pour les types groupés.

### 2.8 `static/prices.json` — Prix de marché
**Supprimé** — fichier non utilisé (le code qui le chargeait, `PRICES`, et la route stub `/api/portfolio/prices` ont été retirés). Si besoin de prix de marché, l'ancienne structure était : `{"AAPL": {"price": 220.50, "chg": 3.55, "chg_pct": 1.63, "day": 1.63, "week": -2.1, "ytd": 18.5, "m1": 5.2, "m3": 8.1}, ...}`

### 2.9 `datasource_config.json` — Configuration des chemins

| Clé | Valeur par défaut | Description |
|---|---|---|
| `portfolios_path` | `portfolios.parquet` | Fichier des fonds |
| `holdings_path` | `holdings.parquet` | Fichier des positions |
| `esg_path` | `esg.parquet` | Fichier ESG |
| `operations_path` | `operations.parquet` | Fichier des opérations |
| `inventories_path` | `inventories.parquet` | Fichier des inventaires |
| `cash_path` | *(absent par défaut)* | Fichier cash (retombe sur défaut si absent) |
| `constraints_path` | `constraints.parquet` | Fichier des contraintes pre-trade |

Résolution des chemins : relatif au dossier de l'app (`get_parquet_path`, app.py ligne 19) ou absolu. ⚠️ Les chemins sont lus **au démarrage** — un changement de config exige un redémarrage du serveur.

### 2.10 Constantes hardcodées dans `app.py`

| Constante | Contenu |
|---|---|
| `USERS` | `admin/admin123` (admin), `hamdi/hamdi123` (user, client_id `client_hamdi`) |
| `CLIENTS` | liste en dur (ajouts via POST non persistés) |
| `SECTORS` | 17 secteurs (français) |
| `COUNTRIES` | `CH, CN, DE, FR, IE, IT, NL, TW, UK, US` |
| `BENCHMARKS` | Euro Stoxx 50 (**non persisté**, non appelé par l'UI) |

---

## 3. Flux de données & références croisées

```
portfolios.parquet  ◄─── fund_id ───►  holdings.parquet
                                      holdings.parquet
                                        ▲
esg.parquet ──────── ticker ───────────┘  (jointure faite dans le FRONTEND)
cash.parquet ─────── fund_id ──► portfolios  (affichage nom du fond)
operations.parquet ─ fund_id ──► portfolios ; alimente les flux cash
```

- La jointure **ESG ↔ positions** se fait dans le **frontend** (`esgMap` par `ticker`), pas dans le backend.
- Les **noms de fonds** sont résolus dans le frontend via `fundMap[id] = fund_name || fund_code`.
- `category` (si présente) route une position vers EquityView (`action`) ou BondView (`obligation`) — toute autre valeur apparaît dans Global Position uniquement.
- **Si la colonne `category` est absente** (ou vide), la classe d'actif est **déduite automatiquement** : une ligne est une obligation si elle possède au moins un champ obligataire (`maturity_date`, `maturity`, `rating`, `coupon`, `yield`, `bond_rating`, `bond_maturity`) ou si son nom correspond au motif coupon+échéance (ex. `UST 2.5 05/30`) ; sinon elle est traitée en `Action`. Les colonnes `asset_class`, `instrument_type`, `security_type`, `type`… sont aussi reconnues comme équivalentes.

---

## 4. Guide de modification / ajout

### 4.1 Lancer l'application
```bash
cd ~/Documents/Smart-pms
pip install flask pandas pyarrow     # dépendances
python app.py                        # http://0.0.0.0:5000
```
Comptes : `admin/admin123` ou `hamdi/hamdi123`.

### 4.2 Ajouter une donnée (sans code)
1. **Modifier un Parquet** : ouvrir avec pandas (`pd.read_parquet(...)`), modifier, réécrire avec `df.to_parquet(path, index=False)`. Veiller à conserver les colonnes et types attendus.
2. **Changer la source d'un fichier** : onglet **Data Source** (ou éditer `datasource_config.json`) puis **redémarrer le serveur**.
3. **Ajouter un fonds** : onglet Dashboard → bouton « Create » (ou POST `/api/portfolio`). Les positions correspondantes doivent exister dans `holdings.parquet` avec le même `fund_id`.

### 4.3 Ajouter une colonne affichée dans une table
Dans `static/index.html` :
1. Ajouter le champ dans le Parquet correspondant.
2. Ajouter l'entrée dans `POS_COL_DEFS` et/ou `BOND_COL_DEFS` (lignes 813-844) : `{key: 'mon_champ', label: 'Mon Champ'}`.
3. (Optionnel) Ajouter un format dans `POS_CELL_FMT` / `BOND_CELL_FMT` (lignes 845-857), ex. `mon_champ: v => v != null ? v.toFixed(2)+'%' : '--'`.

### 4.4 Ajouter un champ dans le dashboard d'un fond
- Au backend : dans `api_dashboard()` (app.py ligne 224), enrichir chaque `p` (ex. `p['mon_metric'] = ...`).
- Au frontend : l'afficher dans `renderPortfolioCards()` (ligne 716).

### 4.5 Ajouter un filtre (ex. un nouveau critère dans Global Position)
1. Ajouter un `<select>` dans le HTML (ou réutiliser la mécanique existante).
2. Dans le `ctx` correspondant (`POS_CTX` etc.), ajouter `{ sel: 'monFilter', key: 'ma_cle' }` dans la liste `filters`.
3. La mécanique de rendu (`renderPositionSubTab`) applique les filtres automatiquement si la clé existe dans les données.

### 4.6 Ajouter un graphique
Dans le `ctx` : ajouter `{ canvas: 'idCanvas', title: 'Titre', key: 'ma_cle', valueKey: 'weight' }` dans `charts`, et ajouter le `<canvas>` dans le HTML de l'onglet. La boucle de rendu crée le graphique Chart.js tout seul.

### 4.7 Ajouter un onglet / une vue entière
1. **Backend** : créer une route `/api/ma_nouvelle_source` (copier le pattern de `api_cash`) + un fichier Parquet + l'entrée dans `datasource_config.json`.
2. **Frontend** :
   - Ajouter le bouton d'onglet dans `<ul id="mainTabs">` (ligne 187) : `<li class="nav-item"><button class="nav-link" data-tab="mononglet">Mon Onglet</button></li>`.
   - Ajouter le `<div class="tab-pane" id="tab-mononglet">…</div>` dans `#tabContent`.
   - Ajouter la branche `else if (tab === 'mononglet') loadMonOnglet();` dans `switchToTab` (ligne ~558).
   - Implémenter `async function loadMonOnglet()` (pattern : `loadCash`, ligne 1393) puis `render...()`.

### 4.8 Ajouter un endpoint API
```python
@app.route('/api/exemple')
@login_required
def api_exemple():
    df = pd.read_parquet(MA_SOURCE_PATH)
    return jsonify(df_to_json(df))
```
Le frontend l'appelle via `await api('GET','/api/exemple')`.

### 4.9 Modifier l'authentification / les utilisateurs
Éditer `USERS` dans `app.py` (ligne 38). ⚠️ Mots de passe **en clair** dans le code ; `secret_key` régénérée à chaque démarrage → les sessions expirent au redémarrage.

### 4.10 Remplacer le module « AI Model » simulé
`computeAIScores()` (ligne 1633) génère des scores **aléatoires**. Pour brancher une vraie IA :
1. Créer un endpoint backend qui reçoit les positions (`state.positions`) et renvoie des scores (ex. via llama.cpp/ollama sur la machine, cf. ton contexte eGPU).
2. Remplacer le corps de `computeAIScores()` par `const res = await api('POST','/api/ai/score', {positions: data})` et remplir les cellules à partir de `res`.

### 4.11 Ajouter un nouveau type de contrainte pre-trade
1. **Backend** : ajouter une entrée dans `CONSTRAINT_LABELS` (app.py), dans `GROUP_DIMENSIONS` ou `ISIN_TYPES` si pertinent, et un bloc d'évaluation dans `check_constraints()` (copier le pattern « par position », « groupé » ou « ISIN »).
2. **Frontend** : ajouter l'option dans le `<select id="ctDim">` (onglet Pre-Trade), une entrée dans `CONSTRAINT_LABELS` (JS) et, si cible obligatoire, un cas dans `CONSTRAINT_DIM_SUFFIX`/`CT_DIM_META`.
3. Les violations remontent automatiquement dans l'onglet Pre-Trade et le Global Position (bandeau + lignes surlignées).

---

## 5. Limites & points d'attention

- **Pas de base de données** : les Parquet sont lus/surécrits en entier à chaque appel → pas adapté à la concurrence/volumétrie.
- **Pas de persistance** : `CLIENTS`, `BENCHMARKS`, sessions sont en mémoire (perdus au redémarrage).
- **Sécurité** : mots de passe en clair, `secret_key` aléatoire à chaque boot, `/api/config/datasource` non protégé, aucun rate-limiting/CORS. ⚠️ À durcir avant toute mise en production.
- **Code mort retiré** : `PRICES` (chargement), `CURRENCY_RATES`, la route `/api/portfolio/prices`, `state.prices`/`state.clients` (frontend), la fonction `renderBenchmarks()` et le fichier `static/prices.json` ont été supprimés.
- **Champ `yield`** : toujours présent dans `holdings.parquet` mais non affiché (conservé comme donnée).
- **Endpoints non branchés sur l'UI** : `/api/portfolio/export`, `/api/clients`, `/api/config/benchmarks` (API utilisables directement, sans écran dédié).
- **Placeholders UI** : onglets Pending Order, Benchmark, Analysis (perf/risque) sont des stubs « coming soon ».
- **Enrichissement ESG** : la jointure par `ticker` est fragile si les tickers diffèrent entre `holdings` et `esg`.
- **Pre-Trade** : le contrôle évalue les positions **courantes** (pas de simulation de trade) ; le périmètre n'accepte que `all` ; les contraintes `NO_DATA` (champ/cible absent des données) sont ignorées pour le comptage des violations ; les violations groupées (secteur, pays…) ne surlignent pas de ligne en Global Position (pas de ticker).

---

## 6. Module Pre-Trade (détails frontend)

### 6.1 Onglet Pre-Trade
- **Configuration** : liste des contraintes (`#ctTable`), formulaire d'ajout basé sur une **dimension** (`#ctDim` : position, catégorie, secteur, émetteur, pays, devise, ISIN, liste d'ISIN, ESG, cash) + **cible optionnelle** (`#ctTarget`, datalist alimenté par les valeurs présentes dans les holdings) + limite/opérateur/périmètre/activée.
  - Opérateur `<=` → type `max_*` ; `>=` → type `min_*` (le type est dérivé automatiquement). ESG force `min_esg_score`/`>=` ; cash → `max_cash_pct` ou `min_cash_pct`.
  - Pour ISIN et liste d'ISIN, la cible est **obligatoire**. Boutons ⏻ (activer/désactiver) et 🗑 (supprimer).
- **Contrôle** : bouton « Lancer le contrôle pre-trade » → `GET /api/constraints/check` (avec `fund_id` du sélecteur de fonds si renseigné) → rendu dans `#ctResults` (bandeau + tableau statut/détails).
- Fonctions : `loadConstraints()`, `populateConstraintTargets()`, `updateConstraintTargetRow()`, `renderConstraints()`, `addConstraint()`, `toggleConstraint()`, `deleteConstraint()`, `runConstraintCheck()`, `renderConstraintResults()`.

### 6.2 Intégration dans Global Position
- `loadPositionsView()` appelle `/api/constraints/check` en parallèle et stocke le résultat dans `state.checks`.
- `renderPositionsTable()` (vue `pos` uniquement) affiche un **bandeau** (nb de violations, AuM, cash dispo) au-dessus des graphiques.
- Les lignes dont le `ticker` figure dans une violation reçoivent la classe `ct-vio` (fond rouge) + icône ⚠ + tooltip listant les contraintes violées (`constraintViolationMap()`).
- ⚠ Le check de Global Position suit le **filtre de fonds** sélectionné (`fund_id`).
